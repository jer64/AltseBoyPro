#!/bin/bash
cd /home/vai/sdb/crontab
#
PATH=$PATH:/home/vai/sdb/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

#
chmod a+rw /home/vai/sdb/html/cgi/cache/rss/*

#
wget http://www.cnbc.com/id/19789731/device/rss/rss.xml -O /home/vai/sdb/html/cgi/cache/rss/cnbc.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc.list

#
wget http://www.cnbc.com/id/44890461/device/rss/rss.xml -O /home/vai/sdb/html/cgi/cache/rss/cnbc_small_business.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_small_business.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_small_business.list

#
wget http://www.cnbc.com/id/20040302/rssCmp/97085/device/rss/rss.html -O /home/vai/sdb/html/cgi/cache/rss/cnbc_banks.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_banks.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_banks.list

#
wget http://www.cnbc.com/id/20040302/rssCmp/97084/device/rss/rss.html -O /home/vai/sdb/html/cgi/cache/rss/cnbc_bankruptcy.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_bankruptcy.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_bankruptcy.list

#
wget http://www.cnbc.com/id/20040302/rssCmp/97242/device/rss/rss.html -O /home/vai/sdb/html/cgi/cache/rss/cnbc_federal_reserve.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_federal_reserve.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_federal_reserve.list

#
wget http://www.cnbc.com/id/20040302/rssCmp/97097/device/rss/rss.html -O /home/vai/sdb/html/cgi/cache/rss/cnbc_interest_rates.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_interest_rates.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_interest_rates.list

#
wget http://www.cnbc.com/id/20040302/rssCmp/97123/device/rss/rss.html -O /home/vai/sdb/html/cgi/cache/rss/cnbc_oil_and_gas.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/cnbc_oil_and_gas.rss > /home/vai/sdb/html/cgi/cache/rss/cnbc_oil_and_gas.list

#
wget "http://www.kultakaivos.info/rss.pl?sec=kaivos&title=Kultakaivos.info&base=http://www.kultakaivos.info" \
 -O /home/vai/sdb/html/cgi/cache/rss/kultakaivos.rss
rss2txt.pl /home/vai/sdb/html/cgi/cache/rss/kultakaivos.rss > /home/vai/sdb/html/cgi/cache/rss/kultakaivos.list

#
~/sdb/crontab/update_news_db.sh

