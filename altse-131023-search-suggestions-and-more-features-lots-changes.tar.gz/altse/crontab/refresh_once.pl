#!/usr/bin/perl
# OBSOLETE, USE CRONTAB
for($i=0; $i<10;)
{
	#chdir("/home/vai/altse/crontab/crawl_slow_news.sh");
	print STDERR "[Refreshing now]         Crawling news ...\n";
	system("nice -n 20 /home/vai/altse/crontab/crawl_slow_news.sh");
	#print STDERR "[Refreshing now}         Updating news database ...\n";
	#system("nice -n 20 /home/vai/altse/crontab/update_news_db.sh");
	#print STDERR "[Refreshing finished]    Next round up in 30 minutes ...\n";
	sleep(60*10);
}
