#!/usr/bin/perl

#
use POSIX;
use POSIX qw(strftime);
use Encode;
use DateTime;

#
require "./modules/AltseOpenConfig.pm";
require "./modules/settings.pm";
require "./modules/Logging.pm";
require "./modules/FixScands.pm";
#
AltseOpenConfig();
#
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

#####################################################################################
#
sub EnvList
{
	foreach $key (sort(keys %ENV))
	{	
		print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
	}
}

#####################################################################################
#
sub main
{
	#
	EnvList();
}
