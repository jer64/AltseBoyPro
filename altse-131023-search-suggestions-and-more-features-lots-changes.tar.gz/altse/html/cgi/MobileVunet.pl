#!/usr/bin/perl
######################################################################################
#
# MobileVunet.pl - Mobile Vunet
#
######################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/JsHeadLines.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NaytaUutisotsikot.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewHL.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewXML.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/AnyComments.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewMainArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticleLib.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticle.pm";

# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

##################################################
#
sub HtmlBeg
{
	#
        print("
<HTML>

<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\"
        href=\"http://www.altse.vunet.world/images/altse.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

<link rel=\"STYLESHEET\" type=\"text/css\" href=\"http://www.vunet.world/images/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"http://www.vunet.world/images/search.ico\">
<meta name=\"Generator\" content=\"Vunet Information System (www.vunet.world)\">

<meta http-equiv=\"expires\" content=\"0\">
<meta http-equiv=\"content-type\" content=\"text/html; charset=iso-8859-1\">
<meta http-equiv=\"Content-Language\" content=\"fi\">
<meta name=\"robots\" content=\"All\">


<TITLE>Vunet.org - mobiiliversio - uutisi ajatteleville massoille</TITLE>
<META HTTP-EQUIV=\"Content-Language\" CONTENT=\"fi\">
<META name=\"description\" content=\"Mobiiliversio. Ajankohtainen uutisportaali.\">
<META name=\"keywords\" content=\"uutiset, vaihtoehtouutiset, kulta, hopea, pronssi, dollari, juani, euro\">
<META name=\"revisit-after\" content=\"1 days\">
<META name=\"owner\" content=\"jari@vunet.world\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">

</HEAD>

<BODY>

                ");

	#
}

##################################################
#
sub HtmlEnd
{
	#
        print("
</BODY>
</HTML>
	");
}

##################################################
#
sub AjuriHaku
{
	#
	print("
<TABLE width=240 cellspacing=0 cellpadding=0
	bgcolor=\"#00FFFF\">
<TR>
<TD>
");


	#
	
	

	#
	print("
</TD>
</TR>
</TABLE>
");
}

##################################################
#
sub main
{
	#
	HtmlBeg();
	AjuriHaku();
	HtmlEnd();
}

