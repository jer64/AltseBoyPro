#!/usr/bin/perl
################################################################################
#
# rss.pl - RSS News Feed.
# (C) 2006-2008 by Jari Tuominen (jari@vunet.world).
#
################################################################################
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/RSSDump.pm";
use POSIX;
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
###print "Content-type: text/xml\n\n";
print "Content-type: application/xhtml+xml\n\n";
$DONT_AFFECT_DB = 1;

ArgLineParse();

if($so{'base'} eq "") {
	$BASEURL = "http://www.vunet.world";
} else {
	$BASEURL = $so{'base'};
}

if($so{'c'} eq "") { $so{'c'} = "25"; }

main();

#############################################################################
#
sub main
{
	#
	RSSDump($so{'sec'});
}
