<html>
<body>
<?php phpinfo();?>

<?php
$myvar = "Hello World";
echo $myvar;
?>
</body>
</html>



