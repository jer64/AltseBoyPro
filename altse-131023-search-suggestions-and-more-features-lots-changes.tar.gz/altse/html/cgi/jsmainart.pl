#!/usr/bin/perl
#
# jsticker.pl
# Implements ifticker.pl (iframe).
#
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	if($so{'theme'} eq "")
	{
		$BGC1 = "#8080FF";
	}
	if($so{'theme'} eq "red")
	{
		$BGC1 = "#FF8080";
	}

	#
	$uni = sprintf "%d", rand(1000000);

	#
	$ONCLICK = "Javascript:jsreload$uni();";

	#
	$str3 = ("
<TABLE width=274 cellspacing=0 cellpadding=0
	class=simple_window>
<TR valign=top>

<SCRIPT language=\"Javascript\">

var hold=0;

function jsreload$uni()
{
	j = document.getElementById('mainart$uni');
	j.src = 'http://www.vunet.world/ifmainart.pl?s=$so{'s'}&theme=$so{'theme'}';
}

function janna$uni(what)
{
	j = document.getElementById('mainart$uni');
	j.className=what;
}

function timerjob$uni()
{
	if( !hold )
	{
		setTimeout(\"TimeToChange$uni()\", 10000);
		setTimeout(\"janna$uni('opac0');\", 9900);
		setTimeout(\"janna$uni('opac25');\", 9800);
		setTimeout(\"janna$uni('opac50');\", 9700);
		setTimeout(\"janna$uni('opac75');\", 9600);
	}

	setTimeout(\"janna$uni('opac100');\", 500);
	setTimeout(\"janna$uni('opac75');\", 400);
	setTimeout(\"janna$uni('opac50');\", 300);
	setTimeout(\"janna$uni('opac25');\", 200);
	setTimeout(\"janna$uni('opac0');\", 100);
}

function TimeToChange$uni()
{
	jsreload$uni();
	setTimeout(\"timerjob$uni();\", 500);
}
");
if($so{'hold'}!=1)
{
	$str3 = ("$str3 timerjob$uni();\n");
}
else
{
	$str3 = ("$str3 hold=1; timerjob$uni();\n");
}
$str3 = ("$str3

</SCRIPT>

<BR>
<DIV align=center>
<FONT size=2>
");


if($ENV{'HTTP_USER_AGENT'} =~ /firefox/i)
{
	$str3 = ("$str3 <FONT COLOR=#FFFFFF>  </FONT> ");
}

#
$str3 = ("$str3

<TD width=100%>

<TABLE class=ad_window_cell2 width=100%>
<TR>
<TD>

<IFRAME width=100% height=400 id=\"mainart$uni\"
	src=\"http://www.vunet.world/ifmainart.pl?s=$so{'s'}&theme=$so{'theme'}\"
	frameborder=\"no\" scrolling=\"no\"
	allowtransparency=\"true\">
</IFRAME>

</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>
");

	#
        $str3 =~ s/[\t\n\r\s]/ /g;
        $str3 =~ s/  / /g;
        $str3 =~ s/\"/\\\"/g;

	#
        print("  document.write(\"$str3\");  \n");

	#
}


