#!/usr/bin/perl
#
require "/home/vai/sdb/bin/tools.pl";

#
system "cd /home/vai/sdb/bin; /home/vai/sdb/bin/cgi-js.pl";
