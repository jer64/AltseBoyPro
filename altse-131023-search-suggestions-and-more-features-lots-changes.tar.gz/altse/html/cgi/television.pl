#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "television";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
HandleRest();

#
sub ShowPlayer
{
	print("
	
	<!-- BEGIN GENERIC ALL BROWSER FRIENDLY HTML FOR NETSHOW V3 --> 
	<OBJECT ID=\"MediaPlayer\"
	classid=\"CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" 
	codebase=\"http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=,1,52,701\" 
	standby=\"Loading Microsoft Windows Media Player components...\"  
	type=\"application/x-oleobject\"> 
	<PARAM name=\"FileName\" value=\"http://82.103.200.47:8080\"> 
	<EMBED type=\"application/x-mplayer2\"  
	pluginspage=\"http://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/\" 
	SRC=\"http://82.103.200.47:8080\" 
	name=\"MediaPlayer\" 
	width=320 
	height=240> 
	</EMBED> 
	</OBJECT> 
	
	");

}

##################################################
sub main
{
	#
	print ("

<br>
<br>

<center>
<h1>VAI-TV</h1>
");
	#
#	ShowPlayer();

	#
	print("
<img src=\"http://www.saunalahti.fi/~takape6/orava/oravasopo.gif\"><br>
Squirrels live forever.<br>
He who rules the peanuts, rules the world<br>
<br>
TV-broadcast status: OFFLINE

<br>
<br>
<a href=\"vara.pl\">
IF YOU CANNOT SEE THE TELEVISION<br>
BROADCAST IN NEXT 30 SECONDS, CLICK HERE.
</a>
</center>

<br>
<br>
<center>
<h2>LIVE TELEVISION BROADCAST<br>
FROM FINLAND</h2></center>
<br>
Todays playlist loop:<br>
1. [music video] Green Star Intro<br>
2. [music video] Vaihtoehtouutiset demo<br>
3. [music video] anti-war demo<br>
4. [music video] Iraq war shots<br>
<br>
<b>Updates</b><br>
14.6.2004: Break in broadcasting. Continuing broadcast in 22:00 PM (HKI TIME).<br>
<br>
<a href=\"http://www.saunalahti.fi/~ehc50/temp/introc-hologrammed-audcomp.avi\">Video 1</a><br>
<a href=\"http://www.saunalahti.fi/~ehc50/temp/multimedia-pro-peace.wmv\">Video 2</a><br>
<a href=\"http://www.saunalahti.fi/~ehc50/temp/VAI-unleashing-plus-audio.wmv\">Video 3</a><br>

Todays programming:<br>
Mostly music videos.<br>
More accurate programming coming soon!<br>
<br>
Please Avoid using a proxy, if possible.<br>
Broadcasting may cease for a few minutes sometimes,<br>
do not worry, simply reconnect a few minutes later.<br>
Requirements: Atleast a 56K modem.<br>
Service provides a stream that goes upto 100 kbps.<br>

</center>


		");

	#
	$t = time;
	system "echo \"visitor television $t\" >> television.txt";
}


