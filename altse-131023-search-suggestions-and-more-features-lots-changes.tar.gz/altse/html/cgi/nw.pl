#!/usr/bin/perl
#######################################################
# nw.pl - Newswire Publishing System 1.4.
# (VIS 1.4)
# NEWS FRONT PAGE.
# - Finnish
# - English
# (C) 2004-2013 by Jari Tuominen (jari@altseboy.online).
#######################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
if($ENV{'DOCUMENT_ROOT'} eq "")
{
	$ENV{'DOCUMENT_ROOT'} = "/home/vai/altse/html";
}

# See nw.pl search for the search functionality.
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ArticleViewerMonitor.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/GoldenChinaTVFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/kultakaivosinfofp.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/geofp.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/FolkFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/FinnishFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/SwedishFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/RussianFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/EnglishFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/OldEnglishFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ChineseFP.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/JsHeadLines.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NaytaUutisotsikot.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewHL.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewXML.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/AnyComments.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewMainArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticleLib.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/EmbeddedViewArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/QuickNavMenu.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewTopPickFrom.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/SectionSpecificView.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NWSearchAlgorithmSpecifiedSection2.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NWSearchControls.pm";
#
#use Time::localtime;
#use File::stat;
#use Socket;
#use Net::DNS;
#use Net::hostent;
use POSIX;


$IMAGES_BASE = "http://www.vunet.world/images";

#
$TFO = "<img src=$IMAGES_BASE/tiny_folder.gif border=0 align=center>";
#
$TXT_NEWS_SERVICES = $so{'w_news_services'};
$TXT_CALENDAR = $so{'w_calendar'};
$ADVERT_SEC = "kaikki";
$TXT_SEND_TIP = $so{'w_send_story_tip'};
$ADVERT_SEC_DESCRIPTION = "kaikki";
$NO_SECTION_HL = 0;
$CHARS_SHOWN_BREAD_TEXT = 500;
# Shorten captions.
$SHORTENCAPTIONS = 1;
#
$ARTVIEWER = "/";

#
$ARTEL_GIF = "$IMGBASE/vpalk.gif";
$BDR_COLOR = "#FFFFFF";
$ABSOLUTE_LIMIT_CAPTION_LENGTH = 75;

#
$SCROLLER_ENABLED = 0;

# Viewing method.
# Valid values: VARIOUS / LATEST
$VIEWING_METHOD = "VARIOUS";

#######################################################
#
# PREFERENCES
#
$MAX_ADVERTSEC_TO_SHOW = 20;
# Number of the first article to show on the listing.
$BEGART = 0;
# Max. number of stories to show at once.
$MAX_STORIES_TO_SHOW = 10;
# Max. number of headlines to show at once.
$MAX_HEADLINES_TO_SHOW = 4;
$MAXHESO = $MAX_HEADLINES_TO_SHOW;
$MAX_PRV_ARTICLE_CHARS = 200;
#
$WEBINDEX = "webindex2.html";
$FILEINDEX = "./fileindex.txt";
$PROGRAM_NAME = "Newswire Publishing System";

#######################################################
# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();
#
if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
	$so{'FP_SECTION'} = "gold";
}
if($ENV{'HTTP_HOST'}=~/ulkomaat.vunet.world/) {
	$so{'FP_SECTION'} = "geo";
}
if($ENV{'HTTP_HOST'}=~/goldenchinatv/) {
	$so{'FP_SECTION'} = "goldenchinatv";
}

#######################################################
# Go to main loop.
#
main();

#
sub banners123
{
	#
	$SWI = 140;

	#
print("
<TABLE width=100% height=6 cellpadding cellspacing=0 bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<!---
<TABLE width=100% cellpadding cellspacing=0 bgcolor=#000000>
<TR>
<TD>
<a href=\"http://altseboy.online/?to=http://isaris.altseboy.online\" class=dark>
<img src=\"$IMAGES_BASE/isaris-super-banner.jpg\" border=0 width=$SWI>
</a>
</TD>
</TR>
</TABLE>

<TABLE width=100% cellpadding cellspacing=0 bgcolor=#000000>
<TR>
<TD>
<a href=\"http://altseboy.online/?to=http://www.car-rent.fi\" class=dark>
<img src=\"$IMAGES_BASE/AVK.gif\" border=0 width=$SWI>
</a>
</TD>
</TR>
</TABLE>
---->


	");
}

#
sub banners321
{
print("
<!----
<div align=center>
<a href=\"/TopTen.pl/?q=video&c=50\" 
class=dark>
<img src=\"$IMAGES_BASE/VideoTop50.gif\" border=0 width=130>
</a>

---->
	");
}

##########################################################
sub _OpenIndex
{
	my ($i,$ff);

	#
	@fileindex = LoadList($_[0]);
}

##########################################################
sub ViewArticleFile
{
	my ($i,$f);

	# READ ARTICLE FILE.
	open($f, $_[0]);
	@lines = <$f>;
	close($f);

	# CHOP LINES.
	for($i=0; $i<($#lines+1); $i++) { chop $lines[$i]; }

	# VIEW ARTICLE.
	for($i=0; $i<($#lines+1); $i++)
	{
		print "$lines[$i]<br>\n";
	}
}

###########################################################################
#
# The actual function that is used to view the article in newswire.pl
# If $FNSIZE is set, it is used as the font size.
#
# Params:
# [article file name] [stream] [table width]
#
sub ViewArticleFileHeadline
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,$size,$bo,
		$imageurl,$tep,$_tep,
		$of);

	###################################################################
	#
	# Determine output stream.
	#
	if($_[1] ne "") { $of=$_[1]; } else { $of=stdout; }

	###################################################################
	#
	# READ ARTICLE FILE.
	#
	@lines = LoadList($_[0]);

	###################################################################
	#
	# VIEW ARTICLE HEADLINE.
	#
	if($section eq "" && $coz!=1 && !$FNSIZE || $supersmall)
	{
		##
		## LESS DETAILED VIEW.
		##
		#################################
		$size3 = $FNSIZE-1;

		# Produce link to it.
		printf $of "<font size=\"$size3\">\n";
		if(!$supersmall) { printf $of "<br>"; }
		if($NO_ICON ne "1")
		{
			printf $of ("
			<br>
				<img 
				src=\"$ARTEL_GIF\" alt=\"-\">
			");
		}
		if($NO_ICON ne "1")
		{
			$bo = Bonus1($_[0], $of);
			print $bo;
		}
		$tep = $lines[0];
		$tep =~ s/<br>//ig;
		$arturl = $_[0];
		$arturl =~ s/\/$ADVERT_SEC\/\.\.//g;

		#
		if($LIMIT_CAPTION_LENGTH ne "")
		{
			if($SHORTENCAPTIONS)
			{
				$raj = 0;
				$_tep = $tep;
				$tep = substr($tep, 0, $LIMIT_CAPTION_LENGTH);
				if( length($_tep) > length($tep) ) { $raj = 1; }
				if($raj) { $tep = "$tep..."; }
				$tep = ">$tep";
				$tep =~ tr/[a-z���]/[A-Z���]/;
			}
		}
		else
		{
			if($tep =~ /[A-Z���][A-Z���][A-Z���][A-Z���]/ && $SHORTENCAPTIONS)
			{
				$tep =~ tr/[A-Z���]/[a-z���]/;
			}
		}
		if($SHORTENCAPTIONS)
		{
			$tep =~ s/(\S{18})/$1- /g;

			$_tep = $tep;
			$tep = substr($_tep, 0, $ABSOLUTE_LIMIT_CAPTION_LENGTH);
			if( length($_tep) > length($tep) )
			{
				$tep = "$tep...";
			}
		}

		#
		printf $of ("<a href=\"$ARTVIEWER$arturl\"
			style=\"color: rgb($LINKCOLOR);\"
			class=\"news1\">
			");
		# ARTICLE CAPTION.
		printf $of ("
				$tep<br>
				");
		printf $of "</a>\n";
		printf $of "</font>\n";

		# Show if there is any comments for the article
		AnyComments($arturl);
		
		# Show creation date.
		if(!$supersmall)
		{
			CrDate($_[0]);
			printf $of "<font color=\"#C0C0C0\" size=\"1\">\n";
			printf $of $aika;
			printf $of "</font>\n";
		}
	}
	else
	{
		##
		## More detailed view.
		##
		#####################################

		#
		printf $of ("
				<table
				BORDERCOLOR=\"$BDR_COLOR\"
				BORDERCOLORDARK=\"$BDR_COLOR\"
				BORDERCOLORLIGHT=\"$BDR_COLOR\"  ");
		
		if($_[2] ne "")
		{
			printf $of ("
					width=\"$_[2]\"
					");
		}
	
		printf $of ("	>   \n");
		printf $of "<tr><td>\n";

		#
		$size = $FNSIZE-1;
		if(!$size)
		{
			$size = 4;
		}
		printf $of "<font size=\"$size\">\n";
		if($FNSIZE) {
		#	printf $of "<center>\n";
			printf $of "<b>";
		}

		#
		$tep = $lines[0];
		$tep =~ s/<br>//g;
		if($SHORTENCAPTIONS)
		{
			$tep =~ s/(\S{18})/$1- <br>/g;

			#
			$_tep = $tep;
			$tep = substr($_tep, 0, $ABSOLUTE_LIMIT_CAPTION_LENGTH);
			if( length($_tep) > length($tep) )
			{
				$tep = "$tep...";
			}
		}

		#
		if($section ne "" && !$supersmall)
		{
	#		print("TEST TEST TEST TEST 1234567890<br>\n");
		}

		#
		if(!$supersmall)
		{
			# ARTICLE SECTION TABLE.
			#
			if($FNSIZE && !$NO_SECTION_HL)
			{
				printf $of ("
					<table width=\"224\" bgcolor=\"#E0F8E0\"
						cellspacing=0 cellpadding=2>
					<tr>
					<td class=\"tdSelector1\"
						onMouseOver=\"ArtTab(this,1);\"
						onMouseOut=\"ArtTab(this,0);\"
			onClick=\"Clixxor(0, '/?section=$sect&FP_SECTION=$so{'FP_SECTION'}');\">

					<font size=\"2\">
						");
				printf $of ("
					<b>$sect</b>\n
					</font>
					<br>\n

					</td>
					</tr>
					</table>

					<table cellpadding=0 cellspacing=0>
					<tr height=\"6\">
					<td>
					</td>
					</tr>
					</table>
					");
			}
			printf $of "</a>\n";
		#	if(!$FNSIZE) { printf $of "<br>\n"; }
		#	if($section ne "" ) { printf $of "<br>\n"; }
		}

	       	# Print image, if any.
		#
		ParseOptions("$_[0]\_options.txt");

		#
		if($ARTICLE_PRV_EXTEND != 0 && IsImage($imageurl)
			&& $so{'section'} eq "")
		{
				#$WID = 268;
				#$HEI = 268;
				$WID = "", $HEI = "";
		                printf $of ("
				<center>
				<a href=\"$ARTVIEWER$_[0]\" 
					class=\"news1\">
				<img src=\"$imageurl\" width=\"$WID\" height=\"$HEI\"
		                        border=\"1\" hspace=\"0\" 
					vspace=\"0\">
				</a>
				</center>
				<br>
				\n");
		}

		# jumbo321
		print Bonus1($_[0]);
		printf $of "<a href=\"$ARTVIEWER$_[0]\" class=\"news1\">";
		$lines[0] =~ s/<br>//ig;
		$tep =~ s/\n//g;
		$tep =~ s/\r//g;
		# PRINT ARTICLE CAPTION.
		printf $of "<!---click1---><b>$tep</b>";
		printf $of "</a><!----- test 1040960 --->\n";
		printf $of "<!---click2---></font>\n";
		if($FNSIZE) {
			printf $of "</b>\n";
		}
		printf $of "<br><!---click3--->\n";
		# Show if there is any comments for the article
		AnyComments($_[0]);
		# PRINT ARTICLE DATE.
		printf $of "<font color=\"#C0C0C0\" size=\"1\">\n";
		$tiedaika = CrDate($_[0]);
		printf $of $tiedaika;
		printf $of "</font>\n";
		printf $of "<br>\n";

		#
		if($ARTICLE_PRV_EXTEND == 0)
		{
			#
			if($_[1] eq "small")
			{
				$WID = 70;
				$HEI = 70;
			}
			else
			{
				$WID = 70;
				$HEI = 70;
			}
	
	                #
			if($so{'hideimages'} ne "true" && $imageurl ne "")
			{
		                printf $of ("
					<a href=\"$ARTVIEWER$_[0]\" 
						class=\"news1\">
					<img src=\"$imageurl\" width=\"$WID\" height=\"$HEI\" align=\"left\"
		                        border=\"1\" hspace=\"4\" vspace=\"4\">
					</a>
					");
			}
	        }
		else
		{
			# No image.
			$imageurl = "";
		}

		#
		$size2 = $size-1;

		#
		printf $of " <font size=\"$size2\"> \n";

		#
		test: for($i=1,$found=0; $i<($#lines+1);
			$i++)
		{
			$str = $lines[$i];
			$str =~ s/<br>//ig;
			$str =~ s/\xa0//g;
			$str =~ s/\s//g;
			if($str ne "")
			{
				$found=1;
				last test;
			}
		}
		if($found)
		{
			# How many chars per article headline text?
			if($imageurl eq "")
			{
				$LIMIT1 = $MAX_PRV_ARTICLE_CHARS;
			}
			else
			{
				$LIMIT1 = $MAX_PRV_ARTICLE_CHARS/2;
			}
			#
			if($SHORTENCAPTIONS)
			{
				$str = $lines[$i];
				$str =~ s/<br>//ig;
				$str = substr($str, 0, $LIMIT1);
				if(length($str)>($LIMIT1-2))
				{
					$str = "$str...";
				}
			}

			#######################################################################3
			#
			# Print article bread text.
			#

			#
			if($ARTICLE_PRV_EXTEND)
			{
				print ("
						<a name=\"$_[0]\" class=\"plain\">
					");
				loopx: for($x9=0,$len=0; $x9<20; $x9++)
				{
					$len = $len + length($lines[$i+$x9]);
					print ("
						$lines[$i+$x9]
						");
					if($len>$CHARS_SHOWN_BREAD_TEXT)
					{
						last loopx;
					}
				}
			}
			else
			{
				#
				printf $of ("
				<a name=\"$_[0]\" class=\"plain\">$str\n
				");
			}

			#
			print "</a>\n";
		}

		#
		printf $of "<br>";
		printf $of "<!---analyze1006437--->\n";

		# jumbo123
		if($ARTICLE_PRV_EXTEND && $section eq "")
		{
			printf $of "<a href=\"$ARTVIEWER$_[0]\" class=\"dark\">";
			printf $of ("
				<div align=right>
				$so{'w_continues'} ...
				</div>
				");
			printf $of "</a>\n";
		}

		#
		if($section ne "")
		{
			$LUE = "$so{'w_read_more'}";
			printf $of "<a href=\"$ARTVIEWER$_[0]\" style=\"color: rgb($LINKCOLOR);\">";
			printf $of ("<img src=\"$IMGBASE/dokumentti.gif\" alt=\">>\" border=\"0\" align=\"center\">
				 $LUE\n
				");
			printf $of "</a><br><br>\n";
		}

		#
		printf $of " </font> \n";
		
		#
		print $of "</td></tr>\n";
		print $of "</table>\n";
	}
}

#
sub Headline
{
		print ("
		<table width=\"100%\"
	BORDERCOLOR=\"$BDR_COLOR\"
	BORDERCOLORDARK=\"$BDR_COLOR\"
	BORDERCOLORLIGHT=\"$BDR_COLOR\"
	background=\"$IMGBASE/sm_gradient.png\" border=\"0\"
			cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		<td>
		<center><b>$_[0]</b></center>
		</td>
		</tr>
		</table>
			");
}

#
sub katkos 
{
				#
				print("
					<table width=\"100%\">
					<tr>
					<td background=\"$IMGBASE/katkoviiva.gif\" height=\"2\">
					</td>
					</tr>
					</table>
					");
}

################################################################
sub MenuSystem
{
	#
	print("
		<script language=\"Javascript\">
			function Action123(i, active)
			{
			//	window.status = i;
				e2 = document.getElementById(i);
				if(active)
				{
				//	e2.innerHTML = 'hello!!!!!!!!!!!!!';
				}
			}
		</script>
		");
}

################################################################
#
sub ViewPick
{
	my ($i,$i2,$f,$img,$str,$str2,@art,$url,$cap);

	#
	$url = "$_[0]";
	$url = NiceArticleURL($url);

	##################################################################################3
	#
	$img = "";

	#
	ParseOptions("$_[0]\_options.txt");
	$img = $so{'imageurl'};

	##################################################################################3
	#
	print("
		<table cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	if( open($f, "$_[0]") )
	{
		#
		$cap = <$f>;
		#
		close($f);
	}
	#
        $url = CapUrl($url, $cap);


	#
	print("
		<a href=\"$url\" class=\"dark\">
		");

	#
	if(IsImage($img))
	{
		print("
			<img src=\"$img\" width=30 height=30 align=\"left\">
			");
	}

	#
	print("
		<font size=\"1\">
		");

	#
	print $cap;

	# Show number of comments, if any.
	AnyComments($_[0], $url);

	#
	print("
		</font>
		");


	#
	print("
		</a>

		</td>
		</tr>
		</table>
		");
}

#################################################################################################
#
sub ViewPicks
{
	my (@picks,$i,$i2);

	#
	@picks = LoadList("picks.txt");

	#
	print("
		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>
		");

	#
	for($i=$#picks,$i2=0; $i2<2; $i2++,$i--)
	{
		#
		print("
			<td width=50% valign=top>
			");
		if(-e $picks[$i]) {
			ViewPick($picks[$i]);
		}
		print("
			</td>
			");
	}

	#
	print("
		</tr>
		</table>
		<br>
		");
}

#########################################################################################
#
sub IsGoodContent
{
	#
	if($_[0] =~ /\//) { return 0; }
	if($_[0] =~ /\[/) { return 0; }
	if($_[0] =~ /Via Ny Transfer/i) { return 0; }
	if($_[0] =~ /_/) { return 0; }
	if($_[0] =~ /By [a-zA-Z]*/) { return 0; }
	if($_[0] =~ /[0-9]{2}\:[0-9]{2}/) { return 0; }
	if($_[0] =~ /\.htm/) { return 0; }
#	if($_[0] =~ /[a-zA-Z]{3}\s[0-9]*\, [0-9]*\,/) { return 0; }

	#
	return 1;
}

#########################################################################################
#
sub PreviewArticle2
{
	my (@l,$i,$i2,$i3,$i4,$str,$str2,$JATKUU,$len,$showi,$f,
		$iurl,$WID,$HEI,$opt,$cap,$cap2,$alg,$VS,$HS,$pm,$t,
		$MORE);

	#
	$url = "$_[0]";
	$url = NiceArticleURL($url);

	#
	$len = $_[2]/1;
        $t = (stat($_[0]))[9];
        $pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$showi = $_[3];

	#
	ParseOptions("$_[0]\_options.txt");
	$iurl = $so{'imageurl'};
	if($iurl ne "")
	{
		# No animations for front page.
		if($iurl =~ /\/anim/) { $iurl=""; }

		#
		$len /= 2;
		$WID = 64; $HEI = 64;
		$alg = "left";
		$VS = 4;
		$HS = 4;
	}

	#
	@l = LoadList($_[0]);

	#
	for($i=0; $i<($#l+1); $i++)
	{
		$l[$i] =~ s/<br>//g;
	}

	#
	$cap = $l[0];

	#
	if($_[1] ne "")
	{
		$cap2 = $_[1];
		$cap2 =~ tr/[a-z���]/[A-Z���]/;
		$MORE = ("
		<a href=\"/finnish/$_[1]\" class=news3><b><font size=5>$cap2</font></b></a><br>
		<table width=100% height=4 cellpadding=0 cellspacing=0 bgcolor=#000000>
		<tr>
		<td>
		</td>
		</tr>
		</table>
		<br>
		");
	#	EXPRESS("$TFO $_[1]", "/finnish/$_[1]", "left", $BGBAK2);
	}

	#
	print("
		<table cellpadding=8 cellspacing=0 width=100%>
		<tr>
		<td>

		$MORE
		");
	print Bonus1("$_[0]");

	#
	if($_[5] ne "")
	{
		if($so{'urlp'} eq "") {$cap = ("[$pm] $cap");}
		$cap =~ s/^(.{70}).*$/$1\.\.\./g;
	}

	#
	print("
		<a href=\"$url\" class=\"news2\">
		<font size=2>
		<b>
			$cap
		</b>
		</font>
		</a>
		");

	#
	if($_[5] eq "")
	{
		print("<br>");
		print("<font size=1>$pm</font>");
	}

	#
	if($_[5] eq "")
	{
		CrDate($_[0]);
		print "<font color=\"#C0C0C0\" size=\"1\">\n";
		print $aika;
		print "</font><br>\n";
	}

	# Show number of comments, if any.
	AnyComments($_[0]);

	#
	print("
		<table width=100% cellpadding=0 cellspacing=0 bgcolor=#E0E0E0>
		<tr>
		<td>
		");

	#
	if($iurl ne "" && $showi && $_[5] eq "")
	{
		print("
<!--		<a href=\"$url\" class=\"news1\">
			<img src=\"$iurl\"
				vspace=0 hspace=0 border=1
				width=$WID height=$HEI align=$alg>
		</a> ------->
			");
	}

	#
	loop2: for($i=1; $i<($#l+1); $i++)
	{
		if( IsGoodContent($l[$i]) )
		{
			last loop2; 
		}
	}

	#
	loop: for($str="",$JATKUU=0; $i<($#l+1); $i++)
	{
		if( length($str) > $len )
		{
			$JATKUU = 1;
			last loop;
		}
		$str2 = $l[$i];
		if(!($str2 =~ /<[x]embed/))	{ $str2 =~ s/http:\/\/(\S)*[\"|\s]//g; }
		if($str2=~/[A-Z���]{5}/)
		{
			$str2 =~ tr/[A-Z���]/[a-z���]/;
		}
		$str2 =~ s/[\[|\]]//g;
		$str2 =~ s/<.*?>//g;
		$str = "$str\n$str2";
	}

	#
	if($_[5] eq "")
	{
		#
		$str = substr($str, 0, $len);
		$str =~ s/(\S{14})/$1 /g;

		#
		print("

			<table cellpadding=8 cellspacing=0 width=100% height=64>
			<tr valign=top>
			<td>

			<font size=2>
			");
		print $str;

		#
		if($JATKUU==1 && $_[5] eq "")
		{
			print "...";
		}

		#
		print("
			</font>

			</td>
			</tr>
			</table>
			");
	}

	print("
			</td>
			</tr>
			</table>
		");

	#
	if($_[5] eq "")
	{
	}
	else
	{
		if($so{'urlp'} eq "") { print("</li>"); }
	}
	print("
		</td>
		</tr>
		</table>
		");
}

############################################################################################
#
sub PrintLinksCalendar
{
		#
		print("
			<table>
			<tr>

			<td width=140 valign=top>
			");

			########## ADD TINY LINK LIST
			Headline($TXT_NEWS_SERVICES);
			ViewLinkList();

			#
			print("
				</td>

				<td width=140 valign=top>
				");

			########## ADD CALENDAR HERE
			Headline($TXT_CALENDAR);
			open(CAL, "./calendar.cgi|");
			@cal = <CAL>;
			close(CAL);
			print (" <font size=\"2\">  ");
			print @cal;
			print (" </font> ");
			print "<br>\n";		
			print("</td>
				</tr>
				</table>");
}
























#
sub Erikoinen2
{
	#
	print("
		<a href=\"/artid/?id=4x65\" class=news2>
		<img src=\"$IMAGES_BASE/vappu.jpg\" border=1>
		</a><br><br>
		");
}

#
sub ArkistoAd
{
	#
	print("
<A HREF=\"$IMAGES_BASE/vahva_mies_valitsee.jpg\">
<IMG SRC=\"$IMAGES_BASE/sm_vahva_mies_valitsee.jpg\"
	onMouseOver=\"this.src='$IMAGES_BASE/sm_vahva_mies_valitsee2.jpg';\"
	onMouseOut=\"this.src='$IMAGES_BASE/sm_vahva_mies_valitsee.jpg';\">
</A>
<BR>
<BR>

<A HREF=\"$IMAGES_BASE/Vaihtoehtouutiset_juliste1.jpg\">
<IMG SRC=\"$IMAGES_BASE/sm_Vaihtoehtouutiset_juliste1.jpg\"
	onMouseOver=\"this.src='$IMAGES_BASE/sm2_Vaihtoehtouutiset_juliste1.jpg';\"
	onMouseOut=\"this.src='$IMAGES_BASE/sm_Vaihtoehtouutiset_juliste1.jpg';\">
</A>
<BR>
<BR>

<A HREF=\"$IMAGES_BASE/oravi.jpg\">
<IMG SRC=\"$IMAGES_BASE/sm_oravi.gif\"
	onMouseOver=\"this.src='$IMAGES_BASE/sm_oravi2.gif';\"
	onMouseOut=\"this.src='$IMAGES_BASE/sm_oravi.gif';\">
</A>
<BR>
<BR>



<A HREF=\"/tv/\">
<IMG SRC=\"$IMAGES_BASE/katsele_ja_lataa2.gif\"
	onMouseOver=\"this.src='$IMAGES_BASE/katsele_ja_lataa.gif';\"
	onMouseOut=\"this.src='$IMAGES_BASE/katsele_ja_lataa2.gif';\">
</A>
<BR>
<BR>

<script language=\"Javascript\" src=\"$IMAGES_BASE/huuto.js\">
</script>
	");
}

#<script type=\"text/javascript\"><!--
#google_ad_client = \"pub-4178289363390566\";
#google_ad_width = 160;
#google_ad_height = 600;
#google_ad_format = \"160x600_as\";
#google_ad_type = \"text_image\";
#//2006-10-12: Etusivu
#google_ad_channel = \"0530277430\";
#google_color_border = \"C04020\";
#google_color_bg = \"FFFFFF\";
#google_color_link = \"000000\";
#google_color_text = \"000000\";
#google_color_url = \"000000\";
#//--></script>
#<script type=\"text/javascript\"
#  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
#</script>




################################################################
#
sub Hullut
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,@adv);

		#
		print("
			<table cellpadding=4 cellspacing=0
				width=400>
			<tr>
			<td>
			");

		#
		EXPRESS("$TFO muistoja menneisyydest�", "/finnish/kaikki");
		OPENTABLE($TABCOL);

		#
		@adv = LoadList("hullut.txt");
		#
        	$NO_ICON = 1;
	        $supersmall = 1;
		$FNSIZE = 3;
		#
		loop: for($i=$#adv,$i2=0; $i2<8; $i2++,$i--)
		{
			if($adv[$i] eq "" || $i<0) { last loop; }
			ViewHL( "$adv[$i]", $cl,90,$fn2);
			print("	
				<table cellpadding=0 cellspacing=0 width=\"100%\"><tr height=\"2\"><td></td></tr></table>
				");
		}			

		#
		CLOSETABLE($TABCOL);

		#
		print("
			</td>
			</tr>
			</table>
			");

		#
		return 0;
}

################################################################
#
sub BannerBlock
{
	#
	print("<br>");

	#
	print("
<div align=center>
<a href=\"http://www.altseboy.online/music/\" class=news2>
<font size=1>
<img src=\"$IMAGES_BASE/jukebox.gif\" border=2>


		<a href=\"/top/\">
<img src=\"$IMAGES_BASE/suosituimmat2.gif\" class=news1>
</a>
		<div align=center>
		<a href=\"/C/alltop/index.html\">
<img src=\"$IMAGES_BASE/suosituimmat.gif\" class=news1>
</a>
		</div>
		<br>
	");
}

#######################################################################################
#
sub AdditionalFrontPage
{
		#
		Hullut();
		NewsImages();
		#
		BigPicksList();
		print("<br>");
		NewsViews();

		#
		print("<br><br>");
		if($so{'FP_SECTION'} eq "english")
		{
			VTVBAN2();
		}
		else
		{
			VTVBAN();
		}
}

#
sub NewsTicker
{
	#
	if($so{'FP_SECTION'} eq "english")
	{
		$ENGLANNIKSI_TITLE = "Progressive";
		$ENGLANNIKSI_SECT = "progressive";
	}
	else
	{
		$ENGLANNIKSI_TITLE = "Talous";
		$ENGLANNIKSI_SECT = "talous";
	}

	#
	#print("
	#	<TABLE width=100% cellpadding=0 cellspacing=0>
	#	<TR>
	#	<TD width=100%>
	#	<IFRAME height=\"13\" marginwidth=\"0\" width=\"100%\" scrolling=\"no\"
	#	src=\"http://www.altseboy.online/ticker.pl?q=$ENGLANNIKSI_SECT&t=$ENGLANNIKSI_TITLE\"
	#	frameborder=\"0\" marginheight=\"0\">
	#	</IFRAME>
	#	</TD>
	#	</TR>
	#	</TABLE>
#

	#	<TABLE cellpadding=0 height=2 cellspacing=0 border=0
	#		bgcolor=#D0D0D0 width=100%
	#		background=\"$IMAGES_BASE/vaakaviiva.gif\">
	#	<TR>
	#	<TD>
	#	</TD>
	#	</TR>
	#	</TABLE>
	#	");
}

#########################################################################################################
#
sub WhiteBox
{
	#
	print("
<TD>
<TABLE width=100% cellpadding=2 cellspacing=0 bgcolor=#FFFFFF>
<TR>
<TD>
<DIV align=center><B>$_[0]</B></DIV>
$_[1]
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>

			");
}

#
sub GetPlainTextStory
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2);

	#
	if(!(-e $_[0])) { return; }

	#
	@lst = LoadList($_[0]);
	$str = $lst[0];
	$str =~ s/<[^\>]*>//g;
	$str =~ s/\"/'/g;
	$str =~ s/[^a-zA-Z������0-9\+\-\,\.\'\!\? ]//g;
	$str =~ s/^(.{35}).*$/$1.../;

	#
	return $str;
}


#################################################################################################################
#
sub ViewMainStoryCaption
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,
			$ext,$ext2);

		#
		$story = GetPlainTextStory($_[0]);

		#
		$tanne = $pick[0];
		$tanne =~ s/pub_artikkeli([0-9]*)\.txt/story-$1.html/;
		$tanne = "/$tanne";
		print("
<TABLE cellspacing=0 cellpadding=0
	width=100%
	height=48
	style=\"background-repeat: no-repeat;\"
	BACKGROUND=\"http://www.altseboy.online/logo/?t=$story&sz=36&face=Helvetica-Bold\"
	onClick=\"window.location='$tanne';\"
	class=withLink>
<TR>
<TD>
</TD>
</TR>
</TABLE>
		");

	#
}



#################################################################################################################
#
sub ESecView
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,$se);

		# MAIN ARTICLE, FRONT PAGE ARTICLE.
		$se = $_[0];
		@pick = LoadList("$se/fileindex.txt");
		@pick = reverse @pick;

		###################################################################################
		#
		print("
<table width=100% cellpadding=8 cellspacing=0
	bgcolor=#0080FF>
<tr>
<td>
<font size=6 class=Caps color=#00FFFF>
$_[2]
</font>
</td>
</table>
		<TABLE width=750 cellpadding=0 cellspacing=0>
		<tr>
		<td>
			<div align=center>
			<br>

			<font size=5>
<IMG SRC=\"$IMAGES_BASE/vunet_news_delivery.gif\">
			</font>

			<br>
			<a href=\"/english/picks\" class=news1>
			See also editor's picks.</a> | 
			<a href=\"/uutiset/\" class=news1>
			Looking for <b>Finnish</b> news?</a> | 
			<a href=\"http://www.altseboy.online/?q=Video%3A&maxts=80&page=0&section=videos&FP_SECTION=finnish\" class=news1>
			Also see our very popular <b>video archive</b>.</a>
			<BR>
			<a href=\"/?to=http://cheap.web.hosting.altseboy.online/\" class=news1>Cheap Web Hosting</a>
			</div>
		</td>
		</tr>
		</TABLE>

		<BR>
			");

		###################################################################################
		$FNSIZE = "4";
		#
		for($i=0; $i<($#pick+1) && $i<$_[1]; $i+=4)
		{
			print("
				<table cellspacing=0 cellpadding=0 width=100%>
				<tr valign=top>
				");

			#
			for($i2=0; $i2<4; $i2++)
			{
				print("
					<td width=25%>
						");
				PreviewArticle2("$se/$pick[$i+$i2]", "", "100", "TRUE", "");
				print("	
					</td>
					");
			}

			#
			print("
				</tr>
				</table>
				");
		}
}

#################################################################################################################
#
# View RSS file.
#
sub ViewRSS
{
	my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
		$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,$se,@lst,@lst2,$cap,
		$str,$str2,$str3,$str4);

	#
	@lst = LoadList("./rss2txt.pl $_[0]|");

	#
	for($i=0,$str="",$cap=1; $i<($#lst+1); $i++)
	{
		if( !($lst[$i]=~/http:\/\/[a-z]*[\.\-]*/) && $cap)
		{
			$lst[$i] =~ s/<[^\>]*>//gi;
			$str2 = $lst[$i];
			$str2 =~ s/[^0-9a-zA-Z]//g;
			if($str2 ne "")
			{
				$lst[$i] =~ s/^([^\.]*).*$/<B>$1<\/B> $2/;
				if($lst[$i]=~/\./) { $cap = 0; }
				$lst[$i] = "$lst[$i]<BR>";
			}
			else
			{
				goto skip;
			}
		}

		if( ($lst[$i]=~/http:\/\/[a-z]*[\.\-]*/) )
		{
			$lst[$i] =~ s/(http:\/\/)([a-z0-9\-]+\S+)/<A HREF=\"$1$2\">$2<\/A>/g;
			$lst[$i] = "<FONT SIZE=1>$lst[$i]</FONT><BR><BR>";
			$cap = 1;
		}
		$str = "$str\n$lst[$i]\n";
skip:
	}

	#
	$str = ("
<font size=2>
$str
</font>
	");

	#
	return $str;
}

#################################################################################################################
#
# Dutch Front Page
#
sub DutchFP
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,$se);

		#
		$sav1 = $MAX_PRV_ARTICLE_CHARS;
		$sav2 = $ARTICLE_PRV_EXTEND;
		$sav3 = $NO_SECTION_HL;
        	$sav4 = $NO_ICON;
	        $sav5 = $supersmall;
		$sav6 = $SHORTENCAPTIONS;
		$MAX_PRV_ARTICLE_CHARS = 800;
		$ARTICLE_PRV_EXTEND = 1;
		$NO_SECTION_HL = 1;
		$SHORTENCAPTIONS = 0;

		# MAIN ARTICLE, FRONT PAGE ARTICLE.
		@pick = LoadList("$ARTBASE/cfg/pick2.txt");
		@pick2 = LoadList("$ARTBASE/cfg/pick3.txt");
		@pick = reverse @pick;
		@pick2 = reverse @pick2;

		###################################################################################
		$FNSIZE = "4";
		$i = $#adv;
		print("
		<TABLE width=800 cellpadding=16 cellspacing=0>
		<TR>
		<TD width=100%>
		<!--- 1 ---->


		<BR>

		<TABLE width=768 cellpadding=0 cellspacing=0>
		<TR>
		<TD width=100%>
		<!--- 2 ---->
		<IFRAME height=\"13\" marginwidth=\"0\" width=\"100%\" scrolling=\"no\"
		src=\"http://www.altseboy.online/ticker/?q=progressive&t=Latest\"
		frameborder=\"0\" marginheight=\"0\">
		</IFRAME>
		<!--- 3 ---->
		<TABLE cellpadding=1 cellspacing=0 border=0
			bgcolor=#D0D0D0 width=100%
			background=\"$IMAGES_BASE/vaakaviiva.gif\">
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>
		<!--- 2 ---->

		<DIV ALIGN=RIGHT>
		<A HREF=\"http://www.altseboy.online/videos/\">
		>> Looking for videos?
		</A>
		</DIV>
		");

                #ViewMainStoryCaption($pick[0]);

		print("

		</TD>
		</TR>
		</TABLE>
		<!--- 1 ---->



		<TABLE width=750 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		<!--- 2 ---->



");

		# DUTCH
		print ViewMainArticle_wide($pick[0], "", "1000", "TRUE", "");

		#
	#	$str = JsHeadlines("bush|videos|picks|progressive", "News Ticker", 10,
	#		1600, "", $ext);
	#	print $str;

		print("
<BR>
			<table cellspacing=8 cellpadding=0 width=748>
			<tr valign=top>

			<td width=588>
			");

		# DUTCH
		#NaytaUutisotsikot("", "Politiek Discussion", 15, 24*3600, "politiek");
		print ViewRSS("rss/indymedia_nl.rss");
		NaytaUutisotsikot("", "Hardware Talk", 15, 24*3600, "nlcomphardware");
		NaytaUutisotsikot("", "Bush news", 15, 24*3600, "bush");
		NaytaUutisotsikot("", "Videos", 15, 24*3600, "videos");

		#
		print("
			</td>

			<td width=160>

<!--- DUTCH AD --->
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
//2006-10-12: Etusivu
google_ad_channel = \"0530277430\";
google_color_border = \"FFA500\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

<!--- AD --->
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
//2006-10-12: Etusivu
google_ad_channel = \"0530277430\";
google_color_border = \"FFA500\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

<!--- AD --->
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
//2006-10-12: Etusivu
google_ad_channel = \"0530277430\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
<BR>
<BR>
<!--- AD --->
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
//2006-10-12: Etusivu
google_ad_channel = \"0530277430\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

			</td>
			");
		#
		print("
			</tr>
			</table>

			<!--- 2 ---->

			<BR>
			");

		#
		print("
<BR><BR><BR><BR><BR><BR><BR><BR>
</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>

		");



		#
		$ARTICLE_PRV_EXTEND = $sav2;
		$MAX_PRV_ARTICLE_CHARS = $sav1;
		#
		$NO_SECTION_HL = $sav3;
		$NO_ICON = $sav4;
		$supersmall = $sav5;
		$SHORTENCAPTIONS = $sav6;
}

#
sub MoreEnglishStuff
{
		#
		print("

		<TABLE width=710 cellpadding=0 cellspacing=0>
		<tr valign=top>

		<TD width=50>
		</TD>

		<TD witdh=350>
<font size=5>12 ways to cheer up a sad, depressed or grieving friend</font><BR>
<font size=3>Give your friend the gift of hope. Be painfully optimistic. Speak often about how things will get 
better, happier, and less painful in the future. Paint a picture of a happy future filled with the things your 
friend wants.</font><BR>
<a href=\"http://www.altseboy.online/english/story233.html\">> $so{'w_read_more'}!</a><BR>
<BR>

<font size=5>Intelligent Design belongs in religion classes</font><BR>
<font size=3>Mr. Tomaselli's column about Intelligent Design inadvertently shows why Intelligent Design (ID) should not be taught in science classes: ID is a religious idea, not a scientific one. If you read th...</font><BR>
<a href=\"http://www.altseboy.online/english/story279.html\">> $so{'w_read_more'}!</a><BR>
<BR>

<font size=5>World Bank questions free trade's benefits</font><BR>
<font size=3>Global agreement may do little to relieve poverty, economic body finds As thousands of trade diplomats meeting in Hong Kong this week struggle to break an impasse over a global trade agreement, some...</font><BR>
<a href=\"http://www.altseboy.online/english/story278.html\">> $so{'w_read_more'}!</a><BR>


		</TD>

		<TD width=310>
<DIV align=right>

<!---- MAILING LIST SUBSCRIPTION FORM ---->

<form action=\"/cgi//dada/mail.cgi\" method=\"post\">
<IMG SRC=\"$IMAGES_BASE/icon_new_mail.gif\" class=bulletin>
GET LATEST NEWS to your E-mail:<BR>
<INPUT TYPE=HIDDEN NAME=language VALUE=fi>
<INPUT type=\"Text\" name=\"email\" value=\"osoite\" size=\"10\" value=\"\">
<input type=\"hidden\" name=\"printable\" value=\"so{'printable'}\">
<input type=\"hidden\" name=\"f\" value=\"subscribe\">
<input type=\"hidden\" name=\"list\" value=\"altnews\">
<INPUT type=\"Submit\" name=\"email-button\" value=\"Subscribe now!\">
</FORM>


</DIV>

<BR>
		<IMG src=\"$IMAGES_BASE/SopoOrava.jpg\" border=1>
		</TD>

		</tr>
		</TABLE>

		<BR>
		<TABLE WIDTH=750 CELLPADDING=0 CELLSPACING=0>
		<TR>
		<TD width=120>
		</TD>
		<TD width=630>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as_rimg\";
google_cpa_choice = \"CAAQj6eVzgEaCIxA5niBniDSKOm293M\";
//--></script>
<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
		</TD>
		</TR>
		</TABLE>

					");

	
		###################################################################################
		#
		# DIV BEGINS
		#
		print("
			<div>
			");

		###################################################################################
		#
		print("
		<table cellpadding=16 cellspacing=0 width=750>
		<tr>
		<td>


		");

		#
		print("
			<table width=100% cellpadding=8 cellspacing=0>
			<tr valign=top>
			");

		#
		print("
			<td width=50%>
			");
		#NaytaUutisotsikot("videos|viihde", "Videos", 15, 24*3600, "videos");
		####NaytaUutisotsikot("videos", "Videos", 15, 24*3600);
		print("
			</td>
			");

		#
		print("
			<td width=50%>
			");
		#NaytaUutisotsikot("videos|viihde", "Videos", 15, 24*3600, "videos");
		#NaytaUutisotsikot("progressive", "Latest news", 15, 24*3600, "progressive");
		print("
			</td>
			");

		print("
			</tr>
			</table>
			");

		#
		#EngDirectorySections();

		#
		print("<br>");
		ESecView("progressive", 16,	"Progressive news");
		ESecView("english", 8,		"Editor's picks");
		##ESecView("global", 8,		"Global warming");

		###################################################################################
		#
		print("
		</td>
		</tr>
		</table>
		");

		###################################################################################
		#
		# CENTER ALIGNMENT ENDS
		#
		print("
			</div>
			<br>
			");

}

#
sub NewsScroller
{
	print("
<center>
<APPLET CODE=\"short_ticker.class\" CODEBASE=\"http://newsticker.shortnews.com/com/newsticker/\" WIDTH=\"335\" HEIGHT=\"18\"><PARAM NAME=\"RUBRIK1\"       VALUE=\"default\"><PARAM NAME=\"SORT\"          VALUE=\"1\"><PARAM NAME=\"SPARTE\"        VALUE=\"4\"><PARAM NAME=\"BGCOLOR\"       VALUE=\"FFFFFF\"><PARAM NAME=\"FGCOLOR\"       VALUE=\"6633FF\"><PARAM NAME=\"LINKCOLOR\"     VALUE=\"000088\"><PARAM NAME=\"HOVERCOLOR\"    VALUE=\"0000ff\"><param name=\"UNDERLINELINKS\"  value=\"1\"><param name=\"FONTTYPE\"    value=\"arial\"><PARAM NAME=\"FONTSIZE\"      VALUE=\"11\"><PARAM NAME=\"MOUSEOVERHOLD\" VALUE=\"1\"><PARAM NAME=\"SPEED\"         VALUE=\"17\"><PARAM NAME=\"U_ID\"          VALUE=\"58471\"></APPLET>
</center>
		");
}

sub haku
{
		###################################################################################
		#
		print("
<BR>
<BR>
<DIV align=center>
<a href=\"http://www.altseboy.online/JulkaisuSivu/\">
<IMG SRC=\"$IMAGES_BASE/exclamation_mark.gif\" border=0 class=bulletin hspace=4 vspace=0>Onko sinulla makoisa kirjoitus jonka haluat julkaista? Klikkaa t�st� julkaistaksesi sen!
</a>
</DIV>
<BR>
		");
		#
		print("
<BR>
<DIV align=center>

<!-- SiteSearch Google -->
<form method=\"get\" action=\"http://www.google.com/custom\" target=\"_top\">
<table border=\"0\" bgcolor=\"#ffffff\">
<tr><td nowrap=\"nowrap\" valign=\"top\" align=\"left\" height=\"32\">
<a href=\"http://www.google.com/\">
<img src=\"http://www.google.com/logos/Logo_25wht.gif\"
border=\"0\" alt=\"Google\"></img></a>
</td>
<td nowrap=\"nowrap\">
<input type=\"hidden\" name=\"domains\" value=\"www.altseboy.online; hanhi.altseboy.online; dbr.altseboy.online\"></input>
<input type=\"text\" name=\"q\" size=\"31\" maxlength=\"255\" value=\"\"></input>
<input type=\"submit\" name=\"sa\" value=\"Haku\"></input>
</td></tr>
<tr>
<td>&nbsp;</td>
<td nowrap=\"nowrap\">
<table>
<tr>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\"\"></input>
<font size=\"-1\" color=\"#000000\">Web</font>
</td>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\"www.altseboy.online\" checked=\"checked\"></input>
<font size=\"-1\" color=\"#000000\">www.altseboy.online</font>
</td>
</tr>
<tr>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\" hanhi.altseboy.online\"></input>
<font size=\"-1\" color=\"#000000\"> hanhi.altseboy.online</font>
</td>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\" dbr.altseboy.online\"></input>
<font size=\"-1\" color=\"#000000\"> dbr.altseboy.online</font>
</td>
</tr>
</table>
<input type=\"hidden\" name=\"client\" value=\"pub-4178289363390566\"></input>
<input type=\"hidden\" name=\"forid\" value=\"1\"></input>
<input type=\"hidden\" name=\"ie\" value=\"ISO-8859-1\"></input>
<input type=\"hidden\" name=\"oe\" value=\"ISO-8859-1\"></input>
<input type=\"hidden\" name=\"cof\" 
value=\"GALT:#663300;GL:1;DIV:#333333;VLC:663300;AH:center;BGC:FFCC00;LBGC:333333;ALC:000000;LC:000000;T:333300;GFNT:000000;GIMP:000000;FORID:1;\"></input>
<input type=\"hidden\" name=\"hl\" value=\"fi\"></input>

</td></tr></table>
</form>
<!-- SiteSearch Google -->

</DIV>
	");
}




################################################################
#
# VAI FINNISH NEWS FRONT PAGE
#
# args: [file stream] [important sections .txt]
#
sub FinnishNews
{
		my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$keyword,$sta,$fz,@il,
			$of);

		#
		if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

		#####################################################
		if( NoTracking() )
		{
			#
			MenuSystem();
		}

		#####################################################
		# UUSIMMAT UUTISET
		#####################################################

		#
		open($fz, "important-sections.txt");
		@isections = <$fz>;
		for($i=0; $i<($#isections+1); $i++) { chomp $isections[$i]; }
		close($fz);

		# Search for the latest article.
		for($i=0; $i<($#isections+1); $i++)
		{
			$lat[$i] = huntn($isections[$i]);
			if($lat[$i] eq "")
			{
				die "empty string returned by huntn on \"$isections[$i]\" i=$i";
			}
		}

		##
		$FNSIZE = "4";
		$BDR_COLOR1 = "#F0F0F0";
		$BDR_COLOR2 = "#408040";

		## TABLE BEGINS (1)
		printf $of ("
			<table
				cellpadding=\"8\"
				cellspacing=\"0\"
				style=\"border:0px solid $BDR_COLOR1;\">
			");

		###############################################################################
		# PICK UP THE SECTIONS
		#
		if($VIEWING_METHOD eq "VARIOUS")
		{
			# Latest from all sections.
			for($i=0,$i2=0; $i2<($#isections+1); $i+=2,$i2++)
			{
				$il[$i+0] = $lat[$i2];
				$il[$i+1] = $isections[$i2];
			}
		}
		else
		{
			# Pick from "kaikki" section.
			@poi = LoadList("kaikki/fileindex.txt");
			for($i=0,$i2=0,$i3=$#poi; $i2<14; $i+=2,$i2++,$i3--)
			{
				$il[$i+0] = $poi[$i3];
				$il[$i+0] =~ s/\.\.\///;
				$il[$i+1] = PathToSection($il[$i+0]);
			}
		}

		###############################################################################
		#
		for($i=0; $i<($#il/2); $i++)
		{
			#
			if( !($i&1) )
			{
				printf $of "<tr>";
			}

			#
			if($i&1)
			{
			#	katkos();
			}

			#
			printf $of ("
	<!--- test lala -->
	<td style=\"vertical-align: top; text-align: center; border:0px solid $BDR_COLOR2;\"
		width=\"50%\">
				");

			#
			$sect = $il[$i*2+1];
			ViewArticleFileHeadline( "$il[$i*2+0]", $of );

			#
			printf $of ("</td> <!--- test lala II --->");

			#
			if( ($i&1) )
			{
				printf $of "</tr>";
			}
		}

		# TABLE ENDS (1)
		#
		printf $of ("</table>");
		$FNSIZE = "";

		#
}

##########################################################
#
# ENGLISH NEWS
#
sub EnglishNews
{
	my ($of);

	#
	if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

	#
	FreeNews($of);
}

##########################################################
sub TableBeg
{
	print("
		<table
			cellspacing=2
			cellpadding=0>

		<tr valign=top>

		<td></td>
		</tr>

		<tr>

		<td width=28>
		</td>

		<td>
		");
}

##########################################################
sub TableEnd
{
	print("
		</td>
		</tr>
		</table>
		");
}

##########################################################
sub FinnishNewsPipe
{
	my ($fin1,$fh);

	#
	open($fh, '>', \$fin1) || die "can't create pipe fin1";
	FinnishNews($fh);
	close($fh);

	#
	return $fin1;
}

##########################################################
sub JSFriendly
{
	my ($str);

	#
	$str = $_[0];
	#
	$str =~ s/\n/ /g;
	$str =~ s/\r/ /g;
	$str =~ s/\\/\\\\/g;
	$str =~ s/\"/\\\"/g;
	$str =~ s/\'/\\\'/g;
	$str =~ s/\%/\\\%/g;

	#
	return $str;
}

##########################################################
sub ActiveFinSections
{
	my ($i,@lst,$ac1,$ac2,$def);

	#
	$ac1 = "#F0F0F0";
	$ac2 = "#C0C0C0";

	#
	$VIEWING_METHOD = "VARIOUS";
	$fin[0] = FinnishNewsPipe();
	$def = $fin[0];
	$fin[0] = JSFriendly($fin[0]);
	$VIEWING_METHOD = "LATEST";
	$fin[1] = FinnishNewsPipe();
	$fin[1] = JSFriendly($fin[1]);

	#
	@lst = LoadList("fpsubsecs.txt");
	print("
			<script language=\"javascript\">


			function Call1(e, c, h)
			{
				e.style.cursor=h;
				e.style.backgroundColor = c;
			}
			function ChangeContents(t, wh, txt, which)
			{
				o = document.getElementById(t);
				o.innerHTML = wh;
				if(which==0) { o.style.backgroundColor = '#FFFFFF'; }
				if(which==1) { o.style.backgroundColor = '#E0FFFF'; }

				o = document.getElementById('status1');
				o.innerHTML = txt;
			}

			</script>




			<center>
			<table
				cellpadding=\"0\"
				cellspacing=\"0\">
			<tr>
				<td>
				<center>
				<font size=\"6\">
				<div id=\"status1\">$lst[0]</div>
				</font>
				</center>
				</td>
			</tr>

			</table>

			<table width=\"100%\"
				cellpadding=\"0\"
				cellspacing=\"0\">	
			<tr>


			<!--BINGOBINGO-->
		");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		print("
				<script language=\"javascript\">
				function ClickHandler$i(th, name, which)
				{
					ChangeContents('newsview1', '$fin[$i]', name, which);
				}
				</script>
		");

		#
		printf("
				<td width=\"50%\"
					bgcolor=\"$ac1\"
					onMouseOver=\"Call1(this, '$ac2', 'hand');\"
					onMouseOut=\"Call1(this, '$ac1', 'arrow');\"
					onClick=\"ClickHandler$i(this, '$lst[$i]', $i);\">
				<center>
				<font size=\"1\">
				> $lst[$i]
				</font>
				</center>
				</td>
			");
	}

	#
	print("	
			</center>

			</tr>
			</table>
		");

	#
	print("
		<table
				cellpadding=\"0\"
				cellspacing=\"0\">
		<tr>
		<td id=\"newsview1\">
		$def
		</td>
		</tr>
		</table>
		");
}

##########################################################
#
# FP_SECTION=shop
#
sub VAIShop
{
	my ($i,$i2,$i3,$i4,
		$str,$str2,
		@lst);

	#
	@lst = LoadList("shop/fileindex.txt");

	#
	$FNSIZE = 4;
	$NO_SECTION_HL = 1;

	#
	print("
		<table>
		");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		if( ($i%3)==0 ) { print "<tr>"; }
		print "<td width=\"33%\">\n";
		ViewArticleFileHeadline("shop/$lst[$i]");
		print "</td>\n";
		if( ($i%3)==2 ) { print "</tr>"; }
	}

	#
	print("
		</table>
		");
}

##########################################################
#
# Display information for a section.
#
sub DisplaySectionInfo
{
	my ($fn,$f,$i,$i2,$str,@lst,$at,$t);

	#
	$t = sprintf "%d", FileAge($_[0])/60;
	$fn = "$_[0]/description.nfo";

	# Render auto-text.
#	if( isAutoSection($_[0])==1 )
#	{
		# NEEDS LANGUAGE LOCALIZATION...
		if($ENV{'NW_LANGUAGE'} eq "fi")
		{
			$minutes = "minuuttia";
			$hours = "tuntia";
			$days = "p�iv��";
			$p1 = "viimeisin p�ivitys tehty";
			$p2 = "sitten";
		}
		if($ENV{'NW_LANGUAGE'} eq "en")
		{
			$minutes = "minutes";
			$hours = "hours";
			$days = "days";
			$p1 = "last update made";
			$p2 = "ago";
		}
		$str = $minutes;
		if($t > 59) { $str = $hours; $t = sprintf "%d", $t/60; }
		if($t > 23) { $str = $days; $t = sprintf "%1.2f", $t/24; }
#		$at = ("
#$_[0]: $p1 $t $str $p2<BR>
#			");
#	}

	#
	if( !(-e $fn) )
	{
		# Create if it does not exist.
		open($f, ">$fn");
		close($f);
	}

	#
	if(-e $fn)
	{
		@lst = LoadList($fn);
	}

	#
	print("
		<table width=100% cellspacing=0 cellpadding=0>
		<tr valign=top>
		");

	#
	print("
		<td width=60%>
$at
		<font size=2>
		");
	if($so{'page'} eq "")
	{
		for($i=0; $i<($#lst+1); $i++)
		{
			print "$lst[$i]\n";
		}
	}
	print("
		</td>
		");

	#
	print("<td width=10%>");
	if(NoTracking())
	{
		#
		print("
			<div align=right>
			<font size=1>
			<a href=\"/cgi/admin/editart.pl?FILE=$_[0]/description.nfo&BAREHTML=true&PLAIN=true&RETURL=/kaikki/\">
			> muokkaa
			</a>
			</font>
			</div>
			");
	}
	print("</td>");

	#
	print("
		<td width=30%>
			<div align=right>
			<font size=2>($_[0]: <b>$#fileindex</b> artikkelia)</font>
			</div>
		</td>
		");

	#
	print("
		</tr>
		</table>
		<br>
		");
}

###################################################################################################
#
# Get article caption text.
#
sub arthl
{
	my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$sta,
		$fz,@il,$str,$str2,$f,@lst);
	#
	if( !(-e "$_[0]/$_[1]") ) { return(); }

	#### 1) Cached (fast)

	#
	if( !@cca && -e "$_[0]/titles.txt" ) # check for caption cache, is it loaded
	{
		@cca = LoadList("$_[0]/titles.txt");
		for($i=0; $i<$#cca; $i+=2)
		{
			$titles{$cca[$i]} = $cca[$i+1];
		}
	}

	#
	if($_[0] eq "folk") { goto skippi; }
	if( @cca )
	{
		#
		return $titles{$_[1]};
	}
skippi:

	#### 2) SLOW WAY ...

	#
	@lst = LoadList("$ARTBASE/$_[0]/$_[1]");

	#
	for($i=0, $str=""; $i<($#lst+1); $i++)
	{
		#
		$str = "$str $lst[$i] ";
	}
	$str =~ s/[^a-zA-Z������0-9]/ /g;

	#
	return $str;
}

##########################################################
#
# Section Headline.
#
# See displaysectioninfo
#
sub SeHead
{
	my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$sta,$fz,@il,$cap);

	#
	$cap = $so{'section'};

	#
	if($so{'rs'} ne "")
	{
		$cap = "$so{'rs'}";
	}

	# $cap =~ tr/[a-z���]/[A-Z���]/;
	if($cap eq "kaikki")
	{
		$cap = "uutisotsikot";
	}
	if($cap eq "videos")
	{
		print("
<IMG SRC=\"$IMAGES_BASE/vunets_music_videos.jpg\" alt=\"Vunet's music videos\">
			");
		return();

		####$cap = "Vunet's music videos";
	}

	#
	if($cap eq "kummalliset")
	{
		print("
<IMG SRC=\"$IMAGES_BASE/vunetin_kummalliset.jpg\" alt=\"kummalliset hauskat oudot uutiset seksi erotiikka naiset miehet\">
			");
		return();
	}

	#
	if($cap eq "seksi" || $cap eq "seksikk��t")
	{
		print("
<IMG SRC=\"$IMAGES_BASE/vunetin_seksi.jpg\" alt=\"kummalliset hauskat oudot uutiset seksi erotiikka naiset miehet\">

			");
		return();
	}

	#
	if($cap eq "dprk")
	{
		print("
<IMG SRC=\"$IMAGES_BASE/vunetin_dprk.jpg\" alt=\"DPRK Pohjois-Korea Korean demokraattinen kansantasavalta\">
			");
		return();
	}

	#
	print("
<TABLE width=100% cellpadding=0 cellspacing=0>
<tr>
<TD width=60%>
	<font class=section_headline>
	$cap
	</font>
</TD>
<TD width=40%>
");

	#
#	if(NoTracking())
#	{
#		print("
#		<DIV ALIGN=RIGHT>
#		<A HREF=\"httpss://www.altseboy.online/admin/logview/?SEARCH=&site=&section=$so{'section'}&ignore_unknown=false\">
#		> n�yt� mit� luetaan t�st� osastosta
#		</A>
#		</DIV>
#		");
#	}

	#
	print("
</TD>

</tr>
</table>

<table width=100% height=6 cellpadding=0 cellspacing=0
	bgcolor=\"#000000\">
<tr>
<td>
</td>
</tr>
</table>
		");
}

#
sub ShowAd
{
	my ($sp,$google);

	#
	$google = 1;
	#
	if(($so{'page'} eq "" && $so{'q'} eq "") || $so{'rs'} ne "")
	{
		$sp = "";

		#
		if($so{'section'} ne "kummalliset")
		{
			print("
<DIV ALIGN=CENTER>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = \"728x90_as\";
google_ad_type = \"text_image\";
//2006-10-12: Osaston�kym�
google_ad_channel = \"9605472795\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</DIV>
				");
		}

		#
		if($so{'section'} eq "kummalliset")
		{
			print("
				");
		}
	}

	#
}

#
sub ShowAd2
{
	my ($sp,$google);

	#
	$google = 1;
	#
	if(($so{'page'} eq "" && $so{'q'} eq "") || $so{'rs'} ne "")
	{
		$sp = "";

		#
		if($so{'section'} ne "kummalliset")
		{
			print("
<DIV ALIGN=CENTER>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as_rimg\";
google_cpa_choice = \"CAAQj6eVzgEaCIxA5niBniDSKOm293M\";
//--></script>
<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</DIV>
				");
		}

		#
		if($so{'section'} eq "kummalliset")
		{
			print("
				");
		}
	}

	#
}

#
sub ShowAd3
{
	my ($sp,$google);

	#
	$google = 1;
	#
	if(($so{'page'} eq "" && $so{'q'} eq "") || $so{'rs'} ne "")
	{
		$sp = "";

		#
		if($so{'section'} ne "kummalliset")
		{
		}

		#
		if($so{'section'} eq "kummalliset")
		{
			print("
				");
		}
	}

	#
}






###########################################################################################################
#
# VIEW LINK LIST
#
sub ViewLinkList
{
		#################### SMALL LINK LIST
		#
		print ("
			<table align=\"center\"
				bgcolor=\"#F8F8FF\"
				border=\"1\"
				vspace=\"4\" hspace=\"4\"
				cellpadding=\"4\" cellspacing=\"0\">
				<tr>
				<td>

				<div align=\"left\">
			");

		#
		open($fzz, "2linklist.txt");
		@tmp = <$fzz>;
		for($i=0; $i<($#tmp+1); $i++) { chomp $tmp[$i]; }
		close($fzz);
		@l = @tmp;

		#
		print(" <font size=\"1\"> ");

		#
		for($i=0,$co=0; $i<$#l,$co<10; $i+=2,$co++)
		{
			#
			if($i) { print "-"; }

			#
			if( ($l[$i+1] =~ /http\:\/\//i) )
			{
				#
				print("
					<a href=\"$l[$i+1]\"
						target=\"_blank\">
					$l[$i+0]
					</a>
					");
			}
			else
			{
				$i++;
			}
		}

		#
		print("<br>
				<center>
				<a href=\"/links/\">
				> more links
				</a>
				</center>
		
				</font>


				</div>
				</td>
				</tr>
			</table>
			");

		#
	#	print("
	#		<center>
	#		Ilmoitus, 9.6.2004:<br>
	#		VAI on kes�lomalla pari viikkoa.<br>
	#		Kirjoittelua jossain m��rin v�hemm�n loma-aikana.<br>
	#		Edistyksellist� kes��, toivottaa VAI-toimituskunta !
	#		</center>
	#		
	#		");

		#################### BIG LINK LIST
		#
		#
		$SCROLLER = "";

		#
		######### FOREIGN NEWS WIRE #################################

		#
		$scr[0] = sprintf ("
		<h4>
		<b>200 most recent foreign news:</b><br>
		<br>
		");

		#
		open($fzz, "linklist.txt");
		@tmp = <$fzz>;
		for($i=0; $i<($#tmp+1); $i++) { chomp $tmp[$i]; }
		close($fzz);
		@l = @tmp;

		#
		$SCROLLER = "$scr[0]\n\n";

		#
		for($i2=($#l-1),$cozz=0; $i2>-1 && $cozz<200; $i2-=2,$cozz++)
		{
			#
			$CURIMG = "";

			#
			if($l[$i2+0] =~ /commondreams/i)
			{
				$CURIMG = 
				"<img src=\"$IMGBASE/commondreams.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /independent\.co\.uk/i)
			{
				$CURIMG = 
				"<img src=\"$IMGBASE/independent.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /xinhua/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/vpalk.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /informationclearinghouse/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/vpalk2.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /guardian/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/guardian.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /communist/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/communist.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /reuters\.com/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/reuters.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /cbsnews\.com/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/cbsnews.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /english\.pravda\.ru/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/pravda.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /abcnews/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/abcnews.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /english.aljazeera.net/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/aljazeera.gif\" border=\"0\">";
			}

			#
			$EXTR = "";
			if( ($cozz % 10)==9 )
			{
				$EXTR = "<br>\n";
			}

		        #
		        $SCROLLER = sprintf ("
				$SCROLLER
		                <li>
		                <a href=\"$l[$i2+0]\" target=\"_blank\">
				$CURIMG
		                $l[$i2+1]
				</a>
		                </li>
				$EXTR
				$EXTR
		                ");

			#
			if($cozz<4)
			{
				$SCROLLER2 = $SCROLLER;
			}
		}



skip123:
}

#
sub CostOfWar
{
	#
	print("

<center>
<!-- include cost of war javascript; this runs the counter -->
<script language=\"JavaScript\" src=\"http://costofwar.com/costofwar.js\"></script>
<!-- the elements 'row' and 'alt' will be changed by the javascript to contain
     the correct numbers -->
<div><b>Cost of the War in Iraq</b></div>
<div id=\"raw\">(JavaScript Error)</div>
<div><a href=\"http://costofwar.com\" target=\"_top\">To see more details, click here.</a></div>
<!-- this line triggers the counter to start -->
<script language=\"JavaScript\">
inc_totals_at_rate(100);
</script>
</center>
		");

	#
	katkos();
}

#
sub kulma
{
	#
	print("
		<table vspace=\"8\" hspace=\"8\" align=\"center\">
		<tr>
		<td>
			<a href=\"/hint/\">$TXT_SEND_TIP</a>
		</td>
		</tr>
		</table>

		<br>
		<br>
		<center>
		<font size=2>
		<!--(C) 2004-2005 Vaihtoehtouutiset organization-->
		</font>
		</center>
		");
}

##########################################################
#
sub TekstiVersio
{
	#
	print "<center>\n";

	#
	if( $so{'low_graphics'} ne "true" )
	{
		print("
			<a href=\"textversion/\">
			> ulkoasu: tekstiversio
			</a>
			<br>
			");
	}
	else
	{
		print("
			<a href=\"graphicversion/\">
			> ulkoasu: graafinen versio
			</a>
			");
	}

	#
	print ("
		</center>\n
			<br>
		");
}

##########################################################
sub AdminTracker
{
	print("
<!-- Begin Nedstat Basic code -->
<!-- Title: VAI (administration users) -->
<!-- URL: $NEBASECGI/newswire/ -->
<script language=\"JavaScript\" type=\"text/javascript\" 
src=\"http://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC+YJg+qDjiUqWpqWJnCYSv9CRuw\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" 
href=\"http://www.nedstatbasic.net/stats?AC+YJg+qDjiUqWpqWJnCYSv9CRuw\"><img
src=\"http://m1.nedstatbasic.net/n?id=AC+YJg+qDjiUqWpqWJnCYSv9CRuw\"
border=\"0\" width=\"18\" height=\"18\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->
	");
}

##########################################################
sub PrimaryTracker
{
	my ($str);
	my ($i,@igl);

	#
	$str = GetUserID();

	#
	if( NoTracking($str) ) { 
		#AdminTracker(); 
			return 1;
		}

	#
	print("
<center>
<small>
(C) 2000-2004 by Jari Tuominen.</small><br>
      </div>
<!-- Begin Nedstat Basic code -->
<!-- Title: Alternative News Agency - VAI -->
<!-- URL: $NEBASECGI/newswire/ -->
<script language=\"JavaScript\" type=\"text/javascript\" src=\"http://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC3zLQsItf3Zve1qO+opNi34AEQQ\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/stats?AC3zLQsItf3Zve1qO+opNi34AEQQ\"><img
src=\"http://m1.nedstatbasic.net/n?id=AC3zLQsItf3Zve1qO+opNi34AEQQ\"
border=\"0\" width=\"18\" height=\"18\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->


<!-- START OF ADDME LINK -->
<a href=\"http://www.addme.com\"><img src=\"http://www.addme.com/button2.gif\" 
alt=\"Search Engine Submission and Internet Marketing\" width=\"88\" height=\"31\" border=\"0\"></a> 
<!-- END OF ADDME LINK -->
</center>


	");

	#
	return 0;
}

##########################################################
#
# [ L��PPI ]                   [IDBOX]
#
sub NotIdentified
{
	#
	if($so{'firstname'} ne "")
	{
		$COLR = "F0F0F0";
	}
	else
	{
		$COLR = "E0E0FF";
	}

	#
	print("
			<table width=\"665\" bgcolor=\"#$COLR\"
				cellpadding=\"2\" cellspacing=\"0\">
			<tr>
			<td width=\"85%\" bgcolor=\"#FFFFFF\" ID=\"CCCP\">
		");

	#
	@capt = LoadList("$so{'FP_SECTION'}_captext.txt");

	#
	$str = "";
	for($i=0; $i<($#capt+1); $i++)
	{
		$str = "$str $capt[$i]";
	}
	print("
		$str
		");

	#
	print("
			</td>
			<td width=\"15%\" bgcolor=\"#FFFFFF\">
			<font size=\"1\">
		");

	#
	if($so{'firstname'} eq "")
	{
	#	print("
	#		Tunnistaudu <a href=\"identify/\">t�st�</a>, niin voit kommentoida VAI:ssa.
	#		");
	}
	else
	{
	#	print("
	#		status: kirjautunut<br><br>
	#		$so{'lastname'}, $so{'firstname'}<br>
	#		$so{'profession'}<br>
	#		");
	}

	#
	print("
			</font>
			</td></tr>
			</table>
			</div>
	");
}

######################################################################################
sub OnTopOfImage
{
	my ($i,$i2,$n,$sec);

	#
	print("

		<p id=\"ne\">

		<table width=\"332\"
			cellpadding=\"0\" cellspacing=\"0\">
		<tr>
		<td class=\"trans\" id=\"NEWSTABLE\"
			onMouseOver=\"MouseOverNewstable(this, 'trans2');\"
			onMouseOut=\"MouseOutNewstable(this, 'trans');\">

		<font face=\"Lucida Console\" class=\"super\">

		<!--- <script language=\"javascript\" src=\"$IMGBASE/newstable.js\"></script> --->
		");

	#
	$NO_ICON = 1;
	$supersmall = 1;
	$OLD_LINKCOLOR = $LINKCOLOR;
	$LINKCOLOR = "255, 255, 255";
	$LIMIT_CAPTION_LENGTH = 37;

	#
	$sec = $ADVERT_SEC;

	#
	OpenIndex("./$sec/fileindex.txt");

	#
	for($i=$#fileindex,$i2=0; $i>0 && $i2<9; $i--,$i2++)
	{
		#
		$n = "./$sec/$fileindex[$i]";

		#
		ViewArticleFileHeadline($n);
	}

	#
	print("
		</font>

		</td>
		</tr>
		</table>

		</p>
	");

	#
	$LIMIT_CAPTION_LENGTH = "";
	$NO_ICON = 0;
	$supersmall = 0;
	$LINKCOLOR = $OLD_LINKCOLOR;

	#
	print("
		<script language=\"javascript\">

		function looppi()
		{
		//	document.ne.border = 8;
		}

		//setTimeout('looppi()', 50);
		
		</script>
		");
}

######################################################################################
sub OnTopOfImage2
{
	my ($i,$i2,$n,$sec,@txt);

	#
	print("

		<script language=\"javascript\" src=\"$IMGBASE/newstable.js\"></script>

		<p id=\"ne3\" class=\"super\">

		<table width=\"308\"
			cellpadding=\"0\" cellspacing=\"0\">
		<tr>
		<td id=\"NEWSTABLE2\">

		<font face=\"Lucida Console\">

		");

	#
	@txt = LoadList("commercial.txt");

	#
	print("
	");

	#
	print("
		</font>
		</td>
		</tr>
		</table>

		</p>
	");
}

#
sub FreeNews
{
	my ($of);

	#
	if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

	#
	printf $of ("
	<br>
	<center>
	<table>
	<tr>
	<td>

	<SCRIPT language=\"javascript\" SRC=http://interestalert.com/cgi-bin/rmt/siteia/nph-sitenews.js?Sys=jer64&Sum=yes&Date=yes&From=0&Cnt=2&Cols=1&St=Style4&Type=News&Fid=LATEBRKN,WORLDNEW,NATIONAL,WOMNEWS1,OPINIONS,BUSINESS></SCRIPT>

	</td>
	</tr>
	</table>
	</center>
	");
}

##########################################################
#
# Image News.
#
# News focused with images.
#
sub ImageNews
{
	my ($i,$i2,$i3,$i4,$c);

	#
	@news = LoadList("imagenews.txt");

	#
	print("
		<!----------------------------------------------------------->
		<script>
		function ImagenewsMouseout(e)
		{
			o = document.getElementById('TOOLTIP1');
			if(o)
			{
				o.style.backgroundColor = '#FFFFFF';
				o.display = 'none';
				o.innerHTML = '';
			}
		}

		function ImagenewsMouseover(e, msg, locy)
		{
			o = document.getElementById('TOOLTIP1');
			n = document.getElementById('ne2');
			if(o)
			{
				n.style.left = 152+48;
				n.style.top = 320+locy;
				o.style.backgroundColor = '#E0E0E0';
				o.display = 'block';
				o.innerHTML = msg;
			}
		}
		</script>


		<!----------------------------------------------------------->
		<p id=\"ne2\">
		<table bgcolor=#FFFFFF border=0 cellpadding=4 cellspacing=0
			width=\"300\">
		<tr>
		<td id=\"TOOLTIP1\">
		</td>
		</tr>
		</table>
		</p>


		<br>
		<br>
		<br>

		");

	#
	for($i=0,$c=0; $i<($#news),$c<10; $i+=3,$c++)
	{
		#
		$i2 = $c*40;

		#
		print("
			<a href=\"$news[$i+2]\">
			<img src=\"$news[$i+1]\"
				width=\"40\" height=\"40\" border=\"0\"
				onMouseover=\"ImagenewsMouseover(this, '$news[$i+0]', $i2);\"
				onMouseout=\"ImagenewsMouseout(this);\">
			</a>
			<br>
			");
	}
}

##########################################################
sub Scripts
{
	#
	print("
			<script language=\"javascript\">

			//
			function ArtTab(e, w)
			{
				if(w==0)
				{
					e.className = 'tdSelector1';
				}
				if(w==1)
				{
					e.className = 'tdSelector2';
				}
			}

			</script>
		");

	#
}


##########################################################
#
sub VTVBAN2
{
	#
	print("
				<a href=\"http://www.altseboy.online/tv/\" class=dark>
				<img src=\"$IMAGES_BASE/vunet-tv-banner-en.gif\">
				</a>
		");
}

##########################################################
#
sub VTVBAN
{
	#
	print("
					<a href=\"http://www.kominf.pp.fi\" target=\"_blank\" class=dark>
					<img src=\"$IMAGES_BASE/oikea.jpg\" border=1>
					</a>
		");
}

##########################################################
sub NoteInEnglish
{
				#
				print("

					<center>					
					<table width=300 cellpadding=1 cellspacing=0 align=center
						bgcolor=\"#000000\">
					<tr>
					<td>

					<table width=300 cellpadding=8 cellspacing=0 align=center
						bgcolor=\"#00FFFF\">
					<tr>
					<td>
					<font size=2>
					<font size=4>altseboy.online</font> primarily concretes on creating Finnish news content.
					The secondary task is the English reporting cause. We wish that you
					<b>enjoy your time</b> on our news site, and hope that you
					find these alternative news from the world useful.<br>
					<br>
					We're deeply sorry about any technical inconveniences such as broken URLs. Everything should be fixed now.<br>
					<br>
					<i>With best regards,<br>
					altseboy.online staff.</i><br>
					</font>
					</td>
					</tr>
					</table>

					</td>
					</tr>
					</table>

					<br>
					</center>

				");
}

#######################################################################################
#
sub FrontPage_mainmenu
{
		my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,$s,@lst);

		#
		$s = $so{'section'};
		if($s eq "") { $s="etusivu"; }

		# Add main menu.
		if($so{'printable'} eq "")
		{
			if($so{'FP_SECTION'} eq "goldenchinatv") {
				$so{'section'} = $so{'page'};
				print inc_goldenchinatv_menu($so{'section'}, $so{'FP_SECTION'}); 

				# BELOW MENU ON GOLDENCHINATV.INFO + JARI.CO.NR, BANNER
				print("
<P>
<A HREF=\"http://www.kultakaivos.info\">
<IMG SRC=\"$IMAGES_BASE/banners/kultakaivos_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.altseboy.online/\">
<IMG SRC=\"$IMAGES_BASE/banners/vaihtoehtouutiset_banner_2011.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.jari.co.nr\">
<IMG SRC=\"$IMAGES_BASE/banners/jari_banner.png\" class=\"localadimage\">
</A>
</P>

$WORLD_STOCKS
                
					");
			} elsif($so{'FP_SECTION'} eq "gold") {
				my $printti = 
		inc_gold_menu($so{'section'}, $so{'FP_SECTION'});
				print $printti;
				# BELOW MENU ON KULTAKAIVOS.INFO, BANNER
				print("
<P>
<A HREF=\"http://www.goldenchinatv.info/\">
<IMG SRC=\"$IMAGES_BASE/banners/golden_china_tv_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.altseboy.online/\">
<IMG SRC=\"$IMAGES_BASE/banners/vaihtoehtouutiset_banner_2011.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.altse.altseboy.online\">
<IMG SRC=\"$IMAGES_BASE/banners/altse_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.jari.co.nr/\">
<IMG SRC=\"$IMAGES_BASE/banners/jari_banner.png\" class=\"localadimage\">
</A>
</P>

$WORLD_STOCKS
					");

			} elsif($so{'FP_SECTION'} eq "geo") {
				my $printti = 
		inc_geo_menu($so{'section'}, $so{'FP_SECTION'});
				print $printti;
				# BELOW MENU ON ULKOMAAT.VAIHTOEHTOUUTISET.INFO, BANNER
				print("
<!----
<P>
<A HREF=\"http://www.goldenchinatv.info/\">
<IMG SRC=\"$IMAGES_BASE/banners/golden_china_tv_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.altseboy.online/\">
<IMG SRC=\"$IMAGES_BASE/banners/vaihtoehtouutiset_banner_2011.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.altse.altseboy.online\">
<IMG SRC=\"$IMAGES_BASE/banners/altse_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.jari.co.nr/\">
<IMG SRC=\"$IMAGES_BASE/banners/jari_banner.png\" class=\"localadimage\">
</A>
</P>

$WORLD_STOCKS

-->
					");

			} else {
				## DEFAULTS TO FINNISH
				print inc_menu($so{'section'}, $so{'FP_SECTION'}); 

				# BELOW MENU ON GOLDENCHINATV.INFO + JARI.CO.NR, BANNER
				print("
<P>
<A HREF=\"http://www.kultakaivos.info\">
<IMG SRC=\"$IMAGES_BASE/banners/kultakaivos_banner.png\" class=\"localadimage\">
</A>
</P>

<P>
<A HREF=\"http://www.jari.co.nr\">
<IMG SRC=\"$IMAGES_BASE/banners/jari_banner.png\" class=\"localadimage\">
</A>
</P>

<!--- obsolete 
<IFRAME SRC=\"/cal/\" width=\"210\" height=\"210\" style=\"border: 0px;\">
</IFRAME>
---------->
					");
			}
			goto shit;

		}


		#
		if($so{'FP_SECTION'} ne "english") { banners123(); }
		banners321();
shit:
	#
}

#######################################################################################
#
sub FrontPage
{
		my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,$s,@lst);

		#
		$s = $so{'section'};
		if($s eq "") { $s="etusivu"; }

		#
		@lst = LoadList("cfg/worldstocks.txt");
		$WORLD_STOCKS = join("\n", @lst);

		#
		WebWalkTo("main-menu");
		print("
<DIV id=ldr align=center>
<IMG SRC=\"http://www.vunet.world/images/icons1/altse_ajax_loader.gif\" valign=middle>
</DIV>


<DIV ID=\"maincontent1\" style=\"display: none;\">
			");
		FrontPage_mainmenu();
		print("
</DIV>

<SCRIPT LANGUAGE=\"JavaScript\">
document.getElementById('ldr').innerHTML = '';
document.getElementById('maincontent1').style.display = 'block';
</SCRIPT>

		");


		# banneri oli t�ss�
		#
		WebWalkTo("-before-corner-");

 		#####################################################
		#

		#
		print("
<DIV id=ldr2 align=center>
<IMG SRC=\"http://www.vunet.world/images/icons1/altse_ajax_loader.gif\" valign=middle>
</DIV>


<DIV ID=\"maincontent2\" style=\"display: none;\">
			");

		print("
<TABLE bgcolor=#FFFFFFF width=100% cellspacing=0 cellpadding=0>
<TR>
<TD width=844>
			");
		#
		if($so{'FP_SECTION'} eq "gold")
		{
			GoldFP();
		}
		if($so{'FP_SECTION'} eq "geo")
		{
			GeoFP();
		}
		if($so{'FP_SECTION'} eq "goldenchinatv")
		{
			GoldenChinaTVFP();
		}
		if($so{'FP_SECTION'} eq "folk")
		{
			FolkMusicFP();
		}
		if($so{'FP_SECTION'} eq "finnish")
		{
			FinnishFP();
		}
		if($so{'FP_SECTION'} eq "swedish")
		{
			SwedishFP();
		}
		if($so{'FP_SECTION'} eq "chinese")
		{
			ChineseFP();
		}
		if($so{'FP_SECTION'} eq "russian")
		{
			RussianFP();
		}
		if($so{'FP_SECTION'} eq "dutch")
		{
			DutchFP();
		}
		if($so{'FP_SECTION'} eq "english")
		{
			OldEnglishFP();
		}
		#
		print("
</TD>
<TD width=100%>
</TD>
</TR>
</TABLE>
		");

		print("
</DIV>

<SCRIPT LANGUAGE=\"JavaScript\">
document.getElementById('ldr2').innerHTML = '';
document.getElementById('maincontent2').style.display = 'block';
</SCRIPT>

		");

		#
}

###########################################################################################################
#
sub VoteThing
{
			my ($f,$i,$i2,$str,$str2);

			#
			if( open($f, "$ARTBASE/cfg/current-poll_fi.txt") )
			{
				$ENV{'POLLNR'} = sprintf("%d", <$f>);
				close($f);
			}
			else
			{
				$ENV{'POLLNR'} = 6;
			}
	
			#
			$ENV{'newswire_conset'} = "TRUE";
			$ENV{'BOUNCE_TO'} = "/$_[0]";
	                if( open(CAL, "./poll.pl|") )
			{
		                @form = <CAL>;
		                close(CAL);
			}
	                print(" 
				
				<center>
				<table width=140 bgcolor=\"#00C0FF\" cellpadding=1 cellspacing=0>
				<tr>
				<td>

				<table width=100% bgcolor=\"#00FFFF\" cellpadding=0 cellspacing=0>
				<tr valign=top>
				<td>

				<div align=center>
				@form
				</div>

				</td>
				</tr>
				</table>
				</td>
				</tr>
				</table>
				</center>
<br>
				");
}

##################################################################################################
#
sub EngDirectorySections
{
	my ($i,$i2,$str,$str2,$url);
	@secs = (
		"Arts",
		"Shopping",
		"Science",
		"Games",
		"Business",
		"Computers",
		"Health",
		"Sports",
		"World",
		"Society",
		"News",
		"Home",
		"Regional",
		"Reference"
		);

	#
	@secs = sort @secs;

	#
	print("
		<DIV align=center>
		<TABLE width=65% bgcolor=#0080C0>
		<TR>
		<TD>
<font color=\"#FFFFFF\">Vunet WEB directory</font>
		</TD>
		</TR>
		</TABLE>

		<TABLE width=65% bgcolor=#0000FF>
		");

	#
	for($i=0; $i<($#secs+1); $i++)
	{
		#
		$url = $secs[$i];
		$url = "http://altse.altseboy.online/directory/?q=top/$url";

		#
		if( ($i&1)==0 )
		{
			print("
				<TR>
				");
		}
		print("
<TD><LI><FONT size=4><a href=\"$url\" class=bright>$secs[$i]</a></FONT></LI></TD>
			");
		if( ($i&1)==3 )
		{
			print("
				</TR>
				");
		}
	}

	#
	print("
		</TR>
		</TABLE>
		</DIV>
		");

}

#
sub Tori
{
			#
			print("
				<BR>


				<!--- TORI I + II ------------>
				<table width=650 cellspacing=0 cellpadding=0>
				<tr valign=top>
				");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("kummalliset", "Hupijutut", 40, 24*1200, "kummalliset");
			print("</td>");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("videos|viihde", "Videoita", 40, 24*3600, "videos");
			print("</td>");
			#
			print("
				</tr>
				</table>
				");

}

##################################################################################################
#
sub SpecificSection
{
	my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,$str3,$str4,@l,$co);

        #
	if($so{'rs'} eq "") {
		$str = $so{'rs'} . " - " . $ENV{'SERVER_NAME'};
	} else {
		$str = $so{'section'} . " - " . $ENV{'SERVER_NAME'};
	}
	$str =~ tr/[a-z���]/[A-Z���]/;
        WebWalkTo("CHOOSE-TITLE1");

	#
	if($so{'section'} eq "videos")
	{
		$str = "[VIDEOS] Bring The People What They Can't Get Otherwise - Enjoy Our News And Videos!";
		$str2 = "Ajankohtaiset uutiset tassa ja nyt.";
		$str3 = "video,sharing,camera phone,video phone,funny,sexy,radical,political,left,progressive,communist,communism";
		$str4 = "en-GB";
	}
	if($so{'section'} eq "bush")
	{
		$str = "[BUSH NEWS] \"I will not withdraw, even if Laura and Barney are the only ones supporting me.\" --George W. Bush";
		$str2 = "We aim to satisfy ALL your needs to get real information on what happends in USA. We have excellent stories picked by for example famous internet reporter HARRY HOPE.";
		$str3 = "family values, christian, jesus christ, traditional marriage, evangelical, end times, rapture, republicans, GOP, conservative, right-wing, George W. Bush, President, Laura Bush, Jenna Bush, Barbara Bush, Dick Cheney, Richard Cheney, Lynne Cheney, Barbara Bush, President Bush, fiscal enema fetishism";
		$str4 = "en-GB";
	}
	if($so{'section'} eq "progressive")
	{
		$str = "[PROGRESSIVE NEWS] Anyone who stops learning is old, whether at twenty or eighty.  ~Henry Ford";
		$str2 = "Progressive news. We fight for labor unity, peace, equality, democracy and socialism. Vunet is part of the growing anti-war movement, fighting for peace locally and nationally.";
		$str3 = "communism, communist, socialism, socialist, Marx, Marxism, Engels, Lenin, Marxism-Leninism, commie-web, McCarthy, McCarthyism, cold war, red scare, revolution, revolutionary, progressive, anti-globalization, anti-corporate, corporate accountability, child labor, sweatshops, sweatshop labor, AFL-CIO, labor, strikes, unions, trade unions, solidarity, exploitation, justice, justice on the job, jobs with justice, workers, pensions, union contracts, grievance procedures, united, unity, youth, students, young workers, young voters, war, anti-war, terrorism, anti-terrorism, peace, peaceful, non-violence, disarmament, gun control, anti-fascist, anti-monopolization, privatization, anti-capitalist, anti-racism, affirmative action, racial profiling, oppression, women, womens equality, women workers, equal pay, abortion, abortion rights, right to choose, terrorism, anti-terrorism, civil rights, community, collective, democracy, democratic, equality, environment, environmental protection, public education, grassroots, immigrant rights, international, internationalism, wages, welfare, wall street, activism, activist, people of color, Latino, Hispanic, Mexican American, black, Asian-American, Arab, Arab-American, native-American, political prisoners, freedom of speech, hate crimes, healthcare, humanity, humanism, Cuba, blockade, community, student, religious, coalition, mobilize, mobilization, social security, unemployment, vote, voters, elections, wealth, welfare, gay, lesbian, GLBT, transgender, bi-sexual, minimum wage, reforms, public, property, public property, public ownership, private property, privet ownership, change, churches, clergy, pastors, culture, financial aid, student loans, retirees, tuition, schools, liberation, proletariat";
		$str4 = "en-GB";
	}

	#
	print("<TITLE>$str</TITLE>");
        print("
<META name=\"description\" content=\"$str2\">
<META name=\"keywords\" content=\"$str3\">
<META HTTP-EQUIV=\"Content-Language\" CONTENT=\"$str4\">
<META name=\"owner\" content=\"LST\@altseboy.online\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">
<META name=\"revisit-after\" content=\"5 days\">
	                ");
        SkipTo("CHOOSE-TITLE2");

	# VIEW SPECIFIC SECTION.
	#############################################################
	if($so{'plainoutfit'} eq "true")
	{
		SkipTo("past-uusilogo2");
	}

	#
	if($so{'section'} eq "videos")
	{
		$so{'FP_SECTION'} = "english";
	}
	$ENV{'CURFPSEC'} = $so{'FP_SECTION'};

	# add main menu
	#
	if($so{'plainoutfit'} ne "true" && $so{'printable'} eq "")
	{
		# Add main menu.
		#
		$s = $so{'section'};
		if($so{'rs'} ne "") { $s = $so{'rs'}; }
		if($s eq "") { $s="etusivu"; }
		#
		banners123();
	}

	# Add main menu.
	WebWalkTo("main-menu");
	if($so{'printable'} eq "") {
		if($so{'FP_SECTION'} eq "goldenchinatv") {
			WebWalkTo("main-menu");
			print inc_goldenchinatv_menu($so{'page'}, $so{'FP_SECTION'}); 
		} elsif($so{'FP_SECTION'} eq "gold") {
			print inc_gold_menu($so{'section'}, $so{'FP_SECTION'}); 
		} elsif($so{'FP_SECTION'} eq "geo") {
			print inc_geo_menu($so{'section'}, $so{'FP_SECTION'}); 
		} else {
			print inc_menu($so{'section'}, $so{'FP_SECTION'});
		}
	} else {
		if($so{'printable'}) {
			SkipTo("before-uusilogo2");
		} else {
		WebWalkTo("before-uusilogo2");
		}
	}

	#
	WebWalkTo("enterhere");


	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR>
<TD width=750>
		");

	#
	SpecificSection2($so{'section'});

	#
	print("
</TD>
<TD width=100%>
</TD>
</TR>
</TABLE>
		");

	#
}

##################################################################################################
#
sub ShowIndex
{
	my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co);

	# Get section argument.
	$tmp = $ENV{'QUERY_STRING'};
	@tmp2 = split("\&", $tmp);
	if($so{'section'} eq "" && $ENV{'CURSEC'} ne "")
	{
		$so{'section'} = $ENV{'CURSEC'};
	}
	$section = $so{'section'};

	#
	$ENV{'CURSEC'} = $section;
	if($section eq "")
	{
		$ENV{'CURSEC'} = "etusivu";
	}

	#
	$BEGART = $so{'page'};

	# Section specified?
	if($section ne "")
	{
		$MAX_HEADLINES_TO_SHOW = 200;
	}

	#
	if($section eq "")
	{
		#
		my $INDEXFN;
		if($so{'FP_SECTION'} eq "folk") {
			$INDEXFN = "FolkMusicindex.html";
		} elsif($so{'FP_SECTION'} eq "goldenchinatv") {
			$INDEXFN = "GoldenChinaTVindex.html";
		} elsif($so{'FP_SECTION'} eq "gold") {
			$INDEXFN = "goldindex.html";
		} elsif($so{'FP_SECTION'} eq "geo") {
			$INDEXFN = "geoindex.html";
		} elsif($so{'FP_SECTION'} eq "english") {
			$INDEXFN = "englishindex.html";
		} else {
			$INDEXFN = "webindex2.html";
		}
		@web = OpenWebIndex($INDEXFN);
		$wherebe = 0;

		#
		if($so{'NW_LANGUAGE'} eq "fi")
		{
			$so{'w_title'} = "Vaihtoehto psykopatialle: Pakottaako nykyaikainen kilpailuyhteiskunta olemaan v�litt�m�tt� toisista ihmisist�, ajamaan pelk�st��n omaa etua ja kovettamaan oman sisinp�ns�?";
		}

		#
	        WebWalkTo("CHOOSE-TITLE1");
		$str = "$so{'w_title'}";
		$str2 = "$so{'w_description'}";
		$str3 = "$so{'w_keywords'}";
		$str4 = $so{'w_content-language'};

		#
	        print("
<TITLE>$str</TITLE>
<META HTTP-EQUIV=\"Content-Language\" CONTENT=\"$str4\">
<META name=\"description\" content=\"$str2\">
<META name=\"keywords\" content=\"$str3\">
<META name=\"revisit-after\" content=\"1 days\">
<META name=\"owner\" content=\"jari\@altseboy.online\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">
<meta http-equiv=\"Content-Type\" content=\"text/xml; charset=iso-8859-1\" />
	                ");


		#
	        SkipTo("CHOOSE-TITLE2");

		# TRANSPARENT TABLE
		if($so{'printable'}) {
			SkipTo("before-uusilogo2");
		} else {
		WebWalkTo("before-uusilogo2");
		}
		OnTopOfImage2();
	}
	else
	{
		my $INDEXFN;
		if($so{'FP_SECTION'} eq "goldenchinatv") {
			$INDEXFN = "GoldenChinaTVindex.html";
		} elsif($so{'FP_SECTION'} eq "gold") {
			$INDEXFN = "goldindex.html";
		} elsif($so{'FP_SECTION'} eq "geo") {
			$INDEXFN = "geoindex.html";
		} elsif($so{'FP_SECTION'} eq "english") {
			$INDEXFN = "englishindex.html";
		} else {
			$INDEXFN = "webindex2.html";
		}
		@web = OpenWebIndex($INDEXFN);

		# TRANSPARENT TABLE
		#if($so{'printable'}) {
		#	SkipTo("before-uusilogo2");
		#} else {
		#	WebWalkTo("before-uusilogo2");
		#}
		#$wherebe = 0;
	}

	#
#	if($so{'printable'} eq "") { WireLogo(); } else { WireLogo("x"); }

	#
	$ix = 0;

	#
	Scripts();
	
	# Got no specific section?
	if($section eq "")
	{
		#############################################################
		# FRONT PAGE [FINNISH, SWEDISH, OR ENGLISH]
		#############################################################
		FrontPage();

		#
	}
	else
	{
		#############################################################
		# Specific Section
		#############################################################
		SpecificSection($section);
	}

	#
	WebWalkTo("ALAPALKKITAHAN");
	#
	if($so{'FP_SECTION'} ne "geo" && $so{'FP_SECTION'} ne "gold" && $so{'FP_SECTION'} ne "goldenchinatv") { 
		print EndBar();
	} else {
		#GoldEndBar();
		print EndBar();
	}

	#
	HandleRest();
}

#############################################################################################################
#
sub LoadSections
{
	my ($i,$f);

	#
	if( !open($f, "sections.txt") )
	{
		print "$so{'w_error'}: $so{'w_cant_find'} sections.txt\n";
		die;
	}

	#
	@sections = <$f>;

	#
	for($i=0; ($i<$#sections+1); $i++)
	{
		chomp $sections[$i];
	}

	#
	close($f);
}

##########################################################
#
# Handles an external section.
#
# [section trigger], [perl program to make the output]
#
sub _HandleExternal
{
        my ($i,$i2,$found);

        # Print until "$_[0]" is found.
        loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
        {
                if($web[$i] =~ /$_[0]/i)
                {
                        $found=1;
                }
                print $web[$i];
        }
	if($found) { system $_[1]; }
        $wherebe=$i;
}

##########################################################
#
# Apply configuration newswire.pl settings.
#
sub ApplyConfiguration
{
	#
	$ENV{'CURFPSEC'} = $so{'FP_SECTION'};

	#
	if($so{'printable'} ne "")
	{
		$WEBINDEX = "index1.html";
		$WEBINDEX2 = "index1.html";
	}
	else
	{
		$WEBINDEX = "webindex2.html";
		$WEBINDEX2 = "webindex2.html";
	}

	#
	if($so{'FP_SECTION'} eq "english")
	{
		#
		$TXT_NEWS_SERVICES = "news services";
		$TXT_CALENDAR = "calendar";
		$ADVERT_SEC = "english";
		$ADVERT_SEC_DESCRIPTION = "recent picks";
		$TXT_SEND_TIP = "send a tip";
	}
}

###############################################################################################################################
#
sub main
{
	# NEWSWIRE LOCALE
	if($ENV{'HTTP_HOST'}=~/goldenchinatv/) {
		LoadVars("$ARTBASE/cfg/locals/goldenchinatv.txt");
	}
	elsif($ENV{'HTTP_HOST'}=~/kultakaivos/) {
		LoadVars("$ARTBASE/cfg/locals/gold.txt");
	} else {
		LoadVars("$ARTBASE/cfg/locals/$ENV{'NW_LOGO_LANGUAGE'}.txt");
	}
	GetTop20FNs();

	#
	if($so{'section'} eq "viihde") { $so{'section'} = "videos"; $so{'FP_SECTION'} = "english"; }

	#
	if($so{'cq'})
	{
		$so{'cq'} =~ s/[^a-zA-Z0-9\_\-\.]/_/g;
		ViewCachePage($so{'cq'});
		exit();
	}

	#
	if($so{'FP_SECTION'} eq "altseboy.online" || $so{'FP_SECTION'} eq "" ||
		$so{'FP_SECTION'} eq "portal")
	{
		#
		if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
			LoadVars("$ARTBASE/cfg/locals/gold.txt");
			ViewCachePage("index-gold.html");
			exit();
		}
		elsif($ENV{'NW_LANGUAGE'} eq "fi")
		{
			LoadVars("$ARTBASE/cfg/locals/fi.txt");
			ViewCachePage("index-finnish.html");
			exit();
		}
		elsif($ENV{'NW_LANGUAGE'} eq "se")
		{
			LoadVars("$ARTBASE/cfg/locals/se.txt");
			ViewCachePage("index-swedish.html");
			exit();
		}
		elsif($ENV{'NW_LANGUAGE'} eq "nl")
		{
			LoadVars("$ARTBASE/cfg/locals/nl.txt");
			ViewCachePage("index-dutch.html");
			exit();
		}
		elsif($ENV{'NW_LANGUAGE'} eq "en")
		{
			LoadVars("$ARTBASE/cfg/locals/en.txt");
			ViewCachePage("index-english.html");
			exit();
		}

		#
		@WHART = LoadList("pick2.txt");
		$ENV{'VIEW_THIS_ARTICLE'} = $WHART[0];
		$ENV{'newswire_conset'} = "TRUE";
		$ENV{'FRONT_PAGE_MODE'} = "TRUE";
	
		#
		system "./viewarticle.pl";
		exit();
	}
	
	#
	if($so{'FP_SECTION'} eq "search" )
	{
		# Tell frontpage.pl that the content /html blabla is already set.
		$ENV{'newswire_conset'} = "TRUE";
		system "./search.pl";
		exit;
	}

	# Default to FINNISH news.
	if($so{'FP_SECTION'} eq "")
	{
		$so{'FP_SECTION'} = "finnish";
	}
	#
	ApplyConfiguration();

	#
	LoadSections();

	###########################################################

	# Show the index.
	if($so{'section'} eq "secspe")
	{
		SectionSpecificView();
	}
	else
	{
		ShowIndex();
	}

	#
}


