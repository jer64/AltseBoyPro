#!/usr/bin/perl
system("/db/sdb/bin/cgi-monitor.pl");
