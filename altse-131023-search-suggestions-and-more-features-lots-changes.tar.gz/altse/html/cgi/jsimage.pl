#!/usr/bin/perl
################################################################################
#
# Embedded image, q = query for image with a keyword from the Vunet image bank.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();

################################################################################
#
sub good_match
{
	if($_[0] =~ /jim rogers/i) { return 1; }
	if($_[0] =~ /peter schiff/i) { return 1; }
	if($_[0] =~ /commodore/i) { return 1; }
	if($_[0] =~ /gold/i) { return 1; }
	if($_[0] =~ /silver/i) { return 1; }
	if($_[0] =~ /yandex/i) { return 1; }
	return 0;
}

################################################################################
#
sub main
{
	my ($str,$str2,@lst,@sp);

	#
	if($so{'q'} ne "")
	{
		$GAL = $so{'q'};
		$GAL =~ s/[^a-z0-9_]//g;
	}

	if(!good_match($so{'q'})) { goto past; }
	#
	@lst = LoadList("imagelist_thumb2.txt");
	my @sp = split(/ /, $so{'q'});
	my @cand_list;
	for($i=0; $i<($#lst+1); $i++) {
		loop: for($i2=0; $i2<($#sp+1); $i2++) {
			if($lst[$i] =~ $sp[$i2]) {
				push(@cand_list, $lst[$i]);
				last loop;
			}
		}
	}

	#
	srand(time);
	$sel_img = $cand_list[rand($#cand_list)];

	#
	if($sel_img ne "") {
		$str = (" 
	<IMG SRC=\"$IMAGES_BASE/$sel_img\" align=left border=1 vspace=4 hspace=4>
	");
	}
past:
        #
        $str =~ s/[\t\n\r\s]/ /g;
        #$str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

	#
        print(" document.write(\"$str\"); \n");
}

