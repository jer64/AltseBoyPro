#!/usr/bin/php
phpinfo();
