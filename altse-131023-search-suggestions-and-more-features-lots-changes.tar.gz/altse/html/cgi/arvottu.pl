##########################################################
#
sub Arvottu
{
	my ($i,$i2,$i3,$i4,@arv,$str,$str2);

	#
	EXPRESS2("arvottu", "", "center");

	#
	OPENTABLE($TABCOL);

	#
	@arv = LoadList("poimitut/fileindex.txt");

	#
	srand(time);
	$i = sprintf("%d", rand($#arv));
	print("
			<table cellpadding=4 cellspacing=0>
			<tr>
			<td>

			<font size=1>
			");

	#
	$str = $arv[$i];
	$str =~ s/\.\.\///;
	ViewArticleFileHeadline($str);

	#
	print("
			</font>

			</td>
			</tr>
			</table>
			");

	#
	CLOSETABLE($TABCOL);

	#
	print("<br>");
}

################################################################################################
#
sub ViewArticleFileHeadline
{
	my ($i,$i2,$i3,$i4,$cap,$url,$Googler);

	#
	if( !(-e $_[0]) ) { return(); }

	#
	$url = UrlFix($_[0]);

	#
	open(f, "$_[0]");
	$cap = <f>;
	close(f);

	#
#	$Googler = Googler($cap);
	#
	$cap = PROCAP($cap);

	#
	print("
		<TABLE width=100% cellpadding=0 cellspacing=0>
		<TR>
		<TD>

		<a href=\"$ARTVIEWER$url\" class=dark>
		<font size=1>
		<li><b>$cap</b></li>
		</font>
		</a>

		</TD>
		</TR>
		</TABLE>
		");
}
