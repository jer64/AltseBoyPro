#!/usr/bin/perl
#######################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
print("
<BODY>
<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"http://www.altse.vunet.world/js/?q=World/Suomi\">
</SCRIPT>
</BODY>
");
