#!/usr/bin/perl -w
# cheesegrater -- scrapes HTML from web sites into RSS feeds.
# Copyright � 2002, 2003, 2004 Jamie Zawinski <jwz@jwz.org>
#
# Permission to use, copy, modify, distribute, and sell this software and its
# documentation for any purpose is hereby granted without fee, provided that
# the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation.  No representations are made about the suitability of this
# software for any purpose.  It is provided "as is" without express or 
# implied warranty.
#
# Created: 20-Nov-2002.
#
# RSS doc:   http://my.netscape.com/publish/formats/rss-spec-0.91.html


require 5;
#use diagnostics;   # this screws up error messages when using eval/die.
use strict;
use POSIX;

my $progname = $0; $progname =~ s@.*/@@g;
my $version = q{ $Revision: 1.76 $ }; $version =~ s/^[^0-9]+([0-9.]+).*$/$1/;
my $progclass = 'CheeseGrater';
my $progurl = 'http://www.jwz.org/cheesegrater/';

my $verbose = 0;

my $html_cache_dir = ".html";
my $rss_output_dir = "rss";

my $max_entries   = 150;

my $rss_lang       = "en";
my $rss_webmaster  = "webmaster\@jwz.org";
my $rss_editor     = $rss_webmaster;

# How to parse sites.  Entries in the table are:
#
#    "URL"  =>   [ parse_function, "site name", "site description",
#                  "site logo image url", image_width, image_height,
#                  expirey_minutes
#                ]
#
# The logo url is optional.
# If the url has been checked within expirey_minutes, it's not checked again.
#
my %filter_table = (

 "http://www.wilwheaton.net/" =>
                    [ \&do_wilwheaton,
                      "Wil Wheaton dot net",
                      "A full feed of Wil Wheaton's blog, " .
                      "rather than just headlines.",
                   "http://www.wilwheaton.net/Images/Wheaton_Wil.jpg", 92, 100,
                      60
                    ],

 "http://www.thismodernworld.com/" =>
# "http://www240.pair.com/tomtom/" =>
                    [ \&do_thismodernworld_blog, "This Modern World",
                      "This Modern World weblog, by Tom Tomorrow",
          "http://images.salon.com/comics/tomo/2002/10/28/tomo/lc.gif", 58, 50,
                      60
                    ],

 "http://dir.salon.com/topics/tom_tomorrow/" =>
                    [ \&do_thismodernworld_comic,
                      "This Modern World",
                      "This Modern World comic, by Tom Tomorrow",
          "http://images.salon.com/comics/tomo/2002/10/28/tomo/lc.gif", 58, 50,
                      60
                    ],

 "http://www.workingforchange.com/column_lst.cfm?AuthrId=43" =>
                    [ \&do_thismodernworld_comic2,
                      "This Modern World",
                      "This Modern World comic, by Tom Tomorrow",
          "http://www.workingforchange.com/webgraphics/WFC/sparky3.gif",
                      47, 46,
                      60 * 6
                    ],

 "http://www.diepunyhumans.com/" =>
                    [ \&do_diepunyhumans,
                      "Die Puny Humans",
                      "The weblog of Warren Ellis.",
                      "http://www.diepunyhumans.com/dphminimonkey.jpg", 82, 59,
                      60
                    ],

 "http://www.straightdope.com/columns/" =>
                    [ \&do_straightdope,
                      "The Straight Dope",
                      "The Straight Dope, by Cecil Adams",
                      undef, 0, 0,
                      60 * 6
                    ],

"http://www.improvisation.ws/mb/showthread.php?threadid=4475&perpage=1000" =>
                    [ \&do_pornclerk,
                      "True Porn Clerk Stories",
                      "True Porn Clerk Stories, by Ali Davis",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.sfgate.com/examiner/bondage/" =>
                    [ \&do_bondagefiles, "The Bondage File",
                      "Weird news from the San Francisco Chronicle.  " .
                      "Updated every friday.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://antwrp.gsfc.nasa.gov/apod/archivepix.html" =>
                    [ \&do_apod_link, "Astronomy Picture of the Day",
                      "Each day a different image or photograph of our " .
                      "fascinating universe is featured, along with a " .
                      "brief explanation written by a professional " .
                      "astronomer.",
                      "http://www.nasa.gov/images/hotnasa.gif", 78, 68,
                      60 * 6
                    ],

 "http://antwrp.gsfc.nasa.gov/apod/" =>
                    [ \&do_apod_inline, "Astronomy Picture of the Day",
                      "Each day a different image or photograph of our " .
                      "fascinating universe is featured, along with a " .
                      "brief explanation written by a professional " .
                      "astronomer.",
                      "http://www.nasa.gov/images/hotnasa.gif", 78, 68,
                      60 * 6
                    ],

 "http://www.redmeat.com/redmeat/meatlocker/" =>
                    [ \&do_redmeat, "Red Meat",
                      "Red Meat, from the secret files of Max Cannon",
                  "http://www.redmeat.com/redmeat/images/rm_nav2.gif", 57, 108,
                      60 * 6
                    ],

 "http://www.webster.com/cgi-bin/mwwod.pl" =>
                    [ \&do_webster_wotd, "Word of the Day",
                      "Merriam-Webster's Word of the Day",
                      "http://www.webster.com/images/mwlogo_new.gif", 94, 95,
                      60 * 6
                    ],

 "http://www.space.com/news/" =>
                    [ \&do_space_com, "Space Dot Com",
                      "Space news from space.com.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.memepool.com/" =>
                    [ \&do_memepool, "memepool",
                      "A full feed of memepool, rather than just headlines.",
                      undef, 0, 0,
                      60
                    ],

 "http://www.catandgirl.com/" =>
                    [ \&do_catandgirl_inline, "Cat and Girl",
                      "A small Girl, a large anthropomorphic Cat, a few " .
                      "wacky adventures and some pretentious conversation. " .
                      "Also Beatnik Vampires and Joseph Beuys. " .
                      "Updated every monday.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.catandgirl.com/archive.cgi" =>
                    [ \&do_catandgirl_index, "Cat and Girl",
                      "A small Girl, a large anthropomorphic Cat, a few " .
                      "wacky adventures and some pretentious conversation. " .
                      "Also Beatnik Vampires and Joseph Beuys. " .
                      "Updated every monday.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.wtbw.net/geisha/" =>
                    [ \&do_geisha_asobi, "Geisha asobi blog",
                      "Geisha asobi blog, by Asobi Tsuchiya",
                      undef, 0, 0,
                      60
                    ],

 "http://www.thestranger.com/current/savage.html" =>
                    [ \&do_savagelove, "Savage Love",
                      "Savage Love, by Dan Savage",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.pennandteller.com/03/coolstuff/roadpenn.html" =>
                    [ \&do_penn, "Penniphile",
                  "Penn Jillette, the taller, louder half of Penn and Teller",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.mnftiu.cc/mnftiu.cc/war.html" =>
                    [ \&do_gywo, "Get Your War On", "Get Your War On",
                      "http://www.mnftiu.cc/mnftiu.cc/images/gywo_cover.gif",
                      120, 81,
                      60 * 6
                    ],

 "http://www.pbs.org/cringely/archive/" =>
                    [ \&do_cringely, "I, Cringely", "I, Cringely",
                      "http://www.pbs.org/cringely/_g/inside_logo.gif",
                      146, 49,
                      60 * 6
                    ],

 "http://slashdot.org/" =>
                    [ \&do_slashdot, "Slashdot", 
                      "Slashdot: News for \"nerds.\"  Stuff that \"matters.\"",
                      undef, 0, 0,
                      60
                    ],

 "http://dnasty.blogspot.com/" =>
                    [ \&do_dnasty, "d-nasty", 
                 "The life and adventures of a 24 year old investment banker.",
                      undef, 0, 0,
                      60
                    ],

 "http://slumbering.lungfish.com/" =>
                    [ \&do_slumberinglungfish, "The Slumbering Lungfish",
                      "Lore Fitzgerald Sj�berg, Proprietor.",
                      undef, 0, 0,
                      60
                    ],

 "http://www.linkfilter.net/" =>
                    [ \&do_linkfilter, "LinkFilter",
                      "A better-formatted (screen-scraped) feed of this site.",
                      undef, 0, 0,
                      60
                    ],

 "http://www.creaturesinmyhead.com/creature.php" =>
                    [ \&do_creaturesinmyhead, "The Creatures in my Head",
                      "By Andrew Bell.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.blacktable.com/" =>
                    [ \&do_blacktable, "The Black Table",
                      "The Black Table.",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.artbomb.net/blog/" =>
                    [ \&do_artbomb, "artbomb.net",
                      "Indy comics news, notes and spare change.",
                      undef, 0, 0,
                      60
                    ],

 "http://www.asofterworld.com/today.htm" =>
                    [ \&do_asofterworld, "a softer world",
                      "a softer world",
                      undef, 0, 0,
                      60 * 6
                    ],

 "http://www.blackboxvoting.com/" =>
                    [ \&do_blackboxvoting, "Black Box Voting",
                      "Ballot-tampering in the 21st century",
                      undef, 0, 0,
                      60
                    ],
);


#############################################################################

my $inside_eval_p = 0;
sub error {
  ($_) = @_;
  if ($inside_eval_p) {  # perl's exception handling sucks
    die $_;
  } else {
    print STDERR "$progname: $_\n";
    exit 1;
  }
}

sub capitalize {
  my ($s) = @_;
  $s =~ s/_/ /g;
  # capitalize words, from the perl faq...
  $s =~ s/((^\w)|(\s\w))/\U$1/g;
  $s =~ s/([\w\']+)/\u\L$1/g;   # lowercase the rest

  # conjuctions and other small words get lowercased
  $s =~ s/\b((a)|(and)|(in)|(is)|(it)|(of)|(the)|(for)|(on)|(to))\b/\L$1/ig;

  # initial and final words always get capitalized, regardless
  $s =~ s/^(\w)/\u$1/;
  $s =~ s/(\s)(\S+)$/$1\u\L$2/;

  return $s;
}



# expands the first URL relative to the second.
#
sub expand_url {
  my ($url, $base) = @_;

  $url =~ s/^\s+//gs;  # lose whitespace at front and back
  $url =~ s/\s+$//gs;

  if (! ($url =~ m/^[a-z]+:/)) {

    $base =~ s@(\#.*)$@@;       # strip anchors
    $base =~ s@(\?.*)$@@;       # strip arguments
    $base =~ s@/[^/]*$@/@;      # take off trailing file component

    my $tail = '';
    if ($url =~ s@(\#.*)$@@) { $tail = $1; }         # save anchors
    if ($url =~ s@(\?.*)$@@) { $tail = "$1$tail"; }  # save arguments

    my $base2 = $base;

    $base2 =~ s@^([a-z]+:/+[^/]+)/.*@$1@        # if url is an absolute path
      if ($url =~ m@^/@);

    my $ourl = $url;

    $url = $base2 . $url;
    $url =~ s@/\./@/@g;                         # expand "."
    1 while ($url =~ s@/[^/]+/\.\./@/@g);       # expand ".."

    $url .= $tail;                              # put anchors/args back

    print STDERR "$progname: relative URL: $ourl --> $url\n"
      if ($verbose > 5);

  } else {
    print STDERR "$progname: absolute URL: $url\n"
      if ($verbose > 6);
  }

  return $url;
}


# converts all relative URLs in SRC= or HREF= to absolute URLs,
# relative to the given base.
#
sub expand_urls {
  my ($html, $base) = @_;

  $html =~ s/</\001</g;
  my @tags = split (/\001/, $html);

  foreach (@tags) {
    if (m/^(.*)\b(HREF|SRC)(\s*=\s*\")([^\"]+)(\".*)$/si) {
      my $head = "$1$2$3";
      my $url  = $4;
      my $tail = $5;
      $url = expand_url ($url, $base);
      $_ = "$head$url$tail";
    }
  }

  return join ('', @tags);
}


# Maps certain UTF8 characters (2 or 3 bytes) to the corresponding
# Latin1 characters.
#
my %unicode_latin1_table = (
   "\xC2\xA1" => '�', "\xC2\xA2" => '�', "\xC2\xA3" => '�', "\xC2\xA4" => '�',
   "\xC2\xA5" => '�', "\xC2\xA6" => '�', "\xC2\xA7" => '�', "\xC2\xA8" => '�',
   "\xC2\xA9" => '�', "\xC2\xAA" => '�', "\xC2\xAB" => '�', "\xC2\xAC" => '�',
   "\xC2\xAD" => '�', "\xC2\xAE" => '�', "\xC2\xAF" => '�', "\xC2\xB0" => '�',
   "\xC2\xB1" => '�', "\xC2\xB2" => '�', "\xC2\xB3" => '�', "\xC2\xB4" => '�',
   "\xC2\xB5" => '�', "\xC2\xB6" => '�', "\xC2\xB7" => '�', "\xC2\xB8" => '�',
   "\xC2\xB9" => '�', "\xC2\xBA" => '�', "\xC2\xBB" => '�', "\xC2\xBC" => '�',
   "\xC2\xBD" => '�', "\xC2\xBE" => '�', "\xC2\xBF" => '�', "\xC3\x80" => '�',
   "\xC3\x81" => '�', "\xC3\x82" => '�', "\xC3\x83" => '�', "\xC3\x84" => '�',
   "\xC3\x85" => '�', "\xC3\x86" => '�', "\xC3\x87" => '�', "\xC3\x88" => '�',
   "\xC3\x89" => '�', "\xC3\x8A" => '�', "\xC3\x8B" => '�', "\xC3\x8C" => '�',
   "\xC3\x8D" => '�', "\xC3\x8E" => '�', "\xC3\x8F" => '�', "\xC3\x90" => '�',
   "\xC3\x91" => '�', "\xC3\x92" => '�', "\xC3\x93" => '�', "\xC3\x94" => '�',
   "\xC3\x95" => '�', "\xC3\x96" => '�', "\xC3\x97" => '�', "\xC3\x98" => '�',
   "\xC3\x99" => '�', "\xC3\x9A" => '�', "\xC3\x9B" => '�', "\xC3\x9C" => '�',
   "\xC3\x9D" => '�', "\xC3\x9E" => '�', "\xC3\x9F" => '�', "\xC3\xA0" => '�',
   "\xC3\xA1" => '�', "\xC3\xA2" => '�', "\xC3\xA3" => '�', "\xC3\xA4" => '�',
   "\xC3\xA5" => '�', "\xC3\xA6" => '�', "\xC3\xA7" => '�', "\xC3\xA8" => '�',
   "\xC3\xA9" => '�', "\xC3\xAA" => '�', "\xC3\xAB" => '�', "\xC3\xAC" => '�',
   "\xC3\xAD" => '�', "\xC3\xAE" => '�', "\xC3\xAF" => '�', "\xC3\xB0" => '�',
   "\xC3\xB1" => '�', "\xC3\xB2" => '�', "\xC3\xB3" => '�', "\xC3\xB4" => '�',
   "\xC3\xB5" => '�', "\xC3\xB6" => '�', "\xC3\xB7" => '�', "\xC3\xB8" => '�',
   "\xC3\xB9" => '�', "\xC3\xBA" => '�', "\xC3\xBB" => '�', "\xC3\xBC" => '�',
   "\xC3\xBD" => '�', "\xC3\xBE" => '�', "\xC3\xBF" => '�',

   "\xE2\x80\x93" => '--',  "\xE2\x80\x94" => '--',
   "\xE2\x80\x98" => '`',   "\xE2\x80\x99" => '\'',
   "\xE2\x80\x9C" => "``",  "\xE2\x80\x9D" => "''",
   "\xE2\x80\xA6" => '...',
);

# Convert any Unicode characters to Latin1 if possible.
# Unconvertable bytes are left alone.
#
sub de_unicoddle {
  my ($text) = @_;
  foreach my $key (keys (%unicode_latin1_table)) {
    my $val = $unicode_latin1_table{$key};
    $text =~ s/$key/$val/gs;
  }
  return $text;
}


# Runs wget to pull an updated copy of the given site into the cache
# directory, unless we've done so very recently (according to the
# expirey/freshness value in this URL's configuration.)
#
sub pull_html {
  my ($url) = @_;

  my $now = time;

  # find the expirey of this URL.  This will error if it's an unknown URL.
  #
  my $expirey = undef;
  {
    my ($fn, $title, $desc, $rss_img, $rss_img_w, $rss_img_h);
    ($fn, $title, $desc, $rss_img, $rss_img_w, $rss_img_h, $expirey) =
      get_filter_data ($url);
    error ("no expirey for $url") unless (defined ($expirey));
  }

  $_ = $url;
  s@/+$@@;
  s@^http://@@gi;
  s@[^-_a-z\d]@_@gi;
  my $file = $_;
  my $hfile = "$html_cache_dir/$_";

  # check the expirey, and if we've checked this URL recently, don't
  # re-download the content.
  #
  {
    my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
        $atime,$mtime,$ctime,$blksize,$blocks) = stat($hfile);
    if (!defined ($mtime)) {
      print STDERR "$progname: $hfile does not exist\n" if ($verbose > 3);
    } elsif ($size < 512) {
      print STDERR "$progname: $hfile is only $size bytes\n" if ($verbose > 3);
    } else {
      my $minutes_ago = int (($now - $mtime) / 60);
      if ($minutes_ago < $expirey) {
        print STDERR "$progname: $hfile: modified < $expirey ($minutes_ago) " .
          "minutes ago.\n"
            if ($verbose > 2);
        return $file;
      } else {
        print STDERR "$progname: $hfile last modified $minutes_ago " .
          "minutes ago.\n"
            if ($verbose > 3);
      }
    }
  }

# my @cmd = ("wget", "-O", $hfile, "-N");
 my @cmd = ("wget", "-O", $hfile);
  push @cmd, ($verbose > 2 ? "-nv" : "-q");
  push @cmd, "--debug" if ($verbose > 4);
  push @cmd, $url;

  print "$progname: executing: " . join (" ", @cmd) . "\n" if ($verbose > 2);

  if (system (@cmd) == 0) {

    # Touch the file so that its date is the current time, so that we
    # know when we last polled it -- rather than the last date it had
    # on the server.  (There doesn't seem to be an option to make
    # wget do this.)
    #
    utime ($now, $now, $hfile) || error ("$hfile: touch: $!");

    print STDERR "$progname: wrote $hfile\n" if ($verbose > 2);
  } else {
    print STDERR "$progname: error retrieving $url\n";
    unlink $hfile;
    $file = undef;
  }
  return $file;
}



# returns the parse rules associated with this URL:
#     ( parse_function, "site name", "site description",
#	"site logo image url", image_width, image_height,
#	expirey_minutes )
# 
sub get_filter_data {
  my ($url) = @_;
  my $ref = $filter_table{$url};
  error ("unknown URL: $url") unless defined ($ref);
  return @{$ref};
}


# Parses the given HTML into log entries, based on the parse function
# associated with the URL.  Returns a list of the form:
#
#  (  "site-title" "site-desc" "site-logo-img" img_width img_height
#     "entry-url-1" "entry-date-1" "entry-title-1" "entry-body-1"
#     "entry-url-2" "entry-date-2" "entry-title-2" "entry-body-2"
#     ... )
#
sub split_entries {
  my ($url, $html) = @_;

  $html = de_unicoddle ($html);    # convert UTF8 to Latin1

  my ($fn, $title, $desc, $rss_img, $rss_img_w, $rss_img_h, $expirey) =
    get_filter_data ($url);

  print STDERR "$progname: parsing \"$url\" with \"$title\" rules\n"
    if ($verbose > 3);

  my @entries = &$fn ($url, $html);
  return ($title, $desc,
          $rss_img, $rss_img_w, $rss_img_h,
          @entries);
}


# Parses the given HTML file into log entries, based on the parse function
# associated with the URL.  Writes an RSS file into the cache directory.
# Does not change the existing RSS file if there have been no changes.
#
sub convert_to_rss {
  my ($url, $html_file) = @_;

  my $rss_file = "$html_file.rss";

  $html_file = "$html_cache_dir/$html_file";
  $rss_file  = "$rss_output_dir/$rss_file";

  my $html = "";
  local *IN;
  open (IN, "<$html_file") || error ("$html_file: $!");
  while (<IN>) { $html .= $_; }
  close IN;

  # Check to see whether this file seems to be empty.
  # Strip out all HTML comments and tags, compress whitespace,
  # and count how many characters are left.
  #
  $_ = $html;
  1 while (s@<!--.*?-->@ @gsi);
  s@<(SCRIPT)\b[^<>]*>.*?</\1\s*>@@gsi;
  s/<[^<>]+>//gsi;
  s/\s+/ /gsi;
  error ("$html_file is empty") if ($html =~ m/^\s*$/s);
  error ("$html_file is almost empty")
    if (length($_) < 400 &&
        (! ($url =~ m/softerworld/)));

  my $items = '';

  my @entries = split_entries ($url, $html);

  my $rss_title = shift @entries;
  my $rss_desc  = shift @entries;
  my $rss_img   = shift @entries;
  my $rss_img_w = shift @entries;
  my $rss_img_h = shift @entries;

  my $count = 0;
  while ($#entries >= 0) {
    my $eurl  = shift @entries;
    my $date  = shift @entries;
    my $title = shift @entries;
    my $body  = shift @entries;

    $eurl  = expand_url  ($eurl,  $url);
    $date  = expand_urls ($date,  $url);
    $title = expand_urls ($title, $url);
    $body  = expand_urls ($body,  $url);

    $date =~ s/&/&amp;/g;  # de-HTMLify
    $date =~ s/</&lt;/g;
    $date =~ s/>/&gt;/g;

    $title =~ s/&/&amp;/g;  # de-HTMLify
    $title =~ s/</&lt;/g;
    $title =~ s/>/&gt;/g;

    $body =~ s/&/&amp;/g;  # de-HTMLify
    $body =~ s/</&lt;/g;
    $body =~ s/>/&gt;/g;

    $eurl =~ s/&/&amp;/g;

    my $item = ("<item>\n" .
                " <title>$title</title>\n" .
                " <link>$eurl</link>\n" .
                " <description>\n" .
                "  $body\n" .
                " </description>\n" .
                "</item>\n");

    $item =~ s/^/  /gm;

    print STDERR "$progname:   entry: " . ($title || $eurl) . "\n"
      if ($verbose > 3);

    if (++$count < $max_entries) {
      $items .= $item;
    }
  }

  error ("$html_file: no entries parsed!") if ($count <= 0);

  if ($verbose > 2) {
    if ($count > $max_entries) {
      print STDERR "$progname:  $count entries (trimmed to $max_entries)\n";
    } else {
      print STDERR "$progname: $count entries\n";
    }
  }

  my $pubdate = strftime ("%a, %e %b %Y %H:%M:%S GMT", gmtime);
  my $builddate = $pubdate;

  my $rurl = $url;
  $rurl =~ s/&/&amp;/g;

  my $rss = ("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n" .
             "<!DOCTYPE rss PUBLIC " .
             "\"-//Netscape Communications//DTD RSS 0.91//EN\" " .
             "\"http://my.netscape.com/publish/formats/rss-0.91.dtd\">\n" .
             "\n" .
             "<rss version=\"0.91\">\n" .
             " <channel>\n" .
             "  <generator>$progclass $version -- $progurl</generator>\n" .
             "  <title>$rss_title</title>\n" .
             "  <link>$rurl</link>\n" .
             "  <description>$rss_desc</description>\n" .
             "  <language>$rss_lang</language>\n" .
             "  <webMaster>$rss_webmaster</webMaster>\n" .
#            "  <managingEditor>$rss_editor</managingEditor>\n" .
             "  <pubDate>$pubdate</pubDate>\n" .
             "  <lastBuildDate>$builddate</lastBuildDate>\n" .
             ($rss_img
              ? ("  <image>\n" .
                 "   <title>$rss_title</title>\n" .
                 "   <url>$rss_img</url>\n" .
                 "   <width>$rss_img_w</width>\n" .
                 "   <height>$rss_img_h</height>\n" .
                 "   <link>$rurl</link>\n" .
                 "  </image>\n")
              : "") .
             $items .
             " </channel>\n" .
             "</rss>\n");

  # de-Windows-ify.  (convert common CP-1252 to ISO-8859-1.)
  #
  $rss =~ s/\205/ --/gs;
  $rss =~ s/\221/\`/gs;
  $rss =~ s/\222/\'/gs;
  $rss =~ s/\223/``/gs;
  $rss =~ s/\224/''/gs;
  $rss =~ s/\225/*/gs;
  $rss =~ s/\226/-/gs;
  $rss =~ s/\227/ --/gs;
  $rss =~ s/\230/~/gs;
  $rss =~ s/\240/ /gs;    # nbsp
  $rss =~ s/\201/E/gs;    # euro symbol?

  # strip out other unknowns, since some RSS parsers are super anal about it.
  $rss =~ s/[\000-\010\013-\037\177-\237]/?/gs;

  my $body = $rss;
  my $nbody = "$body";
  my $obody = "";


  local *IN;
  if (open (IN, "<$rss_file")) {
    while (<IN>) { $obody .= $_; }
    close IN;
  }

  # strip the dates out of both files, for comparison purposes
  #
  $nbody =~ s@<([a-z]+Date)>(.*?)</\1>@<$1>...</$1>@gsi;
  $obody =~ s@<([a-z]+Date)>(.*?)</\1>@<$1>...</$1>@gsi;

  if ($nbody eq $obody) {
    print STDERR "$progname: $rss_file unchanged\n" if ($verbose > 2);
  } else {
    local *OUT;
    open (OUT, ">$rss_file") || error ("$rss_file: $!");
    print OUT $body || error ("$rss_file: $!");
    close OUT || error ("$rss_file: $!");;
    print STDERR "$progname: wrote $rss_file\n" if ($verbose);
  }
}


# Downloads the given URL, and updates the RSS file if necessary.
#
sub scrape {
  my ($url) = @_;

  @_ =
    eval {
      $inside_eval_p = 1;
      my $html_file = pull_html ($url);
      return unless defined ($html_file);
      convert_to_rss ($url, $html_file);
      return ();
    };
  $inside_eval_p = 0;
  if ($@) {
    print STDERR "\n" if ($verbose);
    print STDERR "$progname: ERROR: " . join(' ', $@) . "\n";
    print STDERR "\n" if ($verbose);
    $@ = undef;
    return 1;
  } else {
    return 0;
  }
}


#############################################################################
#
# Site-specific parse functions
# These are referenced by the %filter_table at the top of the file.
#
#############################################################################


sub do_wilwheaton {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*<DIV\b[^<>]*\bCLASS=\"blog\"[^<>]*>\s*@@is ||
    error ("unable to trim head in $url");;
#  s@\s*<DIV\b[^<>]*\bCLASS=\"sidetitle\"[^<>]*>.*$@@is ||
#    error ("unable to trim tail in $url");
  s@\s*<HR\b[^<>]*>\s*<DIV\b[^<>]*>\s*<B>Archives</B>.*?$@@is ||
    error ("unable to trim tail in $url");

  # lose the dates: there is not a date per entry.
  s@<DIV\b[^<>]*\bCLASS=\"date\"[^<>]*>[^<>]*</DIV>\s*@@isg;

  my @sec1 = split (/\s*<DIV\b[^<>]*\bCLASS=\"blogbody\">\s*/i);
  my @sec2 = ();

  foreach (@sec1) {
    next if (m/^\s*$/s);
    s/[\r\n]/ /gs;

    s@^\s*<A\b[^<>]*\bNAME=\"blog\"[^<>]*>\s*(</A>)?\s*@@is;

    s@^\s*<A\b[^<>]*\bNAME=\"([^<>\"]+)\"[^<>]*>\s*(</A>)?\s*@@is ||
      error ("unparsable entry (anchor) in $url");
    my $anchor = $1;

    s@^\s*<SPAN\b[^<>]*\bCLASS=\"title\"[^<>]*>\s*(.*?)\s*</SPAN>\s*@@is ||
      error ("unparsable entry (title) in $url");
    my $title = $1;

    # lose the "posted" class, with the JS comments thingy
    s@<DIV\b[^<>]*\bCLASS=\"posted\"[^<>]*>.*?</DIV>\s*@@isg;

    # lose the last /div
    s@\s*</DIV>\s*$@@is;
    s@\s+$@@s;

    my $body = $_;

    my $eurl = "$url\#$anchor";

    $title =~ s@</?H\d\b[^<>]*>@@gsi;  # lose H tags in title

    my $date = '';
    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


sub do_thismodernworld_blog {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?<DIV\b[^<>]*\bCLASS=\"posts\"[^<>]*>\s*@@is ||
    error ("unable to trim head in $url");
  s@\s*<DIV\b[^<>]*\bCLASS=\"mt\"[^<>]*>.*$@@is ||
    error ("unable to trim tail in $url");

  s@(<A\b[^<>]*\bNAME=\"\d+\"[^<>]*>)@\n\001\001\001\n$1@gi;

  my @sec1 = split (/\n\001\001\001\n/s);
  my @sec2 = ();
  foreach (@sec1) {
    next if (m/^\s*$/s);
    s/[\r\n]/ /gs;

#    next if (m/^(<[pb]>\s*)*Attention Tom-Mart Shoppers/i);  # kludge...
#    next if (m/^(<[pb]>\s*)*Support this site!</i);          # kludge...
#    next if (m/^(<[pb]>\s*)*New design in the store:</i);    # kludge...
#    next if (m/^(<[pb]>\s*)*THE GREAT BIG BOOK OF /i);       # kludge...
    next unless (m/^\s*<A NAME=/i);

    # lose any embedded dates (they occur only daily, not per entry)
    s@\s------+\s*<DIV\b[^<>]*CLASS=\"date\"[^<>]*>.*?</DIV>\s*@@is;

    # lose "posts" class
    s@\s*<DIV\b[^<>]*CLASS=\"posts\"[^<>]*>\s*@@is;

    s@^\s*<A\b[^<>]*?\bNAME=\"([^<>\"]+)\"[^<>]*>\s*</A>\s*@@is ||
      error ("unparsable entry (anchor) in $url");
    my $anchor = $1;
    my $date   = "";

    s@^\s*<DIV\b[^<>]*?\bCLASS=\"title\"[^<>]*>\s*(.*?)\s*</DIV>\s*@@is ||
      error ("unparsable entry (title) in $url");
    my $title  = $1;
    $title =~ s@</?B>@@gi;

    m@<A HREF=\"([^\"]+)\"[^<>]*>[^a-z<>]*\blink\b\s*</A>@i ||
      error ("unparsable entry (link) in $url");
    my $eurl = $1;

    # lose trailing P and /DIV
    1 while (s@\s*</?(P|DIV)\b[^<>]*>\s*$@@is);
    s@\s*</DIV>\s*$@@is;

    # lose trailing crap on last entry, so it doesn't update every
    # time something falls off the log.
#    s@</div>.*?$@@is;

    my $body = $_;

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


# from salon.com, which no longer works
sub do_thismodernworld_comic {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s@[\r\n]+@ @gs;
  s@(<A\b)@\n$1@igs;

  my @sec = ();
  foreach (split (/\n/)) {
    next unless m@/comics/tomo/@;
    next unless m@Tom Tomorrow@;
    s@<A\b[^<>]*\bHREF=\"([^\"]+)\"[^<>]*>@@i
      || error ("unparsable entry (href) in $url");
    my $eurl = $1;
    my $date = "";

    s@<SCRIPT[^<>]*>.*?</SCRIPT>@@gi;

    s@<[^<>]*>@ @g;

    s@^\s*@@s; s@\s*$@@s;
    my @text = split (/\s\s+/);

#    my $title = "$text[0]: $text[1]";
    my $title = "$text[1]";

    $eurl =~ s@/index\.html$@/@;

    my $iurl = $eurl;
    $iurl .= "story.jpg";

    my $body = "<IMG SRC=\"$iurl\">";

    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


# from workingforchange.com
sub do_thismodernworld_comic2 {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s@</?(TR|TD|TABLE|FONT|B|I|H\d)\b[^<>]*>\s*@@gsi;  # lost most tags
  s@&nbsp;@ @g;
  s@[\r\n]+@ @gs;
  s@(<A\b)@\n$1@igs;

  my @sec = ();
  foreach (split (/\n/)) {
    next unless m@<A[^<>]*\bHREF=\"([^<>\"]+)\"[^<>]*>\s*
                  This\s+Modern\s+World:\s*([^<>]+)(.*)@xi;
    my $eurl = $1;
    my $title = $2;
    my $rest = $3;
    $_ = $rest;
    my ($mm, $dd, $yy) = m@\b(\d\d?)\.(\d\d?)\.(\d\d)\b@;
    error ("noo date?") unless ($yy);
    my $date = sprintf("%02d-%02d-%04d", $yy+2000, $mm, $dd);

    $mm = sprintf("%02d", $mm);
    $dd = sprintf("%02d", $dd+1);  # don't ask me, man...

    my $iurl = ("http://workingforchange.speedera.net/" .
                "www.workingforchange.com/webgraphics/wfc/" .
                "TMW$mm-$dd-$yy.gif");

    my $body = "<IMG SRC=\"$iurl\">";

    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_diepunyhumans {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?<DIV\b[^<>]*\bCLASS=\"blogbody\"[^<>]*>\s*@@is ||
    error ("unable to trim head in $url");
  s@\s*<DIV\b[^<>]*\b(CLASS|ID)=\"links\"[^<>]*>.*$@@is ||
    error ("unable to trim tail in $url");

  s@(<A\b[^<>]*\bNAME=\"\d+\"[^<>]*>)@\n\001\001\001\n$1@gi;

  my @sec1 = split (/\n\001\001\001\n/s);
  my @sec2 = ();
  foreach (@sec1) {
    next if (m/^\s*$/s);
    s/[\r\n]/ /gs;

    # lose any embedded dates (they occur only daily, not per entry)
    s@\s(--+\s*)?<(DIV|H\d)\b[^<>]*CLASS=\"date\"[^<>]*>.*?</(DIV|H\d)>\s*@@is;

    # lose "posts" class
    s@\s*<DIV\b[^<>]*CLASS=\"posts\"[^<>]*>\s*@@is;

    s@^\s*<A\b[^<>]*?\bNAME=\"([^<>\"]+)\"[^<>]*>\s*</A>\s*@@is ||
      error ("unparsable entry (anchor) in $url");
    my $anchor = $1;
    my $date   = "";

    # try for a title on the first line
    my $title = $_;
    $title =~ s@^(\s*</?(P|BR)[^<>]*>)+\s*@@si;
    $title =~ s@</?(P|BR)[^<>]*>.*$@@si;
    $title =~ s@<[^<>]*>@ @gs;
    $title =~ s@^(.{20}.*?([:;.?!]+|\s-+)).*@$1@si;
    $title =~ s@^\s+@@;
    $title =~ s@\s+$@@;
    $title = 'Die Puny Humans' if ($title eq '');

    m@<A HREF=\"([^\"]+)\"[^<>]*>\s*\d\d?:\d\d\s*[AP]M\s*</A>@i;
    my $eurl = $1 || "\#$anchor";

    # lose trailing P and /DIV
    1 while (s@\s*<P\b[^<>]*>\s*$@@is);
    s@\s*</DIV>\s*$@@is;

    # lose trailing byline
#    s@\s*<SPAN\b[^<>]*\bCLASS=\"byline\"[^<>]*>.*?</SPAN>\s*@@is;
    s@\s*<DIV\b[^<>]*\bCLASS=\"posted\"[^<>]*>.*?</DIV>\s*@@is;

    # lose trailing Ps, BRs and /DIVs
    1 while (s@\s*</?(P|BR|DIV)\b[^<>]*>\s*$@@is);

    my $body = $_;

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


sub do_straightdope {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?>\s*Current Columns\s*<[^<>]*>@@is ||
    error ("unable to trim head in $url");
  s@\s*</TABLE\b.*$@@is ||
    error ("unable to trim tail in $url");

  s@^.*?<TR[^<>]*>@@si;

  s@</?(TR|TD|TABLE|B|I|H\d)\b[^<>]*>\s*@@gsi;  # lost most tags

  s@[\r\n]+@ @gs;
  s@(<A\b)@\n$1@gsi;

  my @sec = ();
  foreach (split (/\n/)) {
    next unless m@<A\b@i;
    s@<A\b[^<>]*\bHREF=\"([^\"]+)\"[^<>]*>(.*?)</A>(.*)$@@i
      || error ("unparsable entry (href) in $url");
    my $eurl  = $1;
    my $date  = $2;
    my $title = $3;

    my $rtitle = $date;
    my $rbody  = $title;

    my $body  = "<A HREF=\"$eurl\">$rbody</A>";

    unshift @sec, ($eurl, $date, $rtitle, $body);
  }

  return @sec;
}


sub do_pornclerk {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@[\r\n]+@ @gs;
  s@&nbsp;@ @gs;
  s@\s+@ @gs;

  s@(<TD\b)@\n$1@gsi;

  my @sec = ();
  foreach (split (/\n/)) {

    next unless (m@\bPosted on@i);

    s@</?(TR|TD|TABLE|FONT|IMG)\b[^<>]*>\s*@ @gsi;  # lost table-related tags

    s@<A\b[^<>]*\bNAME=\"([^<>\"]+)\"[^<>]*></A>@@si
      || error ("unparsable entry (anchor) in $url");
    my $anchor = $1;

    s@\s+@ @gs;

    s@^(.*?)<BR>\s*Posted on (.*?)\s+<P>\s+@@si
      || error ("unparsable entry (title) in $url");
    my $title = $1;
    my $date  = $2;

    $title = " $title";  # kludge to avoid re-posting everything:
                         # stay compatible with the previous version.

    # delete some left over cruft...
    s@<A\b[^<>]*\bHREF=\"[a-z]+\.php[^<>\"]+\"[^<>]*>(.*?)</A>@$1@gsi;

    my $body  = $_;
    $title =~ s@<[^<>]*>@@g;  # lose tags in title

    my $eurl = "$url\#$anchor";

    unshift @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_bondagefiles {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s/[\r\n]+/ /gs;

  s@^.*?(<A HREF=\"[^\"]*article\.cgi)\b@$1@is ||
    error ("unable to trim head in $url");
  s@<[^<>]*\bblacktri\.gif\b.*$@@is ||
    error ("unable to trim tail in $url");

  s@(<A\b[^<>]*\bHREF\b)@\n\001\001\001\n$1@gi;

  my @sec1 = split (/\n\001\001\001\n/s);
  my @sec2 = ();
  foreach (@sec1) {
    next if (m/^\s*$/s);

    s@^\s*<A\b[^<>]*?\bHREF=\"([^<>\"]+)\"[^<>]*>\s*(.*?)\s*</A>\s*@@is ||
      error ("unparsable entry (url) in $url");
    my $eurl  = $1;
    my $title = $2;
    my $date  = '';
    my $body  = $_;

    $body =~ s@<[^<>]*>@@g;  # lose tags in body

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


# generate a multi-entry RSS file with links to each picture,
# but without inline images.
#
sub do_apod_link {
  my ($url, $html) = @_;

  $url =~ s@/[^/]*$@/@;  # take off last path component

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?</center>\s*@@is || error ("unable to trim head in $url");
  s@\s*<hr>.*?$@@is      || error ("unable to trim tail in $url");

  my @sec = ();
  foreach (split (/\n/)) {
    next unless m@<A\b@i;
    s@^(.*):\s*<A\b[^<>]*\bHREF=\"([^\"]+)\"[^<>]*>(.*?)</A>.*$@@i
      || error ("unparsable entry in $url");
    my $date  = $1;
    my $eurl  = $2;
    my $title = $3;

    my $rtitle = $date;
    my $rbody  = $title;

    my $body  = "<A HREF=\"$eurl\">$rbody</A>";
    push @sec, ($eurl, $date, $rtitle, $body);
  }

  return @sec;
}


# generate a single-entry RSS file with an inline image.
#
sub do_apod_inline {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s/[\r\n]+/ /gs;

  s@^.*?discover the cosmos.*?<p>\s*@@si ||
    error ("unable to trim head in $url");

  s@</?(p|br)>\s*(<[^<>]+>\s*)*Tomorrow\'s picture:.*?$@@ ||
    error ("unable to trim tail in $url");

  s@^(\s*<[^<>]+>\s*)+@@s; # lose leading tags
  s@^\s*((\d{4})[- ]([a-z]+)[- ](\d\d?))\b\s*(<(BR|P)>\s*)*@@i ||
    error ("$url: unable to find date");

  my $date  = $1;
  my $year  = $2;
  my $month = $3;
  my $dotm  = $4;

  s@</?(TR|TD|TABLE)\b[^<>]*>\s*@@gsi;  # lose table tags
  my $body = $_;

  my %m = ( "Jan" => 1, "Feb" => 2,  "Mar" => 3,  "Apr" => 4,
            "May" => 5, "Jun" => 6,  "Jul" => 7,  "Aug" => 8,
            "Sep" => 9, "Oct" => 10, "Nov" => 11, "Dec" => 12);
  $month =~ s/^(...).*/$1/;
  $month = $m{$month} || error ("unparsable month: $month");

  my $eurl = $url . sprintf ("ap%02d%02d%02d.html",
                             $year % 100, $month, $dotm);

  s@<(P|BR)\b[^<>]*>@\n@gsi;  # expand newlines
  s@<[^<>]*>@@g;              # lose other tags

  my ($title) = m@^\s*(.*?)\s*$@m;

  return ($eurl, $date, $title, $body);
}


sub do_redmeat {
  my ($url, $html) = @_;

  $url =~ s@/[^/]*$@/@;  # take off last path component

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@[\r\n]+@ @gs;

  s@^.*?(<LI)@$1@is || error ("unable to trim head in $url");
  
  s@(<LI)@\n$1@gsi;

  my @sec = ();
  foreach (split (/\n/)) {
    next unless m@<A\b@i;
    s@</UL\b.*$@@is;
    s@^.*<A\b[^<>]*\bHREF=\"([^\"]+)\"[^<>]*>(.*?)</A>.*$@@i
      || error ("unparsable entry in $url");
    my $eurl  = $1;
    my $title = $2;

    $_ = $eurl;
    my ($date) = m@\b(\d{4}-\d{2}-\d{2})\b@;
    $date = '' unless $date;

    $eurl =~ s@/index\.html?$@/@i;

    my $rbody = ("<DIV STYLE=\"background: \#FFF\">" .
                 "<IMG SRC=\"$eurl/index-1.gif\" BORDER=0 HSPACE=8 VSPACE=8>" .
                 "</DIV>");
    my $body  = "<A HREF=\"$eurl\">$rbody</A>";
    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_webster_wotd {
  my ($url, $html) = @_;

  $_ = $html;

  s@^.*?<!-- End wordtop[^>]*>@@is
    || error ("unable to trim head in $url");
  s@<!-- Begin wordbot[^>]*>.*$@@is
    || error ("unable to trim tail in $url");

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@&nbsp;@ @gsi;
  s@[\r\n]+@ @gs;

  # lose javascript
  s@javascript:popWin\([\'\"]([^\'\"()]+)[\'\"]\)@$1@gsi;
  error ("javascript still present") if (m@javascript:@i);

  s@</?(FONT|TABLE|TR|TD|IMG)[^<>]*>@@gsi;  # lose fonts and table tags
  1 while (s@</?(BR|P)[^<>]*>\s*</?(BR|P)[^<>]*>\s*@<P>@gsi); # compress P, BR

  # lose now-redundant A tags
  s@<A\b[^<>]*>\s*</A\b[^<>]*>@@gsi;

  # lose heading
  s@^\s*Merriam-Webster's Word of the Day\s*(<P[^<>]*>\s*)?@@si;

  # compress spaces
  s@\s+@ @gs;

  my $body = "$_";

  s@<[^<>]*>@@g;  # lose tags

  m@the\s+word\s+(?:of|for)?\s+the\s+day\s+for\s+([a-z]+\s+\d+)
    (?:\s+is)?\s*:\s*([^\s]+)\b@ix
      || error ("unparsable entry in $url");
  my $date = $1;
  my $title = $2;

  $title = "Word of the Day: $title";
  return ($url, $date, $title, $body);
}


sub do_space_com {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  1 while (s@<SCRIPT\b[^<>]*>.*?</SCRIPT\b[^<>]*>@@gsi);  # lose javascript

  s@[\r\n]+@ @gs;

  s@(<TR\b)@\n$1@gsi;

  my @sec = ();
  foreach (split (/\n/)) {
    s@</TR\b.*$@@is;

    next unless m@<TR\b@i;
    next unless m@<IMG\b@i;
    next unless m@<A\b@i;

    s@</?(TABLE|TD|TR)\b[^<>]*>@@gsi;

    m@^.*<A\b[^<>]*\bHREF=\"([^\"]+)\"[^<>]*>@i
      || error ("unparsable entry (url) in $url");
    my $eurl = $1;

    m@^.*<IMG\b[^<>]*\bSRC=\"([^\"]+)\"[^<>]*>@i
      || error ("unparsable entry (image) in $url");
    my $img = $1;

    next if ($eurl =~ m@(/navigation|/template|doubleclick)@i);
    next if ($img  =~ m@(/navigation|/template|doubleclick)@i);

    # now let's munge the HTML a little...
    s@(<IMG )@$1ALIGN=LEFT @igs;
    s@</?FONT\b[^<>]*>@@igs;
    $_ .= "<BR CLEAR=LEFT>";

    my $body = $_;
    my $date = '';   # note: could parse this from $eurl pathname

    s@<(BR|P)\b[^<>]*>@\n@gsi;  # put newlines back
    s@<[^<>]*>@@gs;             # lose all tags
    s@\n.*$@@s;                 # delete all but first line
    my $title = $_;

    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_memepool {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?\[ recent \]@@is
    || error ("unable to trim head in $url");
  s@\bCopyright &copy; [-\d ]+ Memepool\.Com\b.*$@@is
    || error ("unable to trim tail in $url");

  s@[\r\n]+@ @gs;

  s@(<TR\b)@\n$1@gsi;

  my $last_date = '';

  my @sec = ();
  foreach (split (/\n/)) {
    s@</TR\b.*$@@is;

    next unless m@<TR\b@i;

    s@(<TD)\b@\n$1@gsi;
    s@</?(TABLE|TD|TR)\b[^<>]*>@@gsi;
    s@&nbsp;@ @gs;

    s@^\s*@@gsi;
    s@\s*$@@gsi;
    s@[ \t]+@ @gsi;

    s@^([^\n]+)\n@@ || error ("unparsable entry (first line) in $url");
    my $date = $1;
    s@\s+@ @gs;

    $date =~ s@<[^<>]+>@ @g;
    $date =~ s@\s+@ @g;

    if ($date =~ m/^\s*$/gs) {
      $date = $last_date;
    } else {
      $date =~ m@^\s*\b[a-z]+day,? ([a-z]+ \d+, \d{4}\b)\s*$@si
        || error ("unparsable entry (date) in $url");
      $date = $1;
    }

    my $eurl = "\#$date";     # not really in the src, but we need uniqueness
    $eurl =~ s@[^\#a-z\d]+@_@gi;

    s@</?FONT\b[^<>]*>@@igs;  # fucking color changes!

    my $body = $_;
    my $title = $date;

    next if $body =~ (m/^\s*$/);

    push @sec, ($eurl, $date, $title, $body);

    $last_date = $date;
  }

  # make another pass through the list to make sure that there are no
  # duplicate date strings.  We add "2", "3", etc onto the more recent
  # ones to differentiate them -- but this needs to be done in a second
  # pass, since the newer ones come at the top (so, the top down order
  # is "date 3", "date 2", "date".)
  #
  $last_date = '';
  my @sec2 = ();
  my $tick = 1;
  while ($#sec >= 0) {
    my $body  = pop @sec;
    my $title = pop @sec;
    my $date  = pop @sec;
    my $eurl  = pop @sec;

    my $date2 = $date;
    if ($date eq $last_date) {
      $tick++;
      $date2 .= "_$tick";
      $eurl  .= "_$tick";
      $title .= " \#$tick";
    } else {
      $tick = 1;
    }

    unshift @sec2, ($eurl, $date2, $title, $body);
    $last_date = $date;
  }

  return @sec2;
}


# generate a multi-entry RSS file with links to each episode,
# but without inline images.
#
sub do_catandgirl_index {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s/[\r\n]+/ /gs;

  s@(<A\b)@\n$1@gsi;

  #### delete me after a while
  my $kludge_max = 2;
  my $count = 0;

  my @sec = ();
  foreach (split (/\n/)) {
    m@^<A\b[^<>]*?\bHREF=\"(view\.cgi\?\d+|index\.cgi)
                         \"[^<>]*>\s*([^<>]*?)\s*</A>@xis ||
      next;
    my $eurl  = $1;
    my $title = $2;
    my $date  = '';
    my $body = "<A HREF=\"$eurl\">$title</A>";
    $title =~ s@<[^<>]+>@@gs;  # lose tags in title

    push @sec, ($eurl, $date, $title, $body);

    #### delete me after a while
    last if (++$count >= $kludge_max);
  }

  if ($sec[0] =~ m/index\.cgi/) {
    $_ = $sec[4];
    m/\?(\d+)\b/i || error ("can't find number of first entry?");
    my $n = $1 + 1;
    $sec[0] =~ s/index\.cgi/view.cgi?$n/g;  # url
    $sec[3] =~ s/index\.cgi/view.cgi?$n/g;  # body
  }

  return @sec;
}


# generate a single-entry RSS file with an inline image of the latest cartoon.
#
sub do_catandgirl_inline {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s/[\r\n]+/ /gs;

  s@(<(A|IMG)\b)@\n$1@gsi;

  my $number = 0;
  my ($eurl, $title, $body);
  foreach (split (/\n/)) {

    if (m@^<A\b[^<>]*\bHREF=\"(view\.(cgi|php)\?)(loc=)?(\d+)\"@i) {
      my $base = $1;
      my $n = $4;
      if ($n > $number) {
        $number = $n + 1;
        $eurl = $base . $number;
      }

    } elsif (m@^<IMG\b[^<>]*\bSRC=\"([^<>\"]+)\"[^<>]*\bALT=\"([^<>\"]+)\"@i) {
      my ($img, $alt) = ($1, $2);
      s/>.*$/>/s;
      if ($img =~ m@\barchive/@) {
        $body = $_;
        $title = $alt;
      }
    }
  }

  error ("couldn't find image number? ($number) in $url")
    unless ($number > 123);
  error ("couldn't find image in $url") unless (defined ($body));

  my $date = '';
  return ($eurl, $date, $title, $body);

}


sub do_geisha_asobi {
  my ($url, $html) = @_;

  $_ = $html;

  s@\r\n@\n@gs;
  s@\r@\n@gs;

  s@^.*<!-- start of content of your blog -->@@is ||
    error ("unable to trim head in $url");
  s@<!-- end of content of your blog -->.*$@@is ||
    error ("unable to trim tail in $url");

  s@^.*?(<!--TIME-->)@$1@is ||
    error ("unable to trim head-2 in $url");

  s@<!--TIME-->(\s*<TABLE)@<!--TIMEA-->$1@gsi;  # make start/end differ
  s@<!--TIMEA-->.*?<!--TIME-->@@gis;

  s@\s+@ @gs;  # lose newlines, compress whitespace

  s@<HR\b[^<>]*>@\n@gsi;

  my @sec = ();
  foreach (split ('\n', $_)) {
    next if (m/^\s*$/s);

    s@</?FONT\b[^<>]*>@@gsi;   # lose fonts
    s@(<A\b[^<>]*?)\s*\bTARGET=\"?[^<>\"]+\"@$1@gsi;   # lose TARGETs in A

    s/\s+/ /gs;
    s/^\s+//gs;
    s/\s+$//gs;

    my $body = $_;

    m@\bposted by .* (on|at)\s+<A HREF=\"([^<>\"]+)\">([^<>]+)</A>@i ||
      error ("unparsable time in $url");
    my ($eurl, $date) = ($2, $3);
    $date =~ s/\s+$//g;
    $date =~ s/^\s+//g;

    # try for a title on the first line
    my $title = $body;
    $title =~ s@<(BR|P|IMG)\b[^<>]*>@\n@gsi;
    $title =~ s@</A\b.*$@@gmi;
    $title =~ s@<[^<>]*>@ @gs;
    $title =~ s@^[ \t]*@@;
    $title =~ s@[ \t]*$@@;
    $title =~ s@\n.*$@@s;
    $title =~ s@\s+$@@s;

    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_savagelove {
  my ($url, $html) = @_;

  $_ = $html;

  my ($eurl) = m@<A\s+HREF=\s*\"(/\d{4}-\d\d-\d\d/savage\.html)\"@i;
  error ("unable to find url $url") unless ($eurl);

  s@^.*?<!-- Main Content Table[^>]*>@@is
    || error ("unable to trim head in $url");
  s@<!-- End Story[^>]*>.*$@@is
    || error ("unable to trim tail in $url");

  1 while (s@<!--.*?-->@ @gsi);           # lose comments
  s@</?(TABLE|TD|TR|FONT)\b[^<>]*>@@gsi;  # lose tables, fonts
  s@^\s*@@gs;
  s@\s*$@@gs;
  s@\s+@ @gs;

  s@(<BR>\s*)+(<P)@$2@gsi;                        # lose BR before P
  s@(<P\b[^<>]*>)(\s*<(P|BR)\b[^<>]*>)+@$1@gsi;   # lose BR after P

  # capitalize the title (the first non-whitespace text between tags.)
  s@^\s*(<[^<>]+>\s*)*([^<>]+)@$1 . capitalize($2)@se;

  my $body = "$_";

  s@<(BR|P)\b[^<>]*>@\n@gsi;  # add newlines
  s@<[^<>]*>@@g;              # lose tags

  s@^\s+@@gs;
  s@\n.*$@@gs;
  my $title = $_;
  my $date = '';

  # These articles are generally really long, so instead of the full body,
  # let's just use the first N words.
  my $n = 60;
  $body =~ s@^((\s*[^\s]+\s+){$n}).*$@$1@s;
  $body .= "...</I><BR><A HREF=\"$eurl\">( ...more... )</A>";

  return ($eurl, $date, $title, $body);
}


sub do_penn {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s/\s+/ /gs;

  s@<A HREF="\([^\"]*\)\">@@gi;  # bogosity

  s/(<A\s+[^\s<>])/\n$1/gi;
  s@(</?UL)@\n$1@gi;

  my @sec = ();
  foreach (split (/\n/)) {
    last if ($#sec > 0 && m@</UL@i);
    next unless (m/^<A\b/i);
    next if (m/<IMG/i);
    my ($eurl) = m@<A\s+HREF\s*=\s*\"([^<>\"]+)\"@i;
    error ("unable to find url: $url") unless ($eurl);

    $_ =~ s@<[^<>]+>@@g;
    my ($title, $date) = m@^(.+)(\d\d?[\s/]+\d\d?[\s/]+\d+)[^a-z\d]+$@;
    error ("unable to find title: $url $_") unless ($title);
    error ("unable to find date: $url") unless ($date);

    $title =~ s@^\s+@@s;
    $title =~ s@[^a-z]+$@@s;

    $date =~ s@^\s+@@s;
    $date =~ s@\s+$@@s;

    my $body = "<A HREF=\"$eurl\">$title ($date)</A>";

    push @sec, ($eurl, $date, $title, $body);
  }

  return @sec;
}


sub do_gywo {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s/\s+/ /gs;
  s/(<A\s+[^\s<>])/\n$1/gi;
  s@(</?UL)@\n$1@gi;

  s/\bposted\b.*$//gsi;

  my @sec = ();
  foreach (split (/\n/)) {
    next unless (m/^<A\b/i);
    my ($eurl) = m@<A\s+HREF\s*=\s*\"([^<>\"]+)\"@i;
    next unless ($eurl && $eurl =~ m/\bwar(\d+)\.html$/);
    my $n = $1;

    my $title = "get your war on page $n";
    my $date  = "";
    my $body = "<A HREF=\"$eurl\">$title</A>";

    unshift @sec, ($eurl, $date, $title, $body);
  }
  return @sec;
}


sub do_cringely {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s/\s+/ /gs;

  s@^.*<H\d[^<>]*>\s*20\d\d\s+Archive\b@@gsi
    || error ("unable to trim head in $url");
  s@^.*<TABLE[^<>]*>@@gsi
    || error ("unable to trim head2 in $url");
  s@</TABLE>.*$@@gsi
    || error ("unable to trim tail in $url");

  s@(<TR)\b@\n$1@gsi;

  my @sec = ();
  foreach (split (/\n/)) {
    my ($vers, $date, $title) = m@^\s*<TR[^<>]*>
				   \s*<TD[^<>]*> (.*?) </TD[^<>]*>
				   \s*<TD[^<>]*> (.*?) </TD[^<>]*>
				   \s*<TD[^<>]*> (.*?) </TD[^<>]*>@xsi;
    next unless defined ($title);

    $title =~ s@<(P|BR)\b[^<>]*>@ @gsi;
    my $body = "$vers: $title";
    $body =~ s@(<A)@<BR>$1@i;

    $_ = $body;
    my ($eurl) = m@<A\s+HREF\s*=\s*\"([^<>\"]+)\"@i;
    $title =~ s@<[^<>]*>@@g;

    push @sec, ($eurl, $date, $title, $body);
  }
  return @sec;
}


sub do_slashdot {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s/\s+/ /gs;

  s@^.*>\s*Submit\s+Story\s*<@@gsi
    || error ("unable to trim head in $url");
  s@^.*?</TABLE[^<>]*>.*?(<TABLE)@$1@gsi
    || error ("unable to trim head2 in $url");

  s@(<TABLE)\b@\n$1@gsi;
  s@\n\n+@\n@gsi;
  s@^\n+@@gsi;

  s@</?(IMG|FONT)[^<>]*>@@gsi;                  # lose IMG and FONT tags
  s@\s*<A\b[^<>]*>\s*</A>\s*@@gsi;              # lose null A blocks
  s@(</?(TABLE|TR|TD))[^<>]*>@$1>@gsi;          # lose TABLE parameters
  
  # double up TABLEs
  s@(<TABLE>.*?</TABLE>)\s*(<TABLE>.*?</TABLE>)@$1 $2@gsi;

  s/\&middot;.*$//s;  # sleazy way to kill tail

  my @sec = ();
  foreach (split (/\n/)) {

    my ($title, $body) = m@^\s*<TABLE>
                            \s* <TR>
			    \s*  <TD[^<>]*> (.*?) </TD[^<>]*>
                            \s* </TR>
                            \s*</TABLE>
                            \s*<TABLE> .*? </TABLE>
                            (.*) $@xsi;
    next unless defined ($title);
    next unless ($title =~ m@^\s*<B>.*</B>\s*$@si);

    $title =~ s@</?B>@@gsi;

    $_ = $body;
    my ($eurl) = m@<A\s+HREF\s*=\s*\"([^<>\"]+)\"[^<>]*>\s*<B>\s*Read More@i;
    error ("unable to find entry URL in $url") unless defined ($eurl);

    $eurl =~ s@^//@http://@;   # wtf?

    $_ = $eurl;
    my ($host, $article_id) =
      m@^(http://[^/]+).*?/(\d+/\d+/\d+/\d+)\.s?html@;
    error ("unable to find article ID in $eurl") unless defined ($article_id);
    $eurl = "$host/article.pl?sid=$article_id";

    $body =~ s@<B>\(</B> .*? Read\sMore .* <B>\)</B> .*$@@xsi
      || error ("unable to trim entry tail in $url");

    1 while ($body =~ s@\s*<P\b[^<>]*>\s*$@@gsi);

    $_ = $body;
    my $first_line;
    m@^(.*?)\s*<BR>\s*(.*)$@ || error ("no first line in entry in $url?");
    $first_line = $1;
    $body = $2;

    $_ = $first_line;
    s@</?[BI]>@@gsi;
    my ($posted_by, $date) =
      m@^(.*? Posted\sBy .*? ) \s* \bon\b ( .* )$@xsi;
    error ("unable to parse posted-by in $url") unless defined ($date);

    $body = "<B>$posted_by </B> $body";

    $_ = $body;
    $title =~ s@<[^<>]*>@@g;

    push @sec, ($eurl, $date, $title, $body);
  }
  return @sec;
}


sub do_dnasty {
  my ($url, $html) = @_;

  # a Blogger variant

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?<DIV\b[^<>]*\bID=\"mainClm\"[^<>]*>\s*@@is ||
    error ("unable to trim head in $url");
  s@<P\b[^<>]*\bID=\"bloggerBug\"[^<>]*>.*$@@is ||
    error ("unable to trim tail in $url");

  # lose the dates: there is not a date per entry.
  s@<H3\b[^<>]*>[^<>]*</H3>\s*@@isg;

  my @sec1 = split (/\s*<DIV\b[^<>]*\bCLASS=\"blogPost\">\s*/i);
  my @sec2 = ();
  foreach (@sec1) {
      next if (m/^\s*$/s);
    s/[\r\n]/ /gs;

    s@\s*<A\b[^<>]*?\bHREF=\"([^<>\"]+)\"[^<>]*?permanent \s link
      [^<>]*>([^<>]*?)</A>\s*@@xis ||
      error ("unparsable entry (anchor) in $url");
    my $eurl = $1;
    my $date = $2;

    # try for a title on the first line
    my $title = $_;
    $title =~ s@^(\s*</?(P|BR)[^<>]*>)+\s*@@si;
    $title =~ s@</?(P|BR)[^<>]*>.*$@@si;
    $title =~ s@<[^<>]*>@ @gs;
    $title =~ s@^(.{20}.*?([:;.?!]+|\s-+)).*@$1@si;
    $title =~ s@^\s+@@;
    $title =~ s@\s+$@@;

    # lose trailing P and /DIV
    1 while (s@\s*<P\b[^<>]*>\s*$@@is);
    s@\s*</DIV>\s*$@@is;

    # lose trailing byline
    s@\s*<DIV\b[^<>]*\bCLASS=\"byline\"[^<>]*>.*?</DIV>\s*@@is;

    # lose trailing Ps, BRs and /DIVs
    1 while (s@\s*</?(P|BR|DIV)\b[^<>]*>\s*$@@is);

    my $body = $_;

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


sub do_slumberinglungfish {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@^.*?<P\b[^<>]*\b(CLASS|ID)=\"headmed\"[^<>]*>\s*@@is ||
    error ("unable to trim head in $url");
  s@\s*</TD[^<>]*>.*?$@@is ||
    error ("unable to trim tail in $url");

  s@\s+@ @gsi;
  s@(\s*<P\b[^<>]*\bCLASS=\"dateline\">\s*)@\n$1@gsi;

  my @sec1 = split (/\n/);
  my @sec2 = ();

  shift @sec1;

  foreach (@sec1) {
    next if (m/^\s*$/s);

    s@<P CLASS=\"dateline\">(.*?)\s*(<A\b\s*)@$2@i ||
      error ("unparsable date in $url");
    my $date = $1;

    s@^\s*<A\b[^<>]*?\bHREF=\"([^<>\"]+)\"[^<>]*>\s*(.*?)\s*</A>@@is ||
      error ("unparsable entry (anchor) in $url");
    my $eurl = $1;
    my $title = $2;

    my $body = $_;

    # lose leading/trailing P, BR, and DIV
    1 while ($body =~ s@^\s*</?(P|BR|DIV)\b[^<>]*>\s*@@is);
    1 while ($body =~ s@\s*</?(P|BR|DIV)\b[^<>]*>\s*$@@is);

    $date =~ s/<[^<>]*>/ /gsi;
    $date =~ s/\s+/ /gs;

    # his urls have ctimes in them - use that instead
    if ($eurl =~ m/\.(\d+)$/) {
      $date = strftime ("%a %b %e %H:%M:%S %Y %Z", localtime($1));
    }

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


sub do_linkfilter {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@&nbsp;@ @gs;
  s@\s+@ @gsi;
  s@\s*(<TD\b[^<>]*?\bCLASS=\"td-head\">)\s*@\n$1@gsi;

  my @sec1 = split (/\n/);
  my @sec2 = ();

  shift @sec1;

  foreach (@sec1) {
    next if (m/^\s*$/s);

    s@^\s*<TD\b[^<>]*>\s*@@si || error ("no TD in entry in $url");

    s@^\s*<A\b[^<>]*?\bHREF=\"([^<>\"]+)\"[^<>]*>\s*(.*?)\s*</A>@@is ||
      error ("unparsable entry (anchor) in $url");
    my $eurl = $1;
    my $title = $2;

    $eurl =~ s@;cmd=go$@@;  # bah.

    s@(</?)(SPAN|TD|TR)\b[^<>]*>@$1P>@gsi;  # fuck SPAN

    # lose the category and submitter links
    s@<A HREF=\"/\?(category|s)=[^<>]*>.*?</A>\s*@@gsi;

    # lose leading P, BR, and DIV
    1 while (s@^\s*</?(P|BR|DIV)\b[^<>]*>\s*@@is);
    # compact <P>
    s@(</?P\b[^<>]*>\s*)+@<P>@gsi;

    my ($date) = m@submitted(.*?)<BR>@si;

    s@^Link\b(.*?)<BR>\s*@@gsi || error ("no date line in $url");

    $date =~ s@^.* on @@;
    $date =~ s@\s*\.?\s*\(.*$@@;


    s@\s+\bONCLICK=\"[^\"]+\"@@gsi;

    # you chumps.  undo link-tracking BS.
    s@<A\b[^<>]*>\s*(http:[^<>\"]+)\s*</A>\s*@@si;
    my $turl = $1;
    my $oturl = $turl;

    error ("no url found in $url") unless defined ($turl);

    # FUCK!  assholes!  we have to use their redirector if the link was
    # long, because they truncate it.
    if ($turl =~ m/\.\.\.$/) {
      $turl = "$eurl;cmd=go";
    }

    # lose trailing Comments links
    s@<A HREF=\"\?id[^<>]*>\s*Comments\b.*$@@si;

    # lose trailing P, BR, and DIV
    1 while (s@\s*</?(P|BR|DIV)\b[^<>]*>\s*$@@is);

    my $body = $_;

    $body = "<A HREF=\"$turl\">$oturl</A><P>$body";

    push @sec2, ($eurl, $date, $title, $body);
  }

  return @sec2;
}


sub do_creaturesinmyhead {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@&nbsp;@ @gs;
  s@\s+@ @gsi;

  my ($img, $title) = m@(<IMG \s+ SRC=\"/?creatures/\d+[^<>]*>)
                         \s* (.*?)</TD>
                       @xsi;
  error ("no image in $url") unless defined ($img);

  $img =~ s/\s+ALT\s*=\s*\"[^<>\"]*\"\s*/ /gsi;
  $title =~ s@<[^<>]*>@ @gsi;
  $title =~ s@\s+@ @g;
  $title =~ s@^\s+@@g;
  $title =~ s@\s+$@@g;

  my ($date) = ($img =~ m@creatures/(\d{6})[^\d]@);
  error ("no date in $img") unless defined ($date);

  my $eurl = "/creature.php?date=$date";

  $date =~ s@^(\d\d)(\d\d)(\d\d)$@$1/$2/$3@;
  $title =~ s@^[-\s\d/]+:\s*@@gs;

  my $body = "<BR CLEAR=BOTH><P ALIGN=CENTER>" .
             "<A HREF=\"$eurl\">$img<BR>$title</A></P>";

  my @sec = ($eurl, $date, $title, $body);
  return @sec;
}


sub do_blacktable {
  my ($url, $html) = @_;

  my $max_links_each = 5;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s@^.*?<TABLE\b[^<>]*>\s*@@si;

  s@&nbsp;@ @gs;
  s@\s+@ @gsi;

  # newlines at magic cells
  s@<TD\b[^<>]*\bCLASS=\"(topheadline|secondheadline)\"[^<>]*>\s*@\n@gsi;
  s@(<(A|P)\b[^<>]*\bCLASS=\"(linklink)\"[^<>]*>\s*) @ \n $1 @gsix;

  my @body_sec = ();
  my @link_sec = ();

  my @sec1 = split (/\n/);

  shift @sec1;
  foreach (@sec1) {

    s@</?(TD|TR|IMG|FONT|DIV|SPAN)\b[^<>]*>@ @gsi;
    next if (m/^\s*$/);

    my $headp = (m/CLASS=\"[^\"<>]*?headline\"/i ? 1 : 0);

    s@\s*\b(CLASS|TARGET)=\"[^\"<>]*\"@@gsi;
    s@<A\b[^<>]*>\s*</A>\s*@@gsi;
    s@\s+@ @gsi;

    s@^\s*<P\b[^<>]*>\s*@@gsi;

    next if (m/^\s*$/);

    next if (! m/<A\b/i); # fuck it

    s@^\s*<A\b[^<>]*?\bHREF=\"([^<>\"]+)\"[^<>]*>\s*(.*?)\s*</A>@@is ||
      error ("unparsable entry (anchor) in $url");
    my $eurl = $1;
    my $title = $2;

    my ($date) = m@\s(\d\d?\.\d\d\.\d\d)\s*@si;
    error ("no date line in $url") if ($headp && !defined ($date));
    $date = '' unless defined($date);

    # lose byline
    s@^\s*--.*?\d\d?\.\d\d\.\d\d\s*@@gsi;

    # lose trailing P, BR, and DIV
    1 while (s@\s*</?(P|BR|DIV|TR|TD|TABLE)\b[^<>]*>\s*$@@is);

    my $body = $_;

    if ($headp) {
      $title = capitalize ($title);
    } else {
      $_ = $title;
      m@^\s*(<B>.*?</B>)\s*(.*)$@si;
#        || error ("unable to extract title in $url");
      $title = $1 || '';
      $body = $2 || $body;
    }

    $title =~ s@<[^<>]*>@ @sg;
    $title =~ s@\s+@ @sg;

    $body =~ s@^\s*<P>\s*@@si;
    $body = "<A HREF=\"$eurl\">$title</A> $body";

    $title =~ s@[\s.,:;]+$@@sg;

    if ($headp) {
      push @body_sec, ($eurl, $date, $title, $body)
        if ($#body_sec+1 < $max_links_each * 4);
    } else {
      push @link_sec, ($eurl, $date, $title, $body)
        if ($#link_sec+1 < $max_links_each * 4);
    }
  }

  return (@body_sec, @link_sec);
}


sub do_artbomb {
  my ($url, $html) = @_;

  # a Blogger variant

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  # lose the dates: there is not a date per entry.
  s@<SPAN\s+CLASS=\"greyhdr\"[^<>]*>.*?</SPAN>\s*@@gsi;

  s@&nbsp;@ @gsi;
  s@\s+@ @gsi;
  s@(<A\s+NAME=\"\d+\")@\n$1@gsi;

  my @sec1 = split (/\n/i);
  my @sec2 = ();

  shift @sec1;
  pop @sec1;
  foreach (@sec1) {
    next if (m/^\s*$/s);

    s@^\s*<A\s+NAME=\"(\d+)\"\s*>\s*(<P>\s*)?</A>\s*@@si ||
      error ("unparsable entry (anchor) in $url");
    my $anchor = $1;

    s@<BR\s*/>@<BR>@gsi;
    1 while (s@<BR>\s*<BR>@<P>@gsi);

    s@</?(TD|TR|FONT|DIV|SPAN)\b[^<>]*>@ @gsi;
    s@\s*\b(CLASS|TARGET)=\"?[^\"<>]*\"?@@gsi;

    # lose trailing P, DIV, HR
    1 while (s@\s*</?(P|DIV|HR)\b[^<>]*>\s*$@@is);

    my $date = '';


    # This blog is fucked up, because it has only one anchor for multiple
    # entries per day!  WTF, man.  So let's split it and manufacture
    # different URLs.
    #
    my $count = 0;
    my @sec3 = split (/<HR>\s*/i);
    foreach (@sec3) {
      my $body = $_;

      # try for a title on the first line
      my ($title) = m@<B>\s*(.*?)\s*</B>@si;
      ($title) = m@<A\b[^<>]*>\s*(.*?)\s*</A>@si
        unless defined ($title);
      $title = '' unless defined ($title);
      $title =~ s@^(.{20}.*?([:;.?!]+|\s-+)).*@$1@si;
      $title =~ s@^\s+@@;
      $title =~ s@[\s:;.,]*$@@;

      my $ii = $#sec3 - $count;
      my $eurl = $url . ($ii == 0 ? "" : "?$ii") . "#" . $anchor;

      push @sec2, ($eurl, $date, $title, $body);
      $count++;
    }
  }

  return @sec2;
}


# generate a single-entry RSS file with an inline image of the latest cartoon.
#
sub do_asofterworld {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments

  s@\s+@ @gsi;
  s@</?(BODY|FONT)\b[^<>]*>\s*@@gsi;
  s@\s+TARGET=[^<>]*@@gsi;
  s@\s*<a href="index.html">.*?</a>\s*@@gsi;

  my $body = $_;
  my ($eurl)  = m@SRC=\"([^<>\"]*)\"@si;
  my ($title) = m@\bTITLE=\"([^<>\"]*)\"@si;
  my $date = '';

  error ("couldn't find url in $url") unless ($eurl);
  error ("couldn't find title in $url") unless ($title);
  return ($eurl, $date, $title, $body);
}


sub do_blackboxvoting {
  my ($url, $html) = @_;

  $_ = $html;

  1 while (s@<!--.*?-->@ @gsi);  # lose comments
  s/\s+/ /gs;

  s@^.*\bOlder Articles\b@@si;
  s@<[^<>]*\bclass="sideboxtitle"[^<>]*>@\n@gsi;
  s@^.*?\n@@si;

  my @sec = ();
  foreach (split (/\n/)) {

    s@&nbsp;@ @gsi;
    my ($title, $body) = m@^(.*?)<[^<>]*\bclass="content"[^<>]*>(.*)$@si;

    next unless ($body);

    $title =~ s@</?(TR|TD|TABLE|FONT|IMG|A|B|I|P|BR|DIV)\b[^<>]*>@@gsi;
    $body  =~ s@</?(TR|TD|TABLE|FONT|IMG)\b[^<>]*>@@gsi;

    $_ = $body;
    my ($eurl) = m@<A\s+HREF\s*=\s*\"(modules\.[^<>\"]+)\"@i;
    error ("unable to find entry URL in $url") unless defined ($eurl);
    $eurl =~ s/&amp;/&/g;

    s@<a href="">(.*?)</a>@$1@gsi;  # moron

    s@(\bPosted\sBy .*? ) \s* \bon\b ( .*? ) \s* \(.*$ @@xsi;

    my ($posted_by, $date) = ($1, $2);
    error ("unable to parse posted-by in $url") unless defined ($date);

    $body = $_;
    $body .= "<P><I>$posted_by</I>";

    $body  =~ s/\s+/ /gs;
    $title =~ s/\s+/ /gs;

    push @sec, ($eurl, $date, $title, $body);
  }
  return @sec;
}



#############################################################################
#
# Command line and glue.
#
#############################################################################


sub usage {
  print STDERR "usage: $progname [--verbose] [urls...]\n";
  exit 1;
}

sub main {
  my @urls = ();
  my $file = undef;
  while ($_ = $ARGV[0]) {
    shift @ARGV;
    if ($_ eq "--verbose") { $verbose++; }
    elsif (m/^-v+$/) { $verbose += length($_)-1; }
    elsif (m/^-./) { usage; }
    elsif (m/^http:/) { push @urls, $_; }
    else { usage; }
  }

  usage unless ($#urls >= 0);

  error "$rss_output_dir: output directory does not exist"
    unless (-d $rss_output_dir);
  error "$html_cache_dir: cache directory does not exist"
    unless (-d $html_cache_dir);

  my $err_count = 0;
  foreach (@urls) {
    $err_count += scrape ($_);
  }
  exit ($err_count);
}

main;
exit 0;
