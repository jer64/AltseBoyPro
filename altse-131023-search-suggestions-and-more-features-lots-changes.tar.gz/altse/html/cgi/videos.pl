#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

##################################################
sub main
{
	#
	print ("
        <meta http-equiv=\"REFRESH\"
        content=\"0;url=http://vunet.world/search.pl?cmd=searchnow&searchstring=Video%3A&where=news\">
		");

	#
}


