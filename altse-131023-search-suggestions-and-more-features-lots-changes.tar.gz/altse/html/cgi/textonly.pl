#!/usr/bin/perl
######################################################################################
#
# Text Only News from VUnet.org.
#
######################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
main();


##################################################
sub main
{
		if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
			$ENV{'printable'} = 2;
			$ENV{'maara'} = 20;
			$ENV{'osasto'} = "kaivos";
			$so{'printable'} = 2;
			$so{'sec'} = "kaivos";
			$so{'c'} = 20;
		}

		#
		my $PUBLISHER;
		if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
			$PUBLISHER = ("
<a href=\"http://$ENV{'HTTP_HOST'}\" class=goldminelink>
<font size=6>
Kultakaivos
</font>
<BR>
http://$ENV{'HTTP_HOST'}
</a>
<br>
<font size=4>
Goldmine
</font>
");
		} else {
			$PUBLISHER = ("
<a href=\"http://www.vunet.world/top/\">
<font size=6>
Vaihtoehtouutiset
</font>
<BR>
www.vunet.world
</a>
<br>
<font size=4>
Alternative News
</font>
");
		}
		$ENV{'PUBLISHER'} = $PUBLISHER;

		#
		print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
  <title>News</title>
  <meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\">
  <meta http-equiv=\"Content-Language\" content=\"fi\">
</head>

<body>

$PR2

<table width=640 bgcolor=#FFFFFF>
<tr>
<td>

<div align=center>
$PUBLISHER
</div>
<br>

			");

                ############################################################################################
                #
                # ADD NEWS HERE
                #
                open(TEXTONLY, "./TextOnly.pl|");
                @textonly = <TEXTONLY>;
                close(TEXTONLY);
                print @textonly;

		#
		print("

</td>
</tr>
</table>

</body>
			");
}


