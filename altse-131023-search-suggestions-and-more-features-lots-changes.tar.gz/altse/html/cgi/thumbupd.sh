
#!/bin/bash
cd /home/vai/public_html/images/thumb; /home/vai/sdb/bin/th 2>&1
cd /home/vai/public_html/images/thumb2; /home/vai/sdb/bin/th2 2>&1
cd /home/vai/public_html/images/thumb3; /home/vai/sdb/bin/th3 2>&1
cd /home/vai/public_html/images/thumb4; /home/vai/sdb/bin/th4 2>&1

