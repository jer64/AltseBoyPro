#!/usr/bin/perl

#
require "admin.pl";


#
$ENV{'CURSEC'} = "linkit";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex.html");

# Add main menu.
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

#
WebWalkTo("enterhere_section");
system "cat al.txt";
HandleRest();
