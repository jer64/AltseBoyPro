#!/bin/bash
lynx -dump -head "$1"
