#!/bin/bash
#
lynx -dump "http://www.vunet.world/saa.pl?q=Helsinki" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Jyv�skyl�" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Kuopio" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Turku" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Lahti" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Rovaniemi" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Lappeenranta" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Ivalo" > /dev/zero
lynx -dump "http://www.vunet.world/saa.pl?q=Oulu" > /dev/zero
/home/vai/cgi-bin/comwea
