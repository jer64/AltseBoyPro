#!/usr/bin/perl
#################################################################################
#
# VUNET.org director script. 
#
#################################################################################

#
print "Content-type: text/html\n\n";
#
require "$ENV{'DOCUMENT_ROOT'}/tools.pl";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

#
CallNewswire();

#
sub CallNewswire
{
	my ($i,$i2,$i3,$i4,@lst,$fn);

	#
	require("newswire.pl");
}

#
sub Track
{
	# Specify that only users get logged.
	if(!NoTracking())
	{
		#
		open($f, ">>logs/redir.log") || die "<a href=\"$_[0]\">Error while redirecting. Click here manually ...</a>";
		$t = time;
		$str = "$t & $ENV{'REMOTE_ADDR'} & $ENV{'REMOTE_HOST'} & $_[0]\n";
		####print $str;
		print $f $str;
		close($f);
	}
}

############################################################################
#
sub main
{
	my ($i,$i2,$f,$t,$str,$str2);

        ###################################################################
        # Search arguments line for options.
	#
        $DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	if($so{'cmd'} ne "" || $so{'submit'} ne "")
	{
		system("./find.pl");
		exit;
	}

	#
	if($so{'to'} ne "" || $so{'t'} ne "")
	{
		#
		print "Content-type: text/html\n\n";
		# Send error messages to the user, not system log
		open(STDERR,'<&STDOUT');  $| = 1;

		#
		print("
<font size=5>
<a href=\"$so{'to'}\">
Redirecting, click on this link if redirection does not happend within next 30 secs ...
</a>
</font>
			");

		#
		if($so{'t'} ne "")
		{
			$so{'to'} = rot($so{'t'});
		}

		#
		$so{'to'} = $ENV{'QUERY_STRING'};
		$so{'to'} =~ s/^\S*to\=(.*)$/$1/;

		#
		Track($so{'to'});

		#
		print("
                <meta http-equiv=\"refresh\" content=\"0; url=$so{'to'}\">
			");
		exit();
	}

	#
        if($so{'id'} ne "")
        {
                #
                $reurl = ResolveQuickUrl($so{'id'});
		$reurl =~ s/^([a-z]*)\/pub_artikkeli([0-9]*)\.txt$/\/$1\/story-$2.html/;

		#
		print "Content-type: text/html\n\n";
		# Send error messages to the user, not system log
		open(STDERR,'<&STDOUT');  $| = 1;
		#
                print("
<meta http-equiv=\"refresh\" content=\"0; url=http://www.vunet.world$reurl\">
                        ");
		
		#system "./viewarticle.pl";

		#
		exit();
        }

	#
        if($so{'pl'} ne "")
        {
		#
		print "Content-type: text/html\n\n";
		# Send error messages to the user, not system log
		open(STDERR,'<&STDOUT');  $| = 1;

		#
		$so{'to'} = "http:\/\/www.plenglish.com\/article.asp?ID={$so{'pl'}}&language=EN";
		#
		Track($so{'to'});
		#
		print("
<meta http-equiv=\"refresh\" content=\"0; url=$so{'to'}\">
			");		

		#
		exit();
        }
}

