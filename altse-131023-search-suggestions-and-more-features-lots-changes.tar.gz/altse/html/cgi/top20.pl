#!/usr/bin/perl
#############################################################################
# top20.pl - ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use DateTime;
use Time::Moment;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseBoyMenu.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
Top20();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub Top20
{
        #
        my $HTML_MENU = AltseBoyMenu();


        #
        print("
$HTML_MENU
	");
	
	#
	print("
<TABLE width=\"640\" align=\"center\" bgcolor=\"black\">
<TR>

<TD>
	");
	
	################
	#
	# LOAD UP THE ALTSE's Search log slog.txt.
	#
	
	#
	if(-e "$DB/slog.txt")
	{
		@lst = reverse LoadList("$DB/slog.txt");
	}
	
	#
	my (%gotit,%jackpot);
	
#my $int_time = DateTime->from_epoch(
#    epoch     => time()
#    );

	my $aika = Time::Moment->from_object( scalar Time::Piece::localtime() );
	#	print $aika;
	$int_time = int(Time::Moment->from_string($aika)->epoch);
	
#	print ();
	
	for(my $i=0; $i<($#lst+1); $i++)
	{
		#
		my @sp = split(/ & /, $lst[$i]);
		# sp[0]         sp[1]              sp[2]                        sp[3]
		#1660383048 & 87.95.85.45 & 87-95-85-45.bb.dnainternet.fi & <markkinatalous>
		
		if( ($int_time-$sp[0]) < (60*60*24) )
		{	
			$sp[3] =~ s/^\s//;
			$sp[3] =~ s/\s$//;
			$sp[3] =~ s/[\<\>]//g;
			my $what = "$sp[1].$sp[3]";
			if(!$gotit{$what})
			{
				$gotit{$what}++;
				
				$jackpot{$sp[3]}++;
				#print "<P>$what</P>\n";
			}
		}
		
		#foreach $hash_key (keys %nd_results)
	}
	
	#
	my (@lista,$key,$i);
	$i = 0;
	foreach $key (keys %jackpot)
	{
		my $tmpstr = sprintf "%1.8d & %s", $jackpot{$key}, $key;
		$lista[$i++] = $tmpstr;
		#print "<p>$tmpstr</p:";
	}
	@lista = sort @lista; @lista = reverse @lista;
	
	#
	print("
<A NAME=\"#top500\">
	<CENTER><H1><FONT STYLE=\"color: WHITE;\">P&auml;iv&auml;n Top 20 haut &#128513;:</FONT></H1></CENTER>
</A>

	");
	for(my $i=0; $i<($#lista+1) && $i<20; $i++)
	{
		#
		@sp = split(/ & /, $lista[$i]);
		#
		$nicen = $i+1;
		print("
<TABLE width=100%
style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;\">
<TR>

<TD>
	<A HREF=\"/?cmd=go&q=$sp[1]\">
	<FONT STYLE=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;\">
	$nicen. $sp[1]
	</FONT>
	</A>
</TD>

</TR>
</TABLE>
		");
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");
}


1;
