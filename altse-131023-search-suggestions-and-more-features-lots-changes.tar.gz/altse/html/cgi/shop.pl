#!/usr/bin/perl
###################################################################
#
# WEB SHOP CGI
#
###################################################################

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "edistyskauppa";

#
OpenWebIndex("./webindex.html");
HandleExternal("main-menu", "./mainmenu.pl");
WebWalkTo("enterhere_section");
main();
HandleRest();

#
sub main
{
	#
	LoadConfiguration();
	ArgLineParse();

	#
	print("
		<br>
		<center>
			<img src=\"../uutiset/shop/edistyskauppa.jpg\">
		</center>

		");
}
