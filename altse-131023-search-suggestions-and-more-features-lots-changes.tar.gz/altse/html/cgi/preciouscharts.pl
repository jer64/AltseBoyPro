#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
print("
<div style=\"border:1px solid #dadada;width:200px;padding-left:5px;\">
<script type=\"text/javascript\" src=\"http://www.goldalert.com/rpc-client/rpc.js\"></script><br />
<script type=\"text/javascript\" src=\"http://www.goldalert.com/_layouts/swfobject.js\"></script></p>
<div id=\"goldTickerCont\"></div>
<div id=\"flashcontent\">upgrade Flash Player</div>
<p><script type=\"text/javascript\">
createTickerNoHash(\"smliveGoldPrice\");
createGoldAlertChartNoHash(\"smgoldchart.white.xml.php\",\"190\",\"180\");

</script></p>
<div style=\"text-align:right;font:11px arial;color:#333333;margin-right:5px;\">
<a style=\"color:#333333\" href=\"http://www.goldalert.com/free-interactive-gold-charts/\">Gold Price</a> by <a style=\"color:#333333;\" href=\"http://www.goldalert.com\">GoldA$
</div>
</div>

<BR>

<a href=\"http://www.regalgoldcoins.com/silver-price-chart.html\">Silver Price</a><br>
<script type=\"text/javascript\" src=\"http://goldcoinblogger.com/charts/tojs.php?filename=show-chart.php&metal=XAG\"></script>

<BR>
<BR>

<!--DO NOT EDIT BELOW!- WIDGETS: http://www.sanebull.com/widgets -->
<div align=\"center\" width=\"250px\" style=\"font-size:12px\">
	<iframe width=\"210\" height=\"180\" src=\"http://widgets.wallstreetsurvivor.com/WidgetTreasuries.aspx\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
	<br />
	<a href=\"http://www.wallstreetsurvivor.com/\" target=\"_top\">Play a stock market game</a> 
	<br />
	<a href=\"http://www.wallstreetsurvivor.com/Public/Research/Quotes.aspx?symbol=GOOG\" target=\"_top\">Get a stock quote</a>


        <iframe width=\"250\" height=\"150\" src=\"http://widgets.wallstreetsurvivor.com/WidgetCommodities.aspx?type=e\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" $
        <br />
        <a href=\"http://www.wallstreetsurvivor.com/\" target=\"_top\">Play a stock market game</a>
        <br />
        <a href=\"http://www.wallstreetsurvivor.com/Public/Research/Quotes.aspx?symbol=GOOG\" target=\"_top\">Get a stock quote</a>

</div>

            
");
