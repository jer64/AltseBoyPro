#!/usr/bin/perl
######################################################################
#
# Vunet Search Engine
# Index Creator.
#
######################################################################
require "/home/vai/public_html/cgi-bin/tools.pl";

#
$SDB = "$NWPUB_CGIBASE/sdb";	# search database root directory
$CID = "$SDB/cid";		# central index
$LISTS = "$SDB/lists";		# list files directory

#
main();

#
sub ImageLinks
{
	my ($i,$i2,$i3,$i4,$str,$str2,$fn,$f,
		@l1,@l2,@l3,@l4,@full,@cl,@lst,$x,$y,$hfn);
	@imgtypes = ("jpg", "jpeg", "gif", "png");

	#
	$fn = $_[1];
	$fn =~ s/^(.*)\.\S*$/$1/;
	$fn = "$fn\.ils";

	#
	$hfn = $_[0];
	# Skip illegal dirs... (TODO)
	if($hfn=~/\~/) { return(); }
	@lst = LoadList("lynx \"$hfn\" -dump -image_links -force_html|");

	#
	loop1: for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] =~ /^References/ && $lst[$i+1] =~ /^\s*$/) { last loop1; }
	}

	#
	for($i2=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] =~ /^\s*[0-9]*\.\s/)
		{
			loop2: for($x=0,$y=0; $x<($#imgtypes+1); $x++) { if($lst[$i]=~/\.$imgtypes[$x]/) { $y=1; last loop2; } }
			if($y)
			{
				$lst[$i] =~ s/^\s*[0-9]*\.\s(.*)$/$1/;
				if($lst[$i] =~ /^file:\/\//)
				{
					$lst[$i] =~ s/^file:\/\/localhost//;
				}
				$cl[$i2++] = $lst[$i];
			}
		}
	}

	#
	if($#cl>0)
	{
		#
		open($f, ">$fn") || die "can't open image list file: $fn\n";
		for($i=0; $i<($#cl+1); $i++) { print $f "$cl[$i]\n"; }
		close($f);
	}
}

##############################################################################
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$fn,$fn2,@lst,@lst2,@lst3,$f,$cid,$cid1,$cid2,$cid3,$cid4,
		$key,$lkey,$hits,$chr,$chr1,$chr2,$lchr,$pwd,$dir);

	# Current work directory path.
	$pwd = $ENV{'PWD'};
	$dir = $pwd;
	$dir =~ s/^.*\/(.*)$/$1/;
	$dir =~ s/[^0-9a-z\.\-]/_/gi;

	#
	if($dir=~/^\S*\.\S*\.\S*$/)
	{
		# OK dir...
	}
	else
	{
		# Bad dir...
		print "Bad directory: $dir\n";
		sleep(2);
		return;
	}

	# Gather all files that have to be indexed.
	@lst = LoadList("find \|grep -E \"\\.htm\$|\\.shtml\$|\\.html\$|\\.asp\$|\\.php\$|\\.php3\$|\\.pl\$|\\.cgi\$\"|");
	# Make it more senseful list.
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\///g;
	}

	#
#	print stderr "Removing old dic -files ($CID: $dir.dic):\n";
#	system "find $CID -name '$dir.dic' | xargs rm";
#	print stderr "Done.\n";

	########################################################################################################
	#
	# Write list of files on name.lst -file.
	#
	open($f, ">$LISTS/$dir.lst") || die "can't write name.lst!\n";
	# Write list of files.
	for($i=0; $i<($#lst+1); $i++)
	{
		$fn = $lst[$i];
		$fn =~ s/^\.\///;
		print $f "$fn\n";
	}
	print $f "\n";
	#
	close($f);

	# Create information files for each cache file.
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$fn = "$i.cin";

		#
		print STDERR "$fn\n";
		open($f, ">$fn") || die "error ...\n";
		print $f "$lst[$i]\n";
		close($f);
	}

	########################################################################################################
	#
	for($i=0,$i4=0; $i<($#lst+1); $i++)
	{
		#
		@index = ();
		print stderr "[$dir] $lst[$i]\n";
		@lst2 = LoadList("ind.pl \"$lst[$i]\"|sort|");
		#
		ImageLinks($lst[$i], $i);
		#
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			if(!($lst2[$i2] =~ /^\s*$/))
			{
				$lst3[$i4++] = "$lst2[$i2] $i";
			}
		}
	}

	#
	@lst3 = sort(@lst3);

	########################################################################################################
	#
	$chr1="";
	$chr2="";
	$chr3="";
	#
	for($i=0,$key="",$lkey="",$chr="",$lchr=""; $i<($#lst3+1); $i++)
	{
		if($lst3[$i] ne "")
		{
			#
			$str = $lst3[$i];
			#
			$lkey = $key;
			$key = $str;
			$key =~ s/^(\S*)\s.*$/$1/;

			#
			$lchr = "$chr1$chr2$chr3";
			$chr1 = $key;
			$chr1 =~ s/^(\S).*$/$1/;
			$chr2 = $key;
			$chr2 =~ s/^\S(\S).*$/$1/;
			$chr3 = $key;
			$chr3 =~ s/^\S\S(\S).*$/$1/;

			#
			if("$chr1$chr2$chr3" ne $lchr)
			{
				#
				$lkey = "";

				#
				if($f)
				{
					#
					print $f "\n";
					close($f);
				}

				# Convert the first three chars into numbers.
				$cid1 = ord($chr1);
				$cid2 = ord($chr2);
				$cid3 = ord($chr3);
				# Make sure all necessary dirs exist.
				mkdir "$CID/$cid1";
				mkdir "$CID/$cid1/$cid2";
				mkdir "$CID/$cid1/$cid2/$cid3";
				#
				$fn2 = "$cid1/$cid2/$cid3/$dir.dic";
				print stderr "$fn2\n";
				open($f, ">$CID/$fn2") || die "can't write $CID/$fn2...";
			}

			#
			$hits = $str;
			$hits =~ s/^\S*\s(\S*)\s\S*.*$/$1/;
			$hits = sprintf "%d", $hits;
			$offs = $str;
			$offs =~ s/^\S*\s\S*\s(\S*).*$/$1/;
			$offs = sprintf "%d", $offs;

			#
			if($key eq $lkey)
			{
				print $f "* $hits $offs\n";
			}
			else
			{
				print $f "$key $hits $offs\n";
			}
		}
	}

	#
	if($f) { close($f); }
}

