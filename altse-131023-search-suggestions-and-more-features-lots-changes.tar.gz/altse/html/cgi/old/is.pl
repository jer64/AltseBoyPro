#!/usr/bin/perl
#######################################################
#
# Instant Search.
#
#######################################################

#
use POSIX;
use String::Approx 'amatch';

#
require "/home/vai/public_html/cgi-bin/tools.pl";

# How many seconds to keep a cached result?
$max_cache_age = 60*240;
$CACHE_ENABLED = 1;

# Path to the central index.
$SDB = "$NWPUB_CGIBASE/sdb";
$CID = "$SDB/cid";

#
main();

################################################################
sub IsCGI
{
	if($ENV{'REMOTE_ADDR'} ne "") { return 1; } else { return 0; }
}

################################################################
# The actual search algorithm.
#
sub Match
{
	my ($i,$i2,$p);

	#
	for($i=0,$p=0; $i<($#W+1); $i++)
	{
		if($_[0] =~ /$W[$i]/i) { $p+=1; }
		if($_[0] =~ /$W[$i]/) { $p+=2; }
		if($_[0] =~ /\s$W[$i]\s/) { $p+=3; }
		if($_[0] =~ /\s$W[$i]\s/i) { $p+=1; }
	}

	#
	if($#W > 1)
	{
		if($_[0] =~ /$so{'q'}/i) { $p+=2; }
		if($_[0] =~ /$so{'q'}/) { $p+=3; }
	}

	#
	return $p;
}

################################################################
# section, search key
#
sub SearchArt
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$f,$k);

	#
	open($f, $_[0]) || die "file not found $_[0]";
	@li = <$f>;
	close($f);
	for($i=0; $i<($#li+1); $i++) { chomp $li[$i]; }

	# Hunt for search string.
	loop1: for($i=0,$found=0; $i<($#li+1); $i++)
	{
		#
		if($i==0) { $k=25; } else { $k=1; }
		$found += Match($li[$i])*$k;
	}

	#
	return $found;
}

################################################################
#
sub Hit
{
	my ($nid,$hitz,$sk,$score);

	#
	$nid = $_[0];
	$hitz = $_[1];
	$sk = $_[2];
	$score = $_[3];

	#
	$hits{$nid}+= $hitz*$score;

	# mk = matching keywords
	if( !($mk{$nid}=~/\[$sk\]/) )
	{
		#
		$mk{$nid} = "$mk{$nid} [$sk] ";
	}
}

################################################################
#
# Search using fast index technology.
#
sub FastSearch
{
	my ($i,$i2,$i3,$i4,$fn,@com,@cat,$f,$str,$skey,$key,$key1,$lkey,
		$found,$t,$findex,$chr,$chr1,$chr2,$chr3,$chr4,@hf,$dicfn,
		$score,@sp,@lst,$x,$y,$hi,$lfn);

	#
	%hits = ();

	###############################################################################
	#
	# The actual search loop.
	#

	#
	$chr1 = $_[0];
	$chr1 =~ s/^(\S).*$/$1/;
	$chr2 = $_[0];
	$chr2 =~ s/^\S(\S).*$/$1/;
	$chr3 = $_[0];
	$chr3 =~ s/^\S\S(\S).*$/$1/;

	#
	if(!(-e $_[1])) { return(); }

	# Load this [.dic] dictionary file.
	@dic = LoadList($_[1]);

	# Read files list.
	$lfn = "$SDB/lists/$_[2]\.lst";
	if( !(-e $lfn) ) { return(); }
	@hf = LoadList($lfn);

	#
	loop2: for($key="",$lkey="",$i=0; $i<($#dic+1); $i++)
	{
		# Skip empty lines...
		if($dic[$i] eq "") { goto skip11; }
	
		#
		$key1 = $dic[$i];
		$key1 =~ s/^(\S*)\s.*$/$1/;
		if($key1 ne "*" && $key1 ne "") { $key = $key1; }
			
		#
		$sk = $_[0];
		$score = 0;
	
		#
		$ll[0] = $key;
	#	while (<@ll>) {
	#		if( ($xx=amatch($sk)) ) { $score+=1;  }
	#	}
		if($key =~ /$sk/i) { $score++; }
		if($key eq $sk) { $score+=2; }
		#
		if($score)
		{
			#
			$hi = $dic[$i];
			$hi =~ s/^\S*\s(\S*)\s.*$/$1/;
			$nid = $dic[$i];
			$nid =~ s/^\S*\s\S*\s(\S*).*$/$1/;

			#
			Hit($nid,$hi,$sk,$score);
		}
skip11:
	}
past:	

	# Extract entries from %hits to @tl;
	#
        foreach $key (keys %hits)
        {
		#
		@sp = split(" ", $mk{$key});
		$i = $#sp+1;

		#
		$fn = "$_[2]/$hf[$key]";
		$t = (stat("$fn"))[9];
		$str = sprintf "%.12d & $fn & $t & $_[2]/$key", $hits{$key}*$i+($i*20);
		$tl[$#tl+1] = $str;
		$tulos++;
        }

	#
}

################################################################
#
sub SaveResult
{
	my ($key,$fn,$f,$i,$i2);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);

	#
	open($f, ">$fn");
	for($i=0; $i<($#tl+1); $i++)
	{
		print $f "$tl[$i]\n";
	}
	close($f);
}

################################################################
#
sub GetCacheFileName
{
	my ($key,$fn);

	#
	$key = $_[0];
	$key =~ tr/[A-Z���]/[a-z���]/;
	$key =~ s/:/\_KP\_/g;
	$key =~ s/ /_/g;
	$key =~ s/[^0-9_a-z���]//gi;
	$fn = "sdb/tmp/cached\_$key\_co$so{'co'}.txt";
	return $fn;
}

################################################################
#
sub IsOldCache
{
	my ($t,$ct);

	#
	$t = (stat($_[0]))[9];
	$ct = time;
	if( ($ct-$t) >= $max_cache_age )
	{
		# Already expired.
		return 1;
	}

	# Fresh entry...
	return 0;
}

################################################################
#
sub GetCachedResult
{
	my ($key,$fn);
	my ($t,$ct);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);
	#
	if(-e $fn)
	{
		#
		$t = (stat($fn))[9];
		$ct = time;
		$cage = ($ct-$t);

		# Cache expires...
		if( IsOldCache($fn) ) { return 0; }

		#
		@tl = LoadList($fn);

		# Cached result found and is loaded!
		return 1;
	}

	# No cached result found.
	return 0;
}

################################################################
#
sub SearchNow1
{
	my ($i,$i2,$i3,$i4,$f,$key,@alst,$x,$y,$sec,$chr1,$chr2,$chr3);

	#
	$key = $_[0];

	#
	#
	$chr1 = $key;
	$chr1 =~ s/^(\S).*$/$1/;
	$chr2 = $key;
	$chr2 =~ s/^\S(\S).*$/$1/;
	$chr3 = $key;
	$chr3 =~ s/^\S\S(\S).*$/$1/;
	$dicpa = sprintf "$CID/%d/%d/%d", ord($chr1), ord($chr2), ord($chr3);
	if(!IsCGI()) { print STDERR "$dicpa\n"; }
	if( !(-e $dicpa) ) { return(); }

	#
	@alst = LoadList("find $dicpa \|grep -E \"\\.dic\$\"|");

	# Go through all dictionaries in this folder.
	for($x=0; $x<($#alst+1); $x++)
	{
		#
		if( !($alst[$i]=~/^\s*$/) )
		{
			#
			$sec = $alst[$x];
			$sec =~ s/^.*\///;
			$sec =~ s/\.dic$//;

			#
			if(!IsCGI()) { print STDERR "."; }

			#
			FastSearch($key, $alst[$x], $sec);
		}
	}
	if(!IsCGI()) {  print STDERR "\n"; }

	#
	return $tulos;
}

################################################################
#
sub SearchNow
{
	my ($key);

	#
	$key = $_[0];

	#
	if($key eq "")
	{
		return;
	}


	#
	$query_st = time;

        # Try to get a cached result.
        if( $CACHE_ENABLED==1 && $so{'REFRESH'} ne "1" && GetCachedResult($key) )
        {
		goto done;
        }
        else
        {
		print STDERR "Refreshing.\n";
        }

	#
	@tl = ();
	for($i=0; $i<($#W+1); $i++)
	{
		SearchNow1($W[$i]);
	}

	#
	@tl = sort(@tl);
	#
	SaveResult($key);

	#
done:
	$query_et = time;
}

################################################################
#
sub ProcessSearchString
{
	my ($str,$i,$i2);

	# Split into search words.
	$str = $so{'q'};
	@W = split(" ", $str);

	#
	for($i=0,$i2=0; $i<($#W+1); $i++)
	{
		$W[$i] =~ s/\*/\.\*/g;
	}

	# Remove impractical words.
	for($i=0; $i<($#W+1); $i++)
	{
		#
		$W[$i] =~ tr/[A-Z���]/[a-z���]/;
		# Do not allow dots, slashes or stars.
		$W[$i] =~ s/\.//g;
		$W[$i] =~ s/\///g;
		#
		$W[$i] =~ s/\*/\.\*/g;

		#
		if(length($W[$i])<2)
		{
			$W[$i] = "";
		}
	}
}

################################################################
#
sub main
{
	my ($i,$i2,$str,$took);

	#
	$so{'q'} = "$ARGV[0] $ARGV[1] $ARGV[2] $ARGV[3] $ARGV[4] $ARGV[5] $ARGV[6] $ARGV[7]";

	# Make the search string abit more nicer ...
	$so{'q'} =~ s/\[|\]|{|}/ /g;
	$so{'q'} =~ s/\?/ /g;
	$so{'q'} =~ s/^\s*//;
	$so{'q'} =~ s/\s*$//;

	#
	if($so{'q'} =~ /\sREFRESH$/)
	{
		$so{'q'} =~ s/\sREFRESH$//;
		$so{'REFRESH'} = 1;
	}

	#
	if($so{'q'} eq "" && $so{'searchstring'} ne "")
	{
		$so{'q'} = $so{'searchstring'};
	}
	if($so{'q'} eq "*")
	{
		$TIME_ORDER = 1;
	}
	#
	ProcessSearchString();

	# Get options.
	#
	$set = $so{'q'};
	$set =~ s/\?/\ /;

	#
	SearchNow($so{'q'});

	#
	$took = $query_et-$query_st;

	# Dump results to STDOUT.
	for($i=0; $i<($#tl+1); $i++)
	{
		print STDOUT "$tl[$i]\n";
	}

	#
	if(!IsCGI()) { print STDERR "$took second(s).\n"; }
}

