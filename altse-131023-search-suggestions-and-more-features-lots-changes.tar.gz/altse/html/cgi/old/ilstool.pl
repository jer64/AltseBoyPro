#!/usr/bin/perl
#############################################################################################
#
# Image List Tool (ILS TOOL).
#
# Fixes ils lists and acquires more information about images (size, etc.).
#
#############################################################################################

#
require "/home/vai/public_html/cgi-bin/tools.pl";

#
$SDB = "$NWPUB_CGIBASE/sdb";    # search database root directory
$CID = "$SDB/cid";              # central index
$LISTS = "$SDB/lists";          # list files directory
$ABS_SDB_PATH = "/home/vai/sdb";

#
main();

#
sub URLInfo
{
	my ($i,$i2,$i3,$i4,$str,@lst,@lst2);

	# Default to something "not found", in case of an empty response.
	$so{'Content-Type'} = "";
	$so{'STATUS'} = "404";
	#
	LoadVars("nfo.pl \"$_[0]\"|");

	#
	$str = sprintf "%.8d & %s & %s",
			$so{'Content-Length'}, $_[0], $so{'Content-Type'};

	#
	if($so{'STATUS'}=~/404/) { print STDERR "$_[0]: $so{'STATUS'}\n"; return ""; }

	#
	return $str;
}

#
sub IlsTool
{
	my ($i,$i2,$i3,$i4,$str,@lst,@lst2,@lst3,@sp,$f);

	#
	if( !(-e $_[0]) ) { print STDERR "NOT FOUND $_[0].\n"; return; }

	#
	@lst2 = LoadList($_[0]);

	#
	%al = ();

	# Fix URLs....
	for($i=0,$i2=0,$maybe=0; $i<($#lst2+1); $i++)
	{
		#
		$maybe = 0;

		#
		$str = $lst2[$i];
		if($str =~ / \& /)
		{
			# Apparently this ils file is already checked.
			print STDERR ">";
			return();

			@sp = split(" & ", $str);
			$str = $sp[1];
		}

		#
		$str =~ s/^\S*\/home\/vai(\/.*)$/$1/;

		#
		$str =~ s/$ABS_SDB_PATH//;

		#
		if($str ne "" && !($str =~ /^http:\/\//) && $str=~/[a-z]*\.[a-z]*\.[a-z]*\//i)
		{
			$str =~ s/^\S*sdb\/(\S*)$/$1/;
			$str = "http:\/\/$str";
		}
		else
		{
			if(!($str=~/^http:\/\//))
			{
				if( !($str=~/^[\/]$dir/) )
				{
					$str = "$dir\/$str";
				}
				$str =~ s/\/\//\//g;
				$str =~ s/^\///g;
				$str = "http:\/\/$str";
			}
		#	print STDERR "?? missing host name: $str\n";
		#	$str = "";
		}

		# Add only valid URLs...
		$str =~ s/^http:\/\/\//http:\/\//g;
		if(($str=~/^http:\/\// && $al{str}<1) || $maybe)
		{
			$lst[$i2++] = $str;
			$al{$str}++;
		}
		else
		{
		#	die "Unhandled: $str\n";
		}
	}

	#
	print STDERR "$_[0]:\n";
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		print STDERR "probing $lst[$i]\n";
		$str = URLInfo($lst[$i]);
		if($str ne "")
		{
			$lst3[$i2++] = $str;
		}
	}
	print STDERR "\n";

	#
	@lst3 = sort @lst3;
	@lst3 = reverse @lst3;

	#
	open($f, ">$_[0]") || die "Can't write $_[0]!\n";
	for($i=0; $i<($#lst3+1); $i++)
	{
		print STDERR "$lst3[$i]\n";
		print $f "$lst3[$i]\n";
	}
	close($f);
}

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,@lst,@lst2,@lst3,@sp,$f);

	#
	if($ARGV[0] eq "") { print "Usage: ilstool [path]\n"; return(); }

        # Current work directory path.
        $pwd = $ENV{'PWD'};
        $dir = $pwd;
        $dir =~ s/^.*\/(.*)$/$1/;
        $dir =~ s/[^0-9a-z\.\-]/_/gi;

	#
	@lst = LoadList("find $ARGV[0] -name '*.ils'|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		IlsTool($lst[$i]);
	}
}

