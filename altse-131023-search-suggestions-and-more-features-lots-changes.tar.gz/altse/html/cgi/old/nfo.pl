#!/usr/bin/perl

#
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,@lst);

	#
	if($ARGV[0] eq "") { print "Usage: nfo [URL]\n"; return(); }

	#
	@lst2 = LoadList("lynx -dump -head \"$ARGV[0]\"|");

	#
	for($i=0,$i2=0; $i<($#lst2+1); $i++)
	{	
		if($lst2[$i] =~ /^\S*:/)
		{
			$lst[$i2] = $lst2[$i];
			$lst[$i2] =~ s/:\s*/\=/;
			$i2++;
		}
	}

	#
	print "STATUS=$lst2[0]\n";
	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]\n";
	}

	#
}

