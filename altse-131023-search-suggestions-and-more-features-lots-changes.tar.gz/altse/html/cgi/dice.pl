#!/usr/bin/perl
#######################################################
# viewarticle.pl
# Newswire Publishing System.
# Now supports comments (viewing / posting).
# (C) 2004-2005 by Jari Tuominen.
#######################################################

#
##print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
require "inc.pl";

#
use Socket;
use Net::DNS;
use Net::hostent;
#use Time::localtime;
#use File::stat;
use POSIX;

#
$ADMPATH = "http://www.vunet.world/admin";
$ARTVIEWER = "http://www.vunet.world/article/";

#
$ARTCAP = "NONE";

#
my @web=("");

#######################################################
# PREFERENCES
#
$PROGRAM_NAME = "Vunet Information System";
$so{'COMMENTS_ENABLED'} = 0;
$so{'AUTO_FIX_LINES'} = 1;
$WEBINDEX = "webindex.html";

#######################################################
# Go to main loop.
#
main();

##########################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@arv,$str,$str2,$fp);

	#
	if( !($so{'sec'} =~ /^[a-z]+$/) ) {
		$so{'sec'} = "poimitut";
	}
	my $fnpath = "$so{'sec'}/fileindex.txt";
	if( -e $fnpath ) {
		@arv = LoadList($fnpath);
	} else {
		# File not found.
		return;
	}

	#
	srand(time);
	$i = sprintf("%d", rand($#arv));

	#
	$str = $arv[$i];
	$str =~ s/\.\.\///;
	$str =~ s/pub_artikkeli(.*)\.txt/story$1.html/;

	#
	$fp = "article";
	my $url = "/$fp/$str";

	#
	print("
<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=$url\">
			");

	#
}


