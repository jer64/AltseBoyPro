#!/usr/bin/perl
################################################################################################################
# quickbar.pl
#
# Link bar on top of all Vunet.org -pages.
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);
	my @items = (
		"uutiset",
		"/uutiset/",
		"finnish_flag.gif",

		"news",
		"/news/",
		"english_flag.gif",

		"text",
		"http://text.vunet.world/",
		"icon_text.gif",

		"music",
		"/music.pl",
		"icon_music.gif",

		"Juche",
		"http://juche.vunet.world",
		"juche_icon.gif",

		"Korea",
		"http://korea.vunet.world",
		"Juche_badge.gif",

		"Jari",
		"http://jari.vunet.world",
		"Jari.gif",

		"Janne",
		"http://janne.vunet.world",
		"Janne.gif",

		"Jarno",
		"http://dbr.vunet.world",
		"dbr.gif",

		"Hannu",
		"http://hanhi.vunet.world",
		"Rainesto.gif",

		"Heikki",
		"http://www.kominf.pp.fi",
		"heikki.gif",

		"Autoja",
		"http://www.car-rent.fi",
		"tiny_avk.gif",

		"Akatemia",
		"http://marx.vunet.world",
		"small_marx.gif",

		);

	#
	print("
<HEAD>
<LINK rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
</HEAD>

<BODY style=\"border:none\"
	topmargin=\"0\" leftmargin=\"0\"
        marginheight=\"0\" marginwidth=\"0\"
        bgcolor=\"#C0C0C0\">

<!--- START OF QUICK BAR: --->

		<DIV>
		<TABLE cellpadding=0 cellspacing=0 width=100% background=\"$IMAGES_BASE/bg10.png\">
		<TR>
		<TD width=1%></TD>
		<TD width=79% valign=center>
");

	#
	$i2 = sprintf "%d", 800/($#items/3);

	#
	print("
<TABLE cellpadding=0 cellspacing=0>
<TR>
	");

	#
	for($i=0; $i<$#items; $i+=3)
	{
		print("

<TD onClick=\"window.open('/?to=$items[$i+1]');\" class=withLink>
<img src=\"$IMAGES_BASE/$items[$i+2]\" align=\"middle\" vspace=0 hspace=0 border=1
	alt=\"icon\" title=\"$items[$i+0]\">
</TD>

<TD width=4>
</TD>
<TD onClick=\"window.open('/?to=$items[$i+1]');\" class=withLink>
<FONT size=2 face=Times Roman>
$items[$i+0]
</FONT>
</TD>
<TD width=4>
</TD>


			");
	}

	#
print("
</TR>
</TABLE>

		</TD>


		<TD width=20%>

		<table cellpadding=0 cellspacing=4 width=100% border=0>
		<tr align=top>

		<td>
		<div align=right>
		<form action=/saa.pl class=formx target=_blank>
		<font size=2 color=#000000>
		S��tiedot:
		<select name=q onChange='this.form.submit()' class=saa>
		<option name= selected>Kaupunki ...</option>
		<option name=Jyv�skyl�>Jyv�skyl�</option>
		<option name=Turku>Turku</option>
		<option name=Tampere>Tampere</option>
		<option name=Lappeenranta>Lappeenranta</option>
		<option name=Kuopio>Kuopio</option>
		<option name=Oulu>Oulu</option>
		<option name=Pori>Pori</option>
		<option name=Helsinki >Helsinki</option>
		<option name=Vantaa >Vantaa</option>
		</select>
		</font>
		</form>
		</div>
		</td>

		</tr>
		</table>

		</TD>	
		</TR>
		</TABLE>
		</DIV>


<!--- END OF QUICK BAR --->

</BODY>
");

	#
}


