#!/usr/bin/perl
while(1)
{
	print("Running news update.\n");
	system("screen -d -m ./newsupd.pl");
	print("Waiting until next event...\n");
	sleep(10000);
}
