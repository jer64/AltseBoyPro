#!/usr/bin/perl

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "tietoa";

#
OpenWebIndex("./webindex.html");
HandleExternal("main-menu", "./mainmenu.pl");
WebWalkTo("enterhere_section");
print("<center>Section not implemented yet.</center><br>");
@txt = LoadList("info.txt");
for($i=0; $i<($#txt+1); $i++) { print "$txt[$i]\r\n";  }
HandleRest();
