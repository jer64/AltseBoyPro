#!/usr/bin/perl
###############################################################################	
#
# Artikkeli julkaisu.
#
###############################################################################	

#
require "tools.pl";

#
$ENV{'CURSEC'} = "hint";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
WireLogo();
WebWalkTo("main-menu");
print inc_menu("etusivu", "finnish");
WebWalkTo("quotehere");
main();
HandleRest();
print EndBar();

###############################################################################	
#
sub main
{
	#
	print("

<table width=650>
<tr>
<td width=650>


<img src=\"$IMAGES_BASE/julkaisu.jpg\">

<br>
Terve! T�ll� kaavakkeella voit toimittaa toimitukselle artikkelisi tai j�tt�� kommentin.
<br>
<H1>$so{'v'}</H1>

<br>

<!---MYSTUFF-->
            <form action=\"/TallennaJuttu.pl\" method=\"post\">
Juttu:<br>
              <textarea name=\"HINT\" cols=\"60\" rows=\"10\"></textarea><br>
Yhteystietosi (ei pakollinen):<br>
              <input type=\"text\" name=\"NAME\" size=40><br>
              <br>
              <input value=\"L�het�\" type=\"submit\"></form>

</td>
</tr>
</table>
	");

	#
}

###############################################################################	



