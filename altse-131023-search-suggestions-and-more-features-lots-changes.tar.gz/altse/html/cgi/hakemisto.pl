#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "hakemisto";
#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################################################################
#
sub FinDirectorySections
{
        my ($i,$i2,$str,$str2,$url,$x,$y,$z);
        @secs = (
                "Alueellinen",
                "Suomi",
                "World/Suomi/Alueellinen/Suomi/",
                "Eurooppa",
                "World/Suomi/Alueellinen/Eurooppa/",
                "Aasia",
                "World/Suomi/Alueellinen/Aasia/",
                "Afrikka",
                "World/Suomi/Alueellinen/Afrikka/",

                "Elinkeinoel�m�",
                "Tietoliikenne",
                "World/Suomi/Elinkeinoel%E4m%E4/Tietoliikenne/",
                "Autot",
                "World/Suomi/Elinkeinoel%E4m%E4/Autot/",
                "Maa- ja mets�talous",
                "World/Suomi/Elinkeinoel%E4m%E4/Maa-_ja_mets%E4talous/",
                "Pankit",
                "World/Suomi/Elinkeinoel%E4m%E4/Pankit/",

                "Koti",
                "Lapset",
                "World/Suomi/Koti/Lapset/",
                "Puutarha",
                "World/Suomi/Koti/Puutarha/",
                "Lemmikit",
                "World/Suomi/Vapaa-aika/Lemmikit/",
                "Ruokaohjeet",
                "World/Suomi/Vapaa-aika/Ruoka_ja_juoma/Reseptit/",

                "Pelit",
                "Korttipelit",
                "World/Suomi/Pelit/Korttipelit/",
                "Roolipelit",
                "World/Suomi/Pelit/Roolipelit/",
                "Tietokonepelit",
                "World/Suomi/Pelit/Videopelit/",
                "Verkkokaupat",
                "World/Suomi/Verkkokaupat/Lelut_ja_pelit/",

                "Vapaa-aika",
                "Ruoka ja juoma",
                "World/Suomi/Vapaa-aika/Ruoka_ja_juoma/",
                "Huumori",
                "World/Suomi/Vapaa-aika/Huumori/",
                "Veneily",
                "World/Suomi/Vapaa-aika/Veneily/",
                "Matkailu",
                "World/Suomi/Vapaa-aika/Matkailu/",

                "Tiede",
                "L��ketiede",
                "World/Suomi/Terveys/L%E4%E4ketiede/",
                "Yhteiskuntatieteet",
                "World/Suomi/Tiede/Yhteiskuntatieteet/",
                "Tietojenk�sittelytieteet",
                "World/Suomi/Tiede/Tietojenk%E4sittelytieteet/",
                "Rajatieto",
                "World/Suomi/Yhteiskunta/Rajatieto/",

                "Yhteiskunta",
                "Filosofia",
                "World/Suomi/Tiede/Humanistiset_tieteet/Filosofia/",
                "Kansantaloustiede",
                "World/Suomi/Tiede/Yhteiskuntatieteet/Kansantaloustiede/",
                "Politiikka",
                "World/Suomi/Yhteiskunta/Politiikka/",
                "J�rjest�t",
                "World/Suomi/Yhteiskunta/J%E4rjest%F6t/",

                "Terveys",
                "Kunto",
                "World/Suomi/Terveys/Kunto/",
                "Mielenterveys",
                "World/Suomi/Terveys/Mielenterveys/",
                "Vaihtoehtoiset hoitomuodot",
                "World/Suomi/Terveys/Vaihtoehtoiset_hoitomuodot/",
                "Verkkokaupat",
                "World/Suomi/Verkkokaupat/Terveys/",

                "Tiedonl�hteet",
                "Kirjastot",
                "World/Suomi/Tiedonl%E4hteet/Kirjastot/",
                "Sanakirjat",
                "World/Suomi/Tiedonl%E4hteet/Sanakirjat/",
                "Kielioppaat",
                "World/Suomi/Tiedonl%E4hteet/Kielioppaat/",
                "Koulutus",
                "World/Suomi/Tiedonl%E4hteet/Koulutus/",

                "Tietotekniikka",
                "Internet",
                "World/Suomi/Tietotekniikka/Internet/",
                "Tietoturva",
                "World/Suomi/Tietotekniikka/Tietoturva/",
                "K�ytt�j�rjestelm�t",
                "World/Suomi/Tietotekniikka/Ohjelmat/K%E4ytt%F6j%E4rjestelm%E4t/",
                "Yritykset",
                "World/Suomi/Tietotekniikka/Yritykset/",

                "Uutiset",
                "Radio",
                "World/Suomi/Kulttuuri_ja_viihde/Radio/",
                "Televisio",
                "World/Suomi/Kulttuuri_ja_viihde/Televisio/",
                "Tietotekniikka",
                "World/Suomi/Tietotekniikka/Julkaisut/",
                "Sanomalehdet",
                "World/Suomi/Uutiset/Sanomalehdet/",

                "Urheilu",
                "Hevoset",
                "World/Suomi/Urheilu/Hevoset/",
                "Jalkapallo",
                "World/Suomi/Urheilu/Jalkapallo/",
                "Sukellus",
                "World/Suomi/Urheilu/Sukellus/",
                "Suunnistus",
                "World/Suomi/Urheilu/Suunnistus/",

                "Verkkokaupat",
                "Tietotekniikka",
                "World/Suomi/Verkkokaupat/Tietotekniikka/",
                "Ruoka",
                "World/Suomi/Verkkokaupat/Ruoka/",
                "Vapaa-aika",
                "World/Suomi/Verkkokaupat/Vapaa-aika/",
                "Musiikki",
                "World/Suomi/Verkkokaupat/Musiikki/"

                );
        #
        print("
                <DIV align=center>
                <TABLE width=100% bgcolor=#000000 cellpadding=2 cellspacing=0 BGCOLOR=\"000000\">
                <TR>
                <TD>

                <TABLE width=100% bgcolor=#000000>
                <TR>
                <TD>
<font color=\"#FFFFFF\">Selaa webbi� hakemiston kautta ...</font>
                </TD>
                </TR>
                </TABLE>

                <TABLE width=100% bgcolor=#FFFFFF>
                ");

        #
        for($i=0,$x=0; $i<($#secs); $i+=9,$x++)
        {
                #
                $url = $secs[$i];
                $url = "http://altse.vunet.world/Top/World/Suomi/$url/";

                #
                if( ($x&1)==0 )
                {
                        print("
                                <TR>
                                ");
                }
                print("
<TD><LI><FONT size=4 face=\"Arial Black\"><a href=\"$url\" class=dark>$secs[$i]</a></FONT>
<BR>
                        ");

                #
                for($y=1; $y<9; $y+=2)
                {
                        print("
<TABLE width=100% cellpadding=0 cellspacing=0>
<TR>
<TD width=15%>
</TD>
<TD width=85%>
<IMG SRC=\"$IMAGES_BASE/RedBox.gif\" align=center>
        <A HREF=\"http://altse.vunet.world/$secs[$y+$i+1]\" class=dark>
        $secs[$y+$i]<BR>
        </A>
</TD>
</TR>
</TABLE>
                                ");
                }

                #
                print("
                        </LI></TD>
                        ");

                #
                if( ($x&1)==3 )
                {
                        print("
                                </TR>
                                ");
                }
        }

        #
        print("
                </TD>
                </TR>
                </TABLE>

                </TR>
                </TABLE>
                </DIV>
                ");

}

#################################################################################################
#
sub main
{
	#
	print("
<TABLE width=70% cellpadding=32 cellspacing=0>
<TR>
<TD>
		");
	#
	FinDirectorySections();
	#
	print("
</TD>
</TR>
</TABLE>
	");
}


