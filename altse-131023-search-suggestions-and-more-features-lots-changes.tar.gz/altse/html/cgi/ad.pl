#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();


##################################################
sub main
{
	#
	print("
<body style=\"background:#000000;\" bgcolor=\"#000000\">
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"333333\";
google_color_bg = \"000000\";
google_color_link = \"FFFFFF\";
google_color_url = \"999999\";
google_color_text = \"CCCCCC\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</body>
	");
}


