#!/usr/bin/perl
#
####################################################################
#
#	News images browser/displayer.
#
####################################################################

#
require "tools.pl";

#
$ENV{'CURFPSEC'} = "finnish";
$ENV{'CURSEC'} = "uutiskuvat";
#
$ARTVIEWER = "/article/";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#
# News Images
#
sub NewsImages
{
        my $i,$i2,$i3,$i4,$lst,$str,$str2,$f,$f2,$url,$cap,$ast;

        #
        @lst = LoadList("poimitut/fileindex.txt");

	#
	$i = $so{'I'} + 50;
	$i2 = $so{'I'} - 50;
	if($i2<0) { $i2=0; }
	$i3 = $so{'I'}+0;
	$i4 = $so{'I'}+50;

	#
	print("
		<table cellpadding=4 cellspacing=0 width=100%
			bgcolor=\"#800000\">
		<tr valing=top>

		<td width=5% align=left>
                <a href=\"/newsimages.pl?I=$i2\" class=bright>
		<font size=5>
		<
		</font>
		</a>
		</td>

		<td align=left width=45%>
		<font color=\"#FFFFFF\" size=5>
		$i3 - $i4
		</font>
		</td>

		<td align=right width=45%>
		<font color=\"#FFFFFF\" size=1>
		Click on image to view article
		</font>
		</td>

		<td width=5% align=right>
                <a href=\"/newsimages.pl?I=$i4\" class=bright>
		<font size=5>
		>
		</font>
		</a>
		</td>

		</tr>
		</table>
		");

        #
        print("
                <div>
		<table cellpadding=0 cellspacing=0 width=100%
			bgcolor=\"#000000\">
		<tr>
		<td>

		<div align=center>
                <table cellpadding=1 cellspacing=0>
                <tr valign=top>
                ");

        #
        for($i=$#lst,$i2=0,$i3=0; $i2<10000 && $i3<50 && $i!=0; $i--)
        {
                #
                $lst[$i] =~ s/..\///;

                #
                $str = "$lst[$i]\_imageurl.txt";

		#
		$lst[$i] = UrlFix($lst[$i]);

                #
                if( open($f, $str) )
                {
                        $url = <$f>;
                        close($f);

			#
			$url =~ s/http:\/\/www\.saunalahti\.fi\/ehc50\/uutiset\//http:\/\/images\.vunet\.org\//;
			$url =~ s/^\.\.\/uutiset\//http:\/\/$IMAGES_BASE\//;

                        #
                        if( open($f, $lst[$i]) )
                        {
                                $cap = <$f>;
                                $cap =~ s/<br>//g;
                                $cap =~ s/\"/\\\"/g;
                                $cap =~ s/'/\\\'/g;
                                $cap =~ s/[\n|\r]//g;
                                close($f);
                        }
                        else
                        {
                        }

                        #
                        $_cap = $cap;
                        $_cap =~ s/\\\"/\"/g;
                        $_cap =~ s/\"/'/g;
			$ast = sprintf("
                                <td>
                                <a href=\"$ARTVIEWER$lst[$i]\" class=\"dark\">
                                <img src=\"$url\" width=50 height=50
                                alt=\"$_cap\" vspace=3 hspace=3 border=1
                                title=\"$_cap\"></a></td>				

                        ");

			#
			if($i2>=$so{'I'})
			{
				if(IsImage($url))
				{
					print("$ast");
					$i3++;
				}
			}

                        #
                        $i2++;
                        if( ($i3%10)==0 )
                        {
                                print("
					</tr>
					</table>

			                <table cellpadding=1 cellspacing=0>
			                <tr valign=top>
                                        ");
                        }

                }
        }

        #
        print("
                </tr>
                </table>
                </div>

                </tr>
                </table>
                </div>
                ");

        #
	$i = $so{'I'} + 50;
	$i2 = $so{'I'} - 50;
	if($i2<0) { $i2=0; }
        print("
		<table cellpadding=4 cellspacing=0 width=100%
			bgcolor=\"#800000\">
		<tr valign=top>

		<td width=50% align=left>
		<div align=left>
                <font size=2>
                <a href=\"/newsimages.pl?I=$i2\" class=bright>
                < previous page
		</a>
		</div>
		</td>

		<td width=50% align=right>
		<div align=rigth>
                <font size=2>
                <a href=\"/newsimages.pl?I=$i\" class=bright>
		next page >
		</a>
		</div>
		</td>

		</tr>
		</table>

		");
}

##################################################
sub main
{
	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	print("
		<table cellpadding=16 cellspacing=0 width=672>
		<tr valing=top>
		<td>
		");

	#
	SectionHeadline();
	#
	print("<br>");

	#
	NewsImages();

	#
	print("
		</td>
		</tr>
		</table>
		");
}


