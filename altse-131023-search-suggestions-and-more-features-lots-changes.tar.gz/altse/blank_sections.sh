#!/bin/bash
mkdir -p ~/db/articles
cd ~/db/articles
mkdir kotimaa
mkdir ulkomaat
mkdir tiede
mkdir talous
mkdir videos
mkdir kummalliset
mkdir kolumnit
mkdir luonto
mkdir tiedotteet
mkdir yhteiskunta
mkdir politiikka
mkdir konfliktit
mkdir english
mkdir shop
mkdir asunnot
mkdir tyopaikat
mkdir huumori
mkdir valokuvaus
mkdir ajatelmat
mkdir software
mkdir kulttuuri
mkdir commodore
mkdir picks
