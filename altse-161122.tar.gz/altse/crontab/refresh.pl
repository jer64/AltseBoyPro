#!/usr/bin/perl
my $sleep_count_seconds = 20;
for(;;)
{
	system("/home/vai/altse/crontab/refresh_once.pl");
	#sleep($sleep_count_seconds);
}
