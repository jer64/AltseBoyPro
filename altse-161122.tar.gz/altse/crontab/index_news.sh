#!/bin/bash
#
screen -d -m wi -i 0 -o -c
#
screen -d -m wi -i 1 -o -c
#
screen -d -m wi -i 2 -o -c
#
screen -d -m wi -i 3 -o -c
#
screen -d -m wi -i 4 -o -c
#
screen -d -m wi -i 5 -o -c
#
screen -d -m wi -i 6 -o -c
#
screen -d -m wi -i 7 -o -c

