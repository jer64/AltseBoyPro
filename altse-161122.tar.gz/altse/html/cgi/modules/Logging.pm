################################################################
#
sub LogThisSearch
{
	my ($f,$t);

	#
	open($f, ">>$DB/slog.txt");
	$t = time;
	print $f "$t & ";
	print $f "$ENV{'REMOTE_ADDR'} & ";
	print $f "$ENV{'REMOTE_HOST'} & ";
	print $f "<$so{'q'}>\n";
	close($f);
}

1;