#!/usr/bin/perl
###############################################################################	

#
require "tools.pl";

#
$ENV{'CURSEC'} = "hint";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
WireLogo();
HandleExternal("main-menu", "./mainmenu.pl");
WebWalkTo("quotehere");
main();
HandleRest();
print EndBar();

###############################################################################	
#
sub main
{
	#
	print("

<table width=650>
<tr>
<td width=650>

<img alt=\"julkaisu\"
 title=\"julkaisu\"
 src=\"http://www.saunalahti.fi/ehc50/uutiset/literacy.gif\"
 style=\"width: 60px; height: 66px;\" align=\"right\">

<img src=\"$IMAGES_BASE/juttuvinkki.jpg\">
<br>

<br>

<!---MYSTUFF-->
            <form action=\"storehint.pl\" method=\"get\">
Juttu:<br>
              <textarea name=\"HINT\" cols=\"60\" rows=\"10\"></textarea><br>
Yhteystietosi (ei pakollinen!):<br>
              <input type=\"text\" name=\"NAME\" size=40><br>
              <br>
              <input value=\"L�het� vinkki\" type=\"submit\"></form>

</td>
</tr>
</table>
	");

	#
}

###############################################################################	



