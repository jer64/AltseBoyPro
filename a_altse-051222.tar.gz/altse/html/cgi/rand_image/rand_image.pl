#!/usr/bin/perl
##############################################################################
# Basic Random Image Displayer  Version 1.2                                  # 
# Copyright 1996 Matt Wright    mattw@scriptarchive.com                      #
# Created 7/1/95                Last Modified 7/20/95                        #
# Scripts Archive at:           http://www.scriptarchive.com/                #
##############################################################################
# COPYRIGHT NOTICE                                                           #
# Copyright 1996 Matthew M. Wright  All Rights Reserved.                     #
#                                                                            #
# Basic Random Image may be used and modified free of charge by anyone so    #
# long as this copyright notice and the comments above remain intact.  By    #
# using this this code you agree to indemnify Matthew M. Wright from any     #
# liability that might arise from it's use.                                  #  
#                                                                            #
# Selling the code for this program without prior written consent is         #
# expressly forbidden.  In other words, please ask first before you try and  #
# make money off of my program.                                              #
#                                                                            #
# Obtain permission before redistributing this software over the Internet or #
# in any other medium.  In all cases copyright and header must remain intact.#
##############################################################################
# Necessary Variables
  $basedir = "$IMAGES_BASE/banners/";
  @files = (
	"banner1.jpg",
	"banner2.jpg",
	"banner3.jpg",
	"banner4.jpg",
	"banner8.jpg",
	"banner9.jpg",
	"banner10.jpg",
	"banner11.jpg",
	"banner12.jpg",
	"banner13.jpg",
	"banner14.jpg",
	"banner16.jpg",
	"banner17.jpg",
	"banner18.jpg",
	"banner19.jpg",
	"banner22.jpg",
	"banner24.jpg"
	);

# Options
  $uselog = 0; # 1 = YES; 0 = NO
        $logfile = "/home/mattw/public_html/image/pics/piclog";

# Done
##############################################################################

srand(time ^ $$);
$num = rand(@files); # Pick a Random Number

# Print Out Header With Random Filename and Base Directory
print "Location: $basedir$files[$num]\n\n";

# Log Image
if ($uselog eq '1') {
    open (LOG, ">>$logfile");
    print LOG "$files[$num]\n";
    close (LOG);
}
