#!/usr/bin/perl
#
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#
sub FixThisFile
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$l);

	#
	if( !(-e $_[0]) && (-d $_[0]) ) { return(); }

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$l = $lst[$i];
		$lst[$i] =~ s/http:\/\/vunet\.org\/~vai\/uutiset\//http:\/\/images\.vunet\.org\//g;
		$lst[$i] =~ s/http:\/\/www\.saunalahti\.fi\/~ehc50\/uutiset\//http:\/\/images\.vunet\.org\//g;
		if($l ne $lst[$i]) { print "Fixed $l.\n"; }
	}

	#
	open($f, ">$_[0]") || die "can't open $_[0]";
	for($i=0; $i<($#lst+1); $i++)
	{
		print $f "$lst[$i]\n";
	}
	close($f);
}

##################################################
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2);

	#
	@lst = LoadList("find . -name \"*_imageurl.txt\"|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		FixThisFile($lst[$i]);
	}
}


