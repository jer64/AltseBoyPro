#!/bin/bash
ls -rt|grep "12"|grep -v \.counter|grep -v \_ref\.txt > new_fileindex.txt

