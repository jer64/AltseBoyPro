#!/usr/bin/perl
# com.pl - Vunet social communication center
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
$ENV{'CURSEC'} = "keskustelu";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");

# Add main menu.
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub PreviewCommentTree
{
	my ($i,$i2,$i3,$i4,$i5,$i6,$x,@lst,@lst2,@art,$str,$str2);

	#
	if( !(-e $_[0]) ) { return 0; }

	#
	@lst = LoadList($_[0]);
	@lst = reverse @lst;

	#
	if($lst[0] eq "") { return 0; }

	#
	$afn = $_[0];
	$afn =~ s/_comindex\.txt//;
	#print "$afn<br>";
	if( !(-e $afn) ) { goto past; }
	@art = LoadList($afn);
	$cap = $art[0];
	$cap =~ s/<[^\>]*>//g;
	$cap =~ s/^(.{80}).*$/$1.../;

	$url = "$afn";
	$url =~ s/^articles\///;
        $url = CapUrl($url,$cap);
        $url =~ s/\.txt$/.html/;

	print("
		<A HREF=\"/$url\" class=news6><b>$cap</b></A><BR>
		");

	#
	loop: for($i4=0,$i5=0; $i4<($#lst+1) && $i5<5; $i4++)
	{
		#
		@com = LoadList($lst[$i4]);
		@sp = split(/\&/, $com[0]);
		$sp[2] =~ s/<[^\>]*>//g;
		for($i=1,$str=""; $i<($#com+1); $i++)
		{
			$str = "$str $com[$i]";
		}
		$str =~ s/<[^\>]*>//g;
		$str =~ s/^(.{70}).*$/$1.../;
		$sp[2] =~ s/^(.{14\S*}).*$/$1.../;
		if($str eq "" || $str=~/^\s*$/) { goto past; }
		if($str=~/http:\/\//) { goto past; }
		if(1)
		{
			#
			$resp = ("<A HREF=\"/viewarticle.pl?article=$afn&respond_to=$lst[$i4]#comments_form\" class=orange><IMG SRC=\"$IMAGES_BASE/respond.gif\" border=0> vastaa</a>");
			#
			$comid = "$lst[$i4]";
			$comid =~ s/^.*comment([0-9]*).*/$1/;
			$comid++;
			#
			#$x = $#lst-($nayta);
			#$con = "";
			#if($x>0)
			#{
			#	$con = "<i>($x muuta viesti�)</i>";
			#}
			$pm = POSIX::strftime("%d.%m.%Y", localtime( (stat($lst[$i4]))[9] ));
			print("
<LI><A HREF=\"/$url#comment$comid\" class=pink>$str</A> $pm <font size=1>$sp[2]</font><BR>$con</LI>
<TABLE cellspacing=0 cellpadding=0 width=600><TR><TD width=450></TD><TD width=150>$resp</TD></TR></TABLE>
			");
			$i5++;
		}
past:
	}

	#
	if( ($#lst+1) > $i5 ) 
	{
		printf("
		...<BR>
		yhteens� %d viesti� jonossa
		<BR>
			",
		$#lst+1);
	}
	print "<BR>";

	#
	return 1;
}

###########################################################################################################
#
sub ViewComments
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$str2);

	#
	@lst = LoadList("find articles -maxdepth 2 -name '*_comindex*' -type f|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$t = (stat($lst[$i]))[9];
		$lst[$i] = "$t $lst[$i]";
	}

	#
	@lst = sort @lst;
	@lst = reverse @lst;

	#
	for($i=0,$i2=0; $i<($#lst+1) && $i2<200; $i++)
	{
		#
		@sp = split(/ /, $lst[$i]);
		if( PreviewCommentTree($sp[1]) ) { $i2++; }
	}

	#
}

###########################################################################################################
#
sub main
{
	#
	print("

<TABLE CELLSPACING=0 CELLPADDING=16
	width=750>
<TR>
<TD>
<IMG SRC=\"$IMAGES_BASE/keskustelufoorumi.jpg\">
<DIV ALIGN=RIGHT>
<FONT SIZE=1 COLOR=#808080>
Photo on left by Vlaudia Veja Valimareanu.<br>
Photo on right by Can Berkol.
</FONT>
</DIV>
<BR>
	");

	#
	ViewComments();	

	#
	print("
</TD>
</TR>
</TABLE>

		");

	#
}


