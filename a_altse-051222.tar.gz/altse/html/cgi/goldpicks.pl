#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$HOSTI = "http://www.kultakaivos.info";
#
$ENV{'CURSEC'} = "goldpicks";
#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$so{'section'} = $ENV{'CURSEC'};

#
OpenWebIndex("./goldindex.html");
# Add main menu.
WebWalkTo("main-menu");
                                my $printti =
                inc_gold_menu($so{'section'}, $so{'FP_SECTION'});
                                print $printti;
#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo);

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "$_[0]";
	$str = "$ENV{'DOCUMENT_ROOT'}/articles/";
	$url =~ s/^$str//;
	$url = "$url";
	#$url = UrlFix($url);
	$url = $HOSTI . NiceArticleURL($url);

        #
	if(-e $_[0])
	{
	        @art = LoadList("$_[0]");
		LoadVars("$_[0]\_options.txt");
	}
	else
	{
		#print "NOT FOUND $_[0]\n";
		return "";
	}

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#	$goo = Googler($cap);

	#
	ParseOptions("$_[0]\_options.txt");

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>


		<table cellpadding=0 cellspacing=0 width=350>
		<tr>

		<TD valign=top width=32>");

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = "$IMAGES_BASE/document.gif";
		if($url=~/software/)
		{
			$so{'imageurl'} = "$IMAGES_BASE/software.gif";
		}
	}
	else
	{
		#$so{'imageurl'} =~ s/^(.*[\/])([a-z0-9\-\_\!]*)\.([a-z])*$/$1thumb2\/th_$2.png/i;
	}
	#$so{'imageurl'} = "$IMAGES_BASE/thumb2/th_usa.png";
	if($so{'imageurl'} ne "")
	{
		$imgurl = $so{'imageurl'};
	        $imgurl =~ s/^.*\/([^\/]+)$/$1/;
	        $imgurl = "$IMAGES_BASE/thumb2/th_$imgurl";
	        $imgurl =~ s/\.[a-z]+$/.png/;
		$str = ("$str
			<a href=\"$url\" class=news1>
			<img src=\"$imgurl\" border=0>
			</a>
			");
	}
	else
	{
	}
	$str = ("$str </TD>");

	#
	$str = ("$str
		<TD width=4>
		</TD>

		<TD valign=top width=274>
                <div>
		<font size=2 face=Times Roman>
		<a href=\"$url\" class=$_[1]>
                $cap
		</a>
		");
	#$t = (stat($_[0]))[9];
	#$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($_[0], "news3");
	$str = ("$str
		</font>
                </div>
		</TD>


		</tr>
		</table>

		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>
                ");

	#
	return $str;
}

###########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);

	#
	@stories = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/goldpick.txt");
	@stories = reverse @stories;

	#
	print("
<TABLE width=800 cellpadding=16 cellspacing=0>
<TR valign=top>
<TD width=80%>
<!---
<IMG src=\"$IMAGES_BASE/usa_valtio.gif\" alt=\"USA - markkinafundamentalistinen utopia. Valtio kest�m�tt�m�ll� pohjalla. Yhteiskunta joka tuottaa enn�tysm��r�t psykopaatteja.\">
--->

<DIV align=justify>
<!---<b>Pakottaako amerikkalaistyylinen kilpailuyhteiskunta olemaan v�litt�m�tt� toisista ihmisist�,
ajamaan pelk�st��n omaa etua ja kovettamaan oman sisinp�ns�?</b></DIV>
<BR>--->
		");

	#
	for($i=0; $i<($#stories+1); $i++)
	{
		$str = ViewHL("$ENV{'DOCUMENT_ROOT'}/articles/$stories[$i]", "news3");
		print "$str";
	}

	#
	print("
</TD>
<TD>
</TD>
</TR>
</TABLE>
		");

		#
#                open($f, "|mail $PRIM_ADMIN_EMAIL -s \"USA - utopia, uusi k�vij�! $ENV{'REMOTE_HOST'}\" 2>&1 > /dev/null");
 #               print $f "Uusi k�vij� k�vi sivuilla osoitteesta:\n";
  #              print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
   #             foreach $key (sort(keys %ENV))
    #            {
     #                   print $f "$key=\"$ENV{$key}\"\n";
      #          }
       #         print $f "==========================================\n";
        #        print $f "Vaihtoehtouutiset Information System\n";
         #       print $f "http://vunet.org\n";
          #      close($f);
}


