#!/usr/bin/perl
# beta_newsfeeds.pl

#
require "tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
#
if($so{'js'} ne "") {
	$MAX_VIEW_COUNT = 10;
	print "Content-type: text/JavaScript\n\n";
} else {
	$MAX_VIEW_COUNT = 500;
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$HOSTI = "http://www.vaihtoehtouutiset.info";
#
$ENV{'CURSEC'} = "picks";

#
if($so{'js'} eq "") {
	OpenWebIndex("./goldindex.html");
	# Add main menu.
	WebWalkTo("main-menu");
	print inc_gold_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
	#
	WebWalkTo("ENTERHERE_SECTION");
}
main();

#
if($so{'js'} eq "") {
	#
	WebWalkTo("ALAPALKKITAHAN");
	#
	print EndBar();
	#
	HandleRest();
}

###########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$niceurl,$age,$content);

	if($so{'js'} eq "") {
	#
	print("
<TABLE width=750 cellpadding=16 cellspacing=0 class=main_frontpage_article_window>
<TR valign=top>
<TD>
		");
	}

	#
	@lst = LoadList("/home/vai/sdb/html/cgi/cache/rss/finance.txt");
	for($i=0; $i<($#lst+1) && $i<$MAX_VIEW_COUNT; $i++) {
		@sp = split(/ \| /, $lst[$i]);
		#print $lst[$i] . "<BR>\n";
		my $age = $sp[0];
		my $title = $sp[1];
		my $description = $sp[2];
		my $niceurl = $sp[3];
		my $url = $sp[3];
		$url =~ s/ \|$//;
		$niceurl =~ s/^http:\/\/([^\/]+).*$/$1/;

		my $nice_age;
		if($age >= 86400) {
			my $days = int($age/86400);
			if($days==1) {
				$nice_age = $days . " day ago";
			} else {
				$nice_age = $days . " days ago";
			}
		} else {
			my $hour = int($age/3600);
			if($hour<=1) {
				$nice_age = "an hour ago";
			} else {
				$nice_age = $hour . " hours ago";
			}
		}
		$age_html = "<font size=1 color=\"#808080\">  - " . $nice_age . "</font>";

		if($title =~ /^\s*$/) { goto skip; }

		if( !($title=~/&h.*\&/) ) {
			#$title =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if( !($description=~/&h.*\&/) ) {
			#$description =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if($alreadytitle{$title} ne "") {
			goto skip;
		} else {
			$alreadytitle{$title}++;
		}

		$source_name_html = ("
<font size=1 color=\"#808080\"> - $niceurl</font>");

		$content .= ("
<TABLE width=100% cellpadding=8 cellspacing=0 bgcolor=\"#FFFFFF\">
<TR valign=top>
<TD>
<A HREF=\"$url\" class=darkul><B>
$title</B></A> $source_name_html $age_html
</TD>
</TR>
</TABLE>
			");
		if( length($description)>5 && $so{'js'} eq ""  ) {
		$content .= ("
<TABLE width=100% cellpadding=8 cellspacing=0 bgcolor=\"#E0E0E0\">
<TR valign=top>
<TD>
$description<BR>
</TD>
</TR>
</TABLE>

			");
		}

		#
skip:
	}

	#
	if($so{'js'} eq "") {
	#
	print("
$content

</TD>
</TR>
</TABLE>
		");
	}

	#
	if($so{'js'} ne "") {
	        $content =~ s/[\t\n\r\s]/ /g;
	        $content =~ s/\"/\\\"/g;
	        print(" document.write(\"$content\"); \n");
	}

	#
}
