#!/usr/bin/perl
###################################################################
#
# Standalone News Bar.
#
###################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();


##################################################
sub main
{
		#
		print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
</head>

<body>



<table width=640>
<tr>
<td>


			");

                ############################################################################################
                #
                # ADD NEWS HERE
                #
                open(CAL, "./newsbar1.pl|");
                @cal = <CAL>;
                close(CAL);
                print @cal;

		#
		print("

</td>
</tr>
</table>

</body>
			");
}


