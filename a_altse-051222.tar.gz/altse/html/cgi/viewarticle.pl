#!/usr/bin/perl
#######################################################
# viewarticle.pl
# Newswire Publishing System.
# Now supports comments (viewing / posting).
# (C) 2004-2009 by Jari Tuominen.
#######################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

# Flush STDOUT buffer after each command.
select(STDOUT);
$| = 1;

#
my $pathi = $ENV{'DOCUMENT_ROOT'};
if($pathi eq "") {
	$pathi = $ENV{'HOME'};
}
require "$pathi/cgi/tools.pl";
require "$pathi/cgi/modules/ArticleViewerMonitor.pm";
require "$pathi/cgi/modules/ViewArticleLib.pm";
require "$pathi/cgi/modules/ViewArticle.pm";

#
#use Socket;
#use Net::DNS;
#use Net::hostent;
#use Time::localtime;
#use File::stat;
use POSIX;

#
$ADMPATH = "/cgi/admin";
$ARTVIEWER = "/cgi/viewarticle.pl";

#
$ARTCAP = "NONE";

#
my @web=("");

#######################################################
# PREFERENCES
#
$PROGRAM_NAME = "Vunet Information System";
#$so{'COMMENTS_ENABLED'} = 1;
$so{'COMMENTS_ENABLED'} = 0;
if($ENV{'HTTP_HOST'}=~/kultakaivos/)
{
	$so{'COMMENTS_ENABLED'} = 1;
}
$so{'AUTO_FIX_LINES'} = 1;
if($ENV{'HTTP_HOST'}=~/kultakaivos/) { 
$WEBINDEX = "goldindex.html";
$GOLDMINE = 1;
} else {
$WEBINDEX = "webindex.html";
}
if($so{'printable'}) { 
$WEBINDEX = "textindex.html";
}

#######################################################
# Go to main loop.
#
main();

#####################################################################################################
#
sub main
{
	#
	ViewArticle("TRUE");
}



