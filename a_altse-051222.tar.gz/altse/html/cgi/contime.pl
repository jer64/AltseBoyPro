#!/usr/bin/perl
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
require "tools.pl";

#
main();

#
sub main
{
	#
	printf "%s\n", NumberToDate($ARGV[0]);
}
