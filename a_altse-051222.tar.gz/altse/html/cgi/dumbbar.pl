#!/usr/bin/perl
################################################################################
#
# jsbar.pl - Embedded News Bar (JAVASCRIPT).
# Featured in articles on the left.
# (C) 2006-2008 by Jari Tuominen.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

################################################################################
#
# CapUrl URL CAP.
#
sub CapUrl
{
        my ($url);
        $urlcap = $_[1];
        $urlcap =~ tr/[A-Z���]/[a-z���]/;
        $urlcap =~ s/\?/_/g;
        $urlcap =~ s/�/a/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/[^a-z0-9]/_/g;
        $urlcap =~ s/_*$//g;
        $urlcap =~ s/^_*//g;
        $urlcap =~ s/__/_/g;
        $urlcap =~ s/^(.{20}[a-z0-9]*).*$/$1/;
        $url = $_[0];
        $url =~ s/\/english\//\/picks\//;
        $url =~ s/\/article//;
        $url =~ s/story([0-9]*)/$urlcap-$1/;
        $url =~ s/\/\-/\/_\-/;
        return $url;
}

################################################################################
#
sub newsbar
{
	my ($str);

	#
	$WID = "100%";

	#
	$str = ("
<TABLE width=100% height=100% cellspacing=4 cellpadding=0
	bgcolor=#A02020>
<TR>
<TD>
	<DIV align=center>
	<FONT COLOR=#E0E0E0>$so{'s'}:</FONT>
	</DIV>
</TD>
</TR>
</TABLE>

		");

	#
	$SEK = "finnish";
	if($SECTION ne "english")
	{
		$SEK = "finnish";
	}

	#
	if($SECTION eq "english")
	{
		$SEK = "english";
	}

	#
	$str = ("$str
		<table width=140 class=left_news_window>
		<tr>
		<td>
		");

	#
	if($SECTION eq "english" || $SECTION eq "")
	{
		$FP = "english";
		$str = sprintf "%s %s", $str, ViewNewStuff("english");
	}

	#
	if($SECTION ne "english")
	{
		#
		$FP = "finnish";
		$str = sprintf "%s %s", $str,ViewNewStuff($SECTION);
	}

	#
	if($SECTION ne "english")
	{
		$JATKUU = "Jatkuu";
		$str = ("$str
		</td>
			</tr>
			</table>
	
			<table width=100% cellspacing=0 cellpadding=4 bgcolor=black>
			<tr>
			<td>
				<div align=middle>
				<A HREF=\"http://www.vunet.org/?rs=&section=kaikki&page=15&FP_SECTION=finnish&maxts=40&ho=&q=\"
					target=_blank class=yellow>$JATKUU ...</A></div>
			</td>
			</tr>
			</table>
		");
	}


	#
	return $str;
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$con,$re,$fn,@lst,$i,$i2,$note,$path,$fn,$ifn);

	#
	$cap = $_[1];

	#
	$con = "";

	#
	$re = 0;

	#
	$u1 = UrlFix(BuildQuickUrl($_[0]));
	$u2 = UrlFix(BuildQuickUrl($so{'a'}));
	$URL = "http://vunet.org$u1";
	$u3 = $_[0];
	$u3 =~ s/[a-z]*\/\.\.\///;
	$u3 =~ s/pub_artikkeli(.*)\.txt/story$1.html/;
	$u3 = "/$u3";
	$URL = CapUrl($u3, $cap);
	if( !($URL=~/^http:\/\//) )
	{
		$URL = "http://www.vunet.org$URL";
	}

	#
	if(($u1 ne $u2) || $sel)
	{
		$con = ("$con
			<font size=1>
			");
	}
	else
	{
		$re = 1;
		$con = ("$con
			<font color=\"#FFFF00\" size=1>
			");
	}

	#
	$visco = "";
	$REF = "";
	if(NoTracking())
	{
		$ifn = "$_[0]\.counter";
		$ifn =~ s/\.txt//;
		if(-e "$_[0]\_ref.txt")
		{
			$REF = ("<A HREF=\"https://www.vunet.org/admin/refview.pl?article=$_[0]\">
<IMG SRC='$IMAGES_BASE/promote.gif' border=1 class=bright align=middle title=\"Klikkaa t�st� n�hd�ksesi referenssit!\"></A>
");
		}
		else
		{
			$REF = "";
		}
		if(-e $ifn)
		{
			@ips = LoadList($ifn);
			$visco = sprintf " <font color=#F00000>(%d$REF)</FONT>", $#ips+1;
		}
	}

	if(-e "$_[0]\_comindex.txt")
	{
	$REF = ("$REF
<IMG SRC=\"http://www.vunet.org/images/mailmsg.gif\" border=0>
");
	}

	#
	$ofn = "$_[0]_options.txt";
	if(-e $ofn)
	{
		$so{'imageurl'} = "";
		LoadVars($ofn);
		if($so{'imageurl'} ne "")
		{
			$so{'imageurl'} =~ s/^.*\/(.+)$/th_$1/;
			$so{'imageurl'} =~ s/\.jpg$/.png/;
			$IMG_HTML = ("
	<IMG SRC='http://images.vunet.org/thumb2/$so{'imageurl'}' border=1 class=bright align=left></A>
	");
		}
		else
		{
			$IMG_HTML = "";
		}
	}
	else
	{
		$REF = "";
	}
	if(NoTracking() && -e $ifn)
	{
		@ips = LoadList($ifn);
		$visco = sprintf " <font color=#F00000>(%d$REF)</FONT>", $#ips+1;
	}

	#
	$fn = "$_[0]\_comindex.txt";
	if(-e $fn)
	{
		@lst = LoadList($fn);
		$i = $#lst+1;
		if($i > 1)
		{
		$note = ("
			<IMG SRC='$IMAGES_BASE/smiles/smile.gif' border=0>
			");
		}
		if($i > 2)
		{
		$note = ("
			<IMG SRC='$IMAGES_BASE/smiles/smile847.gif' border=0>
			");
		}
	}

	#
	if( !($_[0]=~/xinwen/) )
	{
		$cap =~ s/<br>//ig;
		if(!($cap=~/\&\#/))
		{
			$cap =~ s/(\S{15})/$1 /g;
		}
	}

	#
	$cap =~ s/^([^\s]+)([\:])(.+)$/<FONT COLOR=RED>$1<\/FONT>$2$3/;

	#
	$con = ("$con
		<div>
		$IMG_HTML $note
		<b>$cap</b>$visco
		</div>
		");
	if($u1 ne $u2)
	{
		$con = ("$con
			");
	}
	else
	{
		$con = ("$con
			</font>
			");
	}

	#
	return $con;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,@lst2,$i,$i2,$col,$con,$st,$str);

	#
	@lst = GetLatestArticles();
	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]\n";
	}
	exit;

	#
	$str = ("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	$col = "";

	#
	$sel = 0;
	loop: for($ii=0,$i2=0,$st=time; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW && $ii<$#lst; $ii+=3)
	{
		#
		$t = time;
		if( ($t-$st)>5 ) { last loop; }

		#
		$fn = "$lst[$ii+1]/pub_artikkeli$lst[$ii+2].txt";

		#
		#if($fn=~/\/videos\// && $_[0] eq "kaikki")
		#{
		#	goto skip;
		#}

		#
		if( -e $fn && !$al{$fn} )
		{
			$con = ViewHL($fn, $lst[$ii+0]);
			$al{$fn}++;
		}
		else
		{
			$con = "";
		}

		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}
		if($u1 ne "" && $u2 ne "" && $u1 eq $u2 && !$sel) { $col = "#800000"; $sel++; }

		#
		if($con eq "") { goto skip; }

		#
		$str = ("$str
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">

			<font size=1>

			<table cellpadding=4 cellspacing=0>
			<tr>
			<td onMouseover=\"this.className='td_over_white';\"
			    onMouseout= \"this.className='';\"
			    onClick=\"Javascript:parent.window.location='$URL';\">

			$con
			</td>
			</tr>
			</table>

			</font>

			</td>
			");
		$i2++;

		#
skip:
	}

	#
	$str = ("$str
		</table>
		</center>
		");

	#
	return $str;
}

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if( !NoTracking() )
	{
		$IS_ADMIN = 1;
	}
	else
	{
		$IS_ADMIN = 0;
	}

	#
	if($so{'s'} ne "")
	{
		$SECTION = $so{'s'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		$SECTION = "progressive";
	}

	#
	$str = newsbar();
        #
	$str =~ s/[\t\n\r\s]/ /g;
	$str =~ s/  / /g;
	$str =~ s/\"/\\\"/g;

	#
	@sp = split(/(.{48}[^\\]{2})/, $str);
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] ne "")
		{
		        print(" document.write(\"$sp[$i]\");\n ");
		}
	}

	#
}
