#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";
use POSIX;

#
$ENV{'CURSEC'} = "osastot";
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex3.html");
WebWalkTo("CHOOSE-TITLE1");
print("<TITLE>VAIHTOEHTOUUTISET - UUTISIA AJATTELEVILLE MASSOILLE</TITLE>");
print("
<META name=\"description\" content=\"Uutisia ajatteleville massoille.\">
<META name=\"keywords\" content=\"karl marx suojelupoliisi sorto\">
<META HTTP-EQUIV=\"Content-Language\" CONTENT=\"fi\">
<META name=\"owner\" content=\"LST\@vunet.org\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">
<META name=\"revisit-after\" content=\"5 days\">
");
SkipTo("CHOOSE-TITLE2");
#WebWalkTo("main-menu");
#print inc_menu($ENV{'CURSEC'}, "finnish");

#
WebWalkTo("enterhere_section");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
HandleRest();

#
sub GenThumbHtml
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
		$alt,$ifn,$i,$i2,@thu,@ips,$thumbs,
		$fn_thumbs,@lst);

	#
	$fn_thumbs = $_[0];
	$fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
        if(-e $fn_thumbs) { @lst = LoadList("$fn_thumbs"); @thu = split(/\ /, $lst[0]); }
	for($thumbs="",$i=0; $i<($#thu+1); $i++)
	{
		$thumbs = ("$thumbs<IMG SRC=\"$IMAGES_BASE/thumb_up_c.gif\" border=0>");
	}

	#
	return $thumbs;
}

################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
		$alt,$ifn,$i,$i2,@thu,@ips,
		$first);

	#
	$first = $_[0];
	$first =~ s/\!\!$//;

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "/$first";
	$url = NiceArticleURL($url);
	if( $url =~ /^[^\/]/ ) {
		$url = "/" . $url;
	}

        # If article text file exists...
	if(-e $first)
	{
		$fn_counter = $first;
		$fn_counter =~ s/\.txt$/.counter/;
		$fn_thumbs = $first;
		$fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
		$fn_com = $first;
		$fn_com =~ s/\.txt$/.txt_comindex.txt/;
		@art = LoadList("$first");
		@ips = ();
		if(-e $fn_counter) { @ips = LoadList("$fn_counter"); }
		$thumbs = GenThumbHtml($first);
		@kom = ();
		$comments="";
		if(-e $fn_com)
		{
			@kom = LoadList($fn_com);
			$i = $#kom+1;
			if($i != 0)
			{
				if( $ENV{'NW_LANGUAGE'} eq "fi" )
				{
					$comments = "($i kommenttia)";
				}
				if( $ENV{'NW_LANGUAGE'} eq "en" )
				{
					$comments = "($i comments)";
				}
				if( $ENV{'NW_LANGUAGE'} eq "se" )
				{
					$comments = "($i kommentar)";
				}
			}
		}
	}
	else
	{
		return "";
	}

	#
	$score = sprintf "%d", ($#ips+1)/2;
	if($score>99) { $score="medal.gif"; $alt="very popular article"; }
	if($score>7 && $score<100) { $score="7_beyond"; $alt="popular article"; }
	if($score<0) { $score=0; $alt="article($score)"; }

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	if($cap eq "") { return ""; }
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#	$goo = Googler($cap);

	#
	ParseOptions("$first\_options.txt");

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<!--- bold black line --->
		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>


		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>

		<!-- image cell --->
		<TD valign=top width=32");

	#
        #
#        $url = CapUrl($url, $cap);
        #
        $url = $_[0];
	$url =~ s/\/home\/vai\/public_html\/articles\///;
        $url =~ s/^kaikki\/\.\.\///;
        $url = "/cgi/viewarticle.pl?article=$url";
	#$url = NiceArticleURL($url);
        #$VIEWHL_URL = $url;

	$url = CapUrl($url, $cap);
#	$url =~ s/home\/vai\/public_html//;
#	$VIEWHL_URL = $url;

	#
	$z = $_[0];
	$z =~ s/^([a-z]*)\/.*$/$1/;
	if( isAutoSection($z)==1 )
	{
		$so{'imageurl'} = AutoDetermineImage($cap);
	}

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = "$IMAGES_BASE/document.gif";
		if($url=~/software/)
		{
			$so{'imageurl'} = "$IMAGES_BASE/software.gif";
		}
	}
	else
	{
		$so{'imageurl'} =~ s/^(.*[\/])([\%a-z0-9\-\_\!]*)\.([a-z])*$/$1thumb2\/th_$2.png/i;
		if( !($so{'imageurl'}=~/th_/i) )
		{
			$so{'imageurl'} = "";
		}
	}
	if($so{'imageurl'} ne "")
	{
		$str = ("$str
			<!---- ARTICLE IMAGE ---->
			<A HREF=\"$url\" class=news1>
			<IMG SRC=\"$so{'imageurl'}\" border=0>
			</A>
			");
	}
	else
	{
	}
	$str = ("$str </TD>");

	$t = (stat($first))[9];
	$ct = time;
	$age = $ct-$t;
	#
	$headline_class = "news5";
#	if($age < ($UUSI_IKA/3))
#	{
#		$headline_class = "news6";
#	}
	$headline_class2 = "news_title_old";
	if($age < ($UUSI_IKA/3))
	{
		$headline_class2 = "news_title_new";
	}

	#
	$str = ("$str
		<TD width=4>
		</TD>

		<TD valign=top width=200>
                <div>
		<font size=2 face=Times Roman>
		");
	$big = $cap;
	$big =~ s/[^A-Z���]//g;
	$cap =~ s/(\S{12})/$1 /g;
	$lim = 75 - (length($big)*6);
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if( !($_[0]=~/\!\!$/) )
	{
		$str = ("$str
			<a href=\"$url\" class=$headline_class>
	                $cap
			$thumbs</a>
			$comments
			");
	}
	else
	{
		$str = ("$str
	                <FONT CLASS=$headline_class2>$cap</FONT>
			$thumbs
			$comments
			");
	}
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($first, "news3");
	#
	if($score=~/\./)
	{
		$ifn = $score;
	}
	else
	{
		$ifn = "meter$score.gif";
	}

	$good_sec = 1;
	if(	$_[0]=~/ostetaan/ ||
		$_[0]=~/myydaan/ ||
		$_[0]=~/valokuvaus/ ||
		$_[0]=~/bush/ ||
		$_[0]=~/progressive/ ||
		$_[0]=~/huumori/ ||
		$_[0]=~/ruokailu/ ||
		$_[0]=~/tyopaikat/ ||
		$_[0]=~/asunnot/ )
	{
		$good_sec = 0;
	}

	if($age < ($UUSI_IKA) && $good_sec)
	{
                   if($ENV{'NW_LANGUAGE'} eq "fi")
                   {
                           $ifn = "uusi1.gif";
                   }
                   if($ENV{'NW_LANGUAGE'} eq "en")
                   {
                           $ifn = "new1.gif";
                   }
                   if($ENV{'NW_LANGUAGE'} eq "se")
                   {
                           $ifn = "new1.gif";
                   }
	}

	#
	$str = ("$str
		</font>
                </div>
		</TD>

		<TD width=24>
		<!---- ARTICLE RANKING ---->
		<IMG SRC=\"$IMAGES_BASE/$ifn\" alt=\"$alt\" title=\"$alt\">
		</TD>


		</tr>
		</table>

		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>
                ");

	#
	return $str;
}
###############################################################################################################
#
# [match string] [caption] [max. articles to show] [max. age of an article, in hours]
#
sub NaytaUutisotsikot
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,@adv,$old,
			$fn,$str,$age,$cl,$durl,@groups,$path);

		#
		$path = "$ARTBASE/$_[4]";
		if($_[4] eq "")
		{
			$durl = "$_[0]";
		}
		else
		{
			$durl = "$_[4]";
		}
		if($durl=~/\|/)
		{
			@groups = split(/\|/, $durl);
			$durl = "kaikki";
		}
		$durl = "/finnish/$durl";

		#
		print("
		<TABLE width=100% cellspacing=0 cellpadding=8>
		<TR>
		<TD>
		<TABLE class=article_catalog_window width=100%>
		<TR>
		<TD>
			");

		#
		print("
			<table width=100% cellpadding=4 cellspacing=0>
			<tr>
			<TD width=70%>
			<!--- UUTISS�HKEET --->
			<font face=\"Arial Black\"><A href=\"$durl\" class=dark>$_[1]</a></font>
			</TD>

			<TD width=30%>
			<DIV align=right>
			<FONT size=2>
			<!--- EXTRA HTML ON RIGHT --->
			$_[5]
			</FONT>
			</DIV>
			</TD>

			</tr>
			</table>

			<!--- BLACK LINE --->
			<table width=100% height=2 cellpadding=4 cellspacing=0 bgcolor=\"#000000\">
			<tr>
			<td>
			</td>
			</tr>
			</table>
			");

		print("
			<table cellpadding=4 cellspacing=0 width=100%>
			<tr>
			<td>
			");

		#
		if($_[4] ne "")
		{
			$as = "$ARTBASE/$_[4]";
		}
		else
		{
			$as = "$ARTBASE/kaikki"; #$ADVERT_SEC;
		}
		#
		@adv = LoadList("$as/fileindex.txt");
		#
        	$NO_ICON = 1;
	        $supersmall = 1;
		$FNSIZE = 3;
		#
		for($i=$#adv,$i2=0,$i3=0,$headlines=""; $i2<1000 && $i3<$_[2]; $i2++,$i--)
		{
			#
			$fn = "$as/$adv[$i]";

			#
		#	if( !($fn =~ /$_[0]/) || $fn=~/__/ ) { goto skip; }

			#
			$age = FileAge($fn);

			#
			$cl = "news2";
			if( $age>=(3600*24) )
			{
			#	$cl = "dark";
			}

			#
			if($already{$fn} eq "" )
			{
				$already{$fn}++;
				if( ($str=ViewHL($fn,$cl,90)) ne "" )
				{
					$str =~ s/\n/ /g;
					$i3++;
					$headlines = ("$headlines
<TABLE cellspacing=0 cellpadding=0>
<TR>
<TD>
$str
</TD>
</TR>
</TABLE>

");
				}
skip:
			}

			#
		}

		#
		print "<!--HEADLINES---> $headlines <!---HEADLINES--->";

		#
		if($so{'FP_SECTION'} eq "english")
		{
			$ots = "more items";
		}
		else
		{
			$ots = "lis�� otsikoita";
		}

		#
		print ("
				<a href=\"$durl\" class=dark>
				<font size=\"2\">
				> $ots ...
				</font>
				</a>
			");

		#
		print("
			</td>
			</tr>
			</table>


			</td>
			</tr>
			</table>
			</td>
			</tr>
			</table>
			");

		#
		return();
}

###########################################################################################################
#
sub main
{
		#
		if( $ENV{'REQUEST_URI'} =~ /^\/cgi\// ) {
			print("
<meta http-equiv=\"refresh\" content=\"0; url=/osastot.pl\">
");
		}

		print("
		<table width=100% cellspacing=0 cellpadding=0
			bgcolor=#FFFFFF>
		<tr>
		<td>


		<TABLE width=100% height=100 cellspacing=0 cellpadding=0
			style=\"background-image: url('$IMAGES_BASE/osastot.jpg');
			background-repeat: no-repeat;\">
		<TR>
		<TD width=96%>
			<DIV ALIGN=RIGHT>
			<A HREF=\"/np.pl\" class=mainos><IMG SRC=\"$IMAGES_BASE/fast_mail.gif\" class=bulletin border=0> postita oma ilmoituksesi t�st�</A>
			</DIV>
		</TD>
		<TD width=4%>
		</TD>
		</TR>
		</TABLE>

		<table width=100% cellspacing=0 cellpadding=0>
		<tr valign=top>
		");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("kotimaa", "Kotimaa", 10, 24*1200, "kotimaa");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("ulkomaat", "Ulkomaat", 10, 24*3600, "ulkomaat");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("talous", "Talous", 10, 24*3600, "talous");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("tiede", "Tiede & Terveys", 10, 24*3600, "tiede");
		print("</td>");
		#
		print("
		</tr>
		</table>
		");

		#
		print("
		<table width=100% cellspacing=0 cellpadding=0>
		<tr valign=top>
		");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("kolumnit", "Kolumnit", 10, 24*1200, "kolumnit");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("tiedotteet", "Tiedotteet", 10, 24*3600, "tiedotteet");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("kummalliset", "Hauskat", 10, 24*3600, "kummalliset");
		print("</td>");
		#
		print("<td width=25%>");
		NaytaUutisotsikot("kulttuuri", "Kulttuuria", 10, 24*3600, "kulttuuri");
		print("</td>");
		#
		print("
		</tr>
		</table>

		</td>
		</tr>
		</table>
		");
                        print("
<DIV ALIGN=CENTER>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = \"728x90_as\";
google_ad_type = \"text_image\";
//2006-10-12: SFNET-tori
google_ad_channel = \"6046371771\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</DIV>
<BR>
                                ");

	#
}

