#!/usr/bin/perl
# NewsWire Publishing System
# ==========================
#
# Administration related configuration and init.
########################################################

#
require "./tools.pl";

#
# Should comments be posted?
$POST_COMMENTS_ENABLED =	1;
# Will posting comments require a lower level administration key?
$POST_COMMENT_REQUIRE_ADMIN =	1;
# Should comments be viewed?
$VIEW_COMMENTS_ENABLED =	1;

#
$LINKCOLOR = "39, 80, 4";

#
$REQUIREPASSWORD = 0; # 1=always require, 0=do not require.
$ADMINPASSWORD = "9485673983457";

#
$ip = $ENV{'REMOTE_ADDR'};
$host = $ENV{'REMOTE_HOST'};
#print "*$ip* *$host*<br>\n";

#
if($ip eq "62.142.77.49")
{
	$admin = 1;
	print "Administrator mode.<br>\n";
}

#
StartAdmin();

#
true;

#
sub StartAdmin
{
	$qqq = $ENV{'QUERY_STRING'};;
	if($qqq =~ /$ADMINPASSWORD/i)
	{
		$admin = 1;
	}
}

#

##########################################################
sub get_name
{
        local $i,f;

        #
        for($i=0,$found=0; !$found; $i++)
        {
                $str = sprintf "$osasto/pub_artikkeli$_[0]%d.txt",$i;
                $str2 = sprintf "pub_artikkeli%d$_[0].txt",$i;
                if( !open(f, $str) ) {  $name=$str; $found=1;
                                        $name2=$str2;
                                }
                else { close(f); }
        }
}

##########################################################
sub get_comname
{
        local $i,f,$usag;

	#
	$usag = $_[0];

        #
        for($i=0,$found=0; !$found; $i++)
        {
                $str = sprintf "$usag\_comment%d.txt",$i;
                $str2 = sprintf "$usag\_comment%d.txt",$i;
                if( !open(f, $str) ) {  $name=$str; $found=1;
                                        $name2=$str2;
                                }
                else { close(f); }
        }
}


