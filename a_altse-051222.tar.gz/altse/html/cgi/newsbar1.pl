#!/usr/bin/perl
#
# Embedded News Bar
#
################################################################################
require "tools.pl";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		20;
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();


################################################################################
#
sub main
{
	#
	if($ENV{'BAR_SECTION'} ne "")
	{
		$SECTION = $ENV{'BAR_SECTION'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		return;
	}

	#
	newsbar();
}

################################################################################
#
sub newsbar
{
	#
	$WID = "100%";

	#
	print("
			<table width=100% cellpadding=2 cellspacing=0>
		");

	#
	if($SECTION ne "english")
	{
		$SEK = "finnish";
	}

	#
	if($SECTION eq "english")
	{
		$SEK = "english";
	}

	#
	EXPRESS2("$SECTION", "http://www.vunet.org/$SEK/$ENV{'CURSEC'}", "center");

	#
	print("
		<table width=130 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	if($SECTION eq "english" || $SECTION eq "")
	{
		$FP = "english";
		ViewNewStuff("english");
	}

	#
	if($SECTION ne "english")
	{
		#
		$FP = "finnish";
		ViewNewStuff($SECTION);
	}


	#
	print("
		</td>
		</tr>
		</table>
		");
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$con,$re);

	#
	$re = 0;

	#
	@art = LoadList("$_[0]");

	#
	$con = "";
	$cap = substr($art[0], 0, 200);

	#
	if($cap eq "") { return ""; }

	#
#	$u1 =~ s/poimitut\/\.\.//;
#	$u2 =~ s/poimitut\/\.\.//;
	$u1 = UrlFix(BuildQuickUrl($_[0]));
	$u2 = UrlFix(BuildQuickUrl($ENV{'VIEW_THIS_ARTICLE'}));

	#
	if($u1 ne $u2)
	{
		$con = ("$con
		<a href=\"http://vunet.org$u1\" class=\"dark\">
			<font size=1>
			");
	}
	else
	{
		$re = 1;
		$con = ("$con
			<font color=\"#FFFF00\" size=1>
			");
	}

	#
	$cap =~ s/<br>//ig;
	$cap =~ s/(\S{15})/$1 /g;

	#
	$con = ("$con
		<div>
		<li>
		<b>$cap</b>
		</li>
		</div>
		");
	if($u1 ne $u2)
	{
		$con = ("$con
		</a>
			");
	}
	else
	{
		$con = ("$con
			</font>
			");
	}

	#
	return $con;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,$i,$i2,$col,$con,$st);

	#
#	if( !NoTracking() ) { return(); }

	#
	print("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	#
	@lst = "";
	@lst = LoadList("$_[0]/fileindex.txt");
	$col = "";

	#
	loop: for($ii=$#lst,$i2=0,$st=time; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW; $ii--)
	{
		#
		$t = time;
		if( ($t-$st)>2 ) { last loop; }

		#
		$fn = "$_[0]/$lst[$ii]";
		if( -e $fn )
		{
			$con = ViewHL($fn);
		}
		else
		{
			$con = "";
		}

		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}
		if($u1 eq $u2) { $col = "#800000"; }

		#
		if($con eq "") { goto skip; }

		#
		print("
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">
			<font size=1>


			<table cellpadding=4 cellspacing=0>
			<tr>
			<td>

			$con
			</td>
			</tr>
			</table>

			</font>
			</td>
			");
		$i2++;

		#
		if($ii==0) { last loop; }
skip:
	}

	#
	print("	
		</table>
		</center>
		");
}

################################################################################
#
sub Caption
{
	#
	print("
		<table cellpadding=4 cellspacing=0 align=center width=100% border=$_[6] bgcolor=$_[2]>
		<tr>
		<td>
		<center>
		<font color=\"$_[3]\" face=\"$_[4]\" size=\"$_[5]\">
		");
	if($_[8] ne "")
	{
		print("
			<img src=\"$_[8]\" alt=\"\" border=1>
			");
	}
	print("
		$_[0]
		</font>
		</center>
		</td>
		</tr>
		</table>
		");
}

