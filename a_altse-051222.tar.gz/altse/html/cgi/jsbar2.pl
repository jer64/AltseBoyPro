#!/usr/bin/perl
################################################################################
#
# jsbar.pl - Embedded News Bar (JAVASCRIPT).
# Featured in articles on the left.
# (C) 2006-2012 by Jari Tuominen.
#
################################################################################
require "tools.pl";
require "modules/VerboseViewHL.pm";
require "modules/VerboseViewHL_EmphasizeSource.pm";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

################################################################################
#
# CapUrl URL CAP.
#
sub CapUrl
{
        my ($url);
        $urlcap = $_[1];
        $urlcap =~ tr/[A-Z���]/[a-z���]/;
        $urlcap =~ s/\?/_/g;
        $urlcap =~ s/�/a/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/[^a-z0-9]/_/g;
        $urlcap =~ s/_*$//g;
        $urlcap =~ s/^_*//g;
        $urlcap =~ s/__/_/g;
        $urlcap =~ s/^(.{20}[a-z0-9]*).*$/$1/;
        $url = $_[0];
        $url =~ s/\/english\//\/picks\//;
        $url =~ s/\/article//;
        $url =~ s/story([0-9]*)/$urlcap-$1/;
        $url =~ s/\/\-/\/_\-/;
	$url = CapUrl($url, $urlcap);
        return $url;
}

################################################################################
#
sub newsbar
{
	my ($str);

	#
	$WID = "100%";

	#
	$str = ("
<TABLE width=100% height=100% cellspacing=4 cellpadding=0
	bgcolor=#A02020>
<TR>
<TD>
	<DIV align=center>
	<FONT COLOR=#E0E0E0>$so{'s'}:</FONT>
	</DIV>
</TD>
</TR>
</TABLE>

		");

	#
	$SEK = "finnish";
	if($SECTION ne "english")
	{
		$SEK = "finnish";
	}

	#
	if($SECTION eq "english")
	{
		$SEK = "english";
	}
	# TANNE TANNE
	if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
		my $WIDDI = 210;
	} else {
		my $WIDDI = 210;
	}

	#
	$str = ("$str
		<table width=$WIDDI class=left_news_window>
		<tr>
		<td>
		");

	#
	if($SECTION eq "english" || $SECTION eq "")
	{
		$FP = "english";
		$str = sprintf "%s %s", $str, ViewNewStuff("english");
		goto past;
	}

	#
	if($SECTION ne "english")
	{
		#
		$FP = "finnish";
		$str = sprintf "%s %s", $str,ViewNewStuff($SECTION);
		goto past;
	}

	#
	if($SECTION eq "kaivos")
	{
		#
		$FP = "finnish";
		$str = sprintf "%s %s", $str,ViewNewStuff($SECTION);
		goto past;
	}

	elsif($SECTION ne "english")
	{
		$JATKUU = "Jatkuu";
		$str = ("$str
		</td>
			</tr>
			</table>
	
			<table width=100% cellspacing=0 cellpadding=4 bgcolor=black>
			<tr>
			<td>
				<div align=middle>
				<A HREF=\"/cgi/nw.pl?rs=&section=kaikki&page=15&FP_SECTION=finnish&maxts=40&ho=&q=\"
					target=_blank class=yellow>$JATKUU ...</A></div>
			</td>
			</tr>
			</table>
		");
		goto past;
	}
past:


	#
	return $str;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,@lst2,$i,$i2,$col,$con,$st,$str);

	#
	if($_[0] eq "kaivos") {
		@lst = reverse LoadList("$ENV{'DOCUMENT_ROOT'}/articles/kaivos/fileindex.txt");
		for($i=0; $i<($#lst+1) && $i<$AMOUNT_OF_ARTICLES_TO_SHOW+10; $i++) {
			$lst[$i] =~ s/\.\.\///;
		}
	} else {
		@lst = GetLatestArticles();
	}

	#
	$str = ("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	$col = "";

	#
	$sel = 0;
	loop: for($ii=0,$i2=0,$st=time; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW && $ii<$#lst; $ii+=3)
	{
		#
		$t = time;
		if( ($t-$st)>5 ) { last loop; }

		#
		if($_[0] eq "kaivos") {
			$fn = $lst[$i2];
		} else {
			$fn = "$ENV{'DOCUMENT_ROOT'}/articles/$lst[$ii+1]/pub_artikkeli$lst[$ii+2].txt";
		}
		#if(NoTracking()) {
		#	$str .= $fn . "<HR><BR>";
		#}

		#
		#if(!($fn=~/talous/) && $SECTION eq "kaivos")
		#{
		#	goto skip;
		#}

		#
		if( -e $fn && !$al{$fn} )
		{
			if($_[0] eq "kaivos") {
				$con = VerboseViewHL_EmphasizeSource($fn,$cl,90,$fn, "dark");
				$URL = $USE_THIS_URL_ART;
			} else {
				$con =  VerboseViewHL_EmphasizeSource($fn,$cl,90,$fn, "dark");
				$URL = $USE_THIS_URL_ART;
			}
			$al{$fn}++;
		}
		else
		{
			$con = "";
		}

		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}
		if($u1 ne "" && $u2 ne "" && $u1 eq $u2 && !$sel) { $col = "#800000"; $sel++; }

		#
		if($con eq "") { goto skip; }


		#
		if( !($URL=~/^http:\/\//) ) {
			$URL = "http://$ENV{'SERVER_NAME'}/" . $URL;
		}

		#
#		if($al_url{$URL} eq "") {
#			$al_url{$URL}++;
#		} else {
#			goto skip;
#		}
#
		#
		$str = ("$str
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">

			<font size=1>

			<table cellpadding=4 cellspacing=0>
			<tr>
			<td onMouseover=\"this.className='td_over_white';\"
				onMouseout= \"this.className='';\"
				onClick=\"Javascript:parent.window.location='$URL';\"
				target=\"_parent\">
			$con
			</td>
			</tr>
			</table>

			</font>

			</td>
			");
		$i2++;

		#
skip:
	}

                my $FEED_ICON_HTML = ("
<IMG SRC=\"/images/icons2/rss_feed_icon_16x16.gif\" border=0 align=\"middle\">
			");
		#
		$str .= ("
<TABLE width=100% cellspacing=0 cellpadding=0 border=0
	bgcolor=\"#FFE0F8\">
<TR>
<TD>
<DIV ALIGN=\"center\">
<a href=\"http://www.vunet.org/rss.pl?sec=$_[0]\" class=news5 target=\"_blank\">
<font size=\"2\">$FEED_ICON_HTML Tilaa uutiset (Firefox) </font> </a>
</DIV>
</TD>
</TR>
</TABLE>

		");

	#
	$str = ("$str
		</table>
		</center>
		");

	#
	return $str;
}

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if( !NoTracking() )
	{
		$IS_ADMIN = 1;
	}
	else
	{
		$IS_ADMIN = 0;
	}

	#
	if($so{'s'} ne "")
	{
		$SECTION = $so{'s'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		$SECTION = "progressive";
	}

	#
	$str = newsbar();
        #
	$str =~ s/[\t\n\r\s]/ /g;
	$str =~ s/  / /g;
	$str =~ s/\"/\\\"/g;

	#
	#@sp = split(/(.{5000}[^\\]{8})/, $str);
	#for($i=0; $i<($#sp+1); $i++)
	#{
	#	if($sp[$i] ne "")
	#	{
	#	        print(" document.write(\"$sp[$i]\");\n ");
	#	}
	#}
	print(" document.write(\"$str\"); \n ");

	#
}
