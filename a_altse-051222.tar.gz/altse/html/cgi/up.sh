#!/bin/bash
screen -d -m /home/vai/public_html/cgi/admin/up2b.sh
