#!/usr/bin/perl
#
# jsviscount.pl
#
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn,$MSG);

	#
	if($ENV{'NW_LANGUAGE'} eq "fi")
	{
		# Finnish
		$MSG = "eri k�vij��, laskenta aloitettu";
	}
	if($ENV{'NW_LANGUAGE'} eq "en")
	{
		# English
		$MSG = "different visitors since";
	}
	if($ENV{'NW_LANGUAGE'} eq "se")
	{
		# English
		$MSG = "unika bes�kare sedan";
	}

	#
	if(-e "iplist.txt")
	{
		@lst = LoadList("iplist.txt");
	}

	#
	$i = $#lst+1;

	#
	$str3 = ("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR valign=top>
<TD width=20%>
</TD>
<TD width=80%>

<FONT color=orange size=1>
<b>$i</b> $MSG 1.6.2006
</FONT>

</TD>
</TR>
</TABLE>
");

	#
        $str3 =~ s/[\t\n\r\s]/ /g;
        $str3 =~ s/  / /g;
        $str3 =~ s/\"/\\\"/g;
        $str3 =~ s/\'/\\\'/g;

	#
        print("\n  document.write(\"$str3\");  \n");

	#
}


