#!/usr/bin/perl
system("/home/vai/sdb/bin/cgi-front.pl");
