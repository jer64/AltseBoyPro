#!/usr/bin/perl
srand();
printf "%d\n", int(rand(1000000000));
