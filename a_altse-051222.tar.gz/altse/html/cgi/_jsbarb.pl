#!/usr/bin/perl
################################################################################
#
# Embedded News Bar (JAVASCRIPT).
# Featuerd in articles on the left.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		30;
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();

# CapUrl URL CAP.
sub CapUrl
{
        my ($url);
        $urlcap = $_[1];
        $urlcap =~ tr/[A-Z���]/[a-z���]/;
        $urlcap =~ s/�/a/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/�/o/g;
        $urlcap =~ s/[^a-z0-9]/_/g;
        $urlcap =~ s/_*$//g;
        $urlcap =~ s/^_*//g;
        $urlcap =~ s/__/_/g;
        $urlcap =~ s/^(.{20}[a-z0-9]*).*$/$1/;
        $url = $_[0];
        $url =~ s/\/english\//\/picks\//;
        $url =~ s/\/article//;
        $url =~ s/story([0-9]*)/$urlcap-$1/;
        return $url;
}

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if($so{'s'} ne "")
	{
		$SECTION = $so{'s'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		return;
	}

	#
	$str = newsbar();
        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

	#
        print(" document.write(\"$str\"); \n");
}

################################################################################
#
sub newsbar
{
	my ($str);

	#
	$WID = "100%";

	#
	$str = ("
			<table width=100% cellpadding=2 cellspacing=0>
		");

	#
	if($SECTION ne "english")
	{
		$SEK = "finnish";
	}

	#
	if($SECTION eq "english")
	{
		$SEK = "english";
	}

	#
	####EXPRESS2("$SECTION", "http://www.vunet.org/$SEK/$ENV{'CURSEC'}", "center");

	#
	$str = ("$str
		<table width=450 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	if($SECTION eq "english" || $SECTION eq "")
	{
		$FP = "english";
		$str = sprintf "%s %s", $str, ViewNewStuff("english");
	}

	#
	if($SECTION ne "english")
	{
		#
		$FP = "finnish";
		$str = sprintf "%s %s", $str,ViewNewStuff($SECTION);
	}


	#
	$str = ("$str
		</td>
		</tr>
		</table>
		");

	#
	return $str;
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$con,$re);

	#
	$re = 0;

	#
	@art = LoadList("$_[0]");

	#
	$con = "";
	$cap = substr($art[0], 0, 200);

	#
	if($cap eq "") { return ""; }

	#
	$u1 =~ s/poimitut\/\.\.//;
	$u2 =~ s/poimitut\/\.\.//;
	$u1 = UrlFix(BuildQuickUrl($_[0]));
	$u2 = UrlFix(BuildQuickUrl($so{'a'}));
	$URL = "http://vunet.org$u1";
	$u3 = $_[0];
	$u3 =~ s/[a-z]*\/\.\.\///;
	$u3 =~ s/pub_artikkeli(.*)\.txt/story$1.html/;
	$u3 = "/$u3";
	$URL = CapUrl($u3, $cap);
	if( !($URL=~/^http:\/\//) )
	{
		$URL = "http://www.vunet.org$URL";
	}

	#
	if($u1 ne $u2)
	{
		$con = ("$con
			<font size=2>
			");
	}
	else
	{
		$re = 1;
		$con = ("$con
			<font color=\"#FFFF00\" size=1>
			");
	}

	#
	$cap =~ s/<br>//ig;
	$cap =~ s/(\S{15})/$1 /g;

	#
	$con = ("$con
		<div>
		<li>
		<b>$cap</b>
		</li>
		</div>
		");
	if($u1 ne $u2)
	{
		$con = ("$con
			");
	}
	else
	{
		$con = ("$con
			</font>
			");
	}

	#
	return $con;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,$i,$i2,$col,$con,$st,$str);

	#
#	if( !NoTracking() ) { return(); }

	#
	$str = ("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	#
	@lst = "";
	@lst = LoadList("$_[0]/fileindex.txt");
	$col = "";

	#
	loop: for($ii=$#lst,$i2=0,$st=time; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW; $ii--)
	{
		#
		$t = time;
		if( ($t-$st)>2 ) { last loop; }

		#
		$fn = "$_[0]/$lst[$ii]";

		#
		if($fn=~/\/videos\// && $_[0] eq "poimitut")
		{
			goto skip;
		}

		#
		if( -e $fn )
		{
			$con = ViewHL($fn);
		}
		else
		{
			$con = "";
		}

		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}
		if($u1 eq $u2) { $col = "#800000"; }

		#
		if($con eq "") { goto skip; }

		#
		$str = ("$str
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">
			<font size=3>


			<table cellpadding=4 cellspacing=0 width=100%>
			<tr>
			<td onMouseover=\"this.className='td_over_white';\"
			    onMouseout= \"this.className='';\"
			    onClick=\"window.location.href='$URL';\">
			$con
			</td>
			</tr>
			</table>

			</font>
			</td>
			");
		$i2++;

		#
		if($ii==0) { last loop; }
skip:
	}

	#
	$str = ("$str
		</table>
		</center>
		");

	#
	return $str;
}
