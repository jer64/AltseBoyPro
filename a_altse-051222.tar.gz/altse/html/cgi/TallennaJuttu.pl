#!/usr/bin/perl
##############################################################################################
# TallennaJuttu.pl - (C) 2004-2006 by Jari Tuominen.
##############################################################################################

#
$RETURL = "/JulkaisuSivu.pl?v=Juttusi toimitettiin eteenp�in ja se odottaa nyt k�sittely�.";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
if( !($ENV{'HTTP_REFERER'} =~ /www\.vunet\.org/) )
{
        exit;
}

#
require "admin.pl";

##############################################################################################
#
# Go to main loop.
#
main();

##############################################################################################
#
sub read_input
{
	my (@sp,$i,$i2,$all);

	# Read in text
	$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
	if ($ENV{'REQUEST_METHOD'} eq "POST")
	{
		#
		read(STDIN, $all, $ENV{'CONTENT_LENGTH'});
		@sp = split(/\&/, $all);
	}
	else
	{
		print "Error: Post method required.<br>\n";
		die;
	}

	#
	$viesti =	$sp[0];
	$viesti =~ s/\+/ /ig;
	$viesti =~ s/%(..)/pack("C", hex($1))/eg;
	$viesti =~ s/HINT\=//;

	#
	$kuka =	$sp[1];
	$kuka =~ s/\+/ /ig;
	$kuka =~ s/%(..)/pack("C", hex($1))/eg;
	$kuka =~ s/NAME\=//;
}

##############################################################################################
#
sub SaveToHints
{
	my ($x,$f);

	# Add to the country list.
	open($f, ">>hints.txt") || die "Oops! Error while writing hints database.";
	print $f "===============================================================\n";
	print $f "[L�hett�j�n nimi: $kuka]\n\n";
	print $f "$viesti\n";
	print $f "===============================================================\n\n\n";
	close($f);

        open($f, "|mail admin\@vunet.org -s \"Juttuvinkki $des[$so{'t'}] vastaanotettu.\"");
        if(!NoTracking())
        {
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
        }
	print $f "===============================================================\n";
	print $f "[L�hett�j�n nimi: $kuka]\n\n";
	print $f "$viesti\n";
	print $f "===============================================================\n\n\n";
	close($f);
}

##############################################################################################
#
sub main
{
	#
	print "<html>\n";

	#
	read_input();

	#
	SaveToHints();

	#
	print "<meta http-equiv=\"refresh\" content=\"0; url=$RETURL\">\n";

	#
	print "<h2>Hint successfully added. Thank you.</h2><br>\n";
	print "<a href=\"$RETURL\">\n";
	print "Returning to Alternative News Network.<br>\n";
	print "</a>\n";

	#
	print "<hr><br>\n";

	#
	print $buffer;

	#
	print "</html>\n";
}


