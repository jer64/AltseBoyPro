#!/usr/bin/perl
#
# Information tip.
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	@tips = ("You can recommend an article to others by giving it a thumb up. This way we can better rank articles on the website.",
		 "Voit suositella artikkelia toisille antamalla sille peukun. N�in autat meit� arvioimaan mitk� artikkelit ovat olleet eniten mielytt�vi� lukijoille."
		);

	#
	print("
<HTML>
<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
<TITLE> INFO </TITLE>
</HEAD>

<BODY>

<TABLE cellspacing=0 cellpadding=8 width=100% height=100%
	background=\"$IMAGES_BASE/repeat_pattern.gif\">
<TR>
<TD>
<FONT COLOR=#FFFF00>
<DIV align=center>
<IMG SRC=\"$IMAGES_BASE/red_star.gif\">
</DIV>
		");

	#
	print $tips[$so{'id'}];

	#
	print("
</FONT>
</TD>
</TR>
</TABLE>

</BODY>
</HTML>
		");

	#
}


