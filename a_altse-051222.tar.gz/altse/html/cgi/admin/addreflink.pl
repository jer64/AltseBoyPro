#!/usr/bin/perl
#############################################################################
# COMMENTING SCRIPT.
# (C) 2004-2008 by Jari Tuominen.
# Updated 6:17 24.2.2004.
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#######################################################
# Go to main loop.
#
main();

##########################################################
sub Operate
{
	my $i,$i2,$i3,$i4;

	#
	if($so{'ARTICLE'} eq "")
	{
		die "Article parameter is empty (\"$so{'ARTICLE'}\")!";
	}
	if($so{'DESCRIPTION'} eq "")
	{
		die "DESCRIPTION parameter is empty (\"$so{'DESCRIPTION'}\")!";
	}
	if($so{'URL'} eq "")
	{
		die "URL parameter is empty (\"$so{'URL'}\")!";
	}

	#
	$fn = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'ARTICLE'}\_links.txt";

	# Add link.
	open($f, ">>$fn") || die "can't write $fn !<BR>\n";
	print $f "$so{'DESCRIPTION'}\n";
	print $f "$so{'URL'}\n";
	close($f);

	#
	print "<meta http-equiv=\"refresh\" content=\"0; url=/viewarticle.pl?article=$so{'ARTICLE'}\">\n";
}

##########################################################
sub main
{
	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	##################################################################
	#
	Operate();
}


