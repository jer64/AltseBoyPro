#!/usr/bin/perl
main();

#
sub main
{
	#
	if( !(-e "composed/" && -e "tmp/") ) { die "Folders composed or tmp not found.\n"; }
	
	#
	open($f, "section.cfg") || die "not found section.cfg";
	@lst = <$f>;
	for($i=0; $i<($#lst+1); $i++) { chomp $lst[$i]; }
	$grp=$lst[0];
	$much=$lst[1];
	close($f);
	
	#
	print "$grp\n";
	system "cd tmp; /home/vai/public_html/cgi-bin/admin/hae.pl $grp $much; cd ..";
	system "kon.pl";
	##system "gather2.pl";
}
