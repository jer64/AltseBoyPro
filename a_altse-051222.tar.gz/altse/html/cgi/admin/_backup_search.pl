#!/usr/bin/perl
#######################################################
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2005 by Jari Tuominen.
# Calls is.pl -Perl program (instant search).
#######################################################

#
use POSIX;
use String::Approx 'amatch';

#
require "tools.pl";

#
$USE_QUERY_CACHE = 0;
#
$IMP_MESSAGE = "<font size=1><i>Search The Web with<br>The Alternative Search Engine (ALTSE)...</i></font><br>";
#
$PAGE_TITLE = "Altse";
$LOGO1 = "$IMAGES_BASE/altse5.jpg";
$LOGO2 = "$IMAGES_BASE/altse5sm.jpg";

#
$IS_PL = "is.pl";

# Image search.
$MAX_IMGS_PER_LINE = 5;
$MAX_IMGS_PER_PAGE = 2*$MAX_IMGS_PER_LINE;
$REQ_MIN_IMG_SIZE = 8192;
$IMG_SS = 175;

#
$FONTCC =  "dark";
$FONTCC2 = "dark";
$FONTCC3 = "dark";
$TVAR = "#FFFFFF";

#
$COPYRIGHT = "(C) 2003-2005 Vaihtoehtouutiset organization.";

#
$SDB = "$NWPUB_CGIBASE/sdb";    # search database root directory
$CID = "$SDB/cid";              # central index
$DATA = "$SDB/cid/data";
$LISTS = "$SDB/cid/lists";          # list files directory
$TMP = "$SDB/tmp";

#
if( !$ENV{'newswire_conset'} )
{
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "haku";

#
main();

################################################################
#
sub SubmitNewUrlForm
{
	print ("
                <form method=\"get\" action=\"/search.pl\" name=\"FORM1\" class=formx>
			Submit following URL to the search engine:<br>
			URL: <input type=\"text\" name=\"q\" size=\"40\" value=\"$so{'q'}\">
			<input type=\"hidden\" name=\"submit\" value=\"2\">
                        <br>
			<input type=\"submit\" value=\"Submit URL\" class=buttonx>
                </form>
                <script language=\"javascript\">
                function sf()
                {
                        document.FORM1.q.focus();
                }
                </script>

		");
}

########################################################################################
#
sub Hints
{
	my ($i,$i2,$str,$str2,@lst);

	#
	print("
		<br>

		<table cellpadding=1 cellspacing=0 border=0 bgcolor=#0000FF>
		<tr>
		<td>

		<table cellpadding=8 cellspacing=0 width=300 bgcolor=\"$TVAR\">
		<tr>
		<td>
		<div align=center>Hints</div>");

	#
	@lst = LoadList("sdb/hints.txt");
	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$str = $lst[$i];
		$str =~ s/\(.*\)//g;

		#
		print("
			<div style=\"text-align: justify;\">
			<font size=2>
			<a href=\"/search.pl?cmd=go&q=$str\" class=$FONTCC2>
			- $lst[$i]
			</a>
			</font>
		");
	}


	print("
		</div>

		</td>
		</tr>
		</table>

		</td>
		</tr>
		</table>

		");

}

################################################################
#
sub ViewSearchLog
{
	my ($t,$pm,$i,$i2,@s,$key,$host);

	#
	print("
		<br>
		<table cellpadding=4 cellspacing=0 width=500>
		<tr valign=top>
		<td>
		");

	#
	@lst = LoadList("sdb/slog.txt");

	#
	print("
		<div align=center>
		<font size=4><b>10 most recent searches</b></font>
		</div>
		<br>
		");

	#
	for($i=$#lst,$i2=0; $i>0 && $i2<10; $i--)
	{
		#
		@s = split("&", $lst[$i]);
		#
	        $pm = POSIX::strftime("%H:%M", localtime($s[0]));
		#
		$key = $s[3];
		$key =~ s/<|>//g;
		$key =~ s/(\S{20})/$1 /g;
		$host = $s[2];
		if(length($host)<4) { $host = $s[1]; }
		$host =~ s/(\S{40})/$1 /g;
		if($host =~ /user\-200\-47\.kanetti\.fi/i) { goto skip; }
#		if(IsBanned($host)) { $i2--; goto skip; }

		#
		print("
		<table cellpadding=0 cellspacing=0 width=500 height=1>
		<tr valign=top>
		<td width=100 bgcolor=\"$TVAR\">
		</td>
		</tr>
		</table>

		<table bgcolor=#000080 cellpadding=1 cellspacing=0 border=0>
		<tr>
		<td>

		<table cellpadding=4 cellspacing=0 width=500 bgcolor=$TVAR>
		<tr valign=top>
		<td width=50 bgcolor=$TVAR valign=center>
			<div align=center>$pm</div>
		</td>
		<td width=150 bgcolor=$TVAR>
			<font size=2><a href=\"/search.pl?cmd=go&q=$key\" class=$FONTCC3>$key</font>
		</td>
		<td width=300 bgcolor=$TVAR>
			<font size=1>$host</font>
		</td>
		</tr>
		</table>

		</td>
		</tr>
		</table>
			");

		#
		$i2++;
skip:
	}

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
}

################################################################
#
# Search Form.
#
sub SearchMain
{
	#
	my @sop = (	"1K,1024",
			"4K,4096",
			"8K,8192",
			"16K,16384",
			"32K,32768",
			"64K,65536",
			"128K,131072",
			"256K,262144",
		);
	@prop = (
			"10",
			"20",
			"50",
			"100",
			"200"
		);
	my $i,$i2,$i3,$i4,$str,$str2,@sp;

	#
	print("
		<table width=\"550\" cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	if($so{'q'} ne "")
	{
		$ALI = "left";
		$ALI2 = "";
		$ADD1 = sprintf("
			<a href=\"/search/\">
			<img src=\"$LOGO2\" alt=\"SEARCH ENGINE\"
				TITLE=\"Go back to main page!\"
				border=0 align=left>
			</a>
			");
	}
	else
	{
		$ALI =  "center";
		$ALI2 = "<br>";
		$ADD1 = sprintf("
			<br>
			<a href=\"/search/\">
			<img src=\"$LOGO1\" alt=\"SEARCH ENGINE\"
				border=0>
			</a>
			<br>
			");
	}

	#
	if($so{'co'} eq "1") { $check1 = " checked"; }
	if($so{'il'} ne "1") { $check2 = " checked"; }
	if($so{'il'} eq "1") { $check3 = " checked"; }
	#
	if($so{'where'} eq "web") { $t2=""; $t1 = "checked"; } else { $t1 = ""; $t2="checked";}

	#
	print("
		<div align=$ALI>
		$ADD1
		");

	#
	if($so{'submit'} eq "")
	{
		#
		print ("
                <form method=\"get\" action=\"/search.pl\" name=\"FORM1\" class=formx>
			$IMP_MESSAGE
			<input type=radio name=il value=0 $check2 onClick='this.form.submit()'><font size=2>Web</font>
			<input type=radio name=il value=1 $check3 onClick='this.form.submit()'><font size=2>Images</font>");
		if($so{'il'})
		{
			# Image search.....
			print("- min. size: <select name=mis onChange=\"FORM1.submit()\">");
			for($i=0; $i<($#sop+1); $i++)
			{
				@sp = split(",", $sop[$i]);
				if($sp[1]==$so{'mis'}) { $i2="selected"; } else { $i2=""; }
				print("\n<option value=$sp[1] $i2>$sp[0]</option>\n");
			}
			print("</select>
				");
		}
		else
		{
			#
			print("
			<select name=RC onChange=\"FORM1.submit()\">
				");
			for($i=0; $i<($#prop+1); $i++)
			{
				if($prop[$i]==$so{'RC'}) { $i2="selected"; } else { $i2=""; }
				print("\n<option value=$prop[$i] $i2>$prop[$i]</option>\n");
			}
			print("
			</select>
			results to show
				");
		}
		print("
			<br>
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$so{'q'}\">
                        <br>
                        <input type=\"submit\" value=\"Search\" class=buttonx>
                        $ALI2
		<!--	<input type=checkbox name=co value=\"1\"$check1><font size=2>Articles with comments only.</font>-->
			<input type=checkbox name=REFRESH value=\"1\"><font size=2>Refresh.</font>
			<br>
                </form>
		");

		#
		if($so{'q'} eq "")
		{
			print("
		                <script language=\"javascript\">
		                function sf()
		                {
					document.FORM1.q.focus();
		                }
		                </script>
				");
		}
	}
	else
	{
		#
		print("
			<table width=350 cellpadding=8 cellspacing=0
				bgcolor=\"#E0F0FF\">
			<tr>
			<td>
			");

		#
		if($so{'submit'}==1)
		{
			SubmitNewUrlForm();
		}
		else
		{
			#
			if(!($so{'q'}=~/^.*\.../))
			{
				#
				print("
				Bad URL: \"<b>$so{'q'}</b>\"<br>
				");
			#	if(!($so{'q'}=~/http/)) { 
			#		print("URL must begin with <b>http://</b><br>");
			#	}
				print("
				<a href=\"javascript:history.go(-1)\">
				> try again
				</a>
					");
			}
			else
			{
				#
				open($f, ">>sdb/suggested_urls.txt") || die "can't add";
				print $f "$so{'q'}\n";
				close($f);

				#
				print("
					URL added successfully.<br>
					<br>
					The URL is queued to be processed.<br>
					<br>
					<div align=right>
					<a href=\"/search/\" class=$FONTCC3>Click here to continue ...</a><br>
					<font size=2>
					<a href=\"/search.pl?submit=1\" class=$FONTCC3>Or perhaps add another?</a>
					</font>
					</div>
					");
			}

			#
		}

		#
		print("
			</td>
			</tr>
			</table>
			");
	}

	#
	print("
		</div>
		");
#                        <input type=radio name=where value=\"web\" $t1>web
#                        <input type=radio name=where value=\"news\" $t2>VUnet news<br>

	#
	if($so{'q'} eq "" && $so{'submit'} eq "")
	{
		#
	#	Hints();

		#
		print("
<br>
<div align=center>
<a href=\"/search.pl?submit=1\" class=$FONTCC>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
Add new URL
</a>
</div>
		");

		#
		if(NoTracking())
		{
			#
			print("
<div align=center>
<a href=\"/admin/editart.pl?FILE=$NWPUB_CGIBASE/sdb/slog.txt&RETURL=/search/\" class=$FONTCC>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
View search log
</a>
</div>

<div align=center>
<a href=\"/admin/editart.pl?FILE=$NWPUB_CGIBASE/sdb/suggested_urls.txt&RETURL=/search/\" class=$FONTCC>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
View suggested URLs
</a>
</div>

<div align=center>
<a href=\"/admin/crawl.pl\" class=$FONTCC>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
Crawler administration
</a>
</div>
				");

			#
			ViewSearchLog();
		}

		#
		print("
		<br>
		<font size=1>
		$COPYRIGHT
		</font>
		");
	}

	#
	print("

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub PreviewComment
{
	my ($i,$i2,$i3,$i4,@ll,$fn,$str,$ii,$line);

	#
	if( -e $_[0] )
	{
		#
		@ll = LoadList("$_[0]");
		if($#ll<1) { return ""; }

		#
		if($ll[0] =~ /intlfox/) { $ii=1; } else { $ii=0; }
		for($str=""; $ii<($#ll+1); $ii++)
		{
			#
			$line = $ll[$ii];
			$line =~ s/<*?>//g;
			$str = "$str $line ";
		}
		$str =~ s/(.{75}?).*/$1\.\.\./g;
		$str =~ tr/[A-Z���]/[a-z���]/;
		return $str;
	}

	#
	return "";
}

################################################################
#
# section, search string, category
#
sub DisplayCommentTree
{
	my ($i,$i2,$i3,$i4,@l,$fn,$str,$ast,$ast2,$count,$k,$x);

	#
	$fn = "$_[0]\_comindex.txt";

	# Find a comindex...
	if( -e $fn )
	{
		#
		@l = LoadList($fn);

		#
		if($#l<0)
		{
			return 1;
		}

		#
		for($k=0,$count=1,$ast2=""; $k<($#l+1); $k++)
		{
			#
			$ast = PreviewComment($l[$k]);
			if($ast ne "")
			{
				#
				$ast2 = ("$ast2
				<div>
				<table cellpadding=2 cellspacing=0 width=100%>
				<tr valign=top>
				<td width=5%>
				</td>

				<td width=95%>
		<font size=2>$count\. $ast</font>
				</td>
				</tr>
				</table>
				</div>

				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95% bgcolor=\"#F0F0F0\">
				</td>
				</tr>
				</table>
				");
				#
				$count++;
			}
		}

		#
		if($ast2 ne "")
		{
				#
				$x = $count-1;
				$ast2 = ("


				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95%>
				<font size=2><b>$x</b> comment(s):</font>
				</td>
				</tr>
				</table>

				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95% bgcolor=\"#800000\">
				</td>
				</tr>
				</table>

				$ast2
					");


		}

		#
		return $ast2;
	}

	#
	return "";
}

################################################################
#
sub EmphasizeKeywords
{
	my ($str,$i,$i2);

	#
	$str = $_[0];

	#
	for($i=0; $i<($#W+1); $i++)
	{
		#
		$W[$i] =~ s/\s*//g;
		#
		$str =~ s/($W[$i])/<b>$1<\/b>/gi;
	}

	#
	return $str;
}

################################################################
#
# Display results.
#
sub DisplayResults
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$fna,$score,@sp,$id,$ST,
		$str,$str2);

	# Text view.
	####$so{'start'};
	$ST = $so{'start'};

	#
	$i=0;

	# Set total.
	$so{'tot'} = $tl[$i];
	$i+=2;

	#
	loop: for($i2=0,$imgs=0; $i<($#tl+1); $i++)
	{
		#
		if($i2>=$SHOW) { last loop; }

		#
		print("
			<table width=760 cellpadding=0 cellspacing=0>
			<tr valign=top>
			");
		print("
			<td width=100%>
			");
		#
		$url = "$tl[$i+0]/$tl[$i+1]";
		$url =~ s/\/index\.htm[l]$//i;
		$durl = $url;
		$durl =~ s/^(.{30}).*(.{30})$/$1\.\.\.$2/;
		$cap = $tl[$i+2]; if($cap eq "") { $cap = "Untitled."; }
		$cap =~ s/^(.{80}).*/$1\.\.\./; # max. cap. length is 80 chars
		$prv = $tl[$i+3];
		$prv =~ s/^[^a-z���0-9\.]*//gi;
		$dat = $tl[$i+4];
		if( !($dat=~/[0-9]*K/) ) { $dat="[no information available]"; }

		#
		$prv = EmphasizeKeywords($prv);
		$cap = EmphasizeKeywords($cap);
		$durl = EmphasizeKeywords($durl);
		$prv =~ s/^(\.\.\.)\s*/<b>...<\/b> /;
		$prv =~ s/\s*(\.\.\.)$/ <b>...<\/b>/;

		#
		print("
			<a href=\"http://$url\" class=news2>$cap</a><br>
			<font color=#000000>$prv</font><br>
			<font color=#808080>$durl - $dat</font><br>
			<br>
			");
		#
		loopz: for(; $i<($#tl+1); $i++) {  if($tl[$i] eq "") { last loopz; }  }
		$i2++;
		#
		print("
				</td>
				");

		#
		print("
			</tr>
			</table>
			");
skipent:
	}

	#
	return $i2;
}

################################################################
#
# Display image results.
#
sub DisplayImageResults
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$fna,$score,@sp,$id,
		$str,$str2);

	# Image view.
	$i = $#tl;
	$imgz = 0;

	#
	loop: for($i2=0,$imgs=0; $i>-1; $i--,$i2++)
	{
		#
		if($imgz>=$MAX_IMGS_PER_PAGE) { last loop; }

		#
		@sp = split(" & ", $tl[$i]);

		#
		$fna = $sp[1];
		$fna =~ s/\s//g;
		$score = $sp[0];
		$id = $sp[4];
		if($fna eq "") { $i2--; goto skipent; }

		#
		$str = $sp[3];
		$str =~ s/\/[0-9]*$/$1/i;

		#
		# $fna,$score,$id, $id, $str
		ViewTinyGallery($fna,$score, $id, $str);

skipent:
	}

	#
	return $i2;
}

################################################################
#
# Print a single image.
#
sub PrintImage
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$ap,$str,$str2,$fn,$t,$pm,$f,$sl,$big,$score,$nfn,$tmp,$fn_ils,@ils,$host,$x,$y,@li,$img);

	#
	@ils = LoadIls($_[0], $_[1]);

	# 1) Try to find a matching image.
	loop1: for($i=0,$x=0; $i<($#ils+1); $i++)
	{
		for($i2=0; $i2<($#W+1); $i2++)
		{
			if($ils[$i]=~/$W[$i2]/) { $x=$i; last loop1; }
		}
	}

	# 2) Try to find a jpeg if current is not one.
	if($x==0 && !($ils[$x]=~/\.jp[e|]g/i) )
	{
		loop2: for($i=0,$x=0; $i<($#ils+1); $i++)
		{
			if($ils[$i]=~/\.jp[e]g/i) { $x=$i; last loop2; }
		}
	}

	# Skip possible banners.
	loopoz: for(; $x<($#ils+1); $x++)
	{
		if( !($ils[$x] =~ /banner/) ) { last loopoz; };
	}

	#
	$img = $ils[$x];
	if($img ne "" && !($img=~/blank/))
	{
	print("
		<img src=\"$ils[$x]\" width=64 height=64 vspace=2 hspace=2 border=1
			title=\"$ils[$x]\">
		");
	}
}

#
sub IlsName
{
	my ($str);

	#
        $str = "$SDB/cid/data/$_[0]";
        $str =~ s/^(.*)\.\S*$/$1/;
        $str = "x$str\.dor";
	return $str;
}

################################################################
#
# Load & parse an image list.
#
sub LoadIls
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$ap,$str,$str2,$fn,$t,$pm,$f,
	$sl,$big,$score,$nfn,$tmp,$fn_ils,@ils,@ils2,$host,$x,$y,@li,@tlst,$fo);

	#
	$host = "$_[0]";
	$host =~ s/^sdb\/(.*\/).*/$1/;
	$host =~ s/\/.*$//g;

	# Get image list file name.
	$fn_ils = "$DATA/$host/x$_[1].dar";

	#
	@ils2 = ();

	#
	if(-e $fn_ils)
	{
		# Read image list to @ils structure.
		@tlst = LoadList("$fn_ils");
		loop: for($i=0,$fo=0; $i<($#tlst+1); $i++)
		{
			if($tlst[$i] eq "$_[1].ils") { $fo=1; $i++; last loop; }
		}
		if(!$fo) { return(); }
		else
		{
			loop2: for($x=0; $i<($#tlst+1); $x++,$i++)
			{
				if($tlst[$i] eq "") { last loop2; }
				$ils[$x] = $tlst[$i];
			}
		}

		#
		for($x=0,$y=0; $x<($#ils+1); $x++)
		{
			#
			if($ils[$x] =~ / \& / && !$_[2])
			{
				$ils[$x] =~ s/^[0-9]*\s*\&\s*(\S*)\s*.*$/$1/;
			}

			#
			if($ils[$x]=~/\.[a-z][a-z][a-z]\ /i)
			{
				if(!$_[2])
				{
					$ils[$x] =~ s/^file:\/\/.*\/sdb/http:\/\//;
					$ils[$x] =~ s/^.*sdb\///;
					if( !($ils[$x] =~ /^$host/) && !($ils[$x]=~/^http/) )
					{
						$ils[$x] = "$host/$ils[$x]";
					}
					if(!($ils[$x]=~/^http/)) { $ils[$x] = "http:\/\/$ils[$x]"; }
				}
				$ils2[$y++] = $ils[$x];
			}
		}
	}

	#
	return @ils2;
}

################################################################
#
# View result.
#
sub ViewTinyGallery
{
	my ($i,$i2,$str,$str2,$l,$url,$fn,$sz,@sp,$des,$x,$y,$des2,$turl,$k);

	#
	@ils = LoadIls($_[0],$_[2],1);

	#
	for($i=0,$i2=0,$l=""; $i<($#ils+1); $i++,$i2++)
	{
		#
		$url = $ils[$i];
		if($url =~ / \& /)
		{
			@sp = split(" & ", $url);
			$url = $sp[1];
			$sz = sprintf "%d", $sp[0];
		}
		else
		{
			$sz = 0;
		}

		#
		if($url ne $l && $sz>$so{'mis'} && $url=~/^\S*$/)
		{
			#
			$des = $url;
			$des =~ s/^\S*\/(\S*\.\S*)/$1/;
			$des =~ s/%20/ /g;
			$des =~ s/^(.{20}).*$/$1/;
			$des2 = $des;
			$des2 =~ s/\.[a-z]*$//g;
			$des2 =~ s/[\-|_|,|.]/\ /g;
			$turl = $_[0];
			$turl =~ s/^(\S*\/)index\.html$/$1/;
			$x = $IMG_SS;
			$x+=8;

			#
			$k = sprintf "%d", $sz/1024;

			#
			if( $viewed{$url} ) { goto past; }
			#
			$viewed{$url}++;

			#
			$imgs ++;
			if($imgs>$so{'start'} && $imgz<$MAX_IMGS_PER_PAGE)
			{
				#
				if(($imgz%$MAX_IMGS_PER_LINE)==0) { print("<table><tr valign=top>"); }
				print("
<td>
<table cellpadding=4 cellspacing=0 width=$x>
<tr valign=top><td valign>
<div align=center class=CAPS>
<a href=\"http://$turl\" class=news3>
<img src=\"$url\"
	width=$IMG_SS height=$IMG_SS
	vspace=1 hspace=1
	border=2 alt=\"$des2\" title=\"$des\"></a><br>
<a href=\"$url\" TITLE=\"MAGNIFY IMAGE\"><img src=\"$IMAGES_BASE/icon_magnify2.gif\" border=0 align=right></a>
<a href=\"http://$turl\" class=news1>$des2 ($k K)</a>
</div>
</td></tr></table>
</td>
					");
				$l = $ils[$i];

				#
				if( ($imgz%$MAX_IMGS_PER_LINE)== ($MAX_IMGS_PER_LINE-1) ) { print "</tr></table>\n"; }

				#
				$imgz++;
			}
past:
		}
	}

	#
}

################################################################
#
# View image gallery view.
#
sub ViewImgRes
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$ap,$str,$str2,$fn,$t,$pm,$f,$sl,$big,$score,$nfn,$tmp,$fn_ils,@ils,$host,$x,$y,@li);

	################################################
	ViewTinyGallery($_[0], $_[1], $_[2]);
}

#
sub SaneString
{
	my ($str);

	#
	$str = $_[0];
	$str =~ s/[^0-9a-z���\%\&\[\]\(\)\{\}\-\+\*\.\,\'\"\#\=\:\;\/\\\ ]/ /gi;
	$str =~ s/\ \ /\ /g;
	return $str;
}

################################################################
#
# View result.
#
sub ViewResult
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,
		$ap,$str,$str2,$fn,$t,$pm,$f,$sl,$o,
		$big,$score,$nfn,$tmp,$fn_ils,@ils,$host,$x,$y,@li);

	################################################
	$score = $_[1];
	$tree="";
	$lisa = "<br>";

	################################################
	#
	# Check other rules.
	#

	#
	$sl = 0; # ...

	#------------------------------------------------------------
	# Let's fetch the article...
        $sz = (stat("$SDB/$_[0]"))[7];
	$title="";
	if($sz<=(1024*128))
	{
		#
		$nfn = $_[0];
		$nfn =~ s/^(.*)\.[a-z]*$/$1/g;
		$nfn = "/home/vai/sdb/cid/data/$_[4]/x$_[3].dar";
		if(-e $nfn) { @li = LoadList($nfn); } else { print "not found: $nfn "; return(); }
	}
	else
	{
		#
		$title="Big file (>128K)";
	}

	#
#	print("
#		<table cellpadding=4 cellspacing=0 align=left>
#		<tr>
#		<td>
#		");
#	PrintImage($_[0], $_[3]);
#	print("
#		</td>
#		</tr>
#		</table>
#		");

	#------------------------------------------------------------
	# VIEW ARTICLE PREVIEW
	#------------------------------------------------------------
	#

	#
	$URL = "$_[0]";
	$URL =~ s/\.\///;
	$URL =~ s/^sdb\//http:\/\//;
	$URL =~ s/(\/)index\.html/$1/;

	#
	$RURL = $URL;
	$RURL =~ s/^(.{30}).*(.{30})$/$1\.\.\.$2/;

	#
	if($title=~/^\s*$/ || $title eq "" || length($title)<3)
	{
		$title = "UNTITLED";
	}

	#
	$o=1;
	$str = $li[$o+3];
#	$str = SaneString($str);
	$str =~ tr/[A-Z���]/[a-z���]/;
	$tit = $li[$o+2];
	$tit =~ tr/[a-z���]/[A-Z���]/;
	$tit = SaneString($tit);
	$tit =~ s/\&[A-Z]*\;//g;
	if($tit=~/^\s*$/) { $tit = "UNTITLED"; }
	if($str=~/^\s*$/) { $tit = "No valid content available."; }
	print ("
			<br>
			<a href=\"http:\/\/$URL\" class=$FONTCC3><b>$tit</b></a><br>
			<font color=#C0C0C0>$str<br>
			<font size=2 color=\"#00A020\">$RURL - $pm</font><br>
			");
}

################################################################
#
sub LogThisSearch
{
	my ($f,$t);

	#
	open($f, ">>sdb/slog.txt");
	$t = time;
	print $f "$t & ";
	print $f "$ENV{'REMOTE_ADDR'} & ";
	print $f "$ENV{'REMOTE_HOST'} & ";
	print $f "<$so{'q'}>\n";
	close($f);
}

################################################################
#
sub Controls1
{
	#
	print("
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"hidden\" name=\"q\" value=\"$so{'q'}\">
			<input type=\"hidden\" name=\"where\" value=\"$so{'where'}\">
			<input type=\"hidden\" name=\"co\" value=\"$so{'co'}\">
			<input type=\"hidden\" name=\"start\" value=\"$_[0]\">
			<input type=\"hidden\" name=\"il\" value=\"$so{'il'}\">
                        <input type=\"hidden\" name=\"mis\" value=\"$so{'mis'}\">
	");
}

################################################################
#
sub Controls
{
	my ($i,$i2,$i3,$i4,$x,$x2,$v);

	#
	$i =  $so{'start'}-$SHOW; if($i<0){$i=0;}
	$i2 = $so{'start'}+1+$SHOW-1;

	#
	print("
				<div align=center>

				<table width=500 cellpadding=4 cellspacing=0>
				<tr valign=top>
		");

	#
	if(1)
	{
		if($i >= 0 && $so{'start'} != 0) { $DIS=""; } else { $DIS="disabled"; }
		#
		print("
				<td width=30% align=center>
				<form action=\"/search.pl\" class=formx>   ");
		Controls1($i);
		print("		
				<input type=\"submit\" value=\"<< previous page\" $DIS>
				</form>
				</td>
			");
	}

	#
	if(1)
	{
		#
		print("
				<td width=40%>

				<div align=center>

				<table cellpadding=0 cellspacing=0><tr valign=top><td>
				");

		#
		$sx = $so{'start'} - $SHOW*2; if($sx<0) { $sx=0; }
		for($x=$sx,$x2=0; $x2<5; $x+=$SHOW,$x2++)
		{
			#
			$v = $x/$SHOW;
			if($x<=$RESULTS)
			{
				#
				if($x==$so{'start'}) { $for="buttonx"; } else { $for="buttonx2"; }

				#
			print("<td>
				<form action=\"/search.pl\" class=formx>   ");
			Controls1($x);
			print("		<input type=\"submit\" value=\"$v\" name=\"$x\" class=$for>
				</form>
				</td>");
			}
		}

		#
		print("
				</td>
				</tr>
				</table>

				</div>

				</td>
			");
	}

	#
	if(1)
	{
		#
		if( ($i2 > $RESULTS && $so{'start'} != 0) || $RESULTS<$SHOW ) { $DIS="disabled"; } else { $DIS=""; }
		#
		print("
				<td width=30% align=center>
				<form action=\"/search.pl\" class=formx>   ");
		Controls1($i2);
		print("
				<input type=\"submit\" value=\"next page >>\" $DIS>
				</form>
				<br>
				</td>
			");
	}

	#
	print("
				</tr>
				</table>
				</div>
		");
}

################################################################
#
sub ResultInfo
{
	my ($i,$i2,$i3,$i4);

	#
	$i =  $so{'start'}+1;
	$i2 = $so{'start'}+1+$SHOW-1;
	if($i2 > ($RESULTS+1))
	{
		$i2 = $RESULTS;
	}
	$i2++;
	$i3=sprintf "%d", $i2/10;
	$i3*=10;
	if($i3>=$i) { $i2=$i3; }

	#
	print("
		<table width=100% cellpadding=4 cellspacing=0
			bgcolor=\"#C0FFC0\">
		<tr>

		<td width=20%>
		<div class=\"CAPS\">
		<font size=4>
		<b>
		Web
		</b>
		</font>
		</div>
		</td>

		");

	#
	if($RESULTS >= 0)
	{
		#
		$results = $RESULTS;

		#
	print("
		<td width=80%>
		<div align=right>
		<font size=2>
Results <b>$i - $i2</b> of about <b>$results</b> for <b>$so{'q'}</b>. 
		</font>
		</div>
		</td>
		");
	}
	else
	{
		print("
		<td width=80%>
		<div align=right>
		No hits.
		</div>
		</td>
		");
	}

	#
	print("
		</tr>
		</table>
		<br>
		");
}

##########################################################################################################
#
sub SaveCache
{
	my ($fn,$f,$str,$str2);

	#
	$fn = $_[0];

	#
	open($f, ">$fn") || die "can't write cache";
	for($i=0; $i<($#tl+1); $i++)
	{
		print $f "$tl[$i]\n";
	}
	close($f);

	#
}

##########################################################################################################
#
sub CacheQuery
{
	my ($fn);

	#
	$fn = $_[0];
	if(-e $fn && FileAge($fn)<60)
	{
		@tl = LoadList($fn);
		return 1;
	}

	#
	return 0;
}

##########################################################################################################
#
sub QueryDB
{
	my ($key,$comd,$fn);

	#
	$key = $_[0];

	#
	$query_et = time;

	#
	$fn = "$TMP/cache_$key__$so{'start'}";

	#
	if( $USE_QUERY_CACHE!=0 && !($key=~/REFRESH/) && CacheQuery("$fn") )
	{
		# Found cached result.
	}
	else
	{
		# Text search.
		$comd = "wget -q -O - \"http://sdb.vunet.org/search/?q=$key&pg=$so{'start'}\"|";
		#
		@tl = LoadList($comd);
		#
		SaveCache($fn);
	}

	#
	$RESULTS = $tl[0];
}

##########################################################################################################
#
sub SearchNow
{
	my ($key,$comd);

	#
	$key = $_[0];

	#
	if($key eq "")
	{
		return;
	}

	#
	print("
		<table width=\"100%\" cellpadding=4 cellspacing=0>
		<tr valign=top>
		<td>
		");

	#
	$query_st = time;
	$key =~ s/[^a-z���\.\:0-9\@ ]//gi;
	if($so{'REFRESH'}==1) { $key="$key REFRESH"; }

	#
	if($so{'il'}==1)
	{
		# Image search.
		$comd = "$IS_PL \"$key\" 2> /dev/null|";
		#
		@tl = LoadList($comd);
		$query_et = time;
		#
		$RESULTS = $#tl;
	}
	else
	{
		QueryDB($key);
	}


	#
	Controls();
	ResultInfo();
	print("
				<table cellpadding=0 cellspacing=0 width=100%>
				<tr valign=top>
				<td>
		");
	if($so{'il'}==1)
	{
		DisplayImageResults();
	}
	else
	{
		DisplayResults();
	}
	print("

				</td>
				</tr>
				</table>
		");
	Controls();

	#
#	printf "%d result(s).<br>\n", $tulos;

	#
	if($so{'q'} ne "")
	{
		print("
		<center>
		<a href=\"/search.pl?submit=1\" class=$FONTCC3> <i>> add your own URLs!!</i> </a>
		");
	}

	#
	print("
		<br>
		<font size=1>
		$COPYRIGHT
		</font>
		</center>
		");

	#
	print("

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub ProcessSearchString
{
	my ($str,$i,$i2);

	# Split into search words.
	$str = $so{'q'};
	@W = split(" ", $str);

	#
	for($i=0,$i2=0; $i<($#W+1); $i++)
	{
		$W[$i] =~ s/\*/\.\*/g;
	}
}

################################################################
#
sub main
{
	my ($i,$i2,$str);

	#
	if($so{'RC'}<10 || $so{'RC'} > 200)
	{
		$so{'RC'} = 20;
	}

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	if($so{'mis'} eq "")
	{
		$so{'mis'} = $REQ_MIN_IMG_SIZE;
	}

	#
	if($SDB_SERVICE_OFF && !NoTracking()) { print "Palvelu tilap�isesti pois k�yt�st� huoltot�iden vuoksi."; exit(); }


	#
	if($so{'il'}==1)
	{
		# Image search.
		$IS_PL = "is.pl";

		#
		$SHOW = $MAX_IMGS_PER_PAGE;
	}
	else
	{
		#
		$SHOW = $so{'RC'};
	}

	# Make the search string abit more nicer ...
	$so{'q'} =~ s/\[|\]|{|}/ /g;
	$so{'q'} =~ s/\?/ /g;
	$so{'q'} =~ s/^\s*//;
	$so{'q'} =~ s/\s*$//;

	#
	if($so{'q'} =~ /\sREFRESH$/)
	{
		$so{'q'} =~ s/\sREFRESH$//;
		$so{'REFRESH'} = 1;
	}

	#
	if($so{'q'} eq "" && $so{'searchstring'} ne "")
	{
		$so{'q'} = $so{'searchstring'};
	}
	if($so{'q'} eq "*")
	{
		$TIME_ORDER = 1;
	}
	#
	ProcessSearchString();

	# Get options.
	#
	$set = $so{'q'};
	$set =~ s/\?/\ /;

	#
	if($so{'q'} eq "") { $xtra="onload=sf()"; }

	#
                #
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/search.css\" title=\"Cool\">
<title>
$PAGE_TITLE
</title>
</head>

<body $xtra bgcolor=$TVAR
	topmargin=0 leftmargin=0
	marginheight=0 marginwidth=0>

<center>
<table width=100% bgcolor=$TVAR>
<tr>
<td>
			");

	#
	if(($so{'cmd'} eq "go" || $so{'cmd'} eq "searchnow") && $so{'q'} ne "")
	{
		#
	        if( ($i=IsRunning("search.pl")>4) || IsRunning("is.pl")>1 )
	        {
	                #
	                print("
				SEARCH ENGINE IS OVERLOADED. TRY AGAIN AFTER 10-30 SECONDS.<br>
				Will try again automatically after 10 seconds.<br>
				<meta http-equiv=\"refresh\" content=\"10\">
	                        ");
	                return();
	        }
	        #
	        $i = sprintf("%d", $i);

		#
		SearchMain();
		LogThisSearch();
		SearchNow($set);
	}
	else
	{
		#
		print("
			<div align=center>
			");
		SearchMain();
		print("
			</div>
			");
	}

	#
	print("
</td>
</tr>
</table>
</center>

</body>
		");
}

