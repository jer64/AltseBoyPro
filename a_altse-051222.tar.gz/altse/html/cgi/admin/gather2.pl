#!/usr/bin/perl
# gather2.pl
##############################################################################################################

#
require "/home/vai/public_html/cgi-bin/tools.pl";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();


###########################################################################################################
#
sub Convert
{
	my ($i,$i2,@lst,@lst2,$cap,$str,$str2,$fn);

	#
	if(!-e $_[0]) { return; }

	#
	@lst = LoadList($_[0]);

	#
	$cap = $lst[0];
	$cap =~ s/<[^\>]*>//g;
	$str = $_[0];
	$str =~ s/^([0-9]*)\..*$/$1/;
	$str2 = $cap;
	$str2 =~ s/[^a-zA-Z0-9\-]/_/g;
	$str2 =~ s/^(.{50}).*$/$1/;
	$fn = "$str-$str2.txt";
	if( !(-e $fn) )
	{
		system("mv $_[0] $fn");
	}
	return $fn;
}

###########################################################################################################
#
sub main
{
	my ($i,$i2,@lst,@lst2,$f);

	#
	@lst = LoadList("find -maxdepth 1|");

	# Collect needed files.
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\///;
		if($lst[$i]=~/^[0-9]*\.[0-9]*\.txt$/)
		{
			$lst2[$i2++] = $lst[$i];
		}
	}

	# CONVERT FILES
	for($i=0; $i<($#lst2+1); $i++)
	{
		$lst2[$i] = Convert($lst2[$i]);
	}

	# Refresh list of articles.
	#
	@lst = LoadList("find -maxdepth 1|");

	# Collect needed files II.
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\///;
		if($lst[$i]=~/^[0-9]*\-[a-zA-Z0-9\-_]*\.txt$/)
		{
			$lst2[$i2++] = $lst[$i];
		}
	}
	@lst2 = sort @lst2;

	# Save new index.
	open($f, ">fileindex.txt");
	for($i=0; $i<($#lst2+1); $i++)
	{
		if( !$al{$lst2[$i]} )
		{
			print $f "$lst2[$i]\n";
			$al{$lst2[$i]}++;
		}
	}
	close($f);

	#
}


