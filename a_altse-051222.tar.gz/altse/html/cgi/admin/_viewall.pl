#!/usr/bin/perl
##############################################################3

#
require "admin.pl";

##############################################################3
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
##############################################################3

#
$ENV{'CURSEC'} = "long newswire";

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");
#
WebWalkTo("ENTERHERE_SECTION");
main();
#
        #
#        WebWalkTo("-content-below-mmenu-");
        #
        print "<center>";
        tracker();
        print "</center>";
#
HandleRest();

###############################################
#
sub tracker
{
	#
	print ("

<div align=\"right\">
<br>
<br>
<br>
<br>

<!-- Begin Nedstat Basic code -->
<!-- Title: Tracker 3. VAI. Alternative News. -->
<!-- URL: http://www.saunalahti.fi/ehc50/cgi-bin/viewall.pl -->
<script language=\"JavaScript\" type=\"text/javascript\" src=\"http://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC62HgLVOfdwwZj+CB1vH5Vtquhg\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/stats?AC62HgLVOfdwwZj+CB1vH5Vtquhg\"><img
src=\"http://m1.nedstatbasic.net/n?id=AC62HgLVOfdwwZj+CB1vH5Vtquhg\"
border=\"0\" width=\"9\" height=\"9\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->
</div>

		");
}

#
sub main
{
	#
	@l = LoadList("tempfce2.txt");
#        $l[0] =~ s/%(..)/pack("C", hex($1))/eg;
#	$l[0] =~ s/\\//;
#	$l[0] =~ s/\\"/\"/;
#       $l[0] =~ s/\+/ /ig;

	#
        $l[0] =~ s/<!-A1->/\n/g;
        $l[0] =~ s/<!-A2->/\r/g;
        $l[0] =~ s/\\\"/\"/g;
        $l[0] =~ s/\\\'/\'/g;

	#
	print ("
		<table width=\"500\">
		<tr>
		<td>
		");

	#
	print ("
		<br>
		<img src=\"../uutiset/longnewswire.jpg\">
		");

	#
	print $l[0];

	#
	print ("
		</td>
		</tr>
		</table>
		");
}


