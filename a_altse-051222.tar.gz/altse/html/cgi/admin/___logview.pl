#!/usr/bin/perl
##########################################################################

#
require "admin.pl";

# Load configuration & parse args.
ArgLineParse();

#
$ENV{'CURSEC'} = "linkit";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
#OpenWebIndex("./webindex.html");
#HandleExternal("main-menu", "./mainmenu.pl");
WebWalkTo("enterhere_section");
print("
        <meta http-equiv=\"REFRESH\"
        content=\"0;url=/admin/logview.pl\">
                ");
#main();
#HandleRest();


################################################################
# Load & Parse Log !
#
sub LoadLog
{
	my @log,$i,$i2,$i3,$i4,
		$str,$str2,$str3,$str4;

	#
	@log = LoadList($_[0]);

	#
	return @log;

	#
	for($i=0; $i<($#log+1); $i++)	
	{
		#
		$log[$i] =~ s/<br>//g;
		# Get subject.
		$str2 = $log[$i];
		$str2 =~ s/(.*)(')(.*)(')(.*)/$3/i;
		$str2 =~ s/ /_/g;

		# Get other.
		$str = $log[$i];
		$str =~ s/(.*)(')(.*)(')(.*)/$1/i;

		#
		@tab = split(" ", $log[$i]);
		#
		$IP = $tab[6];
		$IP =~ s/.*=//;
		#
		$HOST = $tab[7];
		$HOST =~ s/.*='(.*)'/$1/;

		#
		$log[$i] = "$str $str2";
	}

	#
	return @log;
}

################################################################
sub TableBeg
{
	#
	print("
		<table
			cellspacing=0 cellpadding=32>
		<tr>
		<td>
		");
}

################################################################
sub TableEnd
{
	#
	print("
		</td>
		</tr>
		</table>
		");
}

################################################################
sub LogView
{
	my @log,$str,$str2,$str3,$str4,
		$i,$i2,$i3,$i4,
		@spt;

	#
	if($so{'ignore_unknown'} eq "true")
	{
		$str = "<a href=\"logview.pl?ignore_unknown=false\">> Show unknown</a>";
	}
	else
	{
		$str = "<a href=\"logview.pl?ignore_unknown=true\">> Hide unknown</a>";
	}

	#
	print("
		<center>
		<font size=\"6\">
		Article Reading History
		</font>
		</center>
		<br>
		$str
		<br>
		<br>
		");

	#
	print("
		<table  style=\"vertical-align: top;\"
			cellspacing=0 cellpadding=4>

		<tr style=\"vertical-align: top;\">
			<td width=85 bgcolor=\"#404040\">
			<font color=\"#FFFFFF\">
				TIME
			</font>
			</td>

			<td width=170 bgcolor=\"#606060\">
			<font color=\"#FFFFFF\">
				From Where
			</font>
			</td>

			<td width=400 bgcolor=\"#808080\">
			<font color=\"#FFFFFF\">
				Article Title
			</font>
			</td>
		</tr>
		");

	#
	for($i=$#lg,$i2=0; $i2<40; $i--)
	{
		#
		@spt = split(" ", $lg[$i]);

		#
		$spt[0] =~ s/://g;
		$spt[2] =~ s/\#//g;
	#	$spt[2] =~ s/([0-9]{3}.)/$1 /g;
		$spt[5] =~ s/\_/ /g;

		# Does it have a cookie ID?
		if($spt[2] eq "")
		{
			if($so{'ignore_unknown'} eq "true") { goto past; }
			$spt[2] = "Unknown";
			#
			$str4 = "";
		}
		else
		{
			#
			$str4 = "whoisuserid.pl?profile1=$spt[2]";
		}

		#
		($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime($spt[0]);

		#
		$Year += 1900;
		$Month++;

		#
		$Hour = sprintf "%.2d", $Hour;
		$Minute = sprintf "%.2d", $Minute;
		$Second = sprintf "%.2d", $Second;

		#
		$spt[0] = "$Day.$Month.$Year<br>$Hour:$Minute:$Second";

		#
		$spt[5] =~ s/<br>//;
		$spt[6] =~ s/.*=//;
		$spt[7] =~ s/.*=//;
		$spt[7] =~ s/.*=//;
		$spt[8] =~ s/.*=//;
		$spt[8] =~ s/_/ /g;
		$host = $spt[7];

		#
		if($host =~ /googlebot/i || $host =~ /msnbot/i
			|| $host =~ /search\.com/i
			|| $host =~ /kanetti/i)
		{
			goto past;
		}

		#
		print "<tr style=\"vertical-align: top;\">\n";

		#
		print ("
			<!---- TIME --------->
			<td bgcolor=\"#C0FFFF\" width=85>
				<font size=\"2\">
					$spt[0]
				</font>
			</td>

			<!---- USERID --------->
			<td bgcolor=\"#FFC0FF\" width=170>
				<font size=\"1\">
				<a href=\"$str4\" class=\"dark\">
					$spt[6]
					$host (HOST)
					$spt[8]
				</a>
				</font>
			</td>

			<!---- ARTICLE TITLE --------->
			<td bgcolor=\"#FFFFC0\" width=400>$spt[5]</td>


		<tr height=\"1\" bgcolor=\"#C0C0C0\">
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		</tr>
			");
		$i2++;

		#
		print("
			</tr>
			");
past:

	}

	#
	print("
		</table>
		");
}

################################################################
#
sub main
{
	my $str,$str2,$str3,$str4,
		$i,$i2,$i3,$i4;

	#
	if($so{'ignore_unknown'} eq "") { $so{'ignore_unknown'} = 'false'; }

	#
	TableBeg();

	#
	@lg = LoadLog("avlog.txt");

	#
	LogView(@lg);

	#
	TableEnd();
}
