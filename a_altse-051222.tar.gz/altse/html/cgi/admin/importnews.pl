#!/usr/bin/perl
#############################################################################
# importnews.pl
# Imports news from other sources.
# (C) 2011 by Jari Tuominen (jari@vunet.org).
#############################################################################
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
ArgLineParse();

#
$CUR_URL = "http://www.kominform.eu/uutiset.php";

#######################################################
# Go to main loop.
#
main();

#
sub get_publish_form
{
	my ($str,@osastot);

	@osastot = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/seclst.txt");

	#
	$str = ("
<TABLE width=100% cellspacing=0 cellpadding=32>
<TR>
<TD>

<IMG SRC=\"$IMAGES_BASE/julkaisu.jpg\">

<P>Note: Make sure you enter <i>empty rows</i> [ENTER] between sentances. Some manual editing makes text look better !</P>

<FORM action=\"/cgi/publish.pl\" method=post>
<textarea name=\"article_content\" cols=\"80\" rows=\"20\" id=ta>$_[0]</textarea>
<br>
osasto:
<select name=\"osasto\">
		");

	#
	for($i2=0; $i2<($#osastot+1); $i2++)
	{
		#
		$str .= "<option>$osastot[$i2]</option>\r\n";
	}
	#
	$str .= ("
</select>
<BR>

<input name=\"info\" value=\"archivei43538453\"
type=\"checkbox\">sijoita artikkeli
uutisjonon loppuun
(k�ytet��n <b>vain</b> vanhojen artikkeleiden
tallentamisessa)<br>

<input name=\"IS_HTML\" type=\"checkbox\">raksaa jos artikkeli on t�ysin HTML -muodossa
(ei suositella)

<br>

<br>
<input value=\"Julkaise\" type=\"submit\">
		");

	#
	$str .= ("
</FORM>

</TD>
</TR>
</TABLE>

<SCRIPT LANGUAGE=\"Javascript\">
document.getElementById('ta').focus();
</SCRIPT>
		");

	#
}

#######################################################
#
sub get_news
{
	my ($sect,$fold,$fn,@lst,$f,$i,$i2,$i3,$i4);

	#
	$sect = "kominform";
	$fold = "import_cache_$sect";
	$fn = "$fold/newscache.txt";
	#
	system("mkdir -p $fold");
	$refresh_time = creation_date($fn);
	if(-e $fn && $refresh_time<60*5 ) {
		@lst = LoadList($fn);
	} else {
		@lst = LoadList("lynx -dump $CUR_URL|");
		open($f, ">$fn");
		for($i=0; $i<($#lst+1); $i++) {
			print $f "$lst[$i]\n";
		}
		close($f);
	}
}

#######################################################
#
sub view_news_menu
{
	my ($i,$i2,@lst,$got_news,$ents,$arn,$l,$str,$str2,$str3,$str4);

	#
	@lst = get_news();

	#
	printf "<font size=2><i>$CUR_URL</i> refreshed <b>%d</b> minutes <b>%d</b> seconds ago</font><BR>\n",
		$refresh_time/60,$refresh_time%60;

	#
	for($i=0,$got_news=0,$ents=0,$l=0,$arn=0; $i<($#lst+1); $i++) {
		if(!$got_news) {
			if($i>0 && 
				$lst[$i+0] ne "" &&
				$lst[$i+1] eq "" && $lst[$i+2] eq "" && $lst[$i+3] eq "" &&
				$lst[$i+4] ne "") {
				# found the news
				$i+=4 - 1; # skip past next five lines to the news
				$got_news = 1;
			}
		} else {
			if($lst[$i]=~/^\s*$/) {
				$l=0;
				goto skip;
			}


			if($_[0] eq "select") {
				if($so{'publish'} ne "" && $arn==$so{'publish'}+1 && $l==0) {
					my $str = get_publish_form($content);
					print $str;
				}
				if($l==0) {
					$arn++;
					print "<A HREF=\"?publish=$arn\"><LI>$arn: $lst[$i] ...</LI></A>\n";
					$l++;
				}
				if($so{'publish'} ne "" && $arn==$so{'publish'}) {
					$content .= $lst[$i] . "\n";
				}
			}
		}
skip:
	}

	#
}

#######################################################
#
sub html_header
{
	#
	print("
<HTML>

<BODY>
<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

<script language=\"javascript\">
<!--
function OpenIt(URL)
{
        newWindow = window.open(URL, 'Preview', 'width=200,height=200');
}
function OpenIt2(URL,W,H)
{
        newWindow = window.open(URL, 'Preview', 'width='+W+',height='+H);
}
function OpenIt3(URL,W,H,TITLE)
{
        newWindow = window.open(URL, TITLE, 'width='+W+',height='+H);
}
// -->
</script>
</HEAD>
	");
}

#######################################################
#
sub body_beginning
{
	#
	print("
<BODY>
		");
}


#######################################################
#
sub body_ending
{
	#
	print("
</BODY>

</HTML>
		");
}

#######################################################
#
sub main
{
	#
	html_header();
	body_beginning();

	#
	print("
<H2><B>News import - load & publish news from other places</B></H2>
<P>Current source: <A HREF=\"$CUR_URL\">$CUR_URL</A></P>
");

	#
	print("<P>Please select an article to publish at <i>$ENV{'SERVER_NAME'}</i>:</P>\n");
	view_news_menu("select");

	#
	body_ending();
}

#
