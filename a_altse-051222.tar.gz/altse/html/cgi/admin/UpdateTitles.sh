#!/bin/bash
#
cd /home/vai/cgi-bin/articles/
cd kotimaa; /home/vai/sdb/bin/titler.pl; cd ..
cd ulkomaat; /home/vai/sdb/bin/titler.pl; cd ..
cd kolumnit; /home/vai/sdb/bin/titler.pl; cd ..
cd ajatelmat; /home/vai/sdb/bin/titler.pl; cd ..
cd kulttuuri; /home/vai/sdb/bin/titler.pl; cd ..
cd tiedotteet; /home/vai/sdb/bin/titler.pl; cd ..
cd kummalliset; /home/vai/sdb/bin/titler.pl; cd ..
cd tiede; /home/vai/sdb/bin/titler.pl; cd ..
cd luonto; /home/vai/sdb/bin/titler.pl; cd ..
cd yhteiskunta; /home/vai/sdb/bin/titler.pl; cd ..
cd kaikki; /home/vai/sdb/bin/titler.pl; cd ..
cd kummalliset; /home/vai/sdb/bin/titler.pl; cd ..
cd picks; /home/vai/sdb/bin/titler.pl; cd ..
cd progressive; /home/vai/sdb/bin/titler.pl; cd ..
cd bush; /home/vai/sdb/bin/titler.pl; cd ..

