#!/usr/bin/perl
for(;;)
{
	chdir("/home/vai/public_html/cgi-bin/admin");
	#system("nice -n 20 /home/vai/public_html/cgi/admin/online.pl");
	system("/home/vai/public_html/cgi/admin/online.pl");
	system("nice -n 20 /home/vai/public_html/cgi/admin/alt_up2b.sh");
	sleep(60*60*2);
}
