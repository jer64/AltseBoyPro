CREATE NEW PASSWD FILE:
htpasswd -c ~/admin-passwd jer64

CREATE NEW ACCOUNT:
htpasswd ~/admin-passwd jer64

