#!/usr/bin/perl
use DBI;

#
require "tools.pl";

#
main();

sub article_titles_to_mysql
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4);

	#
	@index = LoadList("articles/$_[0]/fileindex.txt");

	# CREATE NEW TABLE
	$sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`titles\_$_[0]`;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	# CREATE NEW TABLE
	$sth = $dbh->prepare("
CREATE TABLE `vunet`.`titles\_$_[0]` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `title` text,
  `artid` bigint(20) unsigned default NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	#
	for($i=0; $i<($#index+1); $i++)
	{
		#
		@art = LoadList("articles/$_[0]/$index[$i]");
		$title = $art[0]; $title =~ s/\<[^\>]+\>//gi;
		$title =~ s/\'/\\\'/g;
		$id = $index[$i];
		$id =~ s/[^0-9]//g;
		if( length($id)>10 ) { goto past; }
		print STDERR "$_[0]/$id: $title\n";

		# SQL COMMAND
		$sth = $dbh->prepare("DELETE FROM titles\_$_[0] WHERE id=$id;");
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();

		# SQL COMMAND
		$sth = $dbh->prepare("INSERT INTO titles\_$_[0]
				(id, title)
				values
				('$id', '$title');");
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();
past:
	}

	#
	close($f);
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);
	my @secs = (
"activism",
"ajatelmat",
"kaikki",
"kolumnit",
"konfliktit",
"kotimaa",
"kulttuuri",
"kummalliset",
"luonto",
"myydaan",
"ostetaan",
"picks",
"politiikka",
"ruokailu",
"talous",
"tiede",
"tiedotteet",
"tyopaikat",
"ulkomaat",
"videos",
"xinwen",
"yhteiskunta"
);

	#
	for($i=0; $i<($#secs+1); $i++)
	{
		article_titles_to_mysql($secs[$i]);
	}

	#
	#my $query = qq{ SELECT ip,web_browser,time,referer,article_file_name,article_title,cookie_info FROM visitors };

	#
}
