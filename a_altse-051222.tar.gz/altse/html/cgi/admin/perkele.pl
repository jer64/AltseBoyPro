#!/usr/bin/perl
##############################################################################
#
# TOP CHART
#
##############################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "suosituimmat";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
AddPerkele();

#
print "IP-osoitteesi on osoittaunut luotettavaksi, ole hyva ja jatka jarjestelman kayttoa vapaasti.";
