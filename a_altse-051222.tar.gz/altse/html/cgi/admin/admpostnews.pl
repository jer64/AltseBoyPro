#!/usr/bin/perl
# admpostnews.pl
##############################################################################################################

#
use Socket;
use Net::DNS;
use Net::hostent;
#use Time::localtime;
#use File::stat;
use POSIX;

#
require "tools.pl";

#
$cgicmd = "/cgi/admin/admpostnews.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu("admpostnews", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub ViewFullMessage
{
	my (@lst,$i,$i2,$i3,$i4,$ct,$cap,$str,$str2,$pvm,$grp,$body);

	#
	$ct = (stat($_[0]))[9];

	#
	@lst = LoadList($_[0]);

	#
	$cap = $lst[0];
	$cap =~ s/^Subject: //;
	$grp = $lst[2];
	$grp =~ s/(\S{8})/$1/g;

	#
	for($i=0,$body=""; $i<($#lst+1); $i++)
	{
		$body = "$body$lst[$i]\n";
	}
	$body =~ s/\</\[/g;
	$body =~ s/\>/\]/g;
	$body =~ s/\n/<BR>/g;

	#
	$pvm = POSIX::strftime("%d.%m.%Y", localtime($ct));

	#
	$str = ("
<TABLE width=100% cellspacing=0 cellpadding=4
	bgcolor=#400000>
<TR valign=top>
<TD width=15%>
	<font color=#C0C000>
	$pvm
	</font>
</TD>
<TD width=40%>
	<font color=#FFFF00>
	$body
	</font>
</TD>
<TD width=5%>
</TD>
<TD width=30%>
	<font color=#808000 size=1>
	$grp
	</font>	
</TD>
</TR>
</TABLE>
<BR>
");

	#
	return $str
}

###########################################################################################################
#
sub FileInfo
{
	my (@lst,$i,$i2,$i3,$i4,$ct,$cap,$str,$str2,$pvm,$grp);

	#
	$ct = (stat($_[0]))[9];

	#
	@lst = LoadList($_[0]);

	#
	$cap = $lst[0];
	$cap =~ s/^Subject: //;
	$grp = $lst[2];
	$grp =~ s/(\S{8})/$1/g;

	#
	$pvm = POSIX::strftime("%d.%m.%Y", localtime($ct));

	#
	$actions = "";
	$c = "#000000";
	if($_[0]=~/^outgoing\/post[0-9]*\.txt$/)
	{
	$c = "#C00000";
	$actions = ("
	<A HREF=\"/cgi/admin/admpostnews.pl?accept=$_[0]\">
	<font size=1 color=#FFFFFF>
	hyv�ksy
	</font>
	</A>
	<A HREF=\"/cgi/admin/admpostnews.pl?reject=$_[0]\">
	<font size=1 color=#FF8080>
	hylk��
	</font>
	</A>
		");
	}

	#
	$str = ("
<TABLE width=100% cellspacing=0 cellpadding=4
	bgcolor=$c>
<TR valign=top>
<TD width=15%>
	<font color=#C0C000>
	$pvm
	</font>
</TD>
<TD width=40%>
	<A HREF=\"/cgi/admin/admpostnews.pl?view=$_[0]\" class=bright>
	<font color=#FFFF00>
	$cap
	</font>
	</A>
</TD>
<TD width=5%>
$actions
</TD>
<TD width=30%>
	<font color=#808000 size=1>
	$grp
	</font>	
</TD>
</TR>
</TABLE>
");

	#
	return $str
}

###########################################################################################################
#
sub Otsikot
{
	my (@lst,$i,$i2,$i3,$i4);

	#
	@lst = LoadList("find outgoing/ -maxdepth 2 -type f -printf \"%p\n\" -name '*.txt'|");
	@lst = reverse @lst;

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print FileInfo($lst[$i]);
	}

	#
}

###########################################################################################################
#
sub main
{
	#
	if($so{'reject'} ne "" && $so{'reject'}=~/^outgoing\/post[0-9]*\.txt$/)
	{
		system("rm $so{'reject'}");
		#
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/cgi/admin/admpostnews.pl\">
		");
		return;
	}

	#
	if($so{'accept'} ne "" && $so{'accept'}=~/^outgoing\/post[0-9]*\.txt$/)
	{
		system("/usr/bin/postnews --file=$so{'accept'} uutiset.saunalahti.fi");
		#die "test";
		system("mv $so{'accept'} outgoing/accepted");
		#
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/cgi/admin/admpostnews.pl\">
		");
		return;
	}

	#
	print("
<TABLE width=750 cellspacing=0 cellpadding=32>
<TR>
<TD>

<DIV ALIGN=CENTER>
<font face=impact>
<H1>USENET NEWS MODERATION</H1>
</font>
</DIV><BR>
		");

	#
	if($so{'view'} ne "" && ($so{'view'}=~/^outgoing\/post[0-9]*\.txt$/ || $so{'view'}=~/^outgoing\/[a-z*\/post[0-9]*\.txt$/))
	{
		print ViewFullMessage($so{'view'});
	}

	#
	Otsikot();

	#
	print("
</TD>
</TR>
</TABLE>
		");

	#
}


