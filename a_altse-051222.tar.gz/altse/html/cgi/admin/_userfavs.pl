#!/usr/bin/perl
#
# userfavs.pl - Users Favorites.
#
##############################################################################################################

#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#

###########################################################################################################
#
sub UsersFavorites
{
	my ($i,$i2,$str,$str2,$str3,$str4,$con,@lst,@lst2,@thumbs,@statistics,$fn,$fn2);

	#
	@thumbs = LoadList("find articles/ -type f -name '*.txt_thumbs.txt'|");

	#
	$con = "";

	#
	for($i=0,$i2=0; $i<($#thumbs+1); $i++)
	{
		@lst = LoadList($thumbs[$i]);
		@sp = split(/ /, $lst[0]);
		$fn = $thumbs[$i];
		$fn =~ s/^articles\///;
		$fn =~ s/^[^a-z]*([a-z]*\/pub_artikkeli[0-9]*\.txt).*/$1/g;
		$statistics[$i2++] = sprintf "%1.8d %s ", $#sp+1, $fn;
	}

	#
	@statistics = sort @statistics;
	@statistics = reverse @statistics;

	#
	for($i=0,$pos=1; $i<($#statistics+1) && $pos<100; $i++)
	{
		@sp = split(/ /, $statistics[$i]);
		if(-e $sp[1])
		{
			$con = sprintf "$con %s ", ViewHL($sp[1], "news2");
			$pos++;
		}
	}

	#
	$con = ("
<TABLE width=640 cellspacing=0 cellpadding=16>
<TR>
<TD>

<DIV ALIGN=CENTER>
<FONT size=6>
<B>VISITORS OWN TOP PICKS</B>
</FONT><BR>
Determined by the number of thumbs given for each article.<BR>
We encourage you to give thumbs for every article <u>you</u> like!<BR>
<BR>
</DIV>
$con

</TD>
</TR>
</TABLE>
		");

	#
	return $con;
}

###########################################################################################################
#
sub main
{
	my ($i,$i2,$str,$str2);

        #
        $str = UsersFavorites();
        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

        #
        print(" document.write(\"$str\"); \n");

	#
}

################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
		$alt,$ifn,$i,$i2,@thu,@ips);

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "/$_[0]";
	$url = UrlFix($url);

        # If article text file exists...
	if(-e $_[0])
	{
		$fn_counter = $_[0];
		$fn_counter =~ s/\.txt$/.counter/;
		$fn_thumbs = $_[0];
		$fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
		$fn_com = $_[0];
		$fn_com =~ s/\.txt$/.txt_comindex.txt/;
	        @art = LoadList("$_[0]");
		@ips = ();
	        if(-e $fn_counter) { @ips = LoadList("$fn_counter"); }
		$thumbs = GenThumbHtml($_[0]);
		@kom = ();
		$comments="";
		if(-e $fn_com)
		{
			@kom = LoadList($fn_com);
			$i = $#kom+1;
			if($i != 0)
			{
				if( $ENV{'REMOTE_HOST'}=~/\.fi$/ )
				{
					$comments = "($i kommenttia)";
				}
				else
				{
					$comments = "($i comments)";
				}
			}
		}
	}
	else
	{
		return "";
	}

	#
	$score = sprintf "%d", ($#ips+1)/2;
	if($score>99) { $score="medal.gif"; $alt="very popular article"; }
	if($score>7 && $score<100) { $score="7_beyond"; $alt="popular article"; }
	if($score<0) { $score=0; $alt="article($score)"; }

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#	$goo = Googler($cap);

	#
	ParseOptions("$_[0]\_options.txt");

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>


		<table cellpadding=0 cellspacing=0 width=610>
		<tr>

		<TD valign=top width=32>");

	#
	$url = CapUrl($url, $cap);

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = "$IMAGES_BASE/document.gif";
		if($url=~/software/)
		{
			$so{'imageurl'} = "$IMAGES_BASE/software.gif";
		}
	}
	else
	{
		$so{'imageurl'} =~ s/^(.*[\/])([a-z0-9\-\_\!]*)\.([a-z])*$/$1thumb2\/th_$2.png/i;
	}
	if($so{'imageurl'} ne "")
	{
		$str = ("$str
			<!---- ARTICLE IMAGE ---->
			<A HREF=\"$url\" class=news1>
			<IMG SRC=\"$so{'imageurl'}\" border=0><BR>
			</A>
			");
	}
	else
	{
	}
	$str = ("$str </TD>");

	#
	$str = ("$str
		<TD width=4>
		</TD>

		<TD valign=top width=550>
		<font size=3>
		<a href=\"$url\" class=$_[1]>
		<!---- ARTICLE CAPTION ---->
                $cap");
	if($so{'url'} ne "")
	{
		$str = ("$str
		<FONT SIZE=1>http://www.vunet.org$url</FONT>
			");
	}
	$str = ("$str
		$thumbs</a>
		$comments
		");
	$t = (stat($_[0]))[9];
	$ct = time;
	$age = $ct-$t;
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($_[0], "news3");
	#
	if($score=~/\./)
	{
		$ifn = $score;
	}
	else
	{
		$ifn = "meter$score.gif";
	}
	if($age < (60*60*16))
	{
		$ifn = "uusi1.gif";
	}
	#
	$str = ("$str
		</font>
		</TD>

		<TD width=24>
		<!---- ARTICLE RANKING ---->
		<IMG SRC=\"$IMAGES_BASE/$ifn\" alt=\"$alt\" title=\"$alt\">
		</TD>


		</tr>
		</table>

		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>
                ");

	#
	return $str;
}

#
sub GenThumbHtml
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
                $str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
                $alt,$ifn,$i,$i2,@thu,@ips,$thumbs,
                $fn_thumbs,@lst);

        #
        $fn_thumbs = $_[0];
        $fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
        if(-e $fn_thumbs) { @lst = LoadList("$fn_thumbs"); @thu = split(/\ /, $lst[0]); }
        for($thumbs="",$i=0; $i<($#thu+1); $i++)
        {
                $thumbs = ("$thumbs<IMG SRC=\"$IMAGES_BASE/thumb_up_c.gif\" border=0>");
        }

        #
        return $thumbs;
}
