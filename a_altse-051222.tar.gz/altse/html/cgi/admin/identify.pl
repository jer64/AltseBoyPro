#!/usr/bin/perl
#############################################################################
# identify.pl - user identification.
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "tunnistaudu";

#
require "admin.pl";

#
LoadConfiguration();

#
main();

#
sub IdentifyAction
{
	#
	print("
		<br>
		<center>K�ytt�j�n asetukset, tunnistautuminen, jne.</center>
		<br>
		");

	#
	print("
		<script language=\"javascript\">

		if( !(userid=getCookie(\"userid\")) )
		{
			document.write(\"<blink>T�m� sivu vaatii cookiet toimiakseen kunnolla.</blink><br>\");
		}
		
		if( !(name=getCookie(\"name\")) )
		{
			document.write(\"Selaimesi kertoo, ettet ole viel� t�ytt�nyt uusi k�vij� -kaavaketta! Toivomme, ett� k�ytt�isit hetken kaavakkeen t�ytt�miseen, jotta voisimme palvella teit� entist� paremmin.\");

			document.write(\" <form method=\\\"get\\\" action=\\\"identify.pl\\\"> \");
document.write(\" <input type=\\\"hidden\\\" name=\\\"userid\\\" value=\\\"\"+ userid +\"\\\"  > \");
			document.write(\" Etunimi: <input type=\\\"text\\\" name=\\\"firstname\\\"> <br>\");
			document.write(\" Sukunimi: <input type=\\\"text\\\" name=\\\"lastname\\\"> <br>\");
			document.write(\" <br>\");
			document.write(\" S�hk�postiosoite: <input type=\\\"text\\\" name=\\\"email\\\"> <br>\");
			document.write(\" <br>\");
			document.write(\" Ammatti: <input type=\\\"text\\\" name=\\\"profession\\\"> <br>\");
			document.write(\"  \");
			document.write(\"  \");
			document.write(\"  \");
			document.write(\" <input type=\\\"submit\\\" value=\\\"Valmis\\\"> \");
			document.write(\" </form> \");
			document.write(\"  \");
			document.write(\"  <i>\");
			document.write(\"  K�ytt�j�tietoja ei luovuteta toimituskunnan ulkopuolelle ilman\");
			document.write(\"  k�ytt�j�n lupaa. Kaavakkeen t�ytt�minen ei sido k�ytt�j�� mihink��n.\");
			document.write(\"  </i>\");
		}
		else
		{
			document.write(\"Terve \" + name);
		}
		
		</script>
		");

}

#
sub Identify
{
	#
	if( !($cmd =~ /userid/) )
	{
		#
		print("
			<script language=\"javascript\">
document.write(\"<meta http-equiv=\\\"refresh\\\" content=\\\"0; url=identify.pl?userid=\"+getCookie(\"userid\")+\"\\\">\");
			</script>
			");
	}
	else
	{
	#	if( gotUserFile($userid) )
	#	{
	#		print "Tervehdys $firstname. Olet jo tunnistautunut! Kiitos tunnistautumisestasi.\n";
	#	}
	#	else
	#	{
			IdentifyAction();
	#	}
	}

	#
	print("
		<NOSCRIPT>
		T�m� ominaisuus vaatii Javascript -tuen.
		</NOSCRIPT>
		");
}

#####################################################################################
#
sub VerifyParams
{
	#
	if($firstname eq "")
	{
		die "<b>You must fill first name.</b>";
	}
}

#####################################################################################
#
sub SaveUserData
{
	#
	$so{'firstname'} = $firstname;
	$so{'lastname'} = $lastname;
	$so{'email'} = $email;
	$so{'profession'} = $profession;

	#
	SaveProfile(GetUserID());
}

#####################################################################################
#
sub main
{
	#
	$cmd = $ENV{'QUERY_STRING'};
        $cmd =~ s/\+/ /ig;
        $cmd =~ s/%(..)/pack("C", hex($1))/eg;
	@vars = split("\&", $cmd);
	for($i=0; $i<($#vars+1); $i++)
	{
		@tmp = split("\=", $vars[$i]);
		if($tmp[0] eq "userid")
		{
			$userid = $tmp[1];
			$userid =~ s/\?//;
			$userid =~ s/\.//;
			$userid =~ s/\///;
			$userid =~ s/\\//;
		}
		if($tmp[0] eq "email")
		{
			$email = $tmp[1];
		}
		if($tmp[0] eq "profession")
		{
			$profession = $tmp[1];
		}
		if($tmp[0] eq "firstname")
		{
			$firstname = $tmp[1];
		}
		if($tmp[0] eq "lastname")
		{
			$lastname = $tmp[1];
		}
	}

        #
        OpenWebIndex("./webindex2.html");
	WireLogo();
        HandleExternal("main-menu", "./mainmenu.pl");

	#
	JSTools();

        #
        WebWalkTo("ENTERHERE_SECTION");

	#
	if($so{'firstname'})
	{
		print("
			<br>
			<br>
			<table width=\"500\">
			<tr>
			<td>

			Tervehdys $so{'firstname'}!<BR>

			<hr><br>

			<BR>


			<b>PROFIILI</b><BR>
			<BR>
			$so{'lastname'}, $so{'firstname'} ($so{'email'})<br>
			$so{'profession'}<br>
			</td>
			</tr>
			</table>
			
			");
		goto skip_past;
	}

	#
	if($cmd =~ /name\=/)
	{
		#
		VerifyParams();

		#
		print "Kiitos, $firstname, ett� t�ytit kaavakkeen, autat meit� tekem��n t�st� palvelusta paremman!\n";

		#
		SaveUserData();
	}
	else
	{
		#
		Identify();
	}
skip_past:

        #
        HandleRest();
}

