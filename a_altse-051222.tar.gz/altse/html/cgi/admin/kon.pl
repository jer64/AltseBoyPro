#!/usr/bin/perl
#
###############################################################################
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

###############################################################################
#
# Spam filtering...
#
sub GoodContent
{
	my ($i,$i2,@art,$str,$str2,$f);
	@bad_words = ("sex", "porno", "porn", "lol", "iraqi", "Clinton", "fuck", 
		"shit", "undress", "incest",
		"make money", "T�m� on automaattinen postitus","virallinen kuvaus",
		"raped", "brutally", "banned photos", "gay", "year old boys",
		"dildo", "masturb", "make cash",
		"www\.mol\.fi", "hanged", "suicide", "tarjotaan virallinen kuvaus",
		"satan", "osama", "horny",
		"santa claus", "creditwrench", "FREE!", "bill gates", "mov.exe", "drugs",
		"alcohol", "viagra",
		"valium", "penis", "kinky", "girlfriend", "bulk mail", "shoppers",
		"virus", "spyware", "free cash", "Antsoft", "taste this internet pack",
		"paypal", "penis pump", "levitra", "xanax", "invest", "stalin", 
		"communism", "communist",
		"anti-semitism", "must die", 
		"Squawk", "\!\!");
	#
	if($so{'spam_filter'} eq "off") { return 1; }

	#
	@art = LoadList($_[0]);

	# Search for "bad" words...
	for($i=0; $i<($#art+1); $i++)
	{
		#
		for($i2=0; $i2<($#bad_words+1); $i2++)
		{
			if($art[$i] =~ /$bad_words[$i2]/i)
			{
				# This is spam!
			#	print STDERR "\rIgnored because of word \"$bad_words[$i2]\".\n";
				return 0;
			}
		}

		#talk.politics.misc)
		#
		if($art[$i]=~/misc\.activism\.progressive/i)
		{
			return 1;
		}
		#
		if($art[$i]=~/^From\:\srivrvu\@ix\.netcom\.com/)
		{
			return 1;
		}

		#
		if($art[$i]=~/George\sW\.\sMcCain/)
		{
			return 1;
		}
	}

	# Article cleared through the test.
	return 1;
}

###############################################################################
#
sub Convert
{
	my ($i,$i2,@art,$str,$str2,$f,$j);

	#
	if(!-e $_[0]) { return; }

	#
	if(!GoodContent($_[0])) { return; }

	# Load article.
	@art = LoadList($_[0]);

	#
	$so{'Subject'} = "";
	$so{'Date'} = "";
	$so{'From'} = "";

	#
	loop: for($i=0; $i<($#art+1); $i++)
	{
		#
		$str = $art[$i];

		#
		if($str eq "") { last loop; }

		#
		$str =~ s/:[\s]/=/;
		$str =~ s/^\s//;

		#
		VarSet($str);
	}

	#
	$so{'Subject'} =~ s/<[^\>]*>//g;

	# "tmp/1158798874.1945173226.txt-Keeping_the_border_safe_for_defense-contractor_pro.txt".
        $str = $_[0];
        $str =~ s/^tmp\/([0-9]*)\.[0-9]*\.txt$/$1/;
        $str2 = $so{'Subject'};
        $str2 =~ s/[^a-zA-Z0-9\-]/_/g;
        $str2 =~ s/^(.{50}).*$/$1/;
        $fn = "$str-$str2.txt";
	# Output already exists?
	if(-e $fn)
	{
		print "\rAlready exists \"$fn\".\n";
		#sleep(1);
		return;
	}

	#
	loop2: for(; $i<($#art+1); $i++)
	{
		if( !($art[$i] eq "") ) { last loop2; }
	}

	#
	$so{'Subject'} =~ s/^\s//g;
	$so{'Subject'} =~ s/\"/'/g;
	$so{'Subject'} =~ s/^\[.*\]//g;
	if($so{'Subject'} eq "" || $so{'Subject'} =~ /Re:\s/i || length($so{'Subject'})<5)
	{
		# Discard, has empty or error subject.
		print STDERR "\rIgnored: Invalid subject: $so{'Subject'}\n";
		return;
	}

	# Ignore a couple troublesome persons.
	if($so{'From'} =~ /tracey/i)
	{
		print STDERR "\rIgnored: $so{'From'}\n";
		return;
	}

	#
	@sp = split(/\:/, $so{'require_author'});
	$fine = 0;
	loop: for($i2=0; $i2<($#sp+1); $i2++)
	{
		if( length($sp[$i2])>3 && ($so{'From'} =~ /$sp[$i2]/i))
		{
			$fine = 1;
			last loop;
		}
	}
	if(!$fine && $so{'require_author'} ne "")
	{
		print STDERR "\rIgnored: $so{'From'} (mismatch to $so{'require_author'})\n";
		return;
	}

	#
	if($so{'Subject'}=~/Chavez/i)
	{
		#print STDERR "$so{'Subject'} from $so{'From'}\n";
		#sleep(10);
	}

	# OPEN OUTPUT FILE FOR WRITING

	#
	open($f, ">$fn") || die "can't create file";

	#
	print $f "$so{'Subject'}<br>\n";
	print $f "($so{'Date'}) --- ";

	# Skip some lines.
	if($so{'From'} =~ /JobCircle\.com/i)
	{
		#
		loopq: for(; $i<($#art+1); $i++)
		{
			if($art[$i] =~ /\*{10}/) { $j++; }
			if($j>=2) { $i++; last loopq; }
		}
	}

	#
	if($art[$i] eq $so{'Subject'}) { $i++; }

#	#
#	loop2: for(; $i<($#art+1); $i++)
#	{
#		if($art[$i] eq "") { last loop2; }
#	}

	#
	for(; $i<($#art+1); $i++)
	{
		#
		if( !($art[$i]=~/http:\/\//) )
		{
			$art[$i] =~ s/----*/ /g;
			$art[$i] =~ s/~~~~*/ /g;
			$art[$i] =~ s/====*/ /g;
		}
		#$art[$i] =~ s/([^h]\S{40})/$1 /g;
		print $f "$art[$i]<br>\n";
	}

	#
	$str = "$so{'From'}";
#	$str =~ s/\@/ AT /;
	$str =~ s/</(/g;
	$str =~ s/>/)/g;
	print $f "<br><br>$str.<br>\n";

	#
	close($f);

	#
}

###############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,@lst3,@lst4);

	#
	LoadVars("section.cfg");

	#
	@lst = LoadList("find tmp -name '*.txt' -maxdepth 1 -type f -printf '%p\n'|grep -v fileindex\.txt|sort|");
	for($i=0; $i<($#lst+1); $i++)
	{
		#$lst[$i] =~ s/^[^\/]*\/(.*)/$1/;
		#print "$lst[$i]\n";
	}

	#
	if(!-x "tmp" || !-x "composed")
	{
		#
		print("
			Invalid folder.\n
			");
	}

	#
	system "find -maxdepth 1 -type f -name '*.*.txt'|grep -v '_'|xargs rm -fv ";

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		Convert("$lst[$i]");
		# Remove old file. No more needed.
		unlink($lst[$i]);
		#
		print stderr ".";
	}
	print stderr "\n";

	#
	##########################system "ls *.txt |grep -v fileindex\.txt |sort > fileindex.txt";
	#
	# CREATE FILE INDEX
        #
        @lst = LoadList("find . -maxdepth 1|");

        # Collect needed files II.
        for($i=0,$i2=0; $i<($#lst+1); $i++)
        {
                $lst[$i] =~ s/^\.\///;
                if($lst[$i]=~/^[0-9]*\-[a-zA-Z0-9\-_]*\.txt$/)
                {
                        $lst2[$i2++] = $lst[$i];
                }
        }
	# Sorting makes files go in date order (file name begins with timestamp).
        @lst2 = sort @lst2;

        # Save new index.
        open($f, ">fileindex.txt");
        for($i=0; $i<($#lst2+1); $i++)
        {
                if( !$al{$lst2[$i]} )
                {
                        print $f "$lst2[$i]\n";
                        $al{$lst2[$i]}++;
                }
        }
        close($f);

        #

	#
}
