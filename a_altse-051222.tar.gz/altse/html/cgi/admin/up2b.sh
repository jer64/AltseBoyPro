#!/bin/bash

#
cd /home/vai/public_html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
touch /home/vai/cache/reades_online.txt
chmod a+rw /home/vai/cache/reades_online.txt

#
/home/vai/public_html/cgi/admin/online.pl
#
/home/vai/cgi/admin/update_titles.sh
/home/vai/cgi/admin/CPtitles.pl

#
/home/vai/cgi/comwea

#
/home/vai/cgi/analyze_vislogs.pl &

#
echo "0AA: Updating Vunet Portal Cached Index Page (new Portal)"
lynx -source http://www.vaihtoehtouutiset.info/portal.pl > /tmp/index-vunetportal.html
cp /tmp/index-vunetportal.html /home/vai/public_html/cache/index-vunetportal.html

#
echo "0A - generating top20.txt & top20_gold.txt - for ViewHL"
/home/vai/cgi/admin/genranklist.pl > cache/top20.txt
/home/vai/cgi/admin/genranklist.pl gold > cache/top20_gold.txt
cp cache/top20.txt cache/rss/filelist_top20.txt
cp cache/top20_gold.txt cache/rss/filelist_top20_gold.txt
chmod a+rw cache/top20*.txt
chmod a+rw cache/rss/filelist_top20*.txt

#
#echo "0B - generating rank list - genranklist.pl"
#/home/vai/public_html/cgi/admin/genranklist.pl > \
#/home/vai/public_html/cache/top20.txt
#/home/vai/public_html/cgi/admin/genranklist.pl gold > \
#/home/vai/public_html/cache/top20_gold.txt
echo "0 - updating osastot"
lynx -source http://www.vaihtoehtouutiset.info/osastot.pl > /tmp/index-osastot.html
cp /tmp/index-osastot.html /home/vai/public_html/cache/index-osastot.html
#
echo "1"
lynx -source http://www.vaihtoehtouutiset.info/com.pl?l=fi > /tmp/index-keskustelu.html
cp /tmp/index-keskustelu.html /home/vai/public_html/cache/index-keskustelu.html
#
echo "1A"
lynx -source http://www.vaihtoehtouutiset.info/com.pl?l=en > /tmp/index-discussion.html
cp /tmp/index-discussion.html /home/vai/public_html/cache/index-discussion.html
#
echo "1B: Updating Cached Index Page (Discussion, Finnish)"
lynx -source http://www.vaihtoehtouutiset.info/com.pl?IF=1 > /tmp/index-comif1.html
cp /tmp/index-keskustelu.html /home/vai/public_html/cache/index-comif1.html
#
echo "2: Updating Cached Index Page (Discussion, English)"
lynx -source http://www.vaihtoehtouutiset.info/com.pl?l=en > /tmp/index-discussion.html
cp /tmp/index-discussion.html /home/vai/public_html/cache/index-discussion.html
#
echo "3: Updating Cached Index Page (Finnish)"
lynx -source http://www.vaihtoehtouutiset.info/finnish/ > /tmp/index-finnish.html
cp /tmp/index-finnish.html /home/vai/public_html/cache/index-finnish.html
#
echo "4: Updating Cached Index Page (English)"
lynx -source http://www.vaihtoehtouutiset.info/english/ > /tmp/index-english.html
cp /tmp/index-english.html /home/vai/public_html/cache/index-english.html
#
echo "5: Updating Cached Index Page (Section Specific)"
lynx -source http://www.vaihtoehtouutiset.info/finnish/secspe > /tmp/index-finnish-secspe.html
cp /tmp/index-finnish-secspe.html /home/vai/public_html/cache/index-finnish-secspe.html
#
echo "6: Updating Portal Cached Index Page (OLD Portal)"
lynx -source http://www.vaihtoehtouutiset.info/newswire.pl > /tmp/index-portal.html
cp /tmp/index-portal.html /home/vai/public_html/cache/index-portal.html
#
echo "7A: Updating Todays Vaihtoehtouutiset TOP 20"
lynx -source \
"http://www.vaihtoehtouutiset.info/chart.pl?MAGIC=32785782378523758&TLI=86400" > /tmp/index-top.html
cp /tmp/index-top.html /home/vai/public_html/cache/index-top.html

#
echo "7B: Updating Todays Kultakaivos TOP 20"
lynx -source \
"http://www.kultakaivos.info/chart.pl?MAGIC=32785782378523758&TLI=86400" > /tmp/index-gold-top.html
cp /tmp/index-gold-top.html /home/vai/public_html/cache/index-gold-top.html



#
echo "7C: Updating kummalliset"
lynx -source \
"http://www.altseboy.online/nw.pl?FP_SECTION=finnish&section=kummalliset" > /tmp/index-kummalliset.html
cp /tmp/index-kummalliset.html /home/vai/public_html/cache/index-kummalliset.html




#
echo "7D: Updating kulta"
lynx -source \
"http://www.altseboy.online/nw.pl?FP_SECTION=finnish&section=talous&q=kulta&rs=kulta" > /tmp/index-kulta.html
cp /tmp/index-kulta.html /home/vai/public_html/cache/index-kulta.html

#
echo "7E: Updating pronssi"
lynx -source \
"http://www.altseboy.online/nw.pl?FP_SECTION=finnish&section=talous&q=pronssi&rs=pronssi" > /tmp/index-pronssi.html
cp /tmp/index-pronssi.html /home/vai/public_html/cache/index-pronssi.html

#
echo "7F: Updating hopea"
lynx -source \
"http://www.altseboy.online/nw.pl?FP_SECTION=finnish&section=talous&q=hopea&rs=hopea" > /tmp/index-hopea.html
cp /tmp/index-hopea.html /home/vai/public_html/cache/index-hopea.html

#
echo "7G: Updating Jim Rogers"
lynx -source \
"http://www.altseboy.online/nw.pl?FP_SECTION=finnish&section=talous&q=jim_rogers&rs=jim_rogers" > /tmp/index-jim_rogers.html
cp /tmp/index-jim_rogers.html /home/vai/public_html/cache/index-jim_rogers.html

#
echo "Done."
