#!/bin/bash
#
echo "0"
/home/vai/public_html/cgi-bin/admin/genranklist.pl > /home/vai/public_html/cgi-bin/cache/top20.txt
lynx -source http://www.vunet.org/osastot.pl > /tmp/index-osastot.html
cp /tmp/index-osastot.html /home/vai/public_html/cache/index-osastot.html
lynx -source http://www.vunet.org/com.pl?l=fi > /tmp/index-keskustelu.html
cp /tmp/index-keskustelu.html /home/vai/public_html/cache/index-keskustelu.html
lynx -source http://www.vunet.org/com.pl?l=en > /tmp/index-discussion.html
cp /tmp/index-discussion.html /home/vai/public_html/cache/index-discussion.html
echo "1\n";
lynx -source http://www.vunet.org/userfavs.pl > /tmp/index-userfavs.html
cp /tmp/index-userfavs.html /home/vai/public_html/cache/index-userfavs.html
lynx -source http://www.vunet.org/whatsnew.pl > /tmp/index-whatsnew.html
cp /tmp/index-whatsnew.html /home/vai/public_html/cache/index-whatsnew.html
echo "2\n";
lynx -source http://www.vunet.org/chinese/ > /tmp/xinwen-.html
cp /tmp/xinwen-.html /home/vai/public_html/cache/index-xinwen.html
lynx -source http://www.vunet.org/russian/ > /tmp/russian-.html
cp /tmp/russian-.html /home/vai/public_html/cache/index-russian.html
echo "3\n";
lynx -source http://www.vunet.org/finnish/ > /tmp/finnish-.html
cp /tmp/finnish-.html /home/vai/public_html/cache/index-finnish.html
echo "4\n";
lynx -source http://www.vunet.org/swedish/ > /tmp/swedish-.html
cp /tmp/swedish-.html /home/vai/public_html/cache/index-swedish.html
echo "5\n";
lynx -source http://www.vunet.org/dutch/ > /tmp/dutch-.html
cp /tmp/dutch-.html /home/vai/public_html/cache/index-dutch.html
echo "6\n";
lynx -source http://www.vunet.org/english/ > /tmp/english-.html
echo "7\n";
cp /tmp/english-.html /home/vai/public_html/cache/index-english.html
chmod a+rw /home/vai/public_html/cache/*
