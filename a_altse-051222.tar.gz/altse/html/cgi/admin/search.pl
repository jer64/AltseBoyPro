#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "nethak";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");

                        # Add main menu.
                        WebWalkTo("main-menu");
			print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	#
	print("

<TABLE WIDTH=100% CELLSPACING=0 CELLPADDING=0>
<TR>
<TD>
<DIV align=center>
<BR>
<BR>
<TABLE width=512 cellpadding=0 cellspacing=0>
<TR>
<TD valign=bottom>

<FONT color=#0080C0>
<IMG SRC=\"$IMAGES_BASE/google_logo_1_small.jpg\">
</FONT>

<!-- SiteSearch Google -->
<form method=\"get\" action=\"http://www.google.com/custom\" target=\"_top\">
<table border=\"0\" bgcolor=\"#ffffff\">
<tr><td nowrap=\"nowrap\" valign=\"top\" align=\"left\" height=\"32\">

</td>
<td nowrap=\"nowrap\" valign=top>
<input type=\"hidden\" name=\"domains\" value=\"www.vunet.org\"></input>
<input type=\"text\" name=\"q\" size=\"31\" maxlength=\"255\" value=\"\" id=q></input>
<input type=\"submit\" name=\"sa\" value=\"Google Search\"></input>
<script language=\"Javascript\">
document.getElementById('q').focus();
</script>
</td></tr>
<tr>
<td>&nbsp;</td>
<td nowrap=\"nowrap\">
<table>
<tr>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\"\"></input>
<font size=\"-1\" color=\"#000000\">Web</font>
</td>
<td>
<input type=\"radio\" name=\"sitesearch\" value=\"www.vunet.org\" checked=\"checked\"></input>
<font size=\"-1\" color=\"#000000\">www.vunet.org</font>
</td>
</tr>
</table>
<input type=\"hidden\" name=\"client\" value=\"pub-4178289363390566\"></input>
<input type=\"hidden\" name=\"forid\" value=\"1\"></input>
<input type=\"hidden\" name=\"ie\" value=\"ISO-8859-1\"></input>
<input type=\"hidden\" name=\"oe\" value=\"ISO-8859-1\"></input>
<input type=\"hidden\" name=\"cof\" value=\"GALT:#008000;GL:1;DIV:#336699;VLC:663399;AH:center;BGC:FFFFFF;LBGC:E00000;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;LH:50;LW:269;L:$IMAGES_BASE/vunet-a1_search1.gif;S:http://www.vunet.org;FORID:1;\"></input>
<input type=\"hidden\" name=\"hl\" value=\"en\"></input>
</td></tr></table>
</form>
<!-- SiteSearch Google -->


</TD>
</TR>
</TABLE>
</DIV>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>

</TD>
<TD WIDTH=100%
	bgcolor=#000000>
</TD>
</TR>
</TABLE>
		");

	#
}


