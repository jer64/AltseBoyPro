#!/usr/bin/perl
#
require POSIX;

#
main();

#
sub main
{
	my ($t,$j,$i,$i2,$str,$str2,@s,$month,$day,$year,$paiva,$k,$MORE);

	#
	$str2 = localtime(time);
	@s = split(" ", $str2);
	$month = $s[1];
	$year = $s[4];
	$day = $s[2];

	#
	$k = sprintf "%d", $ARGV[1];
	if($k<5) { $k=5; }
	$paiva = 60*60*24;

	#
	if($ARGV[2] ne "")	
	{
		$MORE = " author $ARGV[2] ==";
	}

	#
	$t = time-$paiva;

	#
	$str = POSIX::strftime("%Y%m%d", localtime($t));

	#
	print "($t) Regex = \"$str\".\n";

	#
#	system "find -maxdepth 1 -type f -name '*.*.txt'|grep -v '_'|xargs rm -fv ";
	system("nget -g $ARGV[0] -R \"age $k\d <$MORE\"");
}

