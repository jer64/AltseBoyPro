#!/bin/bash
#
echo "14";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_progressive.js&section=progressive&maxts=100&FP_SECTION=english" > \
/home/vai/public_html/cache/index-progressive.html

echo "15";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_bush.js&section=bush&maxts=100&FP_SECTION=english" > /home/vai/public_html/cache/index-bush.html

