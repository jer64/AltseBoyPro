#!/usr/bin/perl
#
if($ENV{'DOCUMENT_ROOT'} eq "")
{
	$ENV{'DOCUMENT_ROOT'} = "$ENV{'HOME'}/public_html";
}
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
system("$ENV{'DOCUMENT_ROOT'}/cgi/admin/MakeImageList.pl");
system("$ENV{'DOCUMENT_ROOT'}/cgi/admin/Categorize.pl");
