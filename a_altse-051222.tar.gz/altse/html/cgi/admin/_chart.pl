#!/usr/bin/perl
##############################################################################
#
# TOP CHART
#
##############################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "suosituimmat";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$so{'FP_SECTION'} = "finnish";

#
if($so{'blank'} eq "")
{
	#
	OpenWebIndex("./webindex2.html");
	# Add main menu.
	WebWalkTo("main-menu");
	print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
}

# Max. cache age, in seconds.
$M_CAGE = 60*15;

#
if($so{'blank'} eq "")
{
	#
	WebWalkTo("ENTERHERE_SECTION");
}
main();

#
if($so{'blank'} eq "")
{
	WebWalkTo("ALAPALKKITAHAN");
	#
	EndBar();
	#
	HandleRest();
}

#


##################################################
#
sub ViewArt
{
	my (@lst,$ii,$ii2);

	#
	if(!-e $_[0])
	{
		return 0;
	}

	#
	@lst = LoadList($_[0]);

	#
	for($ii=0; $ii<($#lst+1); $ii++)
	{
		$lst[$ii] =~ s/<br>//gi;
	}

	#
	print "$lst[0]";

	#
	return 1;
}

##################################################
#
sub ProduceTopTen
{
	my (@lst,@srt,$i,$i2,$i3,$i4,$t,$host,$lhost,
		$url,$lurl,$t_cache,
		$f,$f2,
		$str,$str2);


	#####################################################################
	#

	#
	$cage = 0;

	#
	#$t_cache = sprintf "%d", time/($CACHE_STAT_INTERVAL);
	$t_cache = 0;

	#
	$fn = sprintf "cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache;
	$fn2 = sprintf "cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache-2;
	# GOT CACHE?
	if( -e $fn && !1 )
	{
		#
		@lst = LoadList("$fn");
		@lst2 = LoadList("$fn2");
		#
		for($i=0; $i<($#lst+1); $i++)
		{
			$pos1{$lst[$i]} = $i+1;
		}

		#
		for($i=0; $i<($#lst2+1); $i++)
		{
			$pos2{$lst2[$i]} = $i+1;
		}

		#
	#	$str = $lst[0];
	#	$str =~ s/\<|\>//g;
	#	print $str;
		for($i=0; $i<($#lst+1); $i++)
		{
			$s[$i]  = $lst[$i];
		}

		#
		if($so{'SAVE_RESULTS'} ne "") { SaveResults(); }
		return();
	}

	#####################################################################
	#
	# Build new statistics.
	#
	@lst = LoadList("tail -n100000 avlog.txt|");

	#
	for($i=0,$lurl="",$lhost="",$i2=0; $i<$#lst; $i+=8)
	{
		# Time limit.
		$t = time;

		#
again:
		if($lst[$i+0] eq "" || !($lst[$i+0]=~/^[0-9]*$/)) { $i++; goto again; }

		#
                $url = $lst[$i+5];
                $host = $lst[$i+4];

                #
                if( IsBanned($host) ||
			($host eq $lhost && $url eq $lurl) )
                {
			#
                        goto past;
                }

		#
		if($lst[$i+6] =~ /\//)
		{
			#
			if( ($so{'TLI'}!=0 && ($t-$so{'TLI'}) >= $lst[$i+0]) )
			{
				goto skip;
			}

			#
			if( $lst[$i+2]=~ /seksiorjia/i )
			{
			#	print "$host<br>\n";
			}

			#
			$srt[$i2] = $lst[$i+6];
			$srt[$i2] =~ s/\/\?id=//;
			$i2++;
skip:
		}
past:

		#
		$lhost = $host;
		$lurl = $url;
	}

	#
	@srt = sort(@srt);

	#
	for($i=0; $i<($#srt+1); $i++)
	{
		$str = $srt[$i];
		$top{$str}++;
	}

	# Produce list of quick urls strings that begin with chart position:
	# 000000001 /?id=123x123
	$i=0;
        foreach $key (keys %top)
        {
		$s[$i++] = sprintf "%1.10d $key", $top{$key};
        }

	#
	@s = sort(@s);

	#
	open($f, ">$fn") || die "can't save cache";
	for($i=0; $i<($#s+1); $i++)
	{
		print $f "$s[$i]\n";
#		print $f "$s2[$i]\n";
#		print $f "$s3[$i]\n";
	}
	close($f);
}

##################################################
#
sub ShowTopTen
{
	my ($i,$i2,$AMO,$lpos,$pos);

	#
	$i = 60*60*24;

	#
	if( NoTracking() )
	{
	print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=$so{'ILMAN'}&TLI=$i\" class=news3>
		> P�iv�n luetuimmat.
		</a>
		</div>
		");

	#
	$i = 60*60*24*7;
	print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=$so{'ILMAN'}&TLI=$i\" class=news3>
		> Viikon luetuimmat.
		</a>
		</div>
		");

	#
	print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=$so{'ILMAN'}&TLI=\" class=news3>
		> Logihistorian luetuimmat.
		</a>
		</div>
		");
	}

	#
	if($so{'ILMAN'} eq "ei" && !NoTracking())
	{
	#	$so{'ILMAN'} = "kylla";
	}
	if(!NoTracking()) { goto skippi; }
	if($so{'ILMAN'} ne "ei")
	{
	print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=ei&TLI=$so{'TLI'}\">
		> N�yt� lukukerrat.
		</a>
		</div>
		");
	}
	else
	{
		print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=kylla&TLI=$so{'TLI'}\">
		> Piilota lukukerrat.
		</a>
		</div>
		");
	}
skippi:

	#
	if($so{'TLI'} == 86400)
	{
		#
		$AMO = 20;
		$LOGO = "paivan.jpg";
	}
	else
	{
		#
		$AMO = 50;
		$LOGO = "top50b.jpg";
	}

	#
	$i = $so{'TLI'} / 60 / 60;
	if($i<=0)
	{
		$i = "";
	}
	else
	{
		$i = "$i tunnin ajalta";
	}
	print("
		<!--- OPTIONAL LOGO HERE --->

		<div align=center>
		<b>
		$AMO SUOSITUINTA ARTIKKELIA<br>
		</b>
		$i");
	if(NoTracking())
	{
		$cage = FileAge($fn);
		print("<font size=1 color=\"404040\"><br>$cage/$CACHE_STAT_INTERVAL</font>");
	}
	print("
		</div>
		<br>
		");

	#
	print("
		<table>
		");

	#
	@s = reverse @s;
	@s2 = reverse @s2;
	@s3 = reverse @s3;

	#
	if($so{'SAVE_RESULTS'} ne "") { SaveResults(); $offi=open($offi, ">currently_pop.txt"); }
	#
	for($i=0,$i2=0; $i2<$AMO && $i<($#s+1); $i++,$i2++)
	{
		#
		if(!(-e $s2[$i]))
		{
		#	if(NoTracking()) { print "<i>not found $s2[$i]</i>"; }
			$i2--;
			goto skip;
		}

		# Get positions.
		$pos=0; $lpos=0;
		$pos =  $pos1{$s[$i]};
		$lpos = $pos2{$s[$i]};
		#
		$indim="";
		#
#		if($pos eq "" || $lpos eq "" || $lpos=~/^\s+$/) { goto sc; }

		#
		if($pos > $lpos)
		{
			$indim = ("<img src=$IMAGES_BASE/nousija.gif border=0 alt=\"\">");
			goto past1;
		}
		#
		if($pos < $lpos)
		{
			$indim = ("<img src=$IMAGES_BASE/laskija.gif border=0 alt=\"\">");
			goto past1;
		}
sc:
		#
		if($lpos eq "" && $pos ne "")
		{
			$indim = ("<img src=$IMAGES_BASE/tulokas.gif border=0 alt=\"\">");
			goto past1;
		}

		#
past1:

		#
		print("
			<tr valign=top>
			");

		#
		$te = $s2[$i];
		$te =~ s/pub_artikkeli/story-/;
		$te =~ s/\.txt$/.html/;
		####$pos/$lpos
		printf "<td width=50 valign=top>%d.</td>", $i2+1;
		print("<td width=400 valign=top> <a href=\"/$te\" class=news1>
		$indim
		");
		ViewArt($s2[$i]);
		print("

		</a></td>
		");
		print "<td width=100 valign=top>";
	#	if($so{'ILMAN'} eq "ei")
	#	{
			printf "<font size=1> (%d lukukertaa)</font><br>\n", $s3[$i];
	#	}
		print "</td>";

		#
		print("
			</tr>
			");

		#
		if( ($i2 % 10)==9 && $i2!=0 )
		{
			print ("<tr>
			<td></td><td><br><hr><br></td>
			</tr>");
		}
skip:
	}

	#
	close($offi);

	#
	print("
		</table>
		");
}

##################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);

	#
	$so{'TLI'} =~ s/[^0-9]//g;

again:
	#
	if( ($i=IsRunning("chart.pl")>1) )
	{
		#
		#print("
		#	CHART APPLICATION IS BUSY. TRY AGAIN AFTER 10-30 SECONDS.
		#	");
		#fflush(STDOUT);
		sleep(1);
		goto again;
	}
	#
	$i = sprintf("%d", $i);

	#
	ProduceTopTen();

	# Resolved quick URLs... -> $s2[...]
	for($i=0,$i2=0; $i<($#s+1); $i++,$i2++)
	{
		# s2 = resolved URL
		$str2 = $s[$i];
		$str2 =~ s/^.*<(.*)>/$1/g;
		$str = ResolveQuickUrl($str2);
		$s2[$i2] = $str;

		# s3 = amount of reads
		$str2 = $s[$i];
		@sp = split(" ", $str2);
		$s3[$i2] = $sp[0];
	}

	#
	print("
		<table width=750 cellpadding=16 cellspacing=0>
		<tr valign=top>
		<td width=550>
		");

	#
	ShowTopTen();

	#
	print("
		</td>

		<TD width=200>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_url = \"000000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

		</TD>

		</tr>
		</table>
		");

	#
}


