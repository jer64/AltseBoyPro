#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu("etusivu", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	#
	print("
		");

	#
}


