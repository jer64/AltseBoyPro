#!/usr/bin/perl
# titler.pl
######################################################################################
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#####################################################################################3
#
sub GetTitle
{
        my ($i,$i2,$i3,$i4,@lst,$f,$cap);

        #
        if( !(-e $_[0]) ) { return(); }

        #
        @lst = LoadList($_[0]);

        #
        $cap = $lst[0];
        $cap =~ s/<[^\>]*>//g;
        $cap =~ s/\s*$//g;
        $cap =~ s/^\s*//g;
        $cap =~ s/\n//g;
        $cap =~ s/\r//g;

        #
        $tit[$#tit+1] = $_[0];
        $tit[$#tit+1] = $cap;
}

#####################################################################################3
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$f);

	#
	if($ARGV[0] eq "")
	{
		print "sqltitler.pl\n";
		print "Usage: sqltitler.pl [article section]\n";
		return;
	}

	#
	chdir("/home/vai/cgi-bin/articles/$ARGV[0]");

	#
	if( !(-e "fileindex.txt") )
	{
		print "Can't find fileindex.txt!\n";
		return();
	}

	#
	@lst = LoadList("fileindex.txt");

#	#
#        # Create it.
#        $sth = $dbh->prepare("
#CREATE TABLE `vunet`.`imagelist` ( `id` bigint(20) unsigned NOT NULL auto_increment,
#  `age` bigint(20) unsigned default NULL,
#  `fname` char(200),
#  `category` char(30),
#  PRIMARY KEY USING BTREE (`id`)
#) ENGINE=InnoDB DEFAULT CHARSET=latin1;
#");
#        $sth->execute() or print "failed on $i ($DBI::errstr)\n";
#        $sth->finish();

        # Delete table first.
        $sth = $dbh->prepare("DELETE FROM imagelist;");
        $sth->execute() or print "failed on $i ($DBI::errstr)\n";
        $sth->finish();

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\.\///;
		if( !($lst[$i]=~/\//) )
		{
			$lst[$i] = "$ARGV[0]\/$lst[$i]";
		}
		$str = "$lst[$i]";
		$str =~ s/[^a-z0-9]/_/g;
		if( $ald{$str} eq "" )
		{
			@tit = GetArticleTitle($lst[$i]);
			if($tit[0] eq "")
			{
				SetArticleTitle($lst[$i], GetTitle($lst[$i]), CreationDate1($lst[$i]));
				print STDERR ".";
			}
		}
		$str = "$lst[$i]";
		$fn = $str;
		$fn =~ s/^.*\/([^\/]+\.txt)$/$1/;
		$in_index{$fn}++;
	}
	print STDERR "\n";

	#
}

