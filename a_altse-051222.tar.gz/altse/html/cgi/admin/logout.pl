#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();


###########################################################################################################
#
sub LogOut
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst);

	#
	@lst = LoadList("cfg/notracking.txt");

	#
	open($f, ">cfg/notracking.txt");
	for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] ne $ENV{'REMOTE_ADDR'})
		{
			print $f "$lst[$i]\n";
		}
	}
	close($f);

	#
}

###########################################################################################################
#
sub main
{
	#
	LogOut();

	#
	print("
<TABLE CELLSPACING=0 CELLPADDING=16 WIDTH=640>
<TR>
<TD>
<FONT size=5>
<I>Olet nyt kirjautunut pois Vunetista.</I>
</FONT>
</TD>
</TR>
</TABLE>
		");

	#
	if($so{'r'} ne "")
	{
	        print ("
	        <meta http-equiv=\"refresh\"
	        content=\"0; url=$so{'r'}\">
	                ");
	}

	#
}


