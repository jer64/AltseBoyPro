#!/usr/bin/perl
# en_postitus.pl
# POSTITUS ENGLANNINKIELISELLE LISTALLE
##############################################################################################################

#
chdir("/home/vai/public_html/cgi-bin/admin/");
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$f,$f2,@lst);

	#
	@lst = LoadList("links -dump \"$ARGV[0]\"|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\s*//;
		$lst[$i] =~ s/\s*$//;
	}

	#
	loop: for($i2=0,$ok=0; $i2<($#lst+1); $i2++)
	{
		if( $ok && $lst[$i2]=~/^\s*$/ )
		{
			goto skip;
		}

		if( $lst[$i2]=~/^\s*$/ && $lst[$i2+1]=~/^\s*http:\/\/www\.vunet\.org/ )
		{
			goto skip;
		}

		if( $lst[$i2]=~/^\s*References\s*$/ )
		{
			last loop;
		}

		if( $lst[$i2]=~/^\[[0-9]*\]/ )
		{
			$lst[$i2] =~ s/^\[[0-9]*\]//;
		}
		if($lst[$i2]=~/^http:\/\/www\.vunet\.org/)
		{
			$ok++;
			$lst[$i2] = "$lst[$i2]\n";
		}
		print "$lst[$i2]\n";
skip:
	}

	#
}


