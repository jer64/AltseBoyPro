#!/usr/bin/perl
#############################################################################
# PUBLISHING.
# (C) 2004 by Jari Tuominen.
# Updated 6:17 24.2.2004.
#############################################################################

#
print "Content-type: image/xbm\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
use Time::localtime;
use File::stat;

#
require "admin.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
# Go to main loop.
#
sub main
{
	#
	open(f, "kuva1.xbm");
	@l = <f>;
	close(f);

	#
	print @l;

	#
	$ti = time;
	#
	system "echo $ENV{'QUERY_STRING'} >> visitors.log";
	system "echo \"$ti $ENV{'QUERY_STRING'}\" >> vis.log";
}



