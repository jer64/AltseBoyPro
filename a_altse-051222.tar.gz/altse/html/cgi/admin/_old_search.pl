#!/usr/bin/perl
#######################################################
# Newswire Publishing System 1.0.
# (C) 2004-2005 by Jari Tuominen.
#######################################################

#
use POSIX;

#
$COPYRIGHT = "(C) 2003-2005 Vaihtoehtouutiset organization.";

#
if( !$ENV{'newswire_conset'} )
{
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "haku";

#
require "admin.pl";

#
main();

################################################################
sub SubmitNewUrlForm
{
	print ("
                <form method=\"get\" action=\"/search.pl\" name=\"FORM1\" class=formx>
			Submit following URL to the search engine:<br>
			URL: <input type=\"text\" name=\"q\" size=\"40\" value=\"$so{'q'}\">
			<input type=\"hidden\" name=\"submit\" value=\"2\">
                        <br>
			<input type=\"submit\" value=\"Submit URL\" class=buttonx>
                </form>
                <script language=\"javascript\">
                function sf()
                {
                        document.FORM1.q.focus();
                }
                </script>

		");
}

########################################################################################
#
sub Hints
{
	print("
		<br>

		<table cellpadding=8 cellspacing=0 width=300 bgcolor=\"#F0F8FF\">
		<tr>
		<td>
		<div align=center>Hints</div>

<div style=\"text-align: justify;\">
<font size=2>
<a href=\"/search.pl?cmd=go&q=Ven%E4j%E4\" class=news1>
Ven�j�</a> - 

<a href=\"/search.pl?cmd=go&q=Kiina\" class=news1>
Kiina</a> - 

<a
href=\"/search.pl?cmd=go&q=Pohjois-Korea\" class=news1>
Pohjois-Korea</a> - 

<a
href=\"/search.pl?cmd=go&q=Kuuba\" class=news1>
Kuuba</a> - 

<a
href=\"/search.pl?cmd=go&q=Vietnam\" class=news1>
Vietnam</a> - 

<a
href=\"/search.pl?cmd=go&q=Zimbabwe\" class=news1>
Zimbabwe</a> - 

<a
href=\"/search.pl?cmd=go&q=Libya\" class=news1>
Libya</a> - 

<a
href=\"/search.pl?cmd=go&q=USA\" class=news1>
Yhdysvallat</a> - 

<a
href=\"/search.pl?cmd=go&q=Bush\" class=news1>
Bush</a> - 

<a
href=\"/search.pl?cmd=go&q=imperialismi\" class=news1>
imperialismi</a>

</font>
</div>


		</td>
		</tr>
		</table>

		");

}

################################################################
#
sub ViewSearchLog
{
	my ($t,$pm,$i,$i2,@s,$key,$host);

	#
	print("
		<br>
		<table cellpadding=4 cellspacing=0 width=500>
		<tr valign=top>
		<td>
		");

	#
	@lst = LoadList("sdb/slog.txt");

	#
	print("
		<div align=center>
		<font size=4><b>10 most recent searches</b></font>
		</div>
		<br>
		");

	#
	for($i=$#lst,$i2=0; $i>0 && $i2<10; $i--,$i2++)
	{
		#
		@s = split("&", $lst[$i]);
		#
	        $pm = POSIX::strftime("%H:%M", localtime($s[0]));
		#
		$key = $s[3];
		$key =~ s/<|>//g;
		$key =~ s/(\S{20})/$1 /g;
		$host = $s[2];
		if(length($host)<4) { $host = $s[1]; }
		$host =~ s/(\S{40})/$1 /g;
		if(IsBanned($host)) { $i2--; goto skip; }

		#
		print("
		<table cellpadding=0 cellspacing=0 width=500 height=1>
		<tr valign=top>
		<td width=100 bgcolor=\"#000000\">
		</td>
		</tr>
		</table>

		<table cellpadding=4 cellspacing=0 width=500>
		<tr valign=top>
		<td width=50 bgcolor=\"#FF0000\" valign=center>
			<div align=center>$pm</div>
		</td>
		<td width=150>
			<font size=2><a href=\"/search.pl?cmd=go&q=$key\" class=news2>$key</font>
		</td>
		<td width=300>
			<font size=1>$host</font>
		</td>
		</tr>
		</table>
			");
skip:
	}

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
}

################################################################
#
sub SearchMain
{
	#
	print("
		<table width=\"550\">
		<tr>
		<td>

		<center>
		");

	#
	if($so{'q'} ne "")
	{
		$ALI = "left";
		$ALI2 = "";
		$ADD1 = sprintf("
			<br>
			<a href=\"/search/\">
			<img src=\"$IMAGES_BASE/sqlooks.jpg\" alt=\"SquirrelLOOK\"
				TITLE=\"Go back to main page!\"
				border=0 align=left>
			</a>
			");
	}
	else
	{
		$ALI =  "center";
		$ALI2 = "<br>";
		$ADD1 = sprintf("
			<br>
			<a href=\"/search/\">
			<img src=\"$IMAGES_BASE/sqlook.jpg\" alt=\"SquirrelLOOK\"
				border=0>
			</a>
			<br>
			");
	}

	#
	if($so{'co'} eq "1") { $check1 = " checked"; }
	#
	if($so{'where'} eq "web") { $t2=""; $t1 = "checked"; } else { $t1 = ""; $t2="checked";}

	#
	print("
		<div align=$ALI>
		$ADD1
		");

	#
	if($so{'submit'} eq "")
	{
	print ("
                <form method=\"get\" action=\"/search.pl\" name=\"FORM1\" class=formx>
			This is a beta version.<br>
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$so{'q'}\">
                        <br>
                        <input type=\"submit\" value=\"Search\" class=buttonx>
                        $ALI2
			<input type=checkbox name=co value=\"1\"$check1><font size=2>Articles with comments only.</font>
			<br>
                </form>
                <script language=\"javascript\">
                function sf()
                {
                        document.FORM1.q.focus();
                }
                </script>

		");
	}
	else
	{
		#
		print("
			<table width=350 cellpadding=8 cellspacing=0
				bgcolor=\"#E0F0FF\">
			<tr>
			<td>
			");

		#
		if($so{'submit'}==1)
		{
			SubmitNewUrlForm();
		}
		else
		{
			#
			if(!($so{'q'}=~/^.*\.../))
			{
				#
				print("
				Bad URL: \"<b>$so{'q'}</b>\"<br>
				");
			#	if(!($so{'q'}=~/http/)) { 
			#		print("URL must begin with <b>http://</b><br>");
			#	}
				print("
				<a href=\"javascript:history.go(-1)\">
				> try again
				</a>
					");
			}
			else
			{
				#
				open($f, ">>sdb/suggested_urls.txt") || die "can't add";
				print $f "$so{'q'}\n";
				close($f);

				#
				print("
					URL added successfully.<br>
					<br>
					The URL is queued to be processed.<br>
					<br>
					<div align=right>
					<a href=\"/search/\" class=news2>Click here to continue ...</a>
					</div>
					");
			}

			#
		}

		#
		print("
			</td>
			</tr>
			</table>
			");
	}

	#
	print("
		</div>
		");
#                        <input type=radio name=where value=\"web\" $t1>web
#                        <input type=radio name=where value=\"news\" $t2>VUnet news<br>

	#
	if($so{'q'} eq "" && $so{'submit'} eq "")
	{
		#
		Hints();

		#
		print("
<br>
<div align=center>
<a href=\"/search.pl?submit=1\" class=dark>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
Add new URL
</a>
</div>
		");

		#
		if(NoTracking())
		{
			#
			print("
<div align=center>
<a href=\"/admin/editart.pl?FILE=$NWPUB_CGIBASE/sdb/slog.txt&RETURL=/search/\" class=dark>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
View search log
</a>
</div>
<div align=center>
<a href=\"/admin/editart.pl?FILE=$NWPUB_CGIBASE/sdb/suggested_urls.txt&RETURL=/search/\" class=dark>
<img src=\"$IMAGES_BASE/icons1/bb073.gif\" align=center border=0>
View suggested URLs
</a>
</div>
				");

			#
			ViewSearchLog();
		}

		#
		print("
		<br>
		<font size=1>
		$COPYRIGHT
		</font>
		");
	}

	#
	print("
		</center>

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub PreviewComment
{
	my ($i,$i2,$i3,$i4,@ll,$fn,$str,$ii,$line);

	#
	if( -e $_[0] )
	{
		#
		@ll = LoadList("$_[0]");
		if($#ll<1) { return ""; }

		#
		if($ll[0] =~ /intlfox/) { $ii=1; } else { $ii=0; }
		for($str=""; $ii<($#ll+1); $ii++)
		{
			#
			$line = $ll[$ii];
			$line =~ s/<*?>//g;
			$str = "$str $line ";
		}
		$str =~ s/(.{75}?).*/$1\.\.\./g;
		$str =~ tr/[A-Z���]/[a-z���]/;
		return $str;
	}

	#
	return "";
}

################################################################
#
# section, search string, category
#
sub DisplayCommentTree
{
	my ($i,$i2,$i3,$i4,@l,$fn,$str,$ast,$ast2,$count,$k,$x);

	#
	$fn = "$_[0]\_comindex.txt";

	# Find a comindex...
	if( -e $fn )
	{
		#
		@l = LoadList($fn);

		#
		if($#l<0)
		{
			return 1;
		}

		#
		for($k=0,$count=1,$ast2=""; $k<($#l+1); $k++)
		{
			#
			$ast = PreviewComment($l[$k]);
			if($ast ne "")
			{
				#
				$ast2 = ("$ast2
				<div>
				<table cellpadding=2 cellspacing=0 width=100%>
				<tr valign=top>
				<td width=5%>
				</td>

				<td width=95%>
		<font size=2>$count\. $ast</font>
				</td>
				</tr>
				</table>
				</div>

				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95% bgcolor=\"#F0F0F0\">
				</td>
				</tr>
				</table>
				");
				#
				$count++;
			}
		}

		#
		if($ast2 ne "")
		{
				#
				$x = $count-1;
				$ast2 = ("


				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95%>
				<font size=2><b>$x</b> comment(s):</font>
				</td>
				</tr>
				</table>

				<table cellpadding=0 cellspacing=0 width=100% height=1>
				<tr valign=top>
				<td width=5%>
				</td>
				<td width=95% bgcolor=\"#800000\">
				</td>
				</tr>
				</table>

				$ast2
					");


		}

		#
		return $ast2;
	}

	#
	return "";
}


################################################################
# The actual search algorithm.
#
sub Match
{
	my ($i,$i2,$p);

	#
	for($i=0,$p=0; $i<($#W+1); $i++)
	{
		if($_[0] =~ /$W[$i]/i) { $p+=1; }
		if($_[0] =~ /$W[$i]/) { $p+=2; }
		if($_[0] =~ /\s$W[$i]\s/) { $p+=3; }
		if($_[0] =~ /\s$W[$i]\s/i) { $p+=1; }
	}

	#
	if($#W > 1)
	{
		if($_[0] =~ /$so{'q'}/i) { $p+=2; }
		if($_[0] =~ /$so{'q'}/) { $p+=3; }
	}

	#
	return $p;
}

################################################################
# section, search key
#
sub SearchArt
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$f,$k);

	#
	open($f, $_[0]) || die "file not found $_[0]";
	@li = <$f>;
	close($f);
	for($i=0; $i<($#li+1); $i++) { chomp $li[$i]; }

	# Hunt for search string.
	loop1: for($i=0,$found=0; $i<($#li+1); $i++)
	{
		#
		if($i==0) { $k=25; } else { $k=1; }
		$found += Match($li[$i])*$k;
	}

	#
	return $found;
}

################################################################
#
# Display results.
#
sub DisplayResults
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$fna,$score);

	#
	loop: for($i=$#tl-$so{'start'},$i2=0; $i>0 && $i2<($SHOW); $i--,$i2++)
	{
		#
		$fna = $tl[$i];
		$fna =~ s/^.*>\s(.*)>.*$/$1/;
		$fna =~ s/\s//g;
		$score = $tl[$i];
		$score =~ s/^(.*)>\s.*>(.*)$/$1/;
		if($fna eq "") { last loop; }
		ViewResult($fna,$score);
	}

	#
	return $i2;
}

################################################################
#
sub MakeSubject1
{
	my ($ap);

	#
	$ap = $_[0];
	#
	$ap =~ s/<script .*>.*<\/script>//gi;
	$ap =~ s/<.*?>//g;
	#
	$ap =~ s/^(.{240}).*$/$1/;
	$ap =~ s/(.{80})/$1\-<br>/g;
	$ap =~ tr/[A-Z���]/[a-z���]/;
	$ap =~ s/(^.*)<br>$/$1/i;


	#
	return $ap;
}

################################################################
#
# View result.
#
sub ViewResult
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$ap,$str,$str2,$fn,$t,$pm,$f,$sl,
		$big,$score);

		################################################
		$score = $_[1];
		$tree="";
		$lisa = "<br>";

		################################################
		#
		# Check other rules.
		#

		#
		$fn = "$_[0]\_comindex.txt";
		if( $so{'co'}==1 && !-e $fn )
		{
			print("ERROR $fn<br>\n");
			goto pastx;
		}

		################################################
		#
		# Display result.
		#
		$tree = DisplayCommentTree($_[0]);
		if( $so{'co'}==1 && length($tree)<4 )
		{
		#	print("ERROR $fn<br>\n");
		#	goto pastx;
		}

		#
		$lisa = "<br>";

	#------------------------------------------------------------
	# Let's fetch the article...
        $sz = (stat($_[0]))[7];
	$title="";
	$osasto="";
	@li = ("");
	if($sz<=(1024*128))
	{
		@li = LoadList($_[0]);
	}
	else
	{
		$title="Big file (>128K)";
	}

	#------------------------------------------------------------
	# Make article a single string.
	for($i=$sl,$big=""; $i<($#li+1); $i++)
	{
		$big = "$big $li[$i]";
	}

	#------------------------------------------------------------
	# Create title string.
	if($_[0] =~ /\/pub_artikkeli/)
	{
		if($title ne "") { goto skipqq; }
		$title = $li[0];
		$title =~ s/<br>//gi;
		$title =~ s/^(.{60}).*$/$1\.\.\./;
		$sl = 1; # search start line

		# Get article section.
		$osasto = $_[0];
		if(!$osasto =~ /^[a-z|�|�|�]/i)
		{
			$osasto =~ s/^.*([a-z|�|�|�].*)$/$1/i;
		}
		$osasto =~ s/^(.*)\/.*$/$1/i;
		$osasto = "($osasto)";
skipqq:
	}
	else
	{	
		$sl = 0; # ...
		if($title ne "") { goto skipq; }
		$title = $big;
		$title =~ s/^.*<title>(.*)<\/title>.*$/$1/i;
		if($title eq "") { $title="Untitled"; }
		else
		{
			$big =~ s/<title>.*<\/title>//gi;
			$big =~ s/^\s//g;
			$big =~ s/\s$//g;
			$big =~ s/\ \ //g;
		}
skipq:
		$osasto = "";
	}

	#------------------------------------------------------------
	# GENERATE ARTICLE PREVIEW
	#------------------------------------------------------------
	#
	#
	$ap = $big;
	$ap =~ s/\s$//g;
	$ap =~ s/^\s//g;
	$ap =~ s/\t//g;
	$ap =~ s/\_/ /g;
	$ap =~ s/\s/ /g;
	$ap =~ s/\ \ //g;
	#
	$ap = MakeSubject1($ap);

	#
	if($ap =~ /^\s*$/)
	{
		$ap = $big;
		$ap =~ s/<title>(.*)<\/title>/$1/i;
		$ap = MakeSubject1($ap);
	}

	#
	if($ap =~ /^\s*$/)
	{
		$ap = "No preview available";
	}
	$ap =("
		<font size=2>
		$ap\.\.\.<br>
		</font>
		");

	#------------------------------------------------------------
	#
        $t = (stat($_[0]))[9];
        $sz = (stat($_[0]))[7];
        $pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	if($score<0) { $score="n/a"; } else { $score=sprintf "%d",$score; }
	$pm = sprintf "%dK - $pm - score %s", ($sz/1024)+1,$score;
	if($_[0] =~ /^sdb\//)
	{
		$URL = "$_[0]";
		$URL =~ s/\.\///;
		$URL =~ s/^sdb\//http:\/\//;
		$URL =~ s/(\/)index\.html/$1/;
	}
	else
	{
		$URL = $_[0];
		$URL =~ s/\.\///;
		$URL = "http://www.vunet.org/article/$URL";
	}
	#
	print ("
			<a href=\"$URL\" class=news2>
			<font size=3>$title</font> <font size=1>$osasto</font>
			</a><br>
			$ap
			$tree
			<font size=2 color=\"#00A020\">$URL - $pm</font>
			<br>$lisa
			");

	#
pastx:
}

################################################################
#
# Search index of articles for a string.
# Section, search string.
#
sub SearchFor
{
	my ($i,$i2,$i3,$i4,$fn,@com,$f,$str,$key,$found,$t);

	#
	$key = $_[1];
	$key =~ s/\*/\.\*/g;

	#
	open($f, "$_[0]/fileindex.txt");
	@ind = <$f>;
	close($f);
	for($i=0; $i<($#ind+1); $i++) { chomp $ind[$i]; $ind[$i]=~s/\s//g; }

	#
	for($i=0; $i<($#ind+1); $i++)
	{
		#
		$fn = "$_[0]/$ind[$i]";
		if($key eq "*") { goto addNow; }
		if( ($found=SearchArt("$fn", $key, $_[0])) )
		{
			#
			if( $so{'co'}==1 && !(-e "$fn\_comindex.txt") )
			{
			#	print("IGNORING $fn<br>");
				goto past;
			}
			if( $so{'co'}==1 && (-e "$fn\_comindex.txt") )
			{
				@com = LoadList("$fn\_comindex.txt");
				if($#com<0) { goto past; }
			}

			#
addNow:
			$da = (stat("$fn"))[9];
			if($TIME_ORDER)
			{
				$t = time;
				$t = ($da);
			}
			else
			{
				$t = 0;
				$t += $found;
			}
			$str = sprintf "%.12d> $fn >$found", $t;
			$tl[$#tl+1] = $str;
			$tulos++;
past:
		}
	}

	#
}

################################################################
#
sub LogThisSearch
{
	my ($f,$t);

	#
	open($f, ">>sdb/slog.txt");
	$t = time;
	print $f "$t & ";
	print $f "$ENV{'REMOTE_ADDR'} & ";
	print $f "$ENV{'REMOTE_HOST'} & ";
	print $f "<$so{'q'}>\n";
	close($f);
}

################################################################
#
sub SaveResult
{
	my ($key,$fn,$f,$i,$i2);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);

	#
	open($f, ">$fn");
	for($i=0; $i<($#tl+1); $i++)
	{
		print $f "$tl[$i]\n";
	}
	close($f);
}

################################################################
#
sub GetCacheFileName
{
	my ($key,$fn);

	#
	$key = $_[0];
	$key =~ s/:/\_KP\_/g;
	$key =~ s/\W//g;
	$fn = "sdb/tmp/cached\_$key\_co$so{'co'}.txt";
	return $fn;
}

################################################################
#
sub GetCachedResult
{
	my ($key,$fn);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);
	#
	if(-e $fn)
	{
		#
		@tl = LoadList($fn);

		# Cached result found and is loaded!
		return 1;
	}

	# No cached result found.
	return 0;
}

################################################################
#
sub SearchNow1
{
	my ($i,$i2,$i3,$i4,$f,$key);

	#
	$key = $_[0];

	#
	if(!NoTracking()) { LogThisSearch(); }

	# Try to get a cached result.
	if( $so{'REFRESH'} eq "" && GetCachedResult($key) )
	{
		return;
	}
	else
	{
		print("
			Due to beta status this can take upto 20-60 seconds of time ...<br>
			Searching ...");
	}

	#
	open($f, "sdb/sdb.txt");
	@sec = <$f>;
	close($f);
	for($i=0; $i<($#sec+1); $i++) { chomp $sec[$i]; }

	#
	@tl = "";

	#
	for($i=0,$tulos=0; $i<($#sec+1); $i++)
	{
		#
		SearchFor($sec[$i], $key);
		print STDERR ".\n";
	}
	print("<br>\n");

	#
	@tl = sort(@tl);

	#
	SaveResult($key);

	#
	return $tulos;
}

################################################################
#
sub Controls1
{
	#
	print("
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"hidden\" name=\"q\" value=\"$so{'q'}\">
			<input type=\"hidden\" name=\"where\" value=\"$so{'where'}\">
			<input type=\"hidden\" name=\"co\" value=\"$so{'co'}\">
			<input type=\"hidden\" name=\"start\" value=\"$_[0]\">
	");
}

################################################################
#
sub Controls
{
	my ($i,$i2,$i3,$i4,$x,$x2);

	#
	$i =  $so{'start'}-$SHOW; if($i<0){$i=0;}
	$i2 = $so{'start'}+1+$SHOW-1;

	#
	print("
				<div align=center>

				<table width=500 cellpadding=4 cellspacing=0>
				<tr valign=top>
		");

	#
	if(1)
	{
		if($i >= 0 && $so{'start'} != 0) { $DIS=""; } else { $DIS="disabled"; }
		#
		print("
				<td width=30% align=center>
				<form action=\"/search.pl\" class=formx>   ");
		Controls1($i);
		print("		
				<input type=\"submit\" value=\"<< previous page\" $DIS>
				</form>
				</td>
			");
	}

	#
	if(1)
	{
		#
		print("
				<td width=40%>

				<div align=center>

				<table cellpadding=0 cellspacing=0><tr valign=top><td>
				");

		#
		$sx = $so{'start'} - $SHOW*2; if($sx<0) { $sx=0; }
		for($x=$sx,$x2=0; $x2<5; $x+=$SHOW,$x2++)
		{
			#
			if($x<=$#tl)
			{
				#
				if($x==$so{'start'}) { $for="buttonx"; } else { $for="buttonx2"; }

				#
			print("<td>
				<form action=\"/search.pl\" class=formx>   ");
			Controls1($x);
			print("		<input type=\"submit\" value=\"$x\" class=$for>
					</form>
				</td>");
			}
		}

		#
		print("
				</td>
				</tr>
				</table>

				</div>

				</td>
			");
	}

	#
	if(1)
	{
		#
		if($i2 < $#tl || $so{'start'} == 0) { $DIS=""; } else { $DIS="disabled"; }
		#
		print("
				<td width=30% align=center>
				<form action=\"/search.pl\" class=formx>   ");
		Controls1($i2);
		print("
				<input type=\"submit\" value=\"next page >>\" $DIS>
				</form>
				<br>
				</td>
			");
	}

	#
	print("
				</tr>
				</table>
				</div>
		");
}

################################################################
#
sub ResultInfo
{
	my ($i,$i2,$i3,$i4);

	#
	$i =  $so{'start'}+1;
	$i2 = $so{'start'}+1+$SHOW-1;
	if($i2 > $#tl)
	{
		$i2 = $#tl;
	}

	#
	print("
		<table width=100% cellpadding=4 cellspacing=0
			bgcolor=\"#E0F0FF\">
		<tr>

		<td width=20%>
		<div class=\"CAPS\">
		<font size=4>
		<b>
		$so{'where'}
		</b>
		</font>
		</div>
		</td>

		");

	#
	if($#tl > 0)
	{
	print("
		<td width=80%>
		<div align=right>
		<font size=2>
Results <b>$i - $i2</b> of about <b>$#tl</b> for <b>$so{'q'}</b>. 
		</font>
		</div>
		</td>
		");
	}
	else
	{
		print("
		<td width=80%>
		<div align=right>
		No hits.
		</div>
		</td>
		");
	}

	#
	print("
		</tr>
		</table>
		<br>
		");
}

################################################################
#
sub SearchNow
{
	my ($key);

	#
	$key = $_[0];

	#
	SearchMain();

	#
	if($key eq "")
	{
		return;
	}

	#
	print("
		<table width=\"100%\" cellpadding=4 cellspacing=0>
		<tr valign=top>
		<td>
		");

	#
#	print "<br>\n";

	#
	SearchNow1($key);

	#
	Controls();
	ResultInfo();
	print("
				<table cellpadding=0 cellspacing=0 width=600>
				<tr valign=top>
				<td>
		");
	DisplayResults();
	print("

				</td>
				</tr>
				</table>
		");
	Controls();

	#
#	printf "%d result(s).<br>\n", $tulos;

	#
	print("
		<br>
		<center>
		<font size=1>
		$COPYRIGHT
		</font>
		</center>
		");

	#
	print("

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub ProcessSearchString
{
	my ($str,$i,$i2);

	# Split into search words.
	$str = $so{'q'};
	@W = split(" ", $str);

	#
	for($i=0,$i2=0; $i<($#W+1); $i++)
	{
		$W[$i] =~ s/\*/\.\*/g;
	}
}

################################################################
#
sub main
{
        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	if(!NoTracking())
	{
		#
		print("
			The search engine is currently down for an upgrade.<br>
			Check back after a few hours.<br>
			");
		return();
	}

	#
	$SHOW = 10;

	#
	if($so{'q'} =~ /\sREFRESH$/)
	{
		$so{'q'} =~ s/\sREFRESH$//;
		$so{'REFRESH'} = 1;
	}

	#
	if($so{'q'} eq "" && $so{'searchstring'} ne "")
	{
		$so{'q'} = $so{'searchstring'};
	}
	if($so{'q'} eq "*")
	{
		$TIME_ORDER = 1;
	}
	#
	ProcessSearchString();

	# Get options.
	#
	$set = $so{'q'};
	$set =~ s/\?/\ /;

	#
                #
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<title>
Squirrel Look Web Search Engine
</title>
</head>

<body onLoad=\"sf()\">



<center>
<table width=100%>
<tr>
<td>
			");

	#
	if(($so{'cmd'} eq "go" || $so{'cmd'} eq "searchnow") && $so{'q'} ne "")
	{
		#
		print("
			<table width=300 cellpadding=0 cellspacing=0 align=right>
			<tr valign=top>
			<td>

			<div align=right>
			<font size=1 face=Georgia>
			<a href=\"/\" class=dark>
			> Go to VUnet News
			</a>
			<br>
			</font>
			</div>

			</td>
			</tr>
			</table>
			");
		SearchNow($set);
	}
	else
	{
		#
		print("
			<div align=center>
			");
		SearchMain();
		print("
			</div>
			");
	}

	#
	print("
</td>
</tr>
</table>
</center>

</body>
		");
}

