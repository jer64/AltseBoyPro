#!/usr/bin/perl
#
print ("
	<a href=\"http://www.vunet.org/uutiset/\" style=\"color: rgb(0,0,0);\">
	<font color=\"#004000\">
	<img src=\"$IMAGES_BASE/artel.gif\" alt=\">>\" align=\"bottom\" border=\"0\">
	return back to the main page
	</a>
	</font>
	");
