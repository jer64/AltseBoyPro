#!/bin/bash
lynx -source http://www.vunet.org/userfavs.pl > /home/vai/public_html/cache/userfavs.js
lynx -source "http://www.vunet.org/jstopten.pl?c=100&t=Suosituimmat_Kummalliset&q=&s=kummalliset" |gzip -d > /home/vai/public_html/cache/top_kummalliset.js
lynx -source "http://www.vunet.org/jstopten.pl?c=100&t=Popular_Videos&s=videos&n=" |gzip -d > /home/vai/public_html/cache/top_videos.js
lynx -source "http://www.vunet.org/jstopten.pl?c=100&t=Popular_Articles&s=picks&n=" |gzip -d > /home/vai/public_html/cache/top_picks.js
lynx -source "http://www.vunet.org/jstopten.pl?c=100&t=Popular_Progressive_Articles&s=progressive&n=" |gzip -d > /home/vai/public_html/cache/top_progressive.js
lynx -source "http://www.vunet.org/jstopten.pl?c=100&t=Popular_Bush_Articles&s=bush&n=" |gzip -d > /home/vai/public_html/cache/top_bush.js
