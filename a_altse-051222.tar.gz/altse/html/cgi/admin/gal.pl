#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu("etusivu", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	my ($modstr);

	#
	$modstr = $so{'q'};
	$modstr =~ s/([^0-9]+)([0-9]+)/$1 $2/g;
	$modstr =~ tr/[a-z���]/[A-Z���]/;

	#
	print("
<BR>
<CENTER>
	<H1>
	$modstr
	</H1>
</CENTER>

<script language=\"Javascript\" src=\"http://www.vunet.org/jsgal.pl?q=$so{'q'}\"></script>
		");

	#
}


