#!/usr/bin/perl
# editimage.pl - Image Descriptor Editor.
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

        #
        if( !($ENV{'REMOTE_HOST'}=~/\.fi$/) )
        {
                print "njet... qin wode pigu!";
                exit;
        }

#
main();

###########################################################################################################
#
# Change selected images to specified group.
#
sub CategorizeTo
{
	my ($i,$i2,@lst,$key,$content,@sp,@sp2,$str,$str2);

	#
	LoadIMD();

	# Change selected images to the specified group.
        for($i=0; $i<($#selim+1); $i++)
        {
		$key = $selim[$i];
		@sp = split(/\,/, $imd{$key});
		$sp[1] = $_[0]; # change group parameter
		$str = "";
		for($i2=0; $i2<($#sp+1); $i2++)
		{
			$str = "$str$sp[$i2],";
		}
		$imd{$key} = $str;
        }

	#	
	SaveIMD();
}

###########################################################################################################
#
sub LoadIMD
{
	my ($i,$i2,@lst,$key,$content,@sp);

	#
	@lst = LoadList("cfg/imgdesc.txt");
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\=/, $lst[$i]);
		$key = $sp[0];
		$content = $sp[1];
		$imd{$key} = $content;
	}

	#
}

###########################################################################################################
#
sub SaveIMD
{
	#
	open($f, ">cfg/imgdesc.txt");
	foreach $key (sort(keys %imd))
	{
		print $f "$key=$imd{$key}\n";
	}
	close($f);
}

###########################################################################################################
#
sub EditImageInformation
{
	my ($str,$str2,$i,$i2,$name,@sp,$keywords);

	#
	@lst = LoadList("cfg/imggroups.txt");

	#
	$name = $so{'i'};
	$name =~ s/^(.{18}).*$/$1.../;

	#
	@sp = split(/\,/, $imd{$so{'i'}});

	#
	$keywords = $sp[0];
	if($keywords eq "")
	{
		#$keywords = $so{'i'};
		#$keywords =~ s/\.[a-zA-Z]*$//g;
		#$keywords =~ tr/[A-Z���]/[a-z���]/;
		#$keywords =~ s/[^a-zA-Z0-9]/ /g;
	}

	#
	if($sp[1] ne "")
	{
		$so{'group'} = $sp[1];
	}

	#
	print("
<TABLE width=100% height=100% cellspacing=0 cellpadding=4
	bgcolor=#7070FF>
<TR valign=top>
<TD>

<B>
<FONT color=#FFFFFF>
$name
</FONT>
</B>

<TABLE width=100% height=4 cellspacing=0 cellpadding=0
	bgcolor=#FFFFFF>
<TR valign=top>
<TD>
</TD>
</TR>
</TABLE>

<TABLE width=100% height=4 cellspacing=0 cellpadding=0>
<TR valign=top>
<TD>
</TD>
</TR>
</TABLE>

<FORM action=editimage.pl>
$default_html

avainsanat:<BR>
<INPUT TYPE=text name=keywords value=\"$keywords\">
<BR>

ryhm�:<BR>
<SELECT name=group>
<OPTION name=>...</OPTION>
");
for($i=0; $i<($#lst+1); $i++)
{
	if($lst[$i] eq $so{'group'})
	{
		$str = "selected";
	}
	else
	{
		$str = "";
	}
	print("<OPTION name=\"$lst[$i]\" $str>$lst[$i]</OPTION>\n");
}
print("
</SELECT>
<BR>

<INPUT TYPE=hidden name=i value=\"$so{'i'}\">
<INPUT TYPE=hidden name=cmd value=save>
<INPUT TYPE=submit value=tallenna>
</FORM>

</TD>
</TR>
</TABLE>

		");
}

###########################################################################################################
#
sub SaveImageInformation
{
	my ($i,$i2,$str,$str2,@lst,@sp,$key,$content);

	#
	print("
<TABLE width=100% height=100% cellspacing=0 cellpadding=4
	bgcolor=#7070FF>
<TR valign=top>
<TD>
<FONT SIZE=4 color=#FFFFFF>
<IMG SRC=\"$IMAGES_BASE/hint.gif\" border=0>
Tiedot tallennettu.
</FONT>
<BR>	
<A HREF=\"Javascript:history.go(-1);\" class=bright>
> palaa edelliseen ruutuun
</A>
</TD>
</TR>
</TABLE>
	");

	#
	$imd{$so{'i'}} = "$so{'keywords'},$so{'group'}";

	#
	SaveIMD();

	#
}

###########################################################################################################
#
sub main
{
	my ($i,$i2,$str,$str2,@lst,@sp,$key,$content,$good);

	#
	$good = "cfg/last_good_group.txt";
	if(-e $good)
	{
		@lst = LoadList($good);
		$last_good = $lst[0];
	}

	#
	if($so{'group'} eq "" && $last_good ne "")
	{
		$so{'group'} = $last_good;
		$default_group = 1;
		$default_html = ("<FONT COLOR=YELLOW>Ryhm�� ei valittu, valitaan oletuksena edellinen valinta.</FONT><BR>");
	}

	#
	print("
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
<FONT COLOR=#FFFFFF>
		");

	#
	LoadIMD();

	#
	if($so{'cmd'} eq "")
	{
		EditImageInformation();
	}

	#
	if($so{'cmd'} eq "save")
	{
		open($f, ">$good");
		print $f "$so{'group'}\n";
		close($f);
		SaveImageInformation();
	}

	#
	if($so{'cmd'} eq "categorize")
	{
		#
		$i=0;
	        foreach $key (sort(keys %so))
	        {
			if($key=~/^selim_/)
			{
				print "$so{$key}<BR>\n";
				$selim[$i++] = $so{$key};
			}
	        }

		#
		CategorizeTo($so{'tgroup'});

		#
		print "Siirto tehty.";
	}

	#
}


