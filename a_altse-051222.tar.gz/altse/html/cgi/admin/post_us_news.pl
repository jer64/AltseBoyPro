#!/usr/bin/perl
# en_postitus.pl
# POSTITUS ENGLANNINKIELISELLE LISTALLE
##############################################################################################################

#
chdir("/home/vai/public_html/cgi-bin/admin/");
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$f,$f2,@lst);

	#
	@lst = LoadList("/home/vai/public_html/cgi-bin/admin/lib_postitus.pl \"http://text.vunet.org/?v=&sec=progressive&c=200&printable=2\"|");

	#
	@lista = LoadList("cfg/us_postituslista.txt");

	#
	$subject = "$lst[3]";
	$subject =~ s/\n//g;
	$subject =~ s/\r//g;
	$subject =~ s/\t/ /g;
	$subject =~ tr/[A-Z���]/[a-z���]/;

	#
	loop: for($i=0,$st=time; $i<($#lista+1); $i++)
	{
		$recp = $lista[$i];
		print STDERR "$recp\n";

		$t = time;
		if( ($t-$st)>=(60*2) ) { last loop; }

		if($recp=~/\@/ && $recp=~/\./)
		{
			open($f, "|mail $recp -s \"$subject\"");
			for($i2=0; $i2<($#lst+1); $i2++)
			{
				print $f "$lst[$i2]\n";
			}
			close($f);
		}
	}

	#
}


