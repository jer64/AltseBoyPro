#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
#
$ENV{'CURFPSEC'} = "english";
$ENV{'CURSEC'} = "favorites";
#$ENV{'CURSEC'} = "favorites";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("CHOOSE-TITLE1");
print("
<TITLE>VUNET USERS FAVORITES</TITLE>
<meta name=\"keywords\" content=\"users own favorites, favorites, favourites, popular, top ten, famous, most readed, top news, top notch, news, rumours, videos\">
");
SkipTo("CHOOSE-TITLE2");
# Add main menu.
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, $ENV{'CURFPSEC'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	#
	print("
<script language=\"javascript\" src=\"http://www.vunet.org/userfavs.pl\"></script>

<!--- http://www.vunet.org/~vai/cache/userfavs.js --->
		");

        #
        if( !NoTracking() && !isRobot($so{'REMOTE_HOST'}) )
        {
                #
                open($f, "|mail $PRIM_ADMIN_EMAIL -s \"$ENV{'SERVER_NAME'}: Top 100: $ENV{'REMOTE_HOST'}\"");
                print $f "K�vij� Favorites-sivuilla osoitteesta:\n";
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
                foreach $key (sort(keys %ENV))
                {
                        print $f "$key=\"$ENV{$key}\"\n";
                }
                print $f "==========================================\n";
                print $f "Vaihtoehtouutiset Information System\n";
                print $f "http://vunet.org\n";
                close($f);
        }

	#
}


