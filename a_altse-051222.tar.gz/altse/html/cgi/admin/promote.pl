#!/usr/bin/perl
#############################################################################
# promote.pl
# Promote an article. Move it to the "promoted articles section".
#############################################################################

require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
print "Content-type: image/gif\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
#system("cat $ENV{'DOCUMENT_ROOT'}/images/nothing.gif");

#
main();

#
sub isPromoted
{
	my ($i,$i2,$i3,$i4,@ind);

	#
#	print "$fname<br>\n";
	$_fn = $fname;
	$_fn =~ s/\.\.//g;
	$_fn =~ s/kaikki\///g;
#	print "$_fn<br>\n";
	@tmp = split("\/", $_fn);
	$fn = $tmp[1];
	$ifn = "articles/kaikki/fileindex.txt";

	# Load index.
	open(f, $ifn) || die "can't open index file $ifn";
	@ind = <f>;
	close(f);
	for($i=0; $i<($#ind+1); $i++)
	{
		chomp $ind[$i];
	}

	# Hunt for fn.
	for($i=0; $i<($#ind+1); $i++)
	{
	#	print "$ind[$i]<br>\n";
		if( $ind[$i] =~ "$_fn" )
		{
			return 1;
		}
	}

	#
	return 0;
}

# Undo article's promotion.
sub UnpromoteArticle
{
	my $i,$i2,$i3,$i4,@ind;

	#
	$fn = $fname;
	$fn =~ s/\.\.//g;
	$fn =~ s/kaikki\///g;
	$fn =~ s/[!\.]txt$/\.txt/g;
	$ifn = "articles/kaikki/fileindex.txt";

	# Load index.
	open(f, $ifn) || die "can't open index file $ifn";
	@ind = <f>;
	close(f);
	for($i=0; $i<($#ind+1); $i++)
	{
		chomp $ind[$i];
	}

	# Hunt for fn.
	open(f, ">$ifn") || die "can't write index file $ifn";
	for($i=0; $i<($#ind+1); $i++)
	{
		if( !($ind[$i] =~ "$fn") )
		{
			print f "$ind[$i]\n";
		}
	}
	close(f);

	#
	return 0;
}

#
sub RequestADD
{
	#
	print("
		Haluatko <b>lis�t�</b> artikkelin kaikki-listalle?<br>
		<b>\"$headline\"</b>
		<br>
		<form action=\"promote.pl\" method=\"get\" id=form1>
		<input type=\"hidden\" value=\"$fname\" name=\"file\">
		<input type=\"hidden\" name=\"confirmation32634\" value=\"TRUE\">
		<input type=\"submit\" value=\"kyll�\">
		<a href=\"/article/$article\">ei</a>");

	print("	
		</form>
		");
	if($so{'yes'} ne "")
	{
		print("
<SCRIPT LANGUAGE=\"Javascript\">
form = document.getElementById('form1');
form.submit();
</SCRIPT>
		");
	}
}

#
sub RequestDELETE
{
	#
	print("
		Artikkeli on listalla <b>kaikki</b>.<BR>
		Haluatko <b>poistaa</b> artikkelin kaikki listalta?<BR>
		<B>\"$headline\"</B>
		<BR>
		<form action=\"promote.pl\" method=\"get\">
		<input type=\"hidden\" value=\"$fname\" name=\"file\">
		<input type=\"hidden\" name=\"confirmation32634\" value=\"TRUE\">
		<input type=\"submit\" value=\"kyll�\">
		<a href=\"/article/$article\">ei</a>
		</form>
		");
}

#
sub Bounce
{
	print ("<meta http-equiv=\"refresh\" content=\"0;
		url=/viewarticle.pl?article=$fname\">\n
		");
}

# Promote article.
sub PromoteArticle
{
	#
	$fn = $fname;
	$fn =~ s/kaikki\///g;

	#
	system "echo \"../$fn\" >> articles/kaikki/fileindex.txt";
}

#
sub main
{
        # Load configuration & parse args.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	# Figure out arguments.
	$frst = $so{'file'};
	@s = split("\/pub_", $frst);
	$artdir = $s[0];
	$fname = $frst;
	$ifname = "$artdir/fileindex.txt";
	$confirmation = 0;
	if($so{'confirmation32634'} ne "")
	{
		$confirmation = 1;
	}

	#
	$article = $fname;
	$article =~ s/pub_artikkeli([0-9]*)\.txt/story$1.html/;

	# Get article headline.
	open(f, $fname) || die "file not found ($fname)";
	$headline = <f>;
	chomp $headline;
	$headline =~ s/<br>//g;
	close(f);

	#
	if(!isPromoted())
	{
		#
		if($so{'action'} eq "delete")
		{
			# Not in picks anyway, so don't bother.
			#Bounce("http://vunet.org/finnish/");
			system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/544.gif");
			return;
		}

		#
		if( !$confirmation )
		{
			#
			#RequestADD();
			system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/544.gif");
		}
		else
		{
			#
			PromoteArticle();
			system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/anim_nodding_cat.gif");
			#Bounce("http://vunet.org/finnish/");
		}
	}
	else
	{
		#
		if( !$confirmation && $so{'action'} ne "delete" )
		{
			#
			system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/544.gif");
			#RequestDELETE();
		}
		else
		{
			#
			system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/anim_nodding_cat.gif");
			UnpromoteArticle();
			#Bounce("http://vunet.org/finnish/");
		}
	}
	
	#
}

#




