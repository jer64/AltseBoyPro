#!/usr/bin/perl
#
# lastday.pl
#
# Report sent via mail at 03:00 FINNISH time.
#
##############################################################################################################

#
require "tools.pl";
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;
use POSIX qw(strftime);

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@lst2,@ips,$i,$i2,$i3,$i4,$str,$str2,$fn,$age,$lfn);

	#
	chdir("/home/vai/cgi-bin");

	#
	%countries = ("");

	#
	if(1)
	{
		$lfn = $ARGV[0];
		$str = $lfn;
		$str =~ s/^[^0-9]*([0-9]*).*$/$1/;
		#print "$str ";
		@lst2 = LoadList($lfn);
		%ips = ();
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			@sp = split(/\;/, $lst2[$i2]);
			if( !($sp[2]=~/google\.[a-z]*$/) && !($sp[2]=~/google\.[a-z]*\.[a-z]*$/) 
				&& !($sp[2]=~/inktomisearch\.[a-z]*$/)
				&& !($sp[2]=~/ask\.com$/)
				&& !($sp[2]=~/picsearch\.com$/)
				&& !($sp[2]=~/googlebot\.com$/)
				&& !($sp[2]=~/vunet\.org$/)
				)
			{
				$ips{$sp[1]}++;
				if($sp[2]=~/\.[a-z]*$/)
				{
					$str = $sp[2];
					$str =~ s/^.*\.([a-z]*)$/$1/;
					$str =~ tr/[a-z���]/[A-Z���]/;
					$countries{$str}++;
				}
			}
		}
		#$tama = sprintf "%d\n", keys %ips;
		#print STDOUT $tama;
	}

	#
	$t = $lfn;
	$t =~ s/[^0-9]//g;

	#
	$pvm = POSIX::strftime("%d.%m.%Y", localtime($t*60*60*24));
	$ct = time;
	$nt = sprintf "%d", $ct/(60*60*24);
	$nt++;
	$nt = $nt*60*60*24;

	#
#	print "\n";

	#
	@lst = LoadList("countrycodes.txt");
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\ \ \ /, $lst[$i]);
		$cc{$sp[0]} = $sp[1];
	}

	#
	@lst = ();
	$i=0;
	$foreign = 0;
	$total = 0;
	$fin = 0;
	foreach $key (sort(keys %countries))
	{
		if($countries{$key}>0)
		{
			if($key eq "FI") { $fin+=$countries{$key}; } else { $foreign+=$countries{$key}; }
			$total+=$countries{$key};
			$lst[$i++] = sprintf "%1.8d %s", $countries{$key}, $cc{$key};
		}
	}
	if(!$total) { $total++; }
	if(!$fin) { $fin++; }
	if(!$foreign) { $foreign++; }
	@lst = sort @lst;
	@lst = reverse @lst;

	$per = ($fin/$total)*100;
	$per = sprintf "%d", $per;

	$str = sprintf "%s: Uniikit k�vij�t maittain (www.vunet.org)\n", $pvm;
	print $str;
	print "----------------------------------------------------------------\n\n";

	#
	print strftime "%a %b %e %H:%M:%S %Y", ctime(CreationDate1($lfn)), "\n";
	print "$per% suomalaisia k�vij�it�\n";
	print "yhteens� ...\n";
	print "$fin		suomalaista\n";
	print "$foreign		ulkomaalaista\n";
	print "$total		kokonaisuudessaan\n\n";

#	for($i=0; $i<($#lst+1); $i++)
#	{
#		print "$lst[$i]\n";
#	}

	#
}


