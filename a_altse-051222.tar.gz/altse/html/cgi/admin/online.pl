#!/usr/bin/perl
#
##############################################################################################################

#
require "/home/vai/cgi/tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();


###########################################################################################################
#
sub main
{
	#
	ReadersOnline();

	#
}


#############################################################################################
#
sub ReadersOnline
{	
	my ($i,$i2,$str,$str2,$url,$img,@lst,$fn,$pm,$t,@sp,$fn);

	#
	@lst = GetAvlog();

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\;/, $lst[$i]);
		$str = "$sp[2]";
		if(  ($t-$sp[0]) < 900 && !($str=~/googlebot/i) && !($str=~/inktomisearch/i) && $str ne "vunet.org"  )
		{
			if($str eq "") { $str = "$sp[1]"; }
			$vis{$str}++;
		}
	}

	#
	$i = keys(%vis);

	#
	open($f, ">cache/readers_online.txt");
	flock $f, LOCK_EX;
	print $f "$i\n";
	flock $f, LOCK_UN;
	close($f);

	#
}
