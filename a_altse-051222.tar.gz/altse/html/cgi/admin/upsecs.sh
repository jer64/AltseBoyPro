#!/bin/bash
#
echo "1\n";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_videos.js&maxts=50&section=videos&FP_SECTION=finnish" > /home/vai/public_html/cache/index-videos.html

echo "2\n";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_kummalliset.js&section=kummalliset&maxts=100&FP_SECTION=finnish" > \
/home/vai/public_html/cache/index-kummalliset.html

echo "3\n";
lynx -source "http://www.vunet.org/nw.pl?q=\
strip alasto christina vibr seksi tissi alasti jessica alba aasialaisia naisia porn takamuk pylly masturb huor ilotyt\
&maxts=200&section=kummalliset&rs=seksi&FP_SECTION=finnish" > /home/vai/public_html/cache/index-seksi.html

echo "4\n";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_picks.js&section=picks&maxts=100&FP_SECTION=english" > /home/vai/public_html/cache/index-picks.html
#
echo "5\n";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_progressive.js&section=progressive&maxts=100&FP_SECTION=english" > \
/home/vai/public_html/cache/index-progressive.html

echo "6\n";
lynx -source "http://www.vunet.org/nw.pl?top=1&js=top_bush.js&section=bush&maxts=100&FP_SECTION=english" > /home/vai/public_html/cache/index-bush.html

echo "7\n";
lynx -source "http://www.vunet.org/nw.pl?rs=libya&q=libya&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-libya.html

echo "8\n";
lynx -source "http://www.vunet.org/nw.pl?rs=laos&q=laos&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-laos.html

echo "9\n";
lynx -source "http://www.vunet.org/nw.pl?rs=vietnam&q=vietnam&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-vietnam.html

echo "10\n";
lynx -source "http://www.vunet.org/nw.pl?rs=kuuba&q=kuuba&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-kuuba.html

echo "11\n";
lynx -source "http://www.vunet.org/nw.pl?rs=kiina&q=kiina&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-kiina.html

echo "12\n";
lynx -source "http://www.vunet.org/nw.pl?rs=dprk&q=korea&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-dprk.html

echo "13\n";
lynx -source "http://www.vunet.org/nw.pl?rs=venezuela&q=venezuela&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-venezuela.html

echo "14\n";
lynx -source "http://www.vunet.org/nw.pl?rs=iran&q=iran&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/public_html/cache/index-iran.html

echo "15\n";
lynx -source "http://www.vunet.org/com.pl" > /home/vai/public_html/cache/index-keskustelu.html
chmod a+rw /home/vai/public_html/cache/*
