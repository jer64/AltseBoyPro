#!/usr/bin/perl
######################################################################
use XML::RSS::SimpleGen;

#
main();

######################################################################
#
sub GetBaseUrl
{
	my $str;

	#
	$str = $_[0];
	$str =~ s/[^\/]*\z//;
#	$str =~ s/(http:\/\/.*\/)[a-zA-Z]*\.[a-zA-Z]*/$1/;
	return $str;
}

######################################################################
#
sub main
{
	my $str,$str2,$str3,$str4,$a1,$a2,$skip;

	#
	if($ARGV[0] eq "" || $ARGV[1] eq "")
	{
		print("html2rss.pl [url] [target] [head]\n");
		return;
	}

	#
	my $url = $ARGV[0];
	my $base;

	#
	@_skip = split(";", $url);
	$skip = sprintf "%d", $_skip[0];
	$url =~ s/^[0-9]*?\;//;
	print "skip = $skip  url = '$url'\n";
#	return;

	#
	rss_new($url, $ARGV[2]);

	#
	$base = GetBaseUrl($url);
	print "*** base URL = $base ***\n";
	if($base eq "")
	{
		return;
	}

	#
	rss_language( 'en' );
	rss_webmaster( 'vai@vunet.org' );
	rss_twice_daily();

	#
	rss_get_url( $url );

	#
	rss_item("$url", "[Index]", "");

	# Older...
		###	while( m{<A[.|\s]*?HREF[.|\s]*?=[.|\s]*?\"([.|\s]*?)\".*?>[.|\s]*?([.|\s]*?)</A>}sig )
		###	while( m{<a href=\"(.*?)\">(.*?)<\/A>}sig )

	#
	loop1: for($i=-$skip; m{<a\s*?href\s*?=\s*?\"(.*?)\"\s*?>([\S|\s]*?)<\/a>}sig; $i++)
	{
		#
		if($i<0)
		{
			goto past1;
		}
		if($i>=25)
		{
			last loop1;
		}

		#
		$a1 = $1;
		$a2 = $2;

		#
#		print "$a1 --- $a2\n";

		#
		$des = $a2;
		$des =~ s/\n//g;
		$des =~ s/\r//g;
		$des =~ s/\s\s/\ /g;
		$ur = $a1;
		$ur =~ s/\n//g;
		$ur =~ s/\r//g;
		$ur =~ s/\s/%020/g;

		#
	#	print "<<$ur>>($a1) <<$des>>\n"; 

		# Remove all tags from the description.
		$des =~ s/<.*?>//g;
		$des =~ s/<\/.*?>//g;
#		$des =~ s/<(.*?)>(.*?)<\/\1>/$2/g;

		#
		$ur =~ s/^\s//g;
		$des =~ s/^\s//g;

		#
		if(length($des)<3)
		{
			$des = "";
		}

		#
		$ur2 = $ur;
		$ur2 =~ s/\W//g;
		#
		$des2 = $des;
		$des2 =~ s/\W//g;

		#
		if( !($ur =~ /mailto:/i) && length($des2)>4 && length($ur2)>1 )
		{
			#
			if($des =~ /[\<|\>]/)
			{
				#
			}
			elsif($ur =~ /http\:/i)
			{
				rss_item("$ur", $des, "");
			}
			else
			{
				if($ur =~ /\.htm/i)
				{
					rss_item("$base$ur", $des, "");
				}
				else
				{
					rss_item("$url$ur", $des, "");
				}
			}
		}
		else
		{
			print stderr "Unable to handle (2): '$ur' ** '$des'\n";
		}
past1:
	}				


	#
	print "No items in this content?\n"
	unless rss_item_count();

	#
	rss_save("$ARGV[1].rss", 1);
}


