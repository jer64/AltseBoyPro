#!/usr/bin/perl
######################################################################
use XML::RSS::SimpleGen;

#
main();

######################################################################
#
sub GetBaseUrl
{
	my $str;

	#
	$str = $_[0];
	$str =~ s/[^\/]*\z//;
#	$str =~ s/(http:\/\/.*\/)[a-zA-Z]*\.[a-zA-Z]*/$1/;
	return $str;
}

######################################################################
#
sub main
{
	#
	if($ARGV[0] eq "" || $ARGV[1] eq "")
	{
		print("html2rss.pl [file name]\n");
		return;
	}

	#
	my $url = $ARGV[0];
	my $base,$str="";
	rss_new( $url, $ARGV[2]);

	#
	$base = GetBaseUrl($url);
	print "*** base URL = $base ***\n";
	if($base eq "")
	{
		return;
	}

	#
	rss_language( 'en' );
	rss_webmaster( 'vai@vunet.org' );
	rss_twice_daily();

	#
	rss_get_url( $url );

	#
	rss_item("$ARGV[0]", "[Index]", "");

	#
	while( m{<A[.|\s]*HREF=\"(.*?)\".*?>\s*?([.|\n|\r]*?)\s*?</A>}sig )
	{
		#
		$des = $2;
		$des =~ s/\n//g;
		$des =~ s/\r//g;
		$des =~ s/\s{2}/\ /g;
		$ur = $1;
		$ur =~ s/[\n|\r]//g;
		$ur =~ s/\ /%%020/g;

		# Remove all tags from the description.
		$des =~ s/<.*?>//g;
		$des =~ s/<\/.*?>//g;
#		$des =~ s/<(.*?)>(.*?)<\/\1>/$2/g;

		#
		$ur =~ s/^\s//g;
		$des =~ s/^\s//g;

		#
		if(length($des)<3)
		{
			$des = "";
		}

		#
		$ur2 = $ur;
		$ur2 =~ s/\W//g;
		#
		$des2 = $des;
		$des2 =~ s/\W//g;

		#
		if( !($ur =~ /mailto:/i) && length($des2)>4 && length($ur2)>4 )
		{
			#
			if($des =~ /[\<|\>]/)
			{
				#
			}
			elsif($ur =~ /http\:/i)
			{
				rss_item("$ur", $des, "");
			}
			else
			{
				if($ur =~ /\.htm/i)
				{
					rss_item("$base$ur", $des, "");
				}
				else
				{
					rss_item("$ARGV[0]$ur", $des, "");
				}
			}
		}
		else
		{
			print stderr "Unable to handle (2): '$ur' ** '$des'\n";
		}
	}				


	#
	print "No items in this content?\n"
	unless rss_item_count();

	#
	rss_save("$ARGV[1].rss", 1);
}


