#!/usr/bin/perl
# titler.pl
######################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');
#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
main();

#####################################################################################3
#
sub GetTitle
{
        my ($i,$i2,$i3,$i4,@lst,$f,$cap,@tit,$path);

        #
	$path = $_[0];
	if($path=~/\//)
	{
		$path = "$ENV{'DOCUMENT_ROOT'}/articles/$_[0]";
	}

	#
	$so{'release_date'} = "0";
        if( !(-e $path) ) { return(); }
	LoadVars("$path\_options.txt");

        #
        @lst = LoadList("$path");

        #
        $cap = $lst[0];
        $cap =~ s/<[^\>]*>//g;
        $cap =~ s/\s*$//g;
        $cap =~ s/^\s*//g;
        $cap =~ s/\n//g;
        $cap =~ s/\r//g;
        $cap =~ s/\'/\\\'/g;
        $cap =~ s/\"/\\\"/g;

        #
        $tit[$#tit+1] = $_[0];
        $tit[$#tit+1] = $cap;

	#
	return $cap;
}

#####################################################################################3
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$f,$date1,$path);

	#
	chdir("$ENV{'DOCUMENT_ROOT'}/articles/kaikki");

	#
	if( !(-e "fileindex.txt") )
	{
		print "Can't find fileindex.txt!\n";
		return();
	}

	#
	@lst = LoadList("tail -n 300 fileindex.txt|");
	print $#lst;

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\.\///;
		$str = "$lst[$i]";
		$str =~ s/[^a-z0-9]/_/g;
		if( $ald{$lst[$i]} eq "" )
		{
			$path = $lst[$i];
			if($path=~/\//)
			{
				$path = "$ENV{'DOCUMENT_ROOT'}/articles/$_[0]";
			}

			$path = $lst[$i];
			if($path=~/\//)
			{
				$path = "$ENV{'DOCUMENT_ROOT'}/articles/$lst[$i]";
			}
			#print "$path\n";
			$so{'release_date'} = "0";
			LoadVars("$path\_options.txt");
			########$date1 = $so{'release_date'}; #CreationDate1($path);
			$date1 = CreationDate1($path);
			@tit = GetArticleTitle($lst[$i]);
			if($tit[0] eq "" || $tit[1] ne $date1)
			{
				if( GetTitle($lst[$i]) ne "" )
				{
					$ald{$lst[$i]}++;
					SetArticleTitle( $lst[$i], GetTitle($lst[$i]), $date1 );
					print STDERR ".";
				}
			}
			else
			{
				print STDOUT ">";
			}
		}
		$str = "$lst[$i]";
		$fn = $str;
		$fn =~ s/^.*\/([^\/]+\.txt)$/$1/;
		$in_index{$fn}++;
	}
	print STDERR "\n";

	#
}

