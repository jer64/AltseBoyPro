#!/usr/bin/perl
#
# Embedded News Bar
#
################################################################################
require "tools.pl";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		20;
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();


################################################################################
#
sub main
{
	#
	if($ENV{'BAR_SECTION'} ne "")
	{
		$SECTION = $ENV{'BAR_SECTION'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		return;
	}

	#
	newsbar();
}

################################################################################
#
sub newsbar
{
	#
	$WID = "100%";

	#
	print("
			<table width=100% cellpadding=2 cellspacing=0>
		");

	#
	if($SECTION ne "english")
	{
		$SEK = "finnish";
	}

	#
	if($SECTION eq "english")
	{
		$SEK = "english";
	}

	#
	EXPRESS2("$SECTION", "http://www.vunet.org/$SEK/$ENV{'CURSEC'}", "center");

#	print("
#			<tr>
#			<td bgcolor=\"#0070FF\">
#				<div align=center>
#				<a href=\"http://www.vunet.org/$SEK/$SECTION\" class=bright>
#				$ENV{'CURSEC'}
#				</a>
#				</div>
#			</td>
#			</tr>	
#			");

	#
	print("
		<table width=130 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	if($SECTION eq "english" || $SECTION eq "")
	{
		$FP = "english";
		ViewNewStuff("english");
	}

	#
	if($SECTION ne "english")
	{
		#
		$FP = "finnish";
		ViewNewStuff($SECTION);
	}


	#
	print("
		</td>
		</tr>
		</table>
		");
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$url,$con);

	#
#	@art = LoadList("$_[0]");

	#
	$con = "";
	$cap = substr($_[1], 0, 200);

	#
	if($cap eq "") { return ""; }

	#
	$url =~ s/poimitut\/\.\.//;
	$url2 =~ s/poimitut\/\.\.//;
	$url = UrlFix(BuildQuickUrl($_[0]));
	$url2 = UrlFix(BuildQuickUrl($ENV{'VIEW_THIS_ARTICLE'}));

	#
	if($url ne $url2)
	{
		$con = ("$con
		<a href=\"http://vunet.org$url\" class=\"dark\">
			<font size=1>
			");
	}
	else
	{
		$con = ("$con
			<font color=\"#000080\" size=1>
			");
	}

	#
	$cap =~ s/<br>//ig;
	$cap =~ s/(\S{15})/$1 /g;

	#
	$con = ("$con
		<div>
		<li>
		<b>$cap</b>
		</li>
		</div>
		");
	if($url ne $url2)
	{
		$con = ("$con
		</a>
			");
	}
	else
	{
		$con = ("$con
			</font>
			");
	}

	#
	return $con;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,$i,$i2,$col,$con);

	#
	print("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	#
	@lst = "";
	@lst = LoadList("tail --lines=40 $_[0]/titles.txt|");
	$col = "";

	#
	for($ii=$#lst-1,$i2=0; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW; $ii-=2)
	{
		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}

		#
		$lst[$ii] =~ s/^\.\.\///g;
		$fn = "$lst[$ii]";
		if( !($fn =~ /\//) ) { $fn = "$_[0]/$fn"; }
		if( -e $fn )
		{
			$con = ViewHL($lst[$ii], $lst[$ii+1]);
		}
		else
		{
			$con = "";
		}

		#
		if($con eq "") { goto skip; }

		#
		print("
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">
			<font size=1>


			<table cellpadding=4>
			<tr>
			<td>

			$con
			");
		print("
			</td>
			</tr>
			</table>

			</font>
			</td>
			");
		$i2++;
skip:
	}

	#
	print("	
		</table>
		</center>
		");
}

################################################################################
#
sub Caption
{
	#
	print("
		<table cellpadding=4 cellspacing=0 align=center width=100% border=$_[6] bgcolor=$_[2]>
		<tr>
		<td>
		<center>
		<font color=\"$_[3]\" face=\"$_[4]\" size=\"$_[5]\">
		");
	if($_[8] ne "")
	{
		print("
			<img src=\"$_[8]\" alt=\"\" border=1>
			");
	}
	print("
		$_[0]
		</font>
		</center>
		</td>
		</tr>
		</table>
		");
}

