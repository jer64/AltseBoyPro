#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "galleries";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex.html");
WireLogo();

# Add main menu.
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, "english");

#
WebWalkTo("ENTERHERE_SECTION");
main();
#
HandleRest();
        EndBar();

#
sub main
{
	#
	print ("
		<table width=\"750\" cellspacing=0 cellpadding=16>
		<tr>
		<td>
		");

	#
	@lst = LoadList("find /home/vai/public_html/images -type d -maxdepth 1|");
	@lst = sort @lst;

	#
	for($i=0; $i<($#lst+1); $i++)
	{
                $lst2[$i] = $lst[$i];
		$lst2[$i] =~ s/^.+[\/]+([^\/]+)$/$1/;
	}

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		if(-e "$lst[$i]/thumbs")
		{
			$str = $lst2[$i];
			$str =~ s/^(.{15}).*$/$1.../;
			$html[$i2++] = ("
<A HREF=\"http://www.vunet.org/gallery/$lst2[$i]/\">
<IMG SRC=\"http://public.vunet.org/icons/folder.gif\"
	border=0 vspace=4 hspace=4 alt=\"\"
	valign=middle>
$str</A>
");
		}
	}

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR>
<TD>
		");

	#
	for($i=0; $i<(((($#html+1)/4)+1)*4); $i++)
	{
		if(($i&3)==0)
		{
			print(" <TR> ");
		}

		if($i<=$#html)
		{
		print("
<TD WIDTH=25%>$html[$i]</TD>
			");
		}
		else
		{
		print("
<TD WIDTH=25%></TD>
			");
		}

		if(($i&3)==3)
		{
			print(" </TR> ");
		}
	}

	#
	print ("
</TD>
</TR>
</TABLE>
		");
}


