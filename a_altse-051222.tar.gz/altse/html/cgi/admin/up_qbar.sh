#!/bin/bash
wget http://www.vunet.org/qbar.pl -O /home/vai/public_html/uutiset/qbar.js
