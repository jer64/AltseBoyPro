#!/usr/bin/perl
require "tools.pl";

#
main();

#
sub main
{
	# 0: time
	# 1: referer
	# 2: article_title
	# 3: ip
	# 4: host
	# 5: web_browser
	# 6: url
	# 7: local_file_name
	my @lst = GetAvlog();

	#
	my $pieces = 8;
	my $daysecs = 86400;
	my %gotit;
	for(my $i=0; $i<($#lst+1); $i+=8) {
		my $agesec = $time - $lst[$i+0];
		if($agesc < $daysecs && !$gotit{$lst[$i+3]})
		{
			$gotit{$lst[3]}++;
			print "OK, less than a day old ($lst[$i+0]): $lst[$i+4] (IP: $lst[$i+3])\n";
		}
	}

	#
}
