#!/usr/bin/perl

#
use Socket;
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


#####################################################################################
#
sub ViewIPs
{
	my ($i,$i2,$i3,$i4,$fn,$str,$str2,$name);

	#
	$fn = $so{'a'};
	$fn =~ s/\.txt$/.counter/;

	#
	if(-e $fn)
	{
		@lst = LoadList($fn);
	}

	#
	printf "%d IP-osoitetta:<BR>\n", $#lst+1;

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$addr = $addr=inet_aton($lst[$i]);
		$name = gethostbyaddr($addr, AF_INET);
		print "<LI>$lst[$i] ($name)</LI>\n";
	}

	#
}

#####################################################################################
#
sub main
{
	#
	if($so{'a'} eq "")
	{
		return;
	}
	$so{'a'} = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'a'}";

	#
	print("
<TABLE CELLSPACING=0 CELLPADDING=16
	WIDTH=640>
<TR>
<TD>

<TABLE CELLSPACING=0 CELLPADDING=16
	WIDTH=640
	BGCOLOR=#800000>
<TR>
<TD>
		");

	#
	@art = LoadList($so{'a'});
	$artcap = $art[0];
	$art[0] =~ s/[^a-zA-Z������0-9]/ /;

	#
	print("
<FONT COLOR=#FFFF00>
<b>IP-osoitteet artikkelille: <i>$artcap</i></b><BR>
		");

	#
	ViewIPs();

	#
	print("
</FONT>

</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>
		");
}


