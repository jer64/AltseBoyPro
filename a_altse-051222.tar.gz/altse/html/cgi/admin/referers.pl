#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu("etusivu", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$str2);

	#
	@lst = GetAvlog(int($so{'t'}));

	#
	for($i=$#lst-7; $i>0; $i-=8)
	{
		#print "$lst[$i+1]<BR>";
		$REFURL = $lst[$i+1];
		#$REFURL =~ s/^[^\:]*\:(.*)$/$1/;
		$REFHOST = $REFURL;
		$REFHOST =~ s/^[a-z]*\:\/\/([^\/]+).*$/$1/;

		#if($REFURL=~/q\=/) { print "$REFURL<BR>\n"; }

		if( 
		!($REFHOST=~/vaihtoehtouutiset\.info/) && 
		!($REFHOST=~/kultakaivos\.info/) && 
		$REFHOST ne "" )
		{
			$host_ref{$REFHOST}++;
			$url_ref{$REFURL}++;
			#if($REFURL=~/q\=/) { print "$REFURL<BR>\n"; }
			if($REFURL =~ /^.*[^a-z]+q\=[a-z0-9\+\%\-\ ]+.*$/i)
			{
				$str = $REFURL;
				$str =~ s/^.*[^a-z]+q\=([a-z0-9\-\%\+\ ]+).*$/$1/i;
				$str =~ s/\ /\+/g;
				if($str ne $REFURL)
				{
					$keyword_ref{$str}++;
				}
			}
		}
	}

	#
	$WID = 500;

	#
	$i = 0;
	foreach $key (sort(keys %host_ref))
	{
		$hosts[$i++] = sprintf "%.8d %s", $host_ref{$key}, $key;
	}

	#
	@hosts = sort @hosts;
	@hosts = reverse @hosts;

	#
	$i = 0;
	foreach $key (sort(keys %url_ref))
	{
		$urls[$i++] = sprintf "%.8d %s", $url_ref{$key}, $key;
	}

	#
	@urls = sort @urls;
	@urls = reverse @urls;


	#
	$i = 0;
	foreach $key (sort(keys %keyword_ref))
	{
		$keywords[$i++] = sprintf "%.8d %s", $keyword_ref{$key}, $key;
	}

	#
	@keywords = sort @keywords;
	@keywords = reverse @keywords;

	#
	print("
<BR>
<BR>
		<TABLE width=$WID>
		<TR>
		<TD>
		<DIV ALIGN=CENTER>
		<B><U>Eniten K�vij�it� T�n��n Tuoneet Vunettiin</U></B><BR>
		<B>Hakusanan Perusteella</B>
		</DIV>
		</TD>
		</TR>
		</TABLE>

		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<b><FONT SIZE=2><DIV ALIGN=CENTER>osumia t�n��n</DIV></FONT></b>
		</TD>
		<TD WIDTH=75%>
		<b>hakusana</b>
		</TD>
		</TR>
		</TABLE>
		");

	#
	for($i=0; $i<($#keywords+1) && $i<20; $i++)
	{
		@sp = split(/ /, $keywords[$i]);
		$sp[0] = sprintf "%d", $sp[0];
		$str = $sp[1];
		$str =~ s/\+/ /g;
		$str =~ s/%(..)/pack("C", hex($1))/eg;
		$str =~ s/ä/�/g;
		$str =~ s/ö/�/g;
		print("
		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<DIV ALIGN=CENTER>$sp[0]</DIV>
		</TD>
		<TD WIDTH=75%>
		<A HREF=\"http:\/\/www.google.com/search?q=$sp[1]+site\:vaihtoehtouutiset.info\">$str</A>
		</TD>
		</TR>
		</TABLE>
			");
	}

	#
	print("
<BR>
<BR>
		<TABLE width=$WID>
		<TR>
		<TD>
		<DIV ALIGN=CENTER>
		<B><U>Eniten K�vij�it� T�n��n Tuoneet Vunettiin</U></B><BR>
		<B>Domainin Perusteella</B>
		</DIV>
		</TD>
		</TR>
		</TABLE>

		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<b><FONT SIZE=2><DIV ALIGN=CENTER>k�vij�it� sivulta t�n��n</DIV></FONT></b>
		</TD>
		<TD WIDTH=75%>
		<b>sivuston osoite</b>
		</TD>
		</TR>
		</TABLE>
		");

	#
	for($i=0; $i<($#hosts+1) && $i<20; $i++)
	{
		@sp = split(/ /, $hosts[$i]);
		$sp[0] = sprintf "%d", $sp[0];
		print("
		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<DIV ALIGN=CENTER>$sp[0]</DIV>
		</TD>
		<TD WIDTH=75%>
		<A HREF=\"http:\/\/$sp[1]\">$sp[1]</A>
		</TD>
		</TR>
		</TABLE>
			");
	}

	#
	print("
<BR>
<BR>
		<TABLE width=$WID>
		<TR>
		<TD>
		<DIV ALIGN=CENTER>
		<B><U>Eniten K�vij�it� T�n��n Tuoneet Vunettiin</U></B><BR>
		<B>Koko Osoitteen Perusteella</B>
		</DIV>
		</TD>
		</TR>
		</TABLE>

		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<b><FONT SIZE=2><DIV ALIGN=CENTER>k�vij�it� sivulta t�n��n</DIV></FONT></b>
		</TD>
		<TD WIDTH=75%>
		<b>sivuston osoite</b>
		</TD>
		</TR>
		</TABLE>
		");

	#
	for($i=0; $i<($#urls+1) && $i<20; $i++)
	{
		@sp = split(/ /, $urls[$i]);
		$sp[0] = sprintf "%d", $sp[0];
		$str = $sp[1];
		$str =~ s/^(.{20}).*(.{20})$/$1...$2/;
		print("
		<TABLE width=$WID>
		<TR>
		<TD WIDTH=25%>
		<DIV ALIGN=CENTER>$sp[0]</DIV>
		</TD>
		<TD WIDTH=75%>
		<A HREF=\"$sp[1]\">$str</A>
		</TD>
		</TR>
		</TABLE>
			");
	}

	#
}


