#!/usr/bin/perl
#############################################################################
#
# editart.pl
# Edit article.
#
# Called by a HTML form:
# editart.pl?FILE=&RETURL=&CAPTION=
# Called by itself:
# editart.pl?FILE=&RETURL=&CAPTION=&CMD=
#
#############################################################################

#
$NDB_ROOT = "..";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$NDB_ROOT/tools.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
sub EditArticleForm
{
	my $i,$i2,$i3,$i4,$str,$WARNING;

	#
	@art = LoadList($fname);
#	open(f5, $fname) || die "article file not found";
#	@art = <f5>;
#	close(f5);

	#
	for($i=0; $i<($#art+1); $i++)
	{
		#
		if($art[$i] =~ /\<o\:p\>/i)
		{
			$WARNING = 1;
		}
	}


	#
	if($so{'CAPTION'} eq "")
	{
		$so{'CAPTION'} = "Artikkelin muokkaaminen";
	}	
	
	#
	print("
		<div align=center>
		<font size=\"6\">
		<b>
		$so{'CAPTION'}
		</b>
		</font>
		</div>
		<br>
		");

	#
	if($WARNING)
	{
		print("
			WARNING! Complex HTML format detected. Edit with YOUR OWN RESPONSIBILITY.<br>
			This article should probably be edited with a bare HTML editor.<br><br>
			");
	}

	#
	print("
		<form method=\"post\" action=\"editart.pl\">

		<input type=\"hidden\" name=\"cmd\" value=\"cmdeditart123894\">

		<input type=\"hidden\" name=\"PLAIN\" value=\"$so{'PLAIN'}\">
		<input type=\"hidden\" value=\"$fname\" name=\"FILE\">
		<input type=\"hidden\" value=\"$so{'RETURL'}\" name=\"RETURL\">

		<textarea name=\"CONTENT\" cols=\"82\" rows=\"20\" class=\"textarea\">");

	#
	if($so{'CONTENT'})
	{
		print("$so{'CONTENT'}");
	}
	else
	{
		#
		if($so{'PLAIN'} eq "true")
		{
			for($i=0; $i<($#art+1); $i++)
			{
				$art[$i] =~ s/\r//g;
				$art[$i] =~ s/\n//g;
				$art[$i] =~ s/<br>/\n/ig;
			}
		}

		#
		for($i=0,$str=""; $i<($#art+1); $i++)
		{
			print $art[$i];
			if($so{'PLAIN'} ne "true") { print"\n"; }
		}
	}

	#
	print("</textarea>
		<br>
		<br>

		<input type=\"submit\" value=\"save\">

		</form>
		<br>
		");
}

#######################################################
#
# The actual image adding process.
#
sub AddImage1
{
	#
	open(f, ">$fname\_imageurl.txt") || die "can't add image url";
	print f "$imageurl";
	close(f);
}

#######################################################
#
# Image add web form application.
#
sub EditArt
{
	#
	

	# Print form if no command detected.
	#
	EditArticleForm();
}

#######################################################
sub SaveArticle
{
	#####################################################################
	#
	@l = split("\n", $so{'CONTENT'});

	#
	$l[0] =~ s/\n//g;
	$l[0] =~ s/\r//g;

	#
	if($l[0] eq "")
	{
		print "<blink>First line must always contain the article subject.</blink><br><br>\n";
		EditArticleForm();
	}
	else
	{
	}

	#####################################################################
	#
	if($so{'PLAIN'} eq "true")
	{
		#
		@l = split("\n", $so{'CONTENT'});
		#
		$so{'CONTENT'} = "";
		for($i=0; $i<($#l+1); $i++)
		{
			$l[$i] =~ s/^(.*)\s$/$1/;
			$so{'CONTENT'} = "$so{'CONTENT'}$l[$i]<br>\n";
		}
	}

	#
####	$so{'CONTENT'} =~ s/<br \/>/<br>/gi;

	# SAVE ARTICLE DATA.
	open(f6, ">$fname");
	print f6 $so{'CONTENT'};
	close(f6);

	#
	if($all[0] =~ /fb\// && $so{'RETURL'} eq "")
	{
		#
	        print("
	                <meta http-equiv=\"refresh\" content=\"0;
	                url=../factbook.pl\">
	         ");
	}
	else
	{
		#
		if($so{'RETURL'} eq "")
		{
			$so{'RETURL'} = "/viewarticle.pl?article=$fname";
		}

		#
	        print("
			<head>
			<script language=\"JavaScript\">
			location.href = \"$so{'RETURL'}\";
			</script>
	                <meta http-equiv=\"refresh\" content=\"0; url=$so{'RETURL'}\">
			</head>
			<br>
			test $so{'RETURL'}
			<br>
	         ");
	}
}

#######################################################
sub main
{
	my $i,$i2,$str,$str2,@sep;

        # Search arguments line for options.
        $DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	$fname = $so{'FILE'};

	#
        if( !($ENV{'REMOTE_HOST'}=~/\.fi$/) )
        {
                print "njet... qin wode pigu!";
                exit;
        }

	#
	print("
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">

		<table width=715 cellpadding=16 cellspacing=0
			bgcolor=\"#E0E0E0\"
			background=\"$IMAGES_BASE/editor_background.jpg\">
		<tr align=top>
		<td>
		");

	#
	if($so{'cmd'} eq "")
	{	
		
		#
		if($so{'BAREHTML'} ne "true")
		{
		}

		#
		EditArt();
	}
	else
	{
		#
		if($so{'cmd'} =~ /cmdeditart123894/)
		{
			# POST ARTICLE.
			SaveArticle();
		}
		else
		{
			#
			print "Unknown request.\n";
		}
	}

	#
	print("
		</td>
		</tr>
		</table>
		");
}


