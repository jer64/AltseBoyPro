#!/usr/bin/perl
# com.pl - Vunet Social Communication Center.
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$so{'CURSEC'} = $ENV{'CURSEC'};
$so{'section'} = $ENV{'CURSEC'};

#
$DONT_AFFECT_DB = 0;
ArgLineParse();
#
if($so{'l'} eq "fi")
{
	$W_TOTAL = "yhteens�";
	$W_MESSAGES_IN_QUEUE = "viesti� jonossa";
	$ANSWER = "vastaa";
	$MAIN_IMG_URL = "keskustelufoorumi.jpg";
	$ENV{'CURSEC'} = "keskustelu";
}
else
{
	$W_TOTAL = "total";
	$W_MESSAGES_IN_QUEUE = "messages in queue";
	$ANSWER = "respond";
	$MAIN_IMG_URL = "discussion_forum.jpg";
	$ENV{'CURSEC'} = "discussion";
}

#
if($so{'IF'} eq "")
{
	#
	OpenWebIndex("./webindex2.html");

	# Add main menu.
	if($so{'l'} ne "en") {
		WebWalkTo("main-menu");
		print inc_menu($ENV{'CURSEC'}, "finnish");
	} else {
		WebWalkTo("main-menu");
		print inc_menu($ENV{'CURSEC'}, "english");
	}
}
else
{
	print("
<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
</HEAD>

<BODY>
	");
}

#
#
if($so{'IF'} eq "")
{
	WebWalkTo("ENTERHERE_SECTION");
}
main();

#
if($so{'IF'} eq "")
{
	#
	WebWalkTo("ALAPALKKITAHAN");
	#
	print EndBar();
	#
	HandleRest();
}
else
{
	print("
</BODY>
		");
}

###########################################################################################################
#
sub PreviewCommentTree
{
	my ($i,$i2,$i3,$i4,$i5,$i6,$x,@lst,@lst2,@art,$str,$str2,$cap,@sp,@sp2,$shown);

	#
	if( !(-e $_[0]) ) { return 0; }

	#
	@lst = LoadList($_[0]);
	@lst = reverse @lst;

	#
	if($lst[0]=~/^\s*$/ || !(-e $_[0])) { return 0; }

	#
	$afn = $_[0];
	$afn =~ s/_comindex\.txt//;
	#print "$afn<br>";
	if( !(-e $afn) ) { goto past; }
	@art = LoadList($afn);
	$cap = $art[0];
	$cap =~ s/<[^\>]*>//g;
	$cap =~ s/^(.{80}).*$/$1.../;

	#
	$url = "$afn";
	$url =~ s/^$ENV{'DOCUMENT_ROOT'}\/articles\///;
        $url = CapUrl($url,$cap);
        $url =~ s/\.txt$/.html/;
	
	#
	$cap =~ s/(\S{15})/$1 /g;
	$caption = ("
		<A HREF=\"/$url';\"></A><BR>
		<A HREF=\"Javascript:parent.location='/$url';\"><b>$cap</b></A><BR>
		");

	#
	loop: for($i4=0,$i5=0,$shown=0; $i4<($#lst+1) && $i5<5; $i4++,$glcm++)
	{
		#
		$lst[$i4] = "$ENV{'DOCUMENT_ROOT'}/articles/$lst[$i4]";
		#print $lst[$i4];
		@com = LoadList($lst[$i4]);
		if(NoTracking() && $so{'q'} ne "" && !($com[0] =~ /$so{'q'}/))
		{
			goto past;
		}

		#
		@sp = split(/\&/, $com[0]);
		$sp[2] =~ s/<[^\>]*>//g;
		for($i=1,$str=""; $i<($#com+1); $i++)
		{
			$str = "$str $com[$i]";
		}
		$str =~ s/<[^\>]*>//g;
		$str =~ s/^(.{70}).*$/$1.../;
		$sp[2] =~ s/^(.{14\S*}).*$/$1.../;
		if($str eq "" || $str=~/^\s*$/) { goto past; }
		if($str=~/http:\/\//) { goto past; }

		#
		if(NoTracking())
		{
			$ADMIN_INFO_QUEUE = "( article :  $_[0] )";
		}

		#
		if(1)
		{
			#
			$to1 = $lst[$i4];
			$to1 =~ s/articles\///;
			$afn1 = $afn;
			$afn1 =~ s/articles\///;
			$resp = ("<A HREF=\"Javascript:parent.location='/viewarticle.pl?article=$afn1&respond_to=$to1#comments_form';\"
					class=orange><IMG SRC=\"$IMAGES_BASE/respond.gif\" border=0> $ANSWER</A></DIV>");
			#
			$comid = "$lst[$i4]";
			$comid =~ s/^.*comment([0-9]*).*/$1/;
			$comid++;
			#
			#$x = $#lst-($nayta);
			#$con = "";
			#if($x>0)
			#{
			#	$con = "<i>($x muuta viesti�)</i>";
			#}
			#$pm = POSIX::strftime("%d.%m.%Y", localtime( (stat($lst[$i4]))[9] ));
			if($pm eq "15.11.2007") { $pm = ""; }
			if(NoTracking())
			{
				# picks/pub_artikkeli280.txt_comment0.txt
				$comnr = $glcm;
				$artk = $lst[$i4];
				$artk =~ s/_comment[0-9]+\.txt//;
#artk = $artk -- comnr = $comnr
				$NOTR1 = "<DIV ID=\"comment$glcm\">";
				$NOTR2 = "</DIV>";
				$NOTR = ("
<A HREF=\"Javascript:RemoveComment($comnr, '$lst[$i4]', 'poistettu!');\">
<IMG SRC=\"$IMAGES_BASE/kori.gif\" align=center border=0 vspace=4 hspace=4>
poista kommentti
</A>
<BR>
					");
#					$lst[$i4]<BR>
			}
			print("
$caption

$NOTR1
	<LI>
	<A HREF=\"Javascript:parent.location='/$url#comment$comid';\" class=pink>$str</A> $pm <font size=1>$sp[2]</font><BR>
	$NOTR
	</LI>
$NOTR2

<TABLE cellspacing=0 cellpadding=0 width=100%><TR><TD width=66%></TD><TD width=34%>$resp</TD></TR></TABLE>
			");
			$caption = "";
			$i5++;
			$shown++;
		}
past:
	}

	#
	if( ($#lst+1) > $i5 && $shown ) 
	{
		printf("
		<B>...</B><BR>
		$W_TOTAL %d $W_MESSAGES_IN_QUEUE $ADMIN_INFO_QUEUE
		<BR>
			",
		$#lst+1);
	}
	print "<BR>";

	#
	return 1;
}

###########################################################################################################
#
sub ViewComments
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$str2);

	#
	@lst = LoadList("find $ENV{'DOCUMENT_ROOT'}/articles/ -maxdepth 2 -name '*_comindex*' -type f|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$t = (stat($lst[$i]))[9];
		$lst[$i] = "$t $lst[$i]";
	}

	#
	#@lst = sort @lst;
	#@lst = reverse @lst;

	#
	for($i=0,$i2=0,$glcm=0; $i<($#lst+1) && $i2<200; $i++,$glcm++)
	{
		#
		if($i==6 && !NoTracking())
		{
			print("
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 15;
google_ad_format = \"468x15_0ads_al\";
//2006-10-18: Videot
google_ad_channel = \"5733392665\";
google_color_border = \"FFFFFF\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_text = \"000000\";
google_color_url = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
<BR>
<BR>
			");
		}
		#
		@sp = split(/ /, $lst[$i]);
		if( PreviewCommentTree($sp[1]) ) { $i2++; }
	}

	#
}

###########################################################################################################
#
sub main
{
	#
	if(NoTracking())
	{
		print("
<SCRIPT language=\"javascript\">
<!--
function RemoveComment(comnr, deletion, req)
{
	document.getElementById('comment' + comnr).innerHTML = '<IMG SRC=\"admin/remcom.pl?' + deletion + '\" title=\"' + req + '\">';
}
// -->
</SCRIPT>
			");
	}

	#
	print("

<TABLE CELLSPACING=0 CELLPADDING=4
	width=100%>
<TR>
<TD>

<TABLE BACKGROUND=\"$IMAGES_BASE/$MAIN_IMG_URL\"
	STYLE=\"background-repeat: no-repeat;\"
	width=100%
	HEIGHT=64>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<BR>
	");

	#
	ViewComments();	

	#
	print("
</TD>
</TR>
</TABLE>

		");

	#
}


