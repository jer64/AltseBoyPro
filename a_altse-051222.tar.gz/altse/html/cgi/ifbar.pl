#!/usr/bin/perl
#
# SHOW A BRIEF VIEW OF NEWS FROM SELECTED SECTION
# ifbriefly.pl
# Called by jsheadlines at nw.pl.
#
################################################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
use POSIX;
require "tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	if($ARGV[0] ne "" && $ARGV[1] ne "")
	{
		$so{'s'} = $ARGV[0];
		$so{'page'} = $ARGV[1];
	}

	#
	$so{'page'} =~ s/[^0-9]//g;
	$so{'page'} = sprintf "%d", $so{'page'};
	$so{'s'} =~ s/[^a-z]//g;

	#
	print("
<HTML>

<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
</HEAD>

<BODY>

		");

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0 background=\"http://www.vunet.org/images/fade2b.gif\" valign=top
	style=\"vertical-align: top; background-repeat: repeat-y;\">
<TR>
<TD>
<script language=\"Javascript\" src=\"http://www.vunet.org/jsbar.pl?s=$so{'s'}&a=$so{'a'}\">
</script>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</TD>
</TR>
</TABLE>
		");

	#
	print("
</BODY>

</HTML>
		");

	#
}




	#
	print("
</BODY>

</HTML>
		");

	#
}


