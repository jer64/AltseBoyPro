		var testzz=0;

		function MouseOverNewstable(e, which)
		{
			e.className = which;
		}

		function MouseOutNewstable(e, which)
		{
			e.className = which;
		}

		function Clixxor(e, url)
		{
			window.location = url;
		}

		function TextViewer1()
		{
			o = document.getElementById('CCCP');
			if(o)
			{
				o.innerHTML = 'Yahoo!'+testzz/3;
				testzz++;
			}
		}
