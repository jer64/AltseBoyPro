#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,@sp);

	#
	@lst = LoadList("iplist.txt");

	#
	unlink("resolved.txt");
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split("\=", $lst[$i]);

		if($sp[0]=~/^[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*$/)
		{
			@lst2 = LoadList("host $sp[0] 2>/dev/null|");
			if($lst2[0]=~/^Name: /)
			{
				$lst2[0] =~ s/^Name: //;
				open($f, ">>resolved.txt");
				print $f "$lst2[0]\n";
				close($f);
			}
		}
	}

	#
}

#
