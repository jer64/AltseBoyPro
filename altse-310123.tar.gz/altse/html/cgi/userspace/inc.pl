#!/usr/bin/perl
#
if($ENV{'newswire_conset'} ne "TRUE")
{
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "pubsettings.pl";
require "admin.pl";

