#!/usr/bin/perl
################################################################################
#
# Embedded gallery.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$GAL = "asian";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if($so{'q'} ne "")
	{
		$GAL = $so{'q'};
		$GAL =~ s/[^a-z0-9_]//g;
	}

	#
	$IMGBASE = "$IMAGES_BASE/$GAL";

	#
	$str = gallery();
        #
        $str =~ s/[\t\n\r\s]/ /g;
        #$str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

	#
        print(" document.write(\"$str\"); \n");
}

################################################################################
#
sub gallery
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$fn);

	#
	if($so{'x'} eq "") { $so{'x'} = "160"; }
	if($so{'y'} eq "") { $so{'y'} = "120"; }

	#
	$str = ("
<embed src=\"$so{'q'}\" width=$so{'x'}} height=$so{'y'}>
</embed>
		");

	#
	return $str;
}

