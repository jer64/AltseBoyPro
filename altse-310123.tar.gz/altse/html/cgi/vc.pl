#!/usr/bin/perl
##############################################################################
#
# TOP VIDEOS CHART
#
##############################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "suosituimmat";

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

# Max. cache age, in seconds.
$M_CAGE = 60*15;
$CACHE_STAT_INTERVAL = (60*60*1);

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
#
sub ViewArt
{
	my (@lst,$ii,$ii2);

	#
	if(!-e $_[0])
	{
		return "";
	}

	#
	@lst = LoadList($_[0]);

	#
	if( !($lst[0] =~ /video/i) ) { return ""; }

	#
	for($ii=0; $ii<($#lst+1); $ii++)
	{
		$lst[$ii] =~ s/<br>//gi;
	}

	#
	return "$lst[0]";
}

##################################################
#
sub ProduceTopTen
{
	my (@lst,@srt,$i,$i2,$i3,$i4,$t,$host,$lhost,
		$url,$lurl,$t_cache,
		$f,$f2,
		$str,$str2);


	#####################################################################
	#

	#
	$so{'TLI'} = 900000000;

	#
	$cage = 0;

	#
	$t_cache = 0;

	#
	$fn = sprintf "cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache;

	#####################################################################
	#
	# Build new statistics.
	#
	#@lst = LoadList("tail -n100000 avlog.txt|");
	my $query = "SELECT * FROM visitors$WHERE ORDER BY ID DESC LIMIT 0, 100000";
	print STDERR "DOING: $query\n";
	$sth = $dbh->prepare($query);
	print STDERR "DONE.\n";
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";

	#
	for($i=0,$lurl="",$lhost="",$i2=0; (@lq = $sth->fetchrow_array); $i+=8)
	{
		# Time limit.
		$t = time();

		#
		if( ($lg[1] eq "" || !($lg[1]=~/^[0-9]*$/)) ) { $i++; goto past; }

		#
		$url = $lq[5];
		$host = $lq[1];

                #
                if( IsBanned($host) ||
			($host eq $lhost && $url eq $lurl) )
                {
			#
                        goto past;
                }

		#
		if($lst[$i+6] =~ /\//)
		{
			#
			if( ($so{'TLI'}!=0 && ($t-$so{'TLI'}) >= $lq[1]) )
			{
				goto skip;
			}

			#
			if( $lst[$i+2]=~ /seksiorjia/i )
			{
			#	print "$host<br>\n";
			}

			#
			$srt[$i2] = $lst[$i+6];
			$srt[$i2] =~ s/\/\?id=//;
			$i2++;
skip:
		}
past:

		#
		$lhost = $host;
		$lurl = $url;
	}

	#
	@srt = sort(@srt);

	#
	for($i=0; $i<($#srt+1); $i++)
	{
		$str = $srt[$i];
		$top{$str}++;
	}

	# Produce list of quick urls strings that begin with chart position:
	# 000000001 /?id=123x123
	$i=0;
        foreach $key (keys %top)
        {
		$s[$i++] = sprintf "%1.10d <$key>", $top{$key};
        }

	#
	@s = sort(@s);

	#
	open($f, ">$fn") || die "can't save cache '$fn'\n";
	for($i=0; $i<($#s+1); $i++)
	{
		print $f "$s[$i]\n";
	}
	close($f);
}

##################################################
#
sub ShowTopTen
{
	my ($i,$i2,$AMO,$lpos,$pos);

	#
	$so{'ILMAN'} = "ei";

	#
	if($so{'ILMAN'} eq "ei" && !NoTracking())
	{
		$so{'ILMAN'} = "kylla";
	}
	if(!NoTracking()) { goto skippi; }
	if($so{'ILMAN'} ne "ei")
	{
	print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=ei&TLI=$so{'TLI'}\">
		> N�yt� lukukerrat.
		</a>
		</div>
		");
	}
	else
	{
		print("
		<div align=right>
		<a href=\"/chart.pl?ILMAN=kylla&TLI=$so{'TLI'}\">
		> Piilota lukukerrat.
		</a>
		</div>
		");
	}
skippi:

	#
	$AMO = 50;
	$LOGO = "VideosTop50.jpg";

	#
	$i = $so{'TLI'} / 60 / 60;
	if($i<=0)
	{
		$i = "";
	}
	else
	{
		$i = "$i tunnin ajalta";
	}
	print("
		<div align=center>
		<img src=\"$IMAGES_BASE/$LOGO\" alt=\"* TOP50 *\"><br>
		</div>");
	print("
		</div>
		<br>
		");

	#
	print("
		<table>
		");

	#
	@s = reverse @s;
	@s2 = reverse @s2;
	@s3 = reverse @s3;

	#
	for($i=0,$i2=0; $i2<$AMO && $i<($#s+1); $i++)
	{
		#
		if(!(-e $s2[$i]))
		{
		#	if(NoTracking()) { print "<i>not found $s2[$i]</i>"; }
			if($i2) { $i2--; }
			goto skip;
		}

		# Get positions.
		$pos=0; $lpos=0;
		$pos =  $pos1{$s[$i]};
		$lpos = $pos2{$s[$i]};
		#
		$indim="";
		#
		if($lpos eq "" && $pos ne "")
		{
			$indim = ("<img src=$IMAGES_BASE/tulokas.gif border=0 title=$pos/$lpos>");
			goto past1;
		}

		#
past1:

		#
		$cont = ViewArt($s2[$i]);
		if($cont eq "") { goto skip; }

		#
		print("
			<tr valign=top>
			");

		#
		####$pos/$lpos
		printf "<td width=50 valign=top>%d.</td>", $i2+1;
		print("<td width=400 valign=top> <a href=\"/article/$s2[$i]\" class=news1>
		$indim
		");
		print("
		$cont
		</a></td>
		");
		print "<td width=100 valign=top>";
		if($so{'ILMAN'} eq "ei")
		{
			printf "<font size=1> (%d lukukertaa)</font><br>\n", $s3[$i];
		}
		print "</td>";

		#
		print("
			</tr>
			");

		#
		$i2++;
		if( ($i2 % 10)==0 && $i2!=0 )
		{
			print ("<tr>
			<td></td><td><br>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"\";
google_color_border = \"3333CC\";
google_color_bg = \"FFFFFF\";
google_color_link = \"6666FF\";
google_color_url = \"000099\";
google_color_text = \"0033FF\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
<BR>
			");
			print("
			<br></td>
			</tr>");
		}
skip:
	}

	#
	print("
		</table>
		");
}

##################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	$so{'TLI'} =~ s/[^0-9]//g;

	#
	if( ($i=IsRunning("chart.pl")>1) )
	{
		#
		print("
			CHART APPLICATION IS BUSY. TRY AGAIN AFTER 10-30 SECONDS.
			");
		return();
	}
	#
	$i = sprintf("%d", $i);

	#
	ProduceTopTen();

	# Resolved quick URLs... -> $s2[...]
	for($i=0,$i2=0; $i<($#s+1); $i++,$i2++)
	{
		# s2 = resolved URL
		$str2 = $s[$i];
		$str2 =~ s/^.*<(.*)>/$1/g;
		$str = ResolveQuickUrl($str2);
		$s2[$i2] = $str;

		# s3 = amount of reads
		$str2 = $s[$i];
		@sp = split(" ", $str2);
		$s3[$i2] = $sp[0];
	}

	#
	print("
		<table width=550 cellpadding=16 cellspacing=0>
		<tr>
		<td>
		");

	#
	ShowTopTen();

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
}


