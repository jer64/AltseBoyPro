#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	#
	print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>

<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">


<meta http-equiv=\"Pragma\" content=\"no-cache\">
<!-- Pragma content set to no-cache tells the browser not to cache the page
This may or may not work in IE -->
<meta http-equiv=\"expires\" content=\"0\">

<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\">
<meta http-equiv=\"Content-Language\" content=\"fi\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">


<!---CHOOSE-TITLE1--->

<TITLE>Vunet news network - get all the latest breaking news.</TITLE>
</HEAD>


<body>
<script language=\"Javascript\" src=\"http://www.vunet.world/qbar.pl\">
</script>

<IFRAME src=\"http://www.skp.fi/\"
        width=100% height=640
        frameborder=0 style=\"border:0px\">
</IFRAME>
</body>
</html>
		");

	#
}


