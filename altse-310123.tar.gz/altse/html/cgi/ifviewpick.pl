#!/usr/bin/perl
#######################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ArticleViewerMonitor.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NaytaUutisotsikot.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewHL.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/AnyComments.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewMainArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/WebPortal.pm";

#######################################################
# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
use POSIX;

#
main();

#
sub main
{
	#
	beg_body();

	#
	if($so{'t'} eq "gold") {
		@pick = LoadList("$ARTBASE/cfg/goldpick.txt");
		@pick = reverse @pick;
	} else {
		@pick = LoadList("$ARTBASE/cfg/pick.txt");
		@pick = reverse @pick;
	}
	$so{'i'} = int($so{'i'});
	$picknr = $so{'i'};
	$i = $#adv;
	print ViewMainArticle($pick[$picknr], "", "1000", "TRUE", "", "", "",
		"225", "");
	PerArticleCounter( "$ENV{'DOCUMENT_ROOT'}/articles/$pick[$picknr]" );
	ArticleViewerMonitor( $pick[$picknr] );

	#
	end_body();
}

#
sub beg_body
{
	print("
<HTML>

<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\"
        href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
</HEAD>

<BODY>
		");
}

#
sub end_body
{
	#
	print("
</BODY>
</HTML>
		");
}
