#!/usr/bin/perl
################################################################################
#
# jsbar.pl - Embedded News Bar (JAVASCRIPT).
# Featured in articles on the left.
# (C) 2006-2008 by Jari Tuominen.
#
################################################################################
require "tools.pl";
require "modules/VerboseViewHL.pm";
require "modules/ViewArticle.pm";
require "modules/ViewArticleLib.pm";
require "modules/EmbeddedViewArticle.pm";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

#
sub JsViewArticles
{
  my ($str);

  $str .= join(" ", LoadList("./cmdviewarticles.pl $so{'sec'} $so{'c'} $so{'ignore'}|"));

  #
  return $str;
}

#
sub main
{
	$so{'sec'} =~ s/[^a-z]//;
	$so{'c'} =~ s/[^0-9]//;
	$so{'ignore'} =~ s/[^0-9\|a-z]//;

	#
	$str = JsViewArticles();
	$str =~ s/<script>.+<\/script>//i;
        #
	$str =~ s/[\t\n\r\s]/ /g;
	$str =~ s/  / /g;
	$str =~ s/\"/'/g;

	#
	@sp = split(/(.{200}[^\\]{8})/, $str);
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] ne "")
		{
		        print(" document.write(\"$sp[$i]\");\n ");
		}
	}

}
