#!/usr/bin/perl
##############################################################################
#
# TOP CHART
# rss.pl - RSS News Feed.
# (C) 2006-2012 by Jari Tuominen (jari@vunet.world).
# (C) 2006-2008 by Jari Tuominen (jari@vunet.world).
#
##############################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Shell helper.
if($ENV{'HTTP_HOST'} eq "") {
	$ENV{'HTTP_HOST'} = $_[0];
}

#
$CGICMD = "/cgi/chart.pl?";
#
$ENV{'CURSEC'} = "suosituimmat";

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/RSSDump.pm";
use POSIX;
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

if($so{'base'} eq "") {
	$BASEURL = "http://www.vunet.world";
} else {
	$BASEURL = $so{'base'};
}
#
if($so{'MAGIC'} ne "32785782378523758" && !NoTracking())
{
	print "<P>Authorization required.</P>\n";
	exit();
}

#
$so{'FP_SECTION'} = "finnish";

#
if($so{'blank'} eq "")
{
	#
	if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
		$FP = "gold";
		OpenWebIndex("./goldindex.html");
	} else {
		$FP = "vunet";
		OpenWebIndex("./webindex2.html");
	}
        #
	WebWalkTo("CHOOSE-TITLE1");
        print("<TITLE>TOP 20 - Vaihtoehtouutiset.info</TITLE>");
        print("
<META name=\"description\" content=\"Top 20 Articles Today in Vunet.org\">
<META name=\"keywords\" content=\"top,articles,top20,top 20,news,uutiset,vunet\">
<META name=\"owner\" content=\"LST\@vunet.world\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">
<META name=\"revisit-after\" content=\"5 days\">
                        ");
        SkipTo("CHOOSE-TITLE2");

	# Add main menu.
	WebWalkTo("main-menu");
	if($ENV{'HTTP_HOST'}=~/kultakaivos/) {
		print inc_gold_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
	} else {
		print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
	}

	#
} else {
	OpenWebIndex("./textindex2.html");
	WebWalkTo("ENTERHERE_SECTION");
}

# Max. cache age, in seconds.
$M_CAGE = 60*15;
$CACHE_STAT_INTERVAL = (60*60*1);

#
if($so{'blank'} eq "")
{
	#
	WebWalkTo("ENTERHERE_SECTION");
}
main();

#
if($so{'blank'} eq "")
{
	WebWalkTo("ALAPALKKITAHAN");
	#
	print EndBar();
	#
	HandleRest();
} else {
	HandleRest();
}

#


##################################################
#
sub GetArtTitle
{
	my (@lst,$ii,$ii2,$IMG);

	#
	if(!-e $_[0])
	{
		return;
	}

	#
	@lst = LoadList($_[0]);
	$optfn = ("$_[0]\_options.txt");
	$so{'imageurl'} = "";
	if(-e $optfn)
	{
		LoadVars($optfn)
	}

	#
	for($ii=0; $ii<($#lst+1); $ii++)
	{
		$lst[$ii] =~ s/<br>//gi;
	}

	#
	$IMG = "";
	if($so{'imageurl'} ne "")
	{
		$IMG = $so{'imageurl'};
		$IMG =~ s/^.*\/([^\/]+)$/$1/;
		$IMG = "$IMAGES_BASE/thumb2/th_$IMG";
		$IMG =~ s/\.[a-z]+$/.png/;
		$IMG = ("
<img src=\"$IMG\" border=0 align=middle>
		");
	}

	#
	return ("$IMG", "$lst[0]");
}

##################################################
#
sub ProduceTopTen
{
	my (@lst,@srt,$i,$i2,$i3,$i4,$t,$host,$lhost,
		$url,$lurl,$t_cache,
		$f,$f2,
		$str,$str2);


	#####################################################################
	#

	#
	$cage = 0;

	#
	#$t_cache = sprintf "%d", time/($CACHE_STAT_INTERVAL);
	$t_cache = 0;

	#
	$fn = sprintf "$ENV{'DOCUMENT_ROOT'}/cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache;
	$fn2 = sprintf "$ENV{'DOCUMENT_ROOT'}/cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache-2;

	#####################################################################
	#
	# Build new statistics.
	#
	@lst = GetAvlog($so{'TLI'});
	#print $#lst."<BR>";

	#
	loop: for($i=$#lst-8,$lurl="",$lhost="",$i2=0; $i>-1; $i-=8,$lip=$ip)
	{
		# Time limit.
		$t = time;

		#
again:
		if($lst[$i+0] eq "" || !($lst[$i+0]=~/^[0-9]*$/) && $i<$#lst) { $i++; goto again; }

		#
		if( ($t-$lst[$i+0]) >= (60*60*24) ) { next; }

		#
                $url = $lst[$i+5];
                $host = $lst[$i+4];
		@sp = split(/\:/, $lst[$i+3]);
		$ip = $sp[0];
		#print "$ip<BR>\n";

                #
                if( ($host ne "" && IsBanned($host)) ||
			(($host ne "" && $host eq $lhost && $url eq $lurl) || $ip eq $lip) )
                {
			#
			#print "$lst[$i+0] <-> $t<BR>";
                        next;
                }

		#
		if($lst[$i+6] =~ /\//)
		{
			#
			if( (($so{'TLI'}!=0 && ($t-$so{'TLI'}) >= $lst[$i+0])) )
			{
				goto skip;
			}
			if( $ENV{'HTTP_HOST'}=~/kultakaivos/ && !($lst[$i+6]=~/talous/) )
			{
				goto skip;
			}

			## Referer: Abusing users reporting.
			if( $lst[$i+2]=~ /seksiorjia/i )
			{
			#	print "$host<br>\n";
			}

			#
			$srt[$i2] = $lst[$i+6];
			$srt[$i2] =~ s/\/\?id=//;
			$i2++;
			#print "$i2: $host - $lst[$i+6]<BR>";
skip:
		}
past:

		#
		$lhost = $host;
		$lurl = $url;
	}

	#
	@srt = sort(@srt);

	#
	for($i=0; $i<($#srt+1); $i++)
	{
		$str = $srt[$i];
		$top{$str}++;
	}

	# Produce list of quick urls strings that begin with chart position:
	# 000000001 /?id=123x123
	$i=0;
        foreach $key (keys %top)
        {
		$s[$i++] = sprintf "%1.10d <$key>", $top{$key};
        }

	#
	@s = sort(@s);
}

#############################################################################
#
sub main
{
	#
	RSSDump($so{'sec'});
}

##################################################
#
sub GenTopTenHTML
{
	my ($i,$i2,$AMO,$lpos,$pos,$content);

	#
	$i = 60*60*24;

	#
	$content = "";

	#
	if( NoTracking() )
	{
	$content .= ("
		<div align=right>
		<a href=\"$CGICMD?ILMAN=$so{'ILMAN'}&TLI=$i\" class=news3>
		> P�iv�n luetuimmat.
		</a>
		</div>
		");

	#
	$i = 60*60*24*7;
	$content .= ("
		<div align=right>
		<a href=\"$CGICMD?ILMAN=$so{'ILMAN'}&TLI=$i\" class=news3>
		> Viikon luetuimmat.
		</a>
		</div>
		");

	#
	$content .= ("
		<div align=right>
		<a href=\"$CGICMD?ILMAN=$so{'ILMAN'}&TLI=\" class=news3>
		> Logihistorian luetuimmat.
		</a>
		</div>
		");
	}

	#
	if($so{'ILMAN'} eq "ei" && !NoTracking())
	{
	#	$so{'ILMAN'} = "kylla";
	}
	if(!NoTracking()) { goto skippi; }
	if($so{'ILMAN'} ne "ei")
	{
	$content .= ("
		<div align=right>
		<a href=\"$CGICMD?ILMAN=ei&TLI=$so{'TLI'}\">
		> N�yt� lukenutta.
		</a>
		</div>
		");
	}
	else
	{
		$content .= ("
		<div align=right>
		<a href=\"$CGICMD?ILMAN=kylla&TLI=$so{'TLI'}\">
		> Piilota lukukerrat.
		</a>
		</div>
		");
	}
skippi:

	#
	if($so{'TLI'} == 86400)
	{
		#
		$AMO = 20;
		$LOGO = "paivan.jpg";
	}
	else
	{
		#
		$AMO = 50;
		$LOGO = "top50b.jpg";
	}

	#
	$i = $so{'TLI'} / 60 / 60;
	if($i<=0)
	{
		$i = "";
	}
	else
	{
		$i = "$i tunnin ajalta";
	}
	if($ENV{'HTTP_HOST'}=~/www\.vaihtoehtouutiset\.info/) {
		$FOR_VUNETORG = ("
<TABLE width=100 height=30 cellspacing=0 cellpadding=0
	align=right>
<TR>
<TD>

<P>
<A HREF=\"http://www.kultakaivos.info\">
<IMG SRC=\"$IMAGES_BASE/banners/kultakaivos_banner.png\" class=localadimage>
</A>
</P>


</TD>
</TR>
</TABLE>

			");
	}

	#
	$RSS_FEED_ORDER_HTML = ("
<TABLE WIDTH=400 cellspacing=0 cellpadding=4 align=right
        style=\"position: absolute;\">
<TR>
<TD width=350>
</TD>
<TD width=50>
        <a href=\"/rss/?sec=$RSS_SEC\" class=news5>
        <font size=\"1\">
                <IMG SRC=\"/images/icons2/rss_feed_icon_16x16.gif\" border=0 align=\"middle\"
                        title=\"Tilaa TOP20\" alt=\"\"> Tilaa
        </font>
        </a><BR>
</TD>
</TR>
</TABLE>
");

	$content .= ("
		<!--- OPTIONAL LOGO HERE --->
$FOR_VUNETORG

<B><FONT COLOR=PURPLE>Lahjoita meille, laita vain tilille fi3710453500542922 (nimi: Vaihtoehtouutiset oder Jari Tuominen)</FONT></B>

Spenden Sie f�r uns, einfach 1 Dollar Konto fi3710453500542922 (nimi: Vaihtoehtouutiset oder Jari Tuominen)

fr�hliche feiertag</FONT>
		<div align=center>
		<b>
		<P><A HREF=\"http://$ENV{'HTTP_HOST'}\">$ENV{'HTTP_HOST'}</A></P>
		<FONT COLOR=BLACK>$AMO</FONT> <FONT COLOR=#400000>SUOSITUINTA ARTIKKELIA</FONT><br>
		</b>
<FONT COLOR=#400000 FACE=IMPACT><P><I>Always our top stories</I><B></P></FONT>
</FONT>
		$i
");
	if(NoTracking())
	{
		$cage = FileAge($fn);
		$content .= ("<font size=1 color=\"404040\"><br>$cage/$CACHE_STAT_INTERVAL</font>");
	}
	$content .= ("
		</div>
$RSS_FEED_ORDER_HTML
		<br>
		");

	#
	$content .= ("
		<table>
		");

	#
	@s = reverse @s;
	@s2 = reverse @s2;
	@s3 = reverse @s3;

	#
	if($FP eq "vunet") {
		$fn = sprintf "$ENV{'DOCUMENT_ROOT'}/cache/chart-cache-$so{'TLI'}-%d.asc", $t_cache;
	}
	if($FP eq "gold") {
		$fn = sprintf "$ENV{'DOCUMENT_ROOT'}/cache/chart-gold-cache-$so{'TLI'}-%d.asc", $t_cache;
	}
	open($f, ">$fn") || print  "<p>can't save cache</p>";

	#
	for($i=0,$i2=0; $i2<$AMO && $i<($#s+1); $i++,$i2++)
	{
		#
		my $arfn = "$ARTBASE/$s2[$i]";
		$arfn =~ s/([a-z]+)\/story\-([0-9]+)\.html$/$1\/pub_artikkeli$2.txt/i;
		if( $s2[$i]=~/kummalliset/
		|| !(-e $arfn))
		{
			#if(NoTracking()) { $content .=  "<i>not found $arfn</i>"; }
			$i2--;
			goto skip;
		}

		# Get positions.
		$pos=0; $lpos=0;
		$pos =  $pos1{$s[$i]};
		$lpos = $pos2{$s[$i]};
		#
		$indim = $i2+1 . ". ";
		#
		if($pos eq "" || $lpos eq "" || $lpos=~/^\s*$/) { goto sc; }

		#
		if($pos > $lpos)
		{
			$indim = ("<img src=$IMAGES_BASE/nousija.gif border=0 alt=\"\">");
			goto past1;
		}
		#
		if($pos < $lpos)
		{
			$indim = ("<img src=$IMAGES_BASE/laskija.gif border=0 alt=\"\">");
			goto past1;
		}
sc:
		#
		if($lpos eq "" && $pos ne "")
		{
			$indim = ("<img src=$IMAGES_BASE/tulokas.gif border=0 alt=\"\">");
			goto past1;
		}

		#
past1:

		#
		$content .= ("
			<tr valign=top>
			");

		#
		$te = $s2[$i];
		$te =~ s/pub_artikkeli/story-/;
		$te =~ s/\.txt$/.html/;
		$te =~ s/^\///g;
		####$pos/$lpos
		#$content . = sprintf "<td width=50 valign=top>%d.</td>", $i2+1;
		$content .= ("<td width=400 valign=top>");
		my @comb = GetArtTitle("$arfn");
		my $art_title = $comb[1];
		my $art_image = $comb[0];
		my $arfn = "$ARTBASE/$s2[$i]";
		$arfn =~ s/([a-z]+)\/story\-([0-9]+)\.html$/$1\/pub_artikkeli$2.txt/i;
		#$arfn =~ s/^$ARTBASE\///;
		#$arfn =~ s/^\///g;
tle;
                #$nicetitle =~ s/<(?:[^>'"		$arfn =~ s/^\///g;
		my $temppistr = sprintf "%1.10d $arfn\n", $s3[$i], $arfn;
		print $f $temppistr;
		my $nicetitle = $art_title;
		#$nicetitle =~ s/<(?:[^>'"]*|(['"]).*?\1)*>//gs;
		my $niceurl = CapUrl($s2[$i],$nicetitle);
		if($art_title ne "")
		{
			$content .= ("<a href=\"$niceurl\" class=dark>");
			$content .= ("$indim $art_image $art_title");
				$arfn =~ s/([a-z]+)\/story\-([0-9]+)\.html$/$1\/pub_artikkeli$2.txt/i;
				$content .= ("
				</a>
			");
		}
		$content .= ("</td>");
		$content .=  "<td width=100 valign=top>";
		if($so{'ILMAN'} eq "ei")
		{
			$content .=  "<font size=1> (%d lukukertaa)</font><br>\n", $s3[$i];
		}

		$content .=  "</td>";

		#
		$content .= ("
			</tr>
			");

		#
		if( ($i2 % 10)==9 && $i2!=0 )
		{
			$content .=  ("<tr>
			<td>

<BR>
<P>
<div align=\"center\">
<img src=\"http://www.vunet.world/images//banners/bluefade.gif\" width=400>
</div>
</P>
<BR>

</td>
<td>
</td>
			</tr>");
		}
skip:
	}

	#
	close($f);

	#
	$content .= ("
		</table>
		");

	#
	if($so{'blank'} eq "") {
	$content .= ("
<P>
<DIV ALIGN=CENTER>
<a class=\"darkul\" href=\"$CGICMD&blank=1\">
<img border=\"0\" alt=\">>\" src=\"/images/print.gif\">
Tulostettava versio
</a>
</DIV>
</P>

<SCRIPT LANGUAGE=\"JavaScript\" src=\"http://www.vunet.world/jsadbar.pl\">
</SCRIPT>
<FONT COLOR=RED><B><P>OSTA MAINOSTILAA T�ST� - 5,000 uniikkia lukijaa p�iv�ss�</P></B></FONT>

$COMMODITIES
");
	}

	#
	return $content;
}

##################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);

	#
	$COMMODITIES = ("
<BR>
<!--DO NOT EDIT BELOW!- WIDGETS: http://www.sanebull.com/widgets -->
<div align=\"center\" width=\"210px\" style=\"font-size:12px\">
	<iframe width=\"210\" height=\"120\" src=\"http://widgets.wallstreetsurvivor.com/WidgetCommodities.aspx?type=e\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
	<br />
	<a href=\"http://www.wallstreetsurvivor.com/\" target=\"_top\">Play a stock market game</a>
	<br />
	<a href=\"http://www.wallstreetsurvivor.com/Public/Research/Quotes.aspx?symbol=GOOG\" target=\"_top\">Get a stock quote</a>
</div>
<!--DO NOT EDIT ABOVE!-->
            ");

	#
	$so{'TLI'} =~ s/[^0-9]//g;

	#
	if( !NoTracking() && ($i=IsRunning("chart.pl")>1) && $so{'MAGIC'} ne "32785782378523758" )
	{
		#
		print("
			CHART APPLICATION IS BUSY. TRY AGAIN AFTER 60-120 SECONDS.
			");
		return();
	}
	#
	$i = sprintf("%d", $i);

	#
	ProduceTopTen();

	# Resolved quick URLs... -> $s2[...]
	for($i=0,$i2=0; $i<($#s+1); $i++,$i2++)
	{
		# s2 = resolved URL
		$str2 = $s[$i];
		$str2 =~ s/^.*<(.*)>/$1/g;
		$str = ResolveQuickUrl($str2);
		$s2[$i2] = $str;

		# s3 = amount of reads
		$str2 = $s[$i];
		@sp = split(" ", $str2);
		$s3[$i2] = $sp[0];
		#print "$sp[0]<BR>\n";
	}

	#
	if($FP eq "gold") {
		$RSS_SEC = ("_top20_gold&title=KULTAKAIVOS.INFO - 20 SUOSITUINTA ARTIKKELIA");
	} else {
		$RSS_SEC = ("_top20&title=VAIHTOEHTOUUTISET.INFO - 20 SUOSITUINTA ARTIKKELIA");
	}
	#
	my $TOP20HTML = GenTopTenHTML();

	my $WORLD_STOCKS = join("", LoadList("cfg/worldstocks.txt"));
	if($ENV{'HTTP_HOST'}=~/www\.kultakaivos\.info/) {
		$TOP20TABLE = ("
<table width=750 cellpadding=16 cellspacing=0>
<tr valign=top>
<td width=550>
$TOP20HTML
</td>
<TD width=300>
<TABLE width=300 height=100% cellspacing=0 cellpadding=0
	align=right>
<TR>
<TD>
$WORLD_STOCKS

<!--- GOLD PRICES INDEX CHART --->
<div style=\"border:1px solid #dadada;width:200px;padding-left:5px;\">
<script type=\"text/javascript\" src=\"http://www.goldalert.com/rpc-client/rpc.js\"></script><br />
<script type=\"text/javascript\" src=\"http://www.goldalert.com/_layouts/swfobject.js\"></script></p>
<div id=\"goldTickerCont\"></div>
<div id=\"flashcontent\">upgrade Flash Player</div>
<p><script type=\"text/javascript\">
createTickerNoHash(\"smliveGoldPrice\");
createGoldAlertChartNoHash(\"smgoldchart.white.xml.php\",\"190\",\"180\");
</script></p>
<div style=\"text-align:right;font:11px arial;color:#333333;margin-right:5px;\">
<a style=\"color:#333333\" href=\"http://www.goldalert.com/free-interactive-gold-charts/\">Gold Price</a> by <a style=\"color:#333333;\" href=\"http://www.goldalert.com\">GoldA$
</div>
</div>

<BR>

<a href=\"http://www.regalgoldcoins.com/silver-price-chart.html\">Silver Price</a><br>
<script type=\"text/javascript\" src=\"http://goldcoinblogger.com/charts/tojs.php?filename=show-chart.php&metal=XAG\"></script>

</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>

			");
	} else {
		$TOP20TABLE = ("
<table width=750 cellpadding=16 cellspacing=0>
<tr valign=top>
<td width=550>
$TOP20HTML
</td>
<TD width=300>
<TABLE width=300 height=100% cellspacing=0 cellpadding=0
	align=right>
<TR>
<TD>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = \"160x600_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"000000\";
google_color_bg = \"FFFFFF\";
google_color_link = \"000000\";
google_color_url = \"000000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

<!--- GOLD PRICES INDEX CHART --->
<div style=\"border:1px solid #dadada;width:200px;padding-left:5px;\">
<script type=\"text/javascript\" src=\"http://www.goldalert.com/rpc-client/rpc.js\"></script><br />
<script type=\"text/javascript\" src=\"http://www.goldalert.com/_layouts/swfobject.js\"></script></p>
<div id=\"goldTickerCont\"></div>
<div id=\"flashcontent\">upgrade Flash Player</div>
<p><script type=\"text/javascript\">
createTickerNoHash(\"smliveGoldPrice\");
createGoldAlertChartNoHash(\"smgoldchart.white.xml.php\",\"190\",\"180\");
</script></p>
<div style=\"text-align:right;font:11px arial;color:#333333;margin-right:5px;\">
<a style=\"color:#333333\" href=\"http://www.goldalert.com/free-interactive-gold-charts/\">Gold Price</a> by <a style=\"color:#333333;\" href=\"http://www.goldalert.com\">GoldA$
</div>
</div>

<BR>

<a href=\"http://www.regalgoldcoins.com/silver-price-chart.html\">Silver Price</a><br>
<script type=\"text/javascript\" src=\"http://goldcoinblogger.com/charts/tojs.php?filename=show-chart.php&metal=XAG\"></script>

</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>
	");
	}

	#
	print("
$TOP20TABLE
		");

	#
}


