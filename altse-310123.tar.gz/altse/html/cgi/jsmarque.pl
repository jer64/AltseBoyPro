#!/usr/bin/perl
################################################################################
#
# Embedded gallery.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$GAL = "asian";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	$str = marque();

	#
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;	

	#
        print(" document.write(\"$str\"); \n");
}

################################################################################
#
sub marque
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$fn);

	#
	$str = ("
<IFRAME src=\"http://www.vunet.world/sisalto.pl?t=$so{'t'}&sz=$so{'sz'}&w=$so{'w'}&c=$so{'c'}\"
	width=600 height=36 style=\"border:0px\" scrolling=no name=\"scr1\" id=\"scr1\"
	onmouseover='javascript:scrolli();'>
</IFRAME>
		");

	#
	return $str;
}
