#!/usr/bin/perl
#########################################################
#
# Add user to the mailing list.
#
#########################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "postituslista";
$CGICMD = "$CGICMD";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
        WebWalkTo("CHOOSE-TITLE1");
#        ArticleTitle($arg);
        SkipTo("CHOOSE-TITLE2");
        # Add main menu.
        WebWalkTo("main-menu");
        print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
        #
        WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


########################################################################################
#
# Ask for E-mail address.
#
sub AskAddress
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,@lst,@lst2);

	#
	print ("
		<center>
		<h2>Vaihtoehtouutiset - uutispostituslista - osoitteet</h2>
		</center>

		<center>
		<img src=\"$IMAGES_BASE/butterfly6.gif\" align=\"right\" vspace=\"8\" hspace=\"8\">
		</center>
		<br>

		<form action=\"$CGICMD\" method=\"get\">
		<input type=\"hidden\" name=cmd value=\"add\">
		S�hk�postiosoite: <input name=\"address\" size=\"24\" type=\"text\"><br>
		<input type=\"submit\" value=\"Lis�� osoite\">
		</form>

		<form action=\"$CGICMD\" method=\"get\">
		<input type=\"hidden\" name=cmd value=\"rm\">
		S�hk�postiosoite: <input name=\"address\" size=\"24\" type=\"text\"><br>
		<input type=\"submit\" value=\"Poista osoite\">
		</form>

		");
}

# Add address to the mailing list.
sub ViewAddresses
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,@lst,@lst2);

	#########################################################################
	#
	@lst = LoadList("cfg/postituslista.txt");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print "<LI>$lst[$i]</LI>\n";
	}
}

# Add address to the mailing list.
sub ProcessAddress
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,@lst,@lst2);

	#########################################################################
	#
	@lst = LoadList("cfg/postituslista.txt");

	#########################################################################
	# Check whether if the address already is in there?
	#
	loop1: for($i=0,$found=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] eq $so{'address'})
		{
			$found = 1;
			last loop1;
		}
	}

	#########################################################################
	# Lis�� listalle.
	#
	if($so{'cmd'} eq "add")
	{
		#
		if($so{'address'} eq "" || $found)
		{
			print "Osoitetta ei voitu lis�t� listalle ($so{'address'}).<BR>";
			return;
		}

		#########################################################################
		# Let's add the address.
		#
		system "echo $so{'address'} >> cfg/postituslista.txt";
	
		#
		print "<i><b>Osoite lis�tty onnistuneesti!</b></i>";
	}

	#########################################################################
	# Poista listalta.
	#
	if($so{'cmd'} eq "rm")
	{
		#
		if($so{'address'} eq "" || !$found)
		{
			print "Osoitetta ei voitu poistaa listalta: osoitetta ei l�ytynyt.<BR>";
			return;
		}

		#########################################################################
		# Let's add the address.
		#
		open($f, ">cfg/postituslista.txt") || die "Can't write postituslista.txt!";
		for($i=0; $i<($#lst+1); $i++)
		{
			if( $lst[$i] ne $so{'$address'} )
			{
				print $f "$lst[$i]\n";
			}
		}
		close($f);
	
		#
		print "<i><b>Osoite poistettu onnistuneesti ($so{'address'})!</b></i>";
	}
}

#
sub main
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,@lst,@lst2);

	#
	print("
		<table width=\"640\" cellspacing=0 cellpadding=32>
		<tr>
		<td>
		");

	#
	ProcessAddress();
	AskAddress();

	#
	ViewAddresses();

	#
	print("
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		</td>
		</tr>
		");

	#
}

#



