#!/usr/bin/perl
#
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,@index,@lst);

	#
	@index = LoadList("articles/ulkomaat/fileindex.txt");

	#
	for($i=0; $i<($#index+1); $i++)
	{
		#
		@lst = LoadList($index[$i]);

		#
		
	}

	#
}
