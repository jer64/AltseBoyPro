#!/usr/bin/perl

open(f,"quotes.txt");
@lines = <f>;
close(f);
$number = int (rand ($#lines));
print ("

<table align=\"center\" width=\"50%\">
<tr>
<td>

<font size=\"3\">
<center>
$lines[$number]
</center>
</font>

</td>
</tr>
</table>

");
