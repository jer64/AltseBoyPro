#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "galleries";

#
main();

#
sub main
{
	#
	@lst = LoadList("find /home/vai/public_html/uutiset -type d -maxdepth 1|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
                $lst2[$i] = $lst[$i];
		$lst2[$i] =~ s/^.+[\/]+([^\/]+)$/$1/;
	}

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$dirthumbs = "$lst[$i]/thumbs/";
		chdir($dirthumbs);
		if(-e $dirthumbs)
		{
			chdir($dirthumbs);
			print STDERR "** $dirthumbs **\n";
			#system("rename 's/[^a-zA-Z0-9\-\.]/_/'*.jpg");
			system("th2; th4");
		}
	}

	#
}


