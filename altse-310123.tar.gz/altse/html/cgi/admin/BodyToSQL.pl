#!/usr/bin/perl
use DBI;

#
require "tools.pl";

#
main();

sub article_body_to_mysql
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4);

	#
	@index = LoadList("articles/$_[0]/fileindex.txt");

	# CREATE NEW TABLE
	$sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`body\_$_[0]`;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	# CREATE NEW TABLE
	$sth = $dbh->prepare("
CREATE TABLE `vunet`.`body\_$_[0]` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `section` text,
  `title` text,
  `body` text,
  `artid` bigint(20) unsigned default NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8 ROW_FORMAT=DYNAMIC;

");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	#
	for($i=0; $i<($#index+1); $i++)
	{
		#
		@art = LoadList("articles/$_[0]/$index[$i]");
		$title = $art[0]; $title =~ s/\<[^\>]+\>//gi;
		$title =~ s/\'/\\\'/g;
		$id = $index[$i];
		$id =~ s/[^0-9]//g;
		if( length($id)>10 ) { goto past; }
		print STDERR "$_[0]/$id: $title                         \r";

		#
		$i2 = 0;

		#
		$title = $art[0];
		$title =~ s/\<[^\>]+\>//gi;
		$title =~ s/([^a-zA-Z0-9������\ ])/\\$1/g;

		#
		$i2++;

		# Skip empty lines.
		loop: for(; $i2<($#art+1); $i2++)
		{
			$str = $index[$i2];
			$str =~ s/\<[^\>]+\>//gi;
			if( !($str=~/^\s*$/) ) { last loop; }
		}

		# Fix to escaped form.
		for($str=""; $i2<($#art+1); $i2++)
		{
			$art[$i2] =~ s/\'/\\\'/gi;
			$str = "$str$art[$i2]";
		}

		#$str =~ s/\n\r/\n/g;
		#$str =~ s/\n/\n\r/g;
		$str =~ s/([^a-zA-Z0-9������\n\r\.\,\-\ ])/\\$1/g;

		# SQL COMMAND
		$sth = $dbh->prepare("DELETE FROM body\_$_[0] WHERE id=$id;");
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();

		# SQL COMMAND
		$sth = $dbh->prepare("INSERT INTO body\_$_[0]
				(id, title, body)
				values
				('$id', '$title', '$str');");
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();
past:
	}

	#
	close($f);
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);
	my @secs = (
#"progressive",
#"bush",
"activism",
"ajatelmat",
"kolumnit",
"konfliktit",
"kotimaa",
"kulttuuri",
"kummalliset",
"luonto",
"myydaan",
"ostetaan",
"picks",
"politiikka",
"ruokailu",
"talous",
"tiede",
"tiedotteet",
"tyopaikat",
"ulkomaat",
"videos",
"xinwen",
"yhteiskunta"
);

	#
	for($i=0; $i<($#secs+1); $i++)
	{
		article_body_to_mysql($secs[$i]);
	}

	#
	#my $query = qq{ SELECT ip,web_browser,time,referer,article_file_name,article_title,cookie_info FROM visitors };

	#
}
