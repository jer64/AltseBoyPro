#!/usr/bin/perl

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex3.html");
#HandleExternal("main-menu", "./fmainmenu.pl");
WebWalkTo("main-menu");
print ("
	<a href=\"../factbook.pl\" style=\"color: rgb(255, 255, 255);\">
	> paluu takaisin
	</a>
	");
WebWalkTo("quotehere");
main();
HandleRest();

#
sub main
{
	#
	print("
            <div style=\"text-align: center;\"><big><span
 style=\"font-weight: bold;\">

Lis�� maa

<img alt=\"julkaisu\"
 title=\"julkaisu\"
 src=\"http://www.saunalahti.fi/ehc50/uutiset/literacy.gif\"
 style=\"width: 60px; height: 66px;\" align=\"right\"></span></big><br>

            </div>
            <br>
<!---MYSTUFF-->
            <form action=\"addcountry1.pl\" method=\"post\">
Nimi:<br>

              <textarea name=\"nimi\" cols=\"40\" rows=\"1\"></textarea><!----><br>
Kuvaus (ei k�yt�ss� t�ll�hetkell�):<br>
              <textarea name=\"kuvaus\" cols=\"40\" rows=\"1\"></textarea><br>
              <br>
              <input value=\"Lis�� maa\" type=\"submit\"></form>
	");

	#
}
