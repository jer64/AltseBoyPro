#!/usr/bin/perl
# titler.pl
######################################################################################
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#####################################################################################3
#
sub GetTitle
{
	my ($i,$i2,$i3,$i4,@lst,$f,$cap);

	#
	if( !(-e $_[0]) ) { return(); }

	#
	@lst = LoadList($_[0]);

	#
	$cap = $lst[0];
	$cap =~ s/<[^\>]*>//g;
	$cap =~ s/\s*$//g;
	$cap =~ s/^\s*//g;
	$cap =~ s/\n//g;
	$cap =~ s/\r//g;

	#
	$tit[$#tit+1] = $_[0];
	$tit[$#tit+1] = $cap;
}

#####################################################################################3
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$f);

	#
	if( !(-e "fileindex.txt") )
	{
		print "Can't find fileindex.txt!\n";
		return();
	}

	#
	if( -e "titles.txt" )
	{
		@tit = LoadList("titles.txt");
		for($i=0,$i2=0; $i<$#tit; $i+=2,$i2++)
		{
			$str = $tit[$i];
			$str =~ s/^\.\.\///;
			$str =~ s/[^a-z0-9]/_/g;
			$ald{$str} = 1;
		}
	}
	else
	{
		print STDERR "TITLES NOT FOUND.\n";
	}

	#
	@lst = LoadList("fileindex.txt");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$str = "$lst[$i]";
		$str =~ s/^\.\.\///;
		$str =~ s/[^a-z0-9]/_/g;
		if( $ald{$str} eq "" )
		{
			GetTitle($lst[$i]);
			print STDERR ".";
		}
		$str = "$lst[$i]";
		$fn = $str;
		$fn =~ s/^.*\/([^\/]+\.txt)$/$1/;
		$in_index{$fn}++;
	}
	print STDERR "\n";

	#
	open($f, ">titles.txt") || die "Can't write titles.txt!\n";
	for($i=0; $i<($#tit); $i+=2)
	{
		$pfn = $tit[$i+0];
		$pfn =~ s/^.*\/([^\/]+\.txt)$/$1/;
		$fn = "articles/$tit[$i+0]";
		if( $in_index{$pfn} ne "" )
		{
			print $f "$tit[$i+0]\n";
			print $f "$tit[$i+1]\n";
		}
		else
		{
			print "Not in index: $pfn\n";
		}
	}
	close($f);

	#
	system("/home/vai/public_html/cgi-bin/admin/CPtitles.pl");

	#
}

