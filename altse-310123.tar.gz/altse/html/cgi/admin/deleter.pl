#!/usr/bin/perl
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

#
sub main
{
	#
	@lst = LoadList("find articles/bush -name '*.txt'|grep -v \"\\\.txt_\"|grep -vi fileindex\\\.txt |grep -v titles\\\.txt|"); 
	for($i=0; $i<($#lst+1); $i++)
	{
		@art = LoadList($lst[$i]);
		$str = join("\n", @art);
		if($str =~ /rivrvu\@ix\.netcom\.com/ && $str =~ /harry hope/i)
		{
		}
		else
		{
			print "$lst[$i]\n";
			#unlink($lst[$i]);
		}
		#print "$str\n";
	}
	#$art[$i]=~/^From\:\srivrvu\@ix\.netcom\.com/
}
