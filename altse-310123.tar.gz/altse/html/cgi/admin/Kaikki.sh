#!/bin/bash
#
cd $DOCUMENT_ROOT/articles/
cd kaikki; $DOCUMENT_ROOT/cgi/admin/titler.pl; cd ..
cd kaikki; $DOCUMENT_ROOT/cgi/admin/sqltitler.pl; cd ..

#/home/vai/public_html/cgi-bin/admin/CPtitles.pl

