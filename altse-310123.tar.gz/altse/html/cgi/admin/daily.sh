#!/bin/bash
links -dump "http://www.vunet.world/admin/chart.pl?TLI=86400&ILMAN=ei&blank=1"|mail LST@vunet.world "Subject: Paivan suosituimmat artikkelit"
