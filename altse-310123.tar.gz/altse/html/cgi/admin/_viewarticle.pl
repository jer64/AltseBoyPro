#!/usr/bin/perl
#######################################################
# viewarticle.pl
# Newswire Publishing System 1.0
# Now supports comments (viewing / posting).
# (C) 2004 by Jari Tuominen
#######################################################

#
##print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#######################################################
#require "cgi-lib.pl";
require "inc.pl";

#######################################################
# PREFERENCES
#
$PROGRAM_NAME = "Newswire Publishing System";
$COMMENTS_ENABLED = 0;	# 0

#######################################################
# Go to main loop.
#
main();

#

##########################################################
sub ViewArticleFileHeadline
{
	local $i;

	# READ ARTICLE FILE.
	open(f, $_[0]);
	@lines = <f>;
	close(f);

	# CHOP LINES.
	for($i=0; $i<($#lines+1); $i++) { chop $lines[$i]; }

	# VIEW ARTICLE HEADLINE.
	print ("<a href=\"cgi-bin/viewarticle.pl?$_[0]\">\n");
		print "<li>$lines[0]</li>\n";
	print "</a>\n";
}

##########################################################
sub ViewComment
{
	local $i,$i2;

	#
	open(f, $_[0]);
	@txt = <f>;
	close(f);

	#
	for($i=0; $i<($#txt+1); $i++)
	{
		# Prevent printing of user ID in non-admin mode.
		if(!($txt[$i] =~ /intlfox userid\ \=\ /) || $admin)
		{
			print $txt[$i];
		}
	}
}

##########################################################
#
# View comments.
#
sub ViewComments
{
	local $i,f;

	#
	$comindex = "$_[0]_comindex.txt";
	open(f, $comindex);
	@ind = <f>;
	close(f);

	#
	print "<a name=\"comments\"></a>\n";

	#
	for($i=0; $i<($#ind+1); $i++)
	{
		#
		$ii = $i+1;
		print "<h3>kommentti $ii</h3>\n";

		#
		ViewComment($ind[$i]);

		#
		print "<br><a href=\"admin/remcom.pl?$ind[$i]\">";
		print ">> poista kommentti\n";
		print "</a><br>\n";

		# Soft seperator xxxx.
		print "<hr color=\"D0F0D0\">\n";
	}
}

##########################################################
sub ViewArticle
{
	local $i;

	#
	open(f, $_[0]);
	@lines = <f>;
	close(f);

	#
	$qq = $ENV{'QUERY_STRING'};
	if($qq =~ /commentsplease/i) { $COMMENTS_ENABLED = 1; }

	##################################################
	# CREATE TABLE.
	print "<table width=\"600\" hspace=\"8\" vspace=\"8\"";
	print " cellpadding=\"16\" cellspacing=\"2\">\n";
	#
	if($printable)
	{
		print "<tr><td bgcolor=\"#FFFFFF\">\n";
	}
	else
	{
		print "<tr><td bgcolor=\"#E0FFE0\">\n";
	}

	##################################################
	#print "<a href=\"$LOGOURL\">\n";
	#print "<img src=\"$LOGO\"></a><br>\n";

	##################################################
	# Print administration mode sign if in one.
	#
	if($admin)
	{
		print ("
			<font size=\"6\">
			<b>
			<center>Hallinto</center>
			</b>
			</font>
			<hr>
			");
	}

	##################################################
	# Print headline
	print "<p><h2>$lines[0]</h2></p>\n";

	# Print image, if any.
	if( open(f4, "$_[0]\_imageurl.txt") )
	{
		# Got image url!
		$imageurl = <f4>;
		close(f4);

		#
		print ("<img src=\"$imageurl\" width=\"140\" height=\"140\" align=\"left\"
			border=\"1\" hspace=\"8\" vspace=\"8\">\n");
	}

	##################################################
	#
	for($i=1,$first=1; $i<($#lines+1); $i++)
	{
		if($first)
		{
			$str=$lines[$i];
			if( length($str)<7 && $str=~/<br>/i )
			{
				# skip
			}
			else
			{
				print "$lines[$i]\n";
				$first = 0;
			}
		}
		else
		{
			# HTTP URL
			if($lines[$i] =~ /http\:\/\//)
			{
				$lines[$i] =~ s/\<br\>//i;
				# .JPG, .JPEG, or .GIF ?
				if($lines[$i] =~ /\.gif/
					||
				   $lines[$i] =~ /\.jpg/
					||
				   $lines[$i] =~ /\.jpeg/
					)
				{
					print "<img src=\"$lines[$i]\"><br>\n";
				}
				else
				{
					print "<a href=\"$lines[$i]\" target=\"_blank\">$lines[$i]</a><br>\n";
				}
			}
			else
			{
				print "$lines[$i]\n";
			}
		}
	}

	# Soft seperator.
	print "<br><br><hr color=\"D0F0D0\"><br>\n";

	#
	if($printable)
	{
		print "<center>\n";
		print "<img src=\"../uutiset/mainos.jpg\"><br>\n";
		print "</center>\n";
	}

	#
	if($printable)
	{
		print "<center>\n";
		print "Julkaistu Vaihtoehtouutisissa.<br>\n";
		print "<a href=\"http://vaihtoehtouutiset.tux.nu\">http://vaihtoehtouutiset.tux.nu</a>\n<br>";
		print "</center>\n";
	}

	# Make possible to add comments.
	if(!$printable && $POST_COMMENTS_ENABLED && $COMMENTS_ENABLED)
	{
		# Add a possibility to comment the article.
		print ("
<script language=\"javascript\">
if(document.cookie != \"\")
{
        document.writeln(\" \\
			<form method=\\\"post\\\"   \\
		action=\\\"moderated/comment.pl?comart7895789235&target=$_[0]&ui=\"+ document.cookie +\"\\\">  \\
			Kommentti:<br>  \\
			<textarea rows=5 cols=60 name=\\\"comment\\\"></textarea> \\
			<br> \\
			<input type=\\\"submit\\\" value=\\\"Lis�� kommentti\\\"> \\
			</form> \\
			\\n \");
}
</script>
		");

	#	# Add a possibility to comment the article.
	#	print ("
	#		<form method=\"post\"
	#	action=\"moderated/comment.pl?comart7895789235&target=$_[0]\">
	#		Kommentti:<br>
	#		<textarea rows=5 cols=60 name=\"comment\"></textarea>
	#		<br>
	#		<input type=\"submit\" value=\"Lis�� kommentti\">
	#		</form>
	#		");
	}

	# Make possible to add comments.
	if(!$printable && $VIEW_COMMENTS_ENABLED && $COMMENTS_ENABLED)
	{
		# Soft seperator 3.
		print "<hr color=\"D0F0D0\">\n";

		# **** VIEW COMMENTS ****
		if($COMMENTS_ENABLED)
		{
			ViewComments($_[0]);
		}
	}

	# Soft seperator 2.
	if(!$printable && !$POST_COMMENTS_ENABLED)
	{
		print "<hr color=\"D0F0D0\"><br>\n";
	}

	# Add link to the printable version.
	if(!$printable)
	{
		#
		print "<a href=\"viewarticle.pl?$arg&printable\">";
		print "<img src=\"../uutiset/print.gif\" border=\"0\" alt=\">>\">";
		print " tulosta uutinen";
		print "</a><br>";

		#
		if($COMMENTS_ENABLED)
		{
			print "<a href=\"viewarticle.pl?$arg&nicht\">";
			print "<img src=\"../uutiset/comments.gif\" alt=\">>\" border=\"0\">\n";
			print " piilota kommentit</a><br>";
		}
		else
		{
			print "<a href=\"viewarticle.pl?$arg&commentsplease\">";
			print "<img src=\"../uutiset/comments.gif\" alt=\">>\" border=\"0\">\n";
			print " n�yt� kommentit / lis�� kommentti</a><br>";
		}

		# Administration only features.
		#
		print("
			<a href=\"admin/addimage.pl?$arg\">
			<img src=\"../uutiset/fix.gif\" alt=\">>\" border=\"0\">
			 lis�� artikkeliin kuva</a><br>
			");

		#
		print("
			<a href=\"admin/editart.pl?$arg\">
			<img src=\"../uutiset/fix.gif\" alt=\">>\" border=\"0\">
			 muokkaa artikkelia</a><br>
			");

		#
		print("
			<a href=\"admin/viewarticle.pl?$arg\">
			<img src=\"../uutiset/fix.gif\" alt=\">>\" border=\"0\">
			 hallinnon n�kym�</a><br>
			");

		#
		print "<a href=\"admin/fixart.pl?$arg\">";
		print "<img src=\"../uutiset/fix.gif\" alt=\">>\" border=\"0\">";
		print " korjaa rivitys</a>";
	}

	##################################################

	#
	print "</td></tr>\n";

	#
	print "</table>\n";

}

##########################################################
sub main
{
	#############################################################
	# Determine if we are a protected admin. script?
	#
	if( open(f, "admin.txt") )
	{
		$admin = 1;
		$COMMENTS_ENABLED = 1;
		close(f);
	}

	#############################################################
	#
	$__arg = $ENV{'QUERY_STRING'};

	#
	@_arg = split("\&", $__arg);
	$arg = $_arg[0];

	#
	if( $__arg =~ /printable/i )
	{
		# Enable printable mode.
		$printable = 1;
	}

	#
	if( $arg =~ /pub_artikkeli/ )
	{
	}
	else
	{
		print "<h2>$PROGRAM_NAME error: Invalid request (2).<br>\n";
		die;
	}

	#
#	if( $arg =~ /\// || $arg =~/\\/ || $arg =~ /\.\./ )
#	{
#		print "<h2>$PROGRAM_NAME error: Invalid request.<br>\n";
#		die;
#	}

	#
	$arg = "./$arg";

	###############################################################################
	#
        open(f, "webindex2.html");
        @web = <f>;
        close(f);

        # CHOP LINES.
        for($i=0; $i<($#web+1); $i++) { chomp $web[$i]; }

	#########################################################################
        # Print until "$_[0]" is found.
	#
	if(!$printable)
	{
		loop1: for($i=0,$found=0; $i<($#web+1) && !$found; $i++)
        	{
			if($web[$i] =~ /enterhere_section/i)
			{
				$found=1;
			}
			print $web[$i];
		}
	        $wherebe=$i;
	}

	###############################################################################
	# View the article.
	#
#	print "'$arg'";
	ViewArticle( $arg );

	###############################################################################
        # Print until end of the web text.
	#
	if(!$printable)
	{
	        for($ix=$wherebe; $ix<($#web+1); $ix++)
		{
                	print $web[$ix];
		}
	}

	#
}



