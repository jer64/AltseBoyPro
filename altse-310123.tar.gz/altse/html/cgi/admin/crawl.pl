#!/usr/bin/perl
########################################################################
#
# Crawler Administration
#
########################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


##################################################
sub Fetch
{
	my ($i,$i2,$str,$str2,@lst,@lst1,@lst2,@tmp);

	#
	print("
		<font size=1>
		");
@lst1 = LoadList("cd \"$NWPUB_CGIBASE/sdb\"; ./fetch.pl \"$so{'t'}\"|");
@lst = LoadList("cd \"$NWPUB_CGIBASE/sdb\"; ./go.pl|");
	print("
		</font>
		");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$lst[$i] =~ s/\n/<br>/g;
		$lst[$i] =~ s/(\S{20})/$1 /g;
#		print "<font face=terminal size=1 color=\"#00FF00\">$lst[$i]</font><br>\n";
	}

	#
}

###########################################################################3
#
sub Formi
{
	my ($i,$i2,$str,$str2);

	#
	print("
		<center>
		<font size=5><b>Vunet Internet Search Engine Web Crawler</b></font><br>
		<img src=\"http://fp.ymv13.plus.com/Spider%20&%20Web.jpg\">
		<br>
		<form action=\"crawl.pl\" class=formx>
		Crawl URL: <input type=\"text\" name=\"t\" value=\"$so{'t'}\">
		<input type=\"submit\">
		</form><br>
		</center>
		");

	#
	if(IsBusy() && $so{'t'} eq "")
	{
		print("
		<center>Crawler is currently busy. It'll probably be available after a minute or two.</center>
		<br>
		");
	}
}

###########################################################################3
#
sub CrawlerBusy
{
	die "Crawler is busy, try again alter.<br>";
}

###########################################################################3
#
sub Lock
{
	#
	if($_[0]<2 && -e "$NWPUB_CGIBASE/sdb/lock.txt")
	{
		CrawlerBusy();
	}

	#
	if($_[0]==0) { system "rm -f \"$NWPUB_CGIBASE/sdb/lock.txt\""; }
	if($_[0]>0) { system "echo \"Enabled.\" >> \"$NWPUB_CGIBASE/sdb/lock.txt\""; }
}

###########################################################################3
#
sub IsBusy
{
	my ($i,$i2,$str,$str2,@lst);

	#
	@lst = LoadList("ps aux|grep fetch.pl|grep -v grep|grep -v defunct|");

	#
	if($lst[0] ne "") { print "$lst[0]<br>"; return 1; } else { return 0; }
}

###########################################################################3
#
sub SingleInstanceOnly
{
	my ($i,$i2,$str,$str2,@lst);

	#
	if(IsBusy())
	{
		CrawlerBusy();
	}
}

###########################################################################3
#
sub main
{
	#######################################################
	# Search arguments line for options.
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	$so{'t'} =~ s/\"/'/g;

	#
	print("
		<table cellpadding=32 cellspacing=0 width=100%>
		<tr>
		<td>
		");

	#
	Formi();

	#
	if($so{'t'} ne "")
	{
		#
		die "service offline"; 
		SingleInstanceOnly();
		Fetch($so{'t'});
	}

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
}


