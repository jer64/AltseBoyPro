#!/usr/bin/perl
system("/home/vai/public_html/cgi-bin/wapirc.exe");
