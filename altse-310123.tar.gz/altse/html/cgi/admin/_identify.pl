#!/usr/bin/perl
#############################################################################
# identify.pl - user identification.
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#
main();

#
sub JSTools
{
	#
print("
<SCRIPT LANGUAGE=\"JavaScript\">
<!--

// name - name of the cookie
// value - value of the cookie
// [expires] - expiration date of the cookie (defaults to end of current session)
// [path] - path for which the cookie is valid (defaults to path of calling document)
// [domain] - domain for which the cookie is valid (defaults to domain of calling document)
// [secure] - Boolean value indicating if the cookie transmission requires a secure transmission
// * an argument defaults when it is assigned null as a placeholder
// * a null placeholder is not required for trailing omitted arguments
function setCookie(name, value, expires, path, domain, secure) {
  var curCookie = name + \"=\" + escape(value) +
      ((expires) ? \"; expires=\" + expires.toGMTString() : \"\") +
      ((path) ? \"; path=\" + path : \"\") +
      ((domain) ? \"; domain=\" + domain : \"\") +
      ((secure) ? \"; secure\" : \"\");
  document.cookie = curCookie;
}

// name - name of the desired cookie
// * return string containing value of specified cookie or null if cookie does not exist
function getCookie(name) {
  var dc = document.cookie;
  var prefix = name + \"=\";
  var begin = dc.indexOf(\"; \" + prefix);
  if (begin == -1) {
    begin = dc.indexOf(prefix);
    if (begin != 0) return null;
  } else
    begin += 2;
  var end = document.cookie.indexOf(\";\", begin);
  if (end == -1)
    end = dc.length;
  return unescape(dc.substring(begin + prefix.length, end));
}

// name - name of the cookie
// [path] - path of the cookie (must be same as path used to create cookie)
// [domain] - domain of the cookie (must be same as domain used to create cookie)
// * path and domain default if assigned null or omitted if no explicit argument proceeds
function deleteCookie(name, path, domain) {
  if (getCookie(name)) {
    document.cookie = name + \"=\" + 
    ((path) ? \"; path=\" + path : \"\") +
    ((domain) ? \"; domain=\" + domain : \"\") +
    \"; expires=Thu, 01-Jan-70 00:00:01 GMT\";
  }
}

// date - any instance of the Date object
// * hand all instances of the Date object to this function for \"repairs\"
function fixDate(date) {
  var base = new Date(0);
  var skew = base.getTime();
  if (skew > 0)
    date.setTime(date.getTime() - skew);
}

// -->
</SCRIPT>
	");

	#
}

#
sub IdentifyAction
{
	#
	print("
		<br>
		<center>K�ytt�j�n asetukset, tunnistautuminen, jne.</center>
		<br>
		");

	#
	print("
		<script language=\"javascript\">

		if( !(userid=getCookie(\"userid\")) )
		{
			document.write(\"<blink>T�m� sivu vaatii cookiet toimiakseen kunnolla.</blink><br>\");
		}
		
		if( !(name=getCookie(\"name\")) )
		{
			document.write(\"Selaimesi kertoo, ettet ole viel� t�ytt�nyt uusi k�vij� -kaavaketta! Toivomme, ett� k�ytt�isit hetken kaavakkeen t�ytt�miseen, jotta voisimme palvella teit� entist� paremmin.\");

			document.write(\" <form method=\\\"get\\\" action=\\\"identify.pl\\\"> \");
document.write(\" <input type=\\\"hidden\\\" name=\\\"userid\\\" value=\\\"\"+ userid +\"\\\"  > \");
			document.write(\" Etunimi: <input type=\\\"text\\\" name=\\\"firstname\\\"> <br>\");
			document.write(\" Sukunimi: <input type=\\\"text\\\" name=\\\"lastname\\\"> <br>\");
			document.write(\" <br>\");
			document.write(\" S�hk�postiosoite: <input type=\\\"text\\\" name=\\\"email\\\"> <br>\");
			document.write(\" <br>\");
			document.write(\" Ammatti: <input type=\\\"text\\\" name=\\\"profession\\\"> <br>\");
			document.write(\"  \");
			document.write(\"  \");
			document.write(\"  \");
			document.write(\" <input type=\\\"submit\\\" value=\\\"Valmis\\\"> \");
			document.write(\" </form> \");
			document.write(\"  \");
			document.write(\"  <i>\");
			document.write(\"  K�ytt�j�tietoja ei luovuteta toimituskunnan ulkopuolelle ilman\");
			document.write(\"  k�ytt�j�n lupaa. Kaavakkeen t�ytt�minen ei sido k�ytt�j�� mihink��n.\");
			document.write(\"  </i>\");
		}
		else
		{
			document.write(\"Terve \" + name);
		}
		
		</script>
		");

}

#
sub Identify
{
	#
	if( !($cmd =~ /userid/) )
	{
		#
		print("
			<script language=\"javascript\">
document.write(\"<meta http-equiv=\\\"refresh\\\" content=\\\"0; url=identify.pl?userid=\"+getCookie(\"userid\")+\"\\\">\");
			</script>
			");
	}
	else
	{
		if( gotUserFile($userid) )
		{
			print "Tervehdys $firstname. Olet jo tunnistautunut! Kiitos tunnistautumisestasi.\n";
		}
		else
		{
			IdentifyAction();
		}
	}

	#
	print("
		<NOSCRIPT>
		T�m� ominaisuus vaatii Javascript -tuen.
		</NOSCRIPT>
		");
}

#####################################################################################
#
sub VerifyParams
{
	#
	if($firstname eq "")
	{
		die "<b>You must fill first name.</b>";
	}
}

#####################################################################################
#
sub SaveUserData
{
	#
	open(f, ">user_$userid.txt") || die "File creation failed.";
	print f "$userid\n";
	print f "$firstname\n";
	print f "$lastname\n";
	print f "$email\n";
	print f "$profession\n";
	close(f);
}

#####################################################################################
#
sub main
{
	#
	$cmd = $ENV{'QUERY_STRING'};
        $cmd =~ s/\+/ /ig;
        $cmd =~ s/%(..)/pack("C", hex($1))/eg;
	@vars = split("\&", $cmd);
	for($i=0; $i<($#vars+1); $i++)
	{
		@tmp = split("\=", $vars[$i]);
		if($tmp[0] eq "userid")
		{
			$userid = $tmp[1];
			$userid =~ s/\?//;
			$userid =~ s/\.//;
			$userid =~ s/\///;
			$userid =~ s/\\//;
		}
		if($tmp[0] eq "email")
		{
			$email = $tmp[1];
		}
		if($tmp[0] eq "profession")
		{
			$profession = $tmp[1];
		}
		if($tmp[0] eq "firstname")
		{
			$firstname = $tmp[1];
		}
		if($tmp[0] eq "lastname")
		{
			$lastname = $tmp[1];
		}
	}

        #
        OpenWebIndex("./webindex2.html");
        HandleExternal("main-menu", "./mainmenu.pl");

	#
	JSTools();

        #
        WebWalkTo("ENTERHERE_SECTION");

	#
	if($cmd =~ /name\=/)
	{
		#
		VerifyParams();

		#
		print "Kiitos, $firstname, ett� t�ytit kaavakkeen, autat meit� tekem��n t�st� palvelusta paremman!\n";

		#
		print("
			<script name=\"javascript\">
			//setCookie(\"name\", \"$firstname $lastname\", \"1.1.2100\");
			//setCookie(\"email\", \"$email\", \"1.1.2100\");
			//setCookie(\"prof\", \"$profession\", \"1.1.2100\");
			// setCookie(\"name\", \"\", \"1.1.2100\", \"/ehc50/cgi-bin\", \"www.saunalahti.fi\", \"0\");
			</script>
			");

		#
		SaveUserData();
	}
	else
	{
		#
		Identify();
	}

        #
        HandleRest();
}

