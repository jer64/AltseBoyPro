#!/usr/bin/perl
#########################################################
#
# post_usenet_article.pl
#
#########################################################
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

# Confirm sending of the message.
sub Confirmation
{
	my ($i,$i2,$i3,$i4,$found,@lst);

	# Get article headline.
	@lst = LoadList($so{'file'});
	$viesti = $lst[0];
	$viesti =~ s/<[^\>]*>//g;

	#
	print ("
		<table width=\"500\" class=admin_window>
		<tr>
		<td>

		<center>
		<h2>Vaihtoehtouutiset - postitus</h2>
		</center>

		Haluatko todella postittaa viestin <font size=1><i>\"$viesti\"</i></font> listalle?

		<form action=\"post_usenet_article.pl\" method=\"get\">
		<input type=\"hidden\" value=\"mailmsg559\" 
						name=\"verify\">
		<input type=\"hidden\" value=\"$so{'file'}\" 
						name=\"file\">
		Otsikko: <input name=\"subject\" size=\"85\" type=\"text\"
			value=\"$viesti\"><br>
		<input type=\"submit\" value=\"L�het� edell� mainittu viesti listalle\">
		<a href=\"$url\">Peruuta</a>
		</form>

		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>

		</td>
		</tr>
		");
}

sub Jonoon
{
	my ($i,$i2,$i3,$i4,$fn,$fn2,$str,$str2,$t,@lst);

	#
	$t = time;

	# Get article headline.
	@lst = LoadList($so{'file'});
	$viesti = $lst[0];
	$viesti =~ s/<[^\>]*>//g;

	#
	$fn = "outgoing/post$t.txt";
	open($f, ">$fn");
	print $f "Subject: [Vunet.org] $so{'subject'}\n";
	print $f "From: Vunet.org News <lst\@vunet.world>\n";
	print $f "Newsgroups: test.group\n";
	print $f "Content-Type: text/html\n\n";
	for($i=0; $i<($#lst+1); $i++)
	{
		print $f "$lst[$i]\n";
	}
	close($f);
}

# Add address to the mailing list.
sub ProcessAddress
{
	my ($i,$i2,$i3,$i4,$found,@lst);

	#########################################################################
	# Lis�� listalle.
	#
	if($so{'action'} eq "mailmsg")
	{
		#
		if($so{'file'} eq "" || $so{'subject'} eq "")
		{
			die "Artikkelia tai otsikkoa ei m��ritelty (<b>$so{'file'}</b> / <b>$so{'subject'}</b>).";
		}

		#########################################################################
		#
		Jonoon();

		#
		print("<i><b>Artikkeli lis�tty jonoon listalle l�hetett�v�ksi.</b></i>
<meta http-equiv=\"refresh\" content=\"1; url=$url\">
");
	}
	else
	{
		die "unknown action\n";
	}

	#
}

#
sub main
{
	my ($i,$i2,$i3,$i4,$found,@lst);

	#
	if($so{'file'} eq "") { die "article not defined\n"; }

	#
	$url = $so{'file'};
	$url =~ s/^([a-z]*)\/pub_artikkeli([0-9]*)\.txt$/http:\/\/www.vunet.world\/$1\/story-$2.html/;

	#
	OpenWebIndex("./webindex2.html");
	WebWalkTo("main-menu");
	print ("
		<a href=\"$url\"
			class=dark>
		Paluu loppuk�ytt�j�n n�kym��n ...
		</a>
		");

	#
	WebWalkTo("enterhere_section");
	if($so{'verify'} eq "mailmsg559")
	{
		$so{'action'} = "mailmsg";
		ProcessAddress();
	}
	else	
	{
		Confirmation();
	}
	
	#
	HandleRest();
}

#



