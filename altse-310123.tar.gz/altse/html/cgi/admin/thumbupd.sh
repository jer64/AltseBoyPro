
#!/bin/bash
echo "Updating thumb folder #1 ..."
cd /home/vai/public_html/images/thumb; /home/vai/cgi/admin/th 2>&1 > /dev/null
echo "Updating thumb folder #2 ..."
cd /home/vai/public_html/images/thumb2; /home/vai/cgi/admin/th2 2>&1 > /dev/null
echo "Updating thumb folder #3 ..."
cd /home/vai/public_html/images/thumb3; /home/vai/cgi/admin/th3 2>&1 > /dev/null
echo "Updating thumb folder #4 ..."
cd /home/vai/public_html/images/thumb4; /home/vai/cgi/admin/th4 2>&1 > /dev/null
echo "Done."
echo "Updating SQL-cache of file names ..."
/home/vai/cgi/admin/IMGdircache.pl
echo "Done."
