#!/usr/bin/perl
#############################################################################
# PUBLISHING.
# (C) 2004 by Jari Tuominen.
# Updated 6:17 24.2.2004.
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
#
sub read_input
{
	# Read in text
	$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
	if ($ENV{'REQUEST_METHOD'} eq "POST")
	{
		###read(STDIN, $_buffer, $ENV{'CONTENT_LENGTH'});
		@__buffer = split(/\&/, $all);
		$buffer = $__buffer[0];
	}
	else
	{
		print "Error: Post method required.<br>\n";
		die;
		#$buffer = $ENV{'QUERY_STRING'};
	}

	#
	$buffer =~ s/review=//;
	$buffer =~ s/\%0D/<br>\n/ig;
	$buffer =~ s/\%0A//ig;
	$buffer =~ s/\+/ /ig;
	$buffer =~ s/%(..)/pack("C", hex($1))/eg;

	# Check for subject.
	@temp = split("\n", $buffer);
	$str1 = $temp[0];
	$str1 =~ s/\n//g;
	$str1 =~ s/<br>//g;
	if($str1 eq "")
	{
		print ("<h2>ERROR: First line must always contain 
		the subject of the article('$str1').<br>\n"); 
		die;
	}

	#
#	print $buffer;
}

##########################################################
sub save_article
{
	local $i;

	# Get a proper file name for the new article.
	get_name();

	#
#	print "name = $name .... name2 = $name2<br>\n";
#	die;

	# Write the article on drive.
	open(f, ">$name");
	print f $buffer;
	close(f);

	#
	if($MUSEUM_ARTICLE)
	{
		# Add the file name to the list of articles.
		system "echo $name2 > $osasto/_tmpfileindex.txt";
		system "cat $osasto/fileindex.txt >> $osasto/_tmpfileindex.txt";
		system "cat $osasto/_tmpfileindex.txt > $osasto/fileindex.txt";
	}
	else
	{
		# Add the file name to the list of articles.
		system "echo $name2 >> $osasto/fileindex.txt";
	}

	# Log IP.
	system "echo $ip >> iplog.txt";
	# Log host.
	system "echo $host >> hostlog.txt";
}

##########################################################
sub HandleComment
{
	local $i,$i2,$i3,$i4;

	#
	@list = split("&", $argarg);
	for($i=0; $i<($#list+1); $i++)
	{
		if($list[$i] =~ /target=/i)
		{
			$comart = $list[$i];
			$comart =~ s/target=//i;
		#	print "$comart<br>\n";
		}
	}

	#
#	print "argarg = $argarg<br>\n";
#	print "content = \"$buffer\"<br>\n";

	# Get a proper file name for the new article.
	get_comname($comart);

	# Specify index file name.
	$indexfname = "$comart\_comindex.txt";

	#
#	print "name = $name<br>\n";
#	print "index file name = $indexfname<br>\n";

	################################################################

	# Write the article on drive.
	open(f, ">./$name");
	$buffer =~ s/comment=//;
	print f $buffer;
	close(f);

	# Add the file name to the list of articles.
	system "echo $name2 >> ./$indexfname";

	# Log IP.
	system "echo $ip >> ./iplog.txt";

	# Log host.
	system "echo $host >> ./hostlog.txt";

	#
	print "<meta http-equiv=\"refresh\" content=\"0; url=../viewarticle.pl?$comart&commentsplease\">\n";
}

##########################################################
sub main
{
	#
	print "<html>\n";

	#
	$argarg = $ENV{'QUERY_STRING'};
	read(STDIN, $all, $ENV{'CONTENT_LENGTH'});
	#print $all;
	#
	@__buffer = split(/\&/, $all);
	$temppi = $__buffer[1];
	@temppi2 = split(/\=/, $temppi);
	$osasto = $temppi2[1];

	# Detect correct password always.
	if($all =~ /$ADMINPASSWORD/)
	{
		# Enable administration mode.
		$admin = 1;
	}

	# Password check.
	if($REQUIREPASSWORD!=0 && !$admin)
	{
		print "Error: Invalid password.<br>\n";
		die;
	}

	##################################################################
	if($argarg =~ /archivei43538453/i)
	{
		# Add article to the end of the list.
		$MUSEUM_ARTICLE = 1;
	}

	##################################################################
	if($argarg =~ /comart7895789235/i)
	{
		#
		print "Illegal function.<br>\n";
		die;
	}
	

	#
#	print "Osasto: $osasto.<br>\n<br>\n";

	#
	if($osasto eq "" || $osasto =~ /\?/g || $osasto =~ /\.\./g ||
		$osasto =~ /\// )
	{
		print "Error: No publishing section specified or invalid section specified ($osasto).<br>\n";
		die;
	}

	#
	read_input();

	#
	save_article();

	#
	print "<meta http-equiv=\"refresh\" content=\"8; url=../../uutiset\">\n";

	#
	print "<hr><br>\n";

	#
	print "<h2>Artikkeli on otettu vastaan. Kiitos panoksestanne!<br>\n";
	print "<a href=\"http://www.saunalahti.fi/ehc50/uutiset\">\n";
	print "Siirtyminen takaisin uutisiin 8 sekunnin kuluttua ...<br>\n";
	print "</a>\n";

	#
	print "</html>\n";
}


