#!/usr/bin/perl
#############################################################################
# addquote.pl
# Adds quote to an article.
#############################################################################

#
$NDB_ROOT = "..";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$NDB_ROOT/admin.pl";

#######################################################
# Go to main loop.
#
StartAdmin();
main();

#
sub AskAdminpw
{
	#
#	print "$target[0]<br>\n";
#	print "$fname<br>\n";

	# Invalid password?
	if(!$admin && $cmd=~/passwd=/)
	{
		print "<font color=\"#FF0000\">Invalid password.</font><br><br>";
	}

	######################################
	# Print passwd form.
	print("
		<title>AUTHENTICATION REQUIRED</title>

		<form action=\"remcom.pl\" method=\"get\">	

		<input type=\"hidden\" value=\"$argarg[0]\" name=\"kana\">
	
		<b>Authentication required.</b><br><br>
	
		Administration password :  
		<input type=\"password\" name=\"passwd\"
			value=\"\">
	
		<input type=\"submit\" value=\"OK\">
	
		</form>
		");
}

#######################################################
sub AddQuoteForm
{
	my $f,$i,$i2,$i3,$i4;

	#
	if( open($f, "$fname\.quote") )
	{
		close($f);
		@ql = LoadList("$fname\.quote");
	}

	#
	print("
		<center>
		<b>
		<font size=\"6\">
		Lis��/poista siteeraus
		</font>
		</b>
		</center>
		<br>

		<form method=\"get\" action=\"addquote.pl\">
		<input type=\"hidden\" value=\"$fname\" name=\"target\">
		<input type=\"hidden\" value=\"cmdaddquote346436\" name=\"cmd\">
		SITEERAUS<br>
		<textarea name=\"quotecontent\" cols=\"82\" rows=\"2\">$ql[0]</textarea><br>
		SITEERAAJA<br>
		<textarea name=\"quoter\" cols=\"82\" rows=\"2\">$ql[1]</textarea><br>
		<input type=\"submit\" name=\"addq2462468\" value=\"tallenna siteeraus\">
		<input type=\"submit\" name=\"remq4573458\" value=\"poista siteeraus\">
		</form>
		");
}

#######################################################
#
# The actual quote adding process.
#
sub AddQuote1
{
	#
	if($REMOVE_QUOTE)
	{
		system "rm -f $fname\.quote";
	}
	else
	{
		open(f, ">$fname\.quote") || die "can't add quote ($fname\.quote)";
		print f "$quotecontent\n";
		print f "$quoter\n";
		close(f);
	}
}

#######################################################
#
# Quote add web form application.
#
sub AddQuote
{
	#
	

	# Print form if no command detected.
	if(!($cmd =~ /addquote346436/i))
	{
		#
		AddQuoteForm();
	}
	else
	{
		# Do some checks.
		if( $quotecontent eq "zzzzz" )
		{
			print ("
				<blink>Invalid quote !</blink>
				");
			AddQuoteForm();
			return true;
		}

		################################################################################
		#
		AddQuote1();

		print("
		<meta http-equiv=\"refresh\" content=\"0; 
			url=/viewarticle.pl?article=$fname\">
		");
		
	}
}

################################################################################################################
#
sub main
{
	# Get raw query string.
	$cmd = $ENV{'QUERY_STRING'};
        # Fix string.
	$buffer = $cmd;
        $buffer =~ s/\%0D/<br>\n/ig;
        $buffer =~ s/\%0A//ig;
        $buffer =~ s/\+/ /ig;
        $buffer =~ s/%(..)/pack("C", hex($1))/eg;
	$buffer =~ s/target\=//ig;
	@az = split("\&", $buffer);
	#
	$fname = "$az[0]";
	if( !($fname=~/article\//) )
	{
#		$fname = "articles/$fname";
	}
	$cmdname = $az[1];
	$quotecontent = $az[2];
	$quotecontent =~ s/quotecontent=//i;
	$quotecontent =~ s/<br>//g;
	$quotecontent =~ s/\n//g;
	$quotecontent =~ s/\r//g;
	$quoter = $az[3];
	$quoter =~ s/quoter=//i;

	#
	if($buffer =~ /remq4573458/)
	{
		$REMOVE_QUOTE = 1;
	}

	#
	if($fname =~ /\.\./)
	{
		die "Illegal request.";
	}

	#
	if($cmd eq "")
	{
		print "<h2>Error: Parameter required.</h2>\n";
		return false;
	}

	#
	AddQuote();
}


