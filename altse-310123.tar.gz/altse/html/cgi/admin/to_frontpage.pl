#!/usr/bin/perl
#############################################################################
# to_frontpage.pl
#############################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
main();

#
sub Bounce
{
	print ("<meta http-equiv=\"refresh\" content=\"0; url=http://www.vunet.world/viewarticle.pl?article=$so{'pick'}\">\n
		<script language=\"JavaScript\">
		location.href = '../viewarticle.pl?article=$so{'pick'}';
		</script>
		");
}

#
sub main
{
	#
	$DONT_AFFECT_DB = 1;
        # Load configuration & parse args.
        ArgLineParse();

	#
	if($so{'type'} eq "1")
	{
		$fn = "$ENV{'DOCUMENT_ROOT'}/articles/cfg/pick.txt";
	}
	if($so{'type'} eq "2")
	{
		$fn = "$ENV{'DOCUMENT_ROOT'}/articles/cfg/pick2.txt";
	}

	#
	open($f, ">>$fn") || die "unexpected error!";
	print $f "$so{'pick'}\n";
	close($f);

	#
	Bounce();
}

#




