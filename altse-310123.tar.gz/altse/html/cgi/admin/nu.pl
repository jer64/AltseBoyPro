#!/usr/bin/perl
#
$NWPUB_CGIBASE =        "/home/vai/public_html/cgi-bin";
#
main();

#
chdir("/home/vai/public_html/cgi-bin/admin");

#
sub main
{
	my ($i,$i2,$i3,$i4);
	my @secs = (
		"bush",
		"progressive",
		"asunnot",
		"tyopaikat",
		"huumori",
		"ostetaan",
		"myydaan",
		"komponentit",
		"kannettavat",
		"elokuvat",
		"veneily",
		"valokuvaus",
		"ruokailu"
		);

	#
	system("wget http://www.etc.se/rss/ -O rss/etc_se.rss");
	system("wget http://www.indymedia.nl/rss/newswire.1-0.rdf -O /home/vai/public_html/cgi-bin/admin/rss/indymedia_nl.rss");
	system("wget http://www.internationalen.se/e107_files/backend/news.xml -O /home/vai/public_html/cgi-bin/admin/rss/internationalen_se.rss");

	#
	for($i=0; $i<($#secs+1); $i++)
	{
		$c1 = "cd $NWPUB_CGIBASE/$secs[$i]; /home/vai/public_html/cgi-bin/admin/gather.pl; cd ..";
		system($c1);
	}
}

