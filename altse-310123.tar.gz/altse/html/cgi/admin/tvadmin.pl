#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
use Time::localtime;
use File::stat;

#
main();

##############################################################
#
# Main
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2);

	#
	chdir("/home/vai/public_html/cgi-bin/admin");
	@lst = LoadList("find channels/ -name '*.cfg' -type f|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		print("
<A HREF=\"/admin/editart.pl?FILE=$lst[$i]&CAPTION=Edit $lst[$i]&RETURL=/admin/tvadmin.pl\">
> edit $lst[$i]
</A><BR>
			");
	}

	#
	
}
