#!/usr/bin/perl
#############################################################################
# cgi-text.pl - administration
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2011 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/SearchSubModule.pm";
require "modules/DirectorySubModule.pm";
require "modules/settings.pm";


#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command
select(STDOUT);
$| = 1;
# Flush STDERR buffer after each command
#select(STDERR);
#$| = 1;

#
$ENV{'CURSEC'} = "admin";

#
main();

####################################################################################
#
sub main
{
	my ($i,$i2,$str,$lng,$host,$fo,$la);

	#
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	### HARDCODED USER INTERFACE
        #
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"http://images.vunet.world/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$CSS_URL\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>
$PAGE_TITLE
</title>
</head>

<BODY $xtra bgcolor=$TVAR
	topmargin=0 leftmargin=0
	marginheight=0 marginwidth=0>


<TABLE width=100% height=1 cellpadding=0 cellspacing=0
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<table width=100% cellpadding=0 cellspacing=0>
<tr>
<td>

			");

	#
	AdministrationInterface();

	#
	print("
</td>
</tr>
</table>

</body>
		");
}

