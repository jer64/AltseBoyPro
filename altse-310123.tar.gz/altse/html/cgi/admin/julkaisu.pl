#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "julkaise";

#
ArgLineParse();

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
print("
<meta http-equiv=\"REFRESH\"
content=\"0;url=admin/center.pl?redirect=true\">
	");
