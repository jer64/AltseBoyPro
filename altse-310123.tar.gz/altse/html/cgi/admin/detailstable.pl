#!/usr/bin/perl
require "tools.pl";

#
sub create_articledetails_table
{
        my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
                $web_browser,$local_file,$sth,$article_title,
                $str,$str2,$str3,$str4,
                @age,@fn);

        # Delete table first.
        # SELECT title,section,artid FROM ArticleDetails
        $sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`ArticleDetails`;
");
        $sth->execute() or print "failed on $i ($DBI::errstr)\n";
        $sth->finish();
        # Create it.
        $sth = $dbh->prepare("
CREATE TABLE `vunet`.`ArticleDetails` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `title` char(255) default NULL,
  `section` char(255) default NULL,
  `artid` char(255) default NULL,
  `date` bigint(20) default NULL,
 PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
");
        $sth->execute() or print "failed on $i ($DBI::errstr)\n";
        $sth->finish();

        # Delete table first.
        $sth = $dbh->prepare("DELETE FROM ArticleDetails;");
        $sth->execute() or print "failed on $i ($DBI::errstr)\n";
        $sth->finish();
}

#
create_articledetails_table();
