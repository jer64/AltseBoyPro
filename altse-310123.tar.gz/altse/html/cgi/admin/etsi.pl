#!/usr/local/bin/perl
#
# ETSI -PERL SCRIPT
# Written by Jari Tapio Tuominen(science.fiction@pp.nic.fi)
# Distributed under GPL, general public license ( see http://www.gnu.org )
#

use CGI qw(:standard);
use File::Find;


### Here is some preferences for the script,
### most of the things are specified in the html file's form
### that calls this perl script...

# SPECIFY HERE WHERE THE BASE DIRECTORY FOR THE SEARCH ENGINE RESIDES..
# THIS IS A VERY IMPORTANT THING, IF YOU SPECIFY WRONG DIRECTORY,
# YOU MIGHT ALTER FILES THAT YOU DO NOT WANT TO BE SEARCHED FOR SEARCHING.
$basedir1=               "/mp3";

# Here is the script version, do not modify, unless you are adding something.
$etsi_version=           "0.0.2";


sub wanted {
 #
 @dir[$i] = $File::Find::name;
 $i++;
}


#
main();

#
sub loyty()
{
 # loyty
 print ("

 <i>$entry[$i] points</i>

 <a href=\"$fn\">
 $fn
 </a>
 <br>
 ");
 # ** or use ..  <a href=\"postman.pl?$fn\"> .. if you fancy .. or similiar
}

#
sub search1()
{
 #
 open(FILE,"$fn") || error2();

 #
 if( $htyp eq "V1" )
 {
  while( <FILE> )
  {
   #
   $str = <FILE>;

   #
   if( $str =~ /$searchstring/i )
   {
    #
    @entry[$i]++;
   }

   #
  }
 }

 #
 if( $htyp eq "V2" )
 {
  if( $fn =~ /$searchstring/i )
  {
   #
   @entry[$i]++;
  }
 }

 #
 close(FILE);
}

#
sub disp1()
{
  #
  $i2 = $i2 + @entry[$i];

  #
  if( @entry[$i] eq 0 )
  {
  }
  else
  {
   #
   $fn = @dir[$i];
   loyty();
  }
}

#
sub displayresults()
{
 #
 for($i=0,$i2=0,$poistu=0; !$poistu; $i++)
 {
  #
  if( $i>=($#dir-1) ) { $poistu=1; }

  #
  if( $naytamax eq -1 )
  {
   disp1();
  }
  else
  {
   if( $i2 >= $naytamax )
   {
    $poistu=1;
   }
   else
   {
    disp1();
   }
  }
 }

 #
 if( $i2 eq 0 )
 {
  #
  print "Better luck next time! :-)<br>\n";
 }
}

#
sub displayresults1()
{
 #
 # J�RJEST� PISTEIDEN MUKAAN SUURUUSJ�RJESTYKSEEN
 #

 #
 for($i=0,$i2=0; $i<$#dir; $i++)
 {
  if( @entry[$i] )
  {
   $ar_n[$i2] = @dir[$i];
   $ar_e[$i2] = @entry[$i];
   $i2++;
  }
 }

 #
 for($kerta=0; $kerta<$#ar_n; $kerta++)
 {
  #  
  for($i=0; $i<$#ar_n; $i++)
  {
   #
   if( $ar_e[$i+1] > $ar_e[$i] )
   {
    #
    $str1 = $ar_e[$i+0];
    $str2 = $ar_e[$i+1];
    $str3 = $ar_n[$i+0];
    $str4 = $ar_n[$i+1];

    #
    $ar_e[$i+0] = $str2;
    $ar_e[$i+1] = $str1;
    $ar_n[$i+0] = $str4;
    $ar_n[$i+1] = $str3;
   }
  }
 }

 #
 # N�YT� TULOKSET
 #

 #
 print "<table>\n";
 for($i=0; $i<$#ar_n; $i++)
 {
  # remove the local dir reference
  # from the beginning of the string
  $tmpstr = $ar_n[$i];
  $tmpstr =~ s/$basedir//;

  #
  print("
 <tr>
  <td width=\"30%\">
   <i>$ar_e[$i] points</i>
  </td>

  <td width=\"70%\">
   <a href=\"$tmpstr\">
   $tmpstr
   </a>
   <br>
  </td>
 </tr>
        ");
 # *** or .. <a href=\"postman.pl?$ar_n[$i]\"> .. with postman
 }
 print "</table>\n";

 #
 if( !$#ar_n )
 {
  #
  print "<i>Better luck next time :-)</i><br>\n";
 }
}

#
sub search()
{
 # empty points
 for($i=0; $i<$#dir; $i++) { @entry[$i]=0; }

 #
 for($i=0; $i<$#dir; $i++)
 {
  #
#  print @dir[$i];
#  print "<br>\n";

  # hakemistot pois
  if( not -d @dir[$i] )
  {
   if( @dir[$i] =~ /$ftype/i ) # onko [.htm] tiedosto?
   {
    #
    $fn = @dir[$i];
    search1();
   }
  }
 }
}

#
sub error()
{
 print "<h2>Error: directory '$basedir' does not exist or I have no permission to access!<br>\n";
 exit;
}

sub error2()
{
 print "<h2>error: tiedostoa ''$fn'' ei loydy ...<br>\n";
 exit;
}

sub body
{
 #
 print ("
       <html>
        <head>
         <title>
          E t s i   -   S e a r c h  E n g i n e
         </title>


        </head>

        <body   bgcolor=\"$PREF_BGCOLOR\"
                vlink=  \"$PREF_VLINK\"
                alink=  \"$PREF_ALINK\"
                link=   \"$PREF_LINK\"
                text=   \"$PREF_TEXT\">
        ");
}


sub main()
{
 #
 $ftype=        param(file_type);
 $naytamax=     param(show_max);
 $searchstring= param(search_string);
 $basedir=      $basedir1;
 # param(base_dir);
 $returnurl=    param(return_url);
 $htyp=         param(search_type);
 $enginelogo=   param(engine_logo);

 #
 $PREF_ALINK=   param(color_link);
 $PREF_VLINK=   param(color_link);
 $PREF_LINK=    param(color_link);
 $PREF_BGCOLOR= param(color_bgcolor);
 $PREF_TEXT=    param(color_text);

 #
 print "Content-type: text/html\n\n";

 #
 body();

 #
 print "<center>";
 print "<table width=\"400\">";
 print "<tr>";
 print "<td>";
 print "<br><h4>";
 print "<center><img src=\"$enginelogo\" alt=\"[ Search Engine ]\"><br><i>Version $etsi_version</i></center><br>\n";


 #
# print ("
#        <h3>
#         <center>
#          hakemisto = ''$basedir'' -- *$ftype -- hakusana = ''$searchstring'' -- tyyppi = ''$htyp''<br>
#         </center>
#        </h3>
#        ");


 #
 $i=0;
 find(\&wanted, $basedir);


 #
 if ($htyp eq "")
 {
  print "Error: search type not defined";
 }
 else
 {
  #
  if ($htyp eq "V1")
  {
   print "<center>Searching for '$searchstring' from the contents of files:</center>";

   search();
   print "<blockquote>";
   displayresults1();
   print "</blockquote>";
  }
  else
  {
   if ($htyp eq "V2")
   {
    print "<center>Searching for '$searchstring' files:</center>";
 
    search();
    print "<blockquote>";
    displayresults1();
    print "</blockquote>";
   }
   else
   {
    print "Error: search type is invalid -> '$htyp'\n";
   }
  }
 
 }
 
 #
 print "<center><h5>Script written by Jari Tapio Tuominen(<a href=\"mailto:science.fiction\@pp.nic.fi\" class=\"linkki\">science.fiction\@pp.nic.fi</a>)</hr></center><br>\n";
 
 # bakki
 print "<br><h4><center><a href=\"$returnurl\" class=\"linkki\">[ Go Back ]</a></center>";

 print "</td>";
 print "</tr>";
 print "</table><br>";
 print "</center>";

 print "</body></html>\n";
}

