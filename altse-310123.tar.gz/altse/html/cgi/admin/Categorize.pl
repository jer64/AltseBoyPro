#!/usr/bin/perl
use DBI;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
main();

#
sub imgdesc_to_imglist
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4);

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$fn = $lst[$i];
		$fn =~ s/(.+)\=(.*)$/$1/;
		$fn = "/home/vai/public_html/uutiset/$fn";
		$category = $lst[$i];
		$category =~ s/.+\=(.*)$/$1/;
		$category =~ s/\,//g;

		# SELECT id, fname, age, group
		my $query = "UPDATE imagelist SET category='$category' WHERE fname='$fn';";
		#print STDERR "$query\n";
		$sth = $dbh->prepare($query);
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();
	}
#	$dbh->commit();
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);

	#
	imgdesc_to_imglist("$ENV{'DOCUMENT_ROOT'}/articles/cfg/imgdesc.txt");

	#
}
