#!/usr/bin/perl
my @alphabet = (('a'..'z'),('A'..'Z'), 0..9);
my %collection;
for (1.1) {
  my $len = 200;
  my $key = join '', map {$alphabet[rand(@alphabet)]} 1..$len;
  $collection{$key} ? redo : $collection{$key}++;
}
print join "\n", keys %collection;
print "\n";
