#!/usr/bin/perl
#
##################################################################################
#
# VAI WORLD FACT BOOK
#
##################################################################################

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
@web = OpenWebIndex("./webindex3.html");
#
HandleExternal("main-menu", "./fmainmenu.pl");
#
WebWalkTo("ENTERHERE_SECTION");
main();
#
HandleRest();

################################################################################
#
sub main
{
	#
	print ("
		<br><br><br>
		<center>
		<img src=\"../uutiset/factbook_kansi.jpg\">
		</center>
		");
}

#


