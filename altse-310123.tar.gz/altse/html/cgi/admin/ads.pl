#!/usr/bin/perl
##################################################################################################
#
# Vunet.org Community Advertising Center (CAC).
#
##################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
        #
        WebWalkTo("CHOOSE-TITLE1");
#        ArticleTitle($arg);
        SkipTo("CHOOSE-TITLE2");
        # Add main menu.
        WebWalkTo("main-menu");
        print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
        #
        WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();

##########################################################################################
#
sub SaveAds
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$ad_count,$f,
		$v1,$v2,$v3,$v4);

	#
	open($f, ">cfg/ads_$so{'l'}.txt") || die "can't write ads_$so{'l'}.txt";

	#
	loop: for($i=0; ; $i++)
	{
		#
		$v1 = "title$i";
		$v2 = "linea$i";
		$v3 = "lineb$i";
		$v4 = "url$i";

		#
		if( $so{$v1} eq "" || $so{$v1} =~ /^\s*$/ ) { last loop; }

		#
		print $f "$so{$v1}\n";
		print $f "$so{$v2}\n";
		print $f "$so{$v3}\n";
		print $f "$so{$v4}\n";
	}

	#
	close($f);
}

##########################################################################################
#
sub AdCenter
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$ad_count);

	#
	if($so{'title0'})
	{
		SaveAds();
		print "$so{'l'} SAVED.<BR>";
	}

	#
	print("
<DIV align=center><b>Yhteis�tiedotekeskus: $so{'l'}</b></DIV><BR>
		");

	#
	@lst = LoadList("cfg/ads_$so{'l'}.txt");
	$items = $#lst/3;
	if($items <= 0) { $items=1; }
	$items++;

	#
	if( $so{'l'} eq "fi") { $s[0] = "selected"; }
	if( $so{'l'} eq "en") { $s[1] = "selected"; }

	#
	print("
<FORM action=ads.pl method=get>
Siirry eri mainososastoon:
<select name=l value=\"$so{'l'}\">
<option name=fi $s[0]>fi</option>
<option name=en $s[1]>en</option>
</select>
<input type=submit value=\"Siirry >>\">
</FORM>

		<FORM action=ads.pl method=post>
	");
	#
	for($i=0,$i2=0; $i<$items; $i++,$i2+=4)
	{
		#
		printf("
		<TABLE width=100%>
		<TR bgcolor=#0000FF>
		<TD><FONT color=#FFFFFF>Mainos #%d</FONT></TD>
		</TR>
		</TABLE>

		<TABLE WIDTH=100%>
		<TR>
		<TD>Otsikko</TD>
		<TD><input type=text name=title$i value=\"$lst[$i2+0]\" size=50></TD>
		</TR>

		<TR>
		<TD>Rivi 1</TD>
		<TD><input type=text name=linea$i value=\"$lst[$i2+1]\" size=60></TD>
		</TR>
		
		<TR>
		<TD>Rivi 2</TD>
		<TD><input type=text name=lineb$i value=\"$lst[$i2+2]\" size=60></TD>
		</TR>

		<TR>
		<TD>URL</TD>
		<TD><input type=text name=url$i value=\"$lst[$i2+3]\" size=40></TD>
		</TR>

		</TABLE>
			",
			$i+1);
	}
	#
	print("
		<TABLE WIDTH=100%
		<TR>
		<TD>
		<input type=submit value=save>
		</TD>
		</TR>
		</TABLE>

		<input type=hidden name=l value=$so{'l'}>

		</FORM>
		");
}

##########################################################################################
#
sub main
{
	#
	$so{'l'} =~ s/[^a-z]//g;
	if($so{'l'} eq "")
	{
		$so{'l'} = "fi";
	}

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	print("
<TABLE cellpadding=32 cellspacing=0 width=640
	bgcolor=#00FFFF>
<TR>
<TD>
		");

	#
	AdCenter();

	#
	print("
</TD>
</TR>
</TABLE>
		");
}


