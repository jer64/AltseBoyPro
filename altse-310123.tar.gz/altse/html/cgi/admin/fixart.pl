#!/usr/bin/perl
##########################################################################
#
# FIX ARTICLE NEW LINES.
#
##########################################################################
require "inc.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

# Load configuration & parse args.
$DONT_AFFECT_DB = 1;
ArgLineParse();


#
main();

#
sub fixart
{
	my ($str,$str2,$str3,$str4,$i,$i2,$i3,$i4,$f,$ofn);

	#######################################################################
	# Load.
	@lines = LoadList($_[0]);

	#
	#$ofn = $_[0];
	$ofn = "/dev/null";
	open($f, ">$_[0]") || die "<LI>Error writing $_[0]</LI><BR>\n";

	#######################################################################
	# Remove unneeded empty lines.
	for($i=0,$i2=0,$got=0; $i<($#lines+1); $i++)
	{
		#
		$str = $lines[$i];
		$str2 = $str;
		$str2 =~ s/<br>//gi;
		$str2 =~ s/ //g;
		$str2 =~ s/\n//g;
		$str2 =~ s/\r//g;
		$str2 =~ s/^\s+//g;
		$str2 =~ s/\s+$//g;

		#
		if($i>0 && !$got && $str2 ne "")
		{
			$got = 1;
		}

		#
		if( ((!$i2 && ($got || !$i)) && $str2 eq "")
			|| $str2 ne "")
		{
			#
			if($str2 ne "")
			{
				$i2=0;
			}
			else
			{
				$i2=1;
			}

			# Print out line.
			print $f "$str<br>\n";
			print "$str<br>\n";
		}
	}

	#
	close($f);
	die "<DIV><P><BLINK>Testausta ...</BLINK></P></DIV>"
}

#
sub main
{
	if($so{'article'} =~ /^[a-z0-9]+\/pub_artikkeli[0-9]+\.txt$/)
	{
		#
		fixart("$ARTBASE\/$so{'article'}");

		#
		print "<meta http-equiv=\"refresh\" content=\"0; url=/viewarticle.pl?article=$so{'article'}\">\n";
	}
	else
	{
		# Invalid request.
		print "Sorry. Invalid request.<BR>\n";
	}
}

#
