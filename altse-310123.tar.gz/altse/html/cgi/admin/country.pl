#!/usr/bin/perl
#
##################################################################################
#
# VAI WORLD FACT BOOK
#
##################################################################################

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
@web = OpenWebIndex("./webindex3.html");
#
HandleExternal("main-menu", "./fmainmenu.pl");
#
WebWalkTo("ENTERHERE_SECTION");
main();
#
HandleRest();

#
sub otsikko
{
	#
	print ("
		<table bgcolor=\"#C0C0C0\" width=\"100%\">
		<tr>
		<td>
			$_[0]
			<br>
		</td>
		</tr>
		</table>
		<br>
		");
}

#
sub PrintLine
{
		#
		if($_[0] =~ /http\:\/\//)
		{
			#
			print "<a href=\"$_[0]\" target=\"_blank\">$_[0]</a><br>";

			#
			return 1;
		}

		#
		print "$_[0]<br>";
}

#
sub johdatus
{
	local @t,$i,$i2;

	#
	@t = LoadList("fb/$country/pub_info.txt");

	#
	otsikko("JOHDATUS");

	#
	for($i=0; $i<($#t+1); $i++)
	{
		#
		PrintLine($t[$i]);
	}
}

#
sub kartta
{
	#
	otsikko("KARTTA");

	#
	print("
		<a href=\"../uutiset/factbook/map\_$country.gif\">
		<img src=\"../uutiset/factbook/smmap\_$country.gif\"
			alt=\"Karttaa ei saatavilla.\">
		</a>
		");

	#
	print("
		<br>
		<br>
		<br>
		");
}

################################################################################
#
sub main
{
        # Get options.
        #
        $all = $ENV{'QUERY_STRING'};
        $buf = $all;
        $buf =~ s/\%0D/<br>\n/ig;
        $buf =~ s/\%0A//ig;
        $buf =~ s/\+/ /ig;
        $buf =~ s/%(..)/pack("C", hex($1))/eg;
        @prt = split("&", $buf);
        $set = $prt[1];
	$country = $prt[0];

	#
	print ("
			<table width=\"500\">
			<tr>
			<td>

			<font size=\"2\">
		");

	#
        if($set =~ /searchstring\=/)
        {
                $set =~ s/searchstring\=//;
        }
        else
        {
                $set = "";
        }

	##########################################################################
	#
	$c = $country;

	##########################################################################
	#
	# MAAN LIPPU
	#

	#
	if($found)
	{
		$LIPPU = ("
				<a href=\"../uutiset/factbook/flag\_$country.gif\">
				<img src=\"../uutiset/factbook/smflag\_$country.gif\" border=\"0\"
					alt=\"Lippua ei l�ytynyt.\">
				</a>
			");
	}

	#
	print ("
		<br><br><br>

		<center>
			<font size=\"5\">
				$country<br>
			</font>
				$LIPPU
				<br>
		</center>

		<br>");

	########################################
	#

	#
	kartta();

	#
	johdatus();

	#
	print("
		<br>
		<br>
		");
	#
	otsikko("TOIMINNOT");

	#
	print("


		<a href=\"admin/editart.pl?fb/$country/pub_info.txt\">
		<img src=\"http://www.saunalahti.fi/ehc50/uutiset/editor.gif\" border=\"0\"
			align=\"center\">
		muokkaa
		</a><br>

		");

	#
	print("
		</tr>
		</td>
		</table>
		");
}

#


