#!/usr/bin/perl
#
# upload_image.pl
#
##############################################################################################################

#
require "tools.pl";
use CGI;

#
$query = new CGI;

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
if( $query->param("datafile") )
{
	#
	SaveFile();
}
else
{
	print "Content-type: text/html\n\n";
	main();
}

#

###########################################################################################################
#
sub UploadForm
{
	#
	$r = $query->param("r");

	#
	print("
<H1>
JPEG-kuvan l�hetys Vunettiin
</H1><BR>

<FORM action=\"/cgi/admin/upload_image.pl\"
	enctype=\"multipart/form-data\" method=\"post\">
Valitse JPEG-kuva jonka haluat l�hett��:<BR>
<input type=file name=datafile size=40 id=fo><BR>
<input type=submit value=\"L�het� kuvatiedosto\">
<input type=hidden name=r value=\"$r\">
</FORM>

<SCRIPT LANGUAGE=\"Javascript\">
//document.getElementById('fo').focus();
</SCRIPT>
		");
}


###########################################################################################################
#
sub SaveFile
{
	my ($up,$f,$i,$i2,$str,$str2,$ofn,$path);

	#
	$up = $query->upload("datafile");

	#
	$r = $query->param("r");
	$fn = $query->param("datafile");
	$fn =~ s/[^a-zA-Z������0-9\-_\ \.]/_/g;
	$fn =~ tr/[A-Z���]/[a-z���]/;

	#
	if( !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.jpg$/) && !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.gif$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.png$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.xls$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.doc$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.txt$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.swf$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.flv$/)
		&& !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.pdf$/)
		)
	{
#		exit;
	}

	#
	$path = "/home/vai/public_html/uutiset";
	$ofn = "$path/$fn";
	unlink("$path/thumb/$fn");
	unlink("$path/thumb2/$fn");
	unlink("$path/thumb3/$fn");
	unlink("$path/thumb4/$fn");

	#
	open($f, ">$ofn");
	binmode $f;
	while( <$up> )
	{
		print $f $_;
	}
	close($f);
	#
	print "Content-type: text/html\n\n";

	#
	$sz = sprintf "%d", ((stat($fn))[7]/1024)+1;

	#
	@temp = LoadList("/home/vai/public_html/cgi/admin/IMGdircache.pl|");

	#
	print("
<H3>File successfully uploaded ($fn, $sz K bytes).</H3>
		");

	#
	if($r eq "") { $r="http://$ENV{'HTTP_HOST'}/upload"; }

	#
	print("
		<meta http-equiv=\"refresh\" content=\"0; url=/thumbupd.pl?r=$r\">
	");
}

###########################################################################################################
#
sub main
{
	#
	print("
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

<TABLE width=100% height=100% cellspacing=0 cellpadding=0>
<TR valign=top>
<TD>

<TABLE width=640 height=100% cellspacing=0 cellpadding=32>
<TR>
<TD>
		");

	#
	if( $query->param("datafile") )
	{
	}
	else
	{
		UploadForm();
	}

	#
	print("
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>

</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
		");

	#
}


