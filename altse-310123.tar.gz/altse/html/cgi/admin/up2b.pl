#!/usr/bin/perl
chdir("cd /home/vai/public_html/cgi-bin/admin");
system("./up2b.sh");
