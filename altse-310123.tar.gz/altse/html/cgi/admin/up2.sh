#!/bin/bash
#


#
cd /home/vai/cgi-bin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH
#
/home/vai/cgi-bin/update_titles.sh

#
/home/vai/cgi-bin/comwea

#
/home/vai/cgi-bin/upjs.sh
#
/home/vai/cgi-bin/upmain.sh
#
/home/vai/cgi-bin/upsecs.sh

#
/home/vai/cgi-bin/analyze_vislogs.pl &
