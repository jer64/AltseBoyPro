#!/usr/bin/perl
use DBI;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
main();

sub imgdir_to_mysql
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4,
		@age,@fn);

	#
	@lst3 = LoadList("find $ENV{'DOCUMENT_ROOT'}/images -type f -name '*.jpg' -maxdepth 1|");

	for($i=0,$i2=0; $i<($#lst3+1); $i++)
	{
	        $fn[$i2] = sprintf "%s", $lst3[$i];
		$age[$i2++] = sprintf "%1.8d", FileAge($lst3[$i]);
	}
	@fn = sort @fn;

	# Delete table first.
	$sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`imagelist`;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
	# Create it.
	$sth = $dbh->prepare("
CREATE TABLE `vunet`.`imagelist` ( `id` bigint(20) unsigned NOT NULL auto_increment,
  `age` bigint(20) unsigned default NULL,
  `fname` char(200),
  `category` char(30),
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	# Delete table first.
	$sth = $dbh->prepare("DELETE FROM imagelist;");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	#
	my $lt = time;
	my $st = time;
	my $large_sql = ("INSERT INTO imagelist
			(age,fname)
			values
");
	for($i=0; $i<($#fn+1); $i++)
	{
		if((time-$lt)>=4) {
			$lt = time;
			print STDERR time-$st . ": MakeImageList.pl: $i / $#fn\n";
		}
		$large_sql .= ("('$age[$i]', '$fn[$i]')");
		if($i==$#fn) {
			$large_sql .= ";";
		} else {
			$large_sql .= ",";
		}
		$large_sql .= "\n";
	}
	#$large_sql =~ s/^(.*),$/$1\;/;
	#print $large_sql . "\n";
	# SQL COMMAND
	$sth = $dbh->prepare($large_sql);
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
	#print "$ip, $article_title\n";

#	$dbh->commit();
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);

	#
	imgdir_to_mysql($lst[$i]);

	#
}
