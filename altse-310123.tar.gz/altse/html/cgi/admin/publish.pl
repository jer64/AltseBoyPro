#!/usr/bin/perl
#############################################################################
# PUBLISHING SCRIPT.
# (C) 2004-2008 by Jari Tuominen.
# Updated 9/2004, 2005, 2006, 2007.
#############################################################################


#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command.
select(STDOUT);
$| = 1;

#
require "./tools.pl";

#######################################################
# Search query string / post for options.
ArgLineParse();

#
#die "Artikkelin julkaisu on v�liaikaisesti poissa k�yt�st�.";

#######################################################
# Go to main loop.
#
main();

#######################################################################################
#
sub get_name
{
        my ($i,$f);

	#
	for($i=0,$found=0; !$found; $i++)
	{
                $str = sprintf "$ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/pub_artikkeli$_[0]%d.txt",$i;
                $str2 = sprintf "pub_artikkeli%d$_[0].txt",$i;
                if( !open($f, $str) ) {  $name=$str; $found=1;
                                        $name2=$str2;
                                }
                else { close($f); }
        }
}

###########################################################################################
#
sub save_article
{
	my ($i,$f);
	my (@tmp,@art,@art2,$section,$id,$q,$i,$i2);

	# Get a proper file name for the new article.
	get_name();

	#
	print $so{'IS_HTML'};
	if($so{'IS_HTML'} ne "on")
	{
		#$so{'article_content'} =~ s/\%0A/<BR>\n/ig; 
		#$so{'article_content'} =~ s/\%0D//ig;
		$so{'article_content'} =~ s/\n/<BR>\n/g;
	}

	# Write the article on drive.
	$counter = $name;
	$counter =~ s/\.txt/.counter/;
	unlink("$counter");
	unlink("$name\_com*");
	open($f, ">$name");
	print $f $so{'article_content'};
	close($f);

	#
#        my $query = ("INSERT INTO body_$so{'osasto'} title,body
#(title,body),
#('$CAP','$BODY');
#");
        #if(NoTracking()) { print "<LI>$query</LI><BR>"; }
#        $sth = $dbh->prepare($query);
#        $sth->execute() or print "failed on $i ($DBI::errstr)\n";

	# Write the article on drive.
	open($f, ">$name\_options.txt");
	$RL = time;
	print $f "release_date=$RL\n";
	close($f);

	#
	if($MUSEUM_ARTICLE)
	{
		# Add the file name to the list of articles.
		system("echo $name2 >> $ENV{'DOCUMENT_ROOT'}/articles/kaikki/fileindex.txt");
		system("echo $name2 > $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/_tmpfileindex.txt");
		system("cat $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/fileindex.txt >> $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/_tmpfileindex.txt");
		system("cat $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/_tmpfileindex.txt > $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/fileindex.txt");
	}
	else
	{
		# Add the file name to the list of articles.
		if($so{'osasto'} ne "xinwen" && $so{'osasto'} ne "picks")
		{
			system("echo ../$so{'osasto'}/$name2 >> $ENV{'DOCUMENT_ROOT'}/articles/kaikki/fileindex.txt");
		}
		system("echo $name2 >> $ENV{'DOCUMENT_ROOT'}/articles/$so{'osasto'}/fileindex.txt");
	}

	# Log IP.
	#system "echo $ip >> iplog.txt";
	# Log host.
	#system "echo $host >> hostlog.txt";

	#
#	if(fork()!=0)
#	{
	system("$ENV{'DOCUMENT_ROOT'}/cgi/admin/Kaikki.sh");
#      }
}

###############################################################################################
#
sub main
{
	#
	if(!NoTracking())
	{
		print "You don't have required rights to publish.<br>\n";
		print ("
		<meta http-equiv=\"refresh\"
		content=\"0; url=/admin/center.pl\">
			");		
		exit();		
	}

	#
	print "<HTML>\n";

	#
	print "Odota hetki ...<BR>";

	# Detect correct password always.
	if($all =~ /$ADMINPASSWORD/)
	{
		# Enable administration mode.
		$admin = 1;
	}

	# Password check.
	if($REQUIREPASSWORD!=0 && !$admin)
	{
		print "Error: Invalid password.<br>\n";
		die;
	}

	##################################################################
	if($all =~ /archivei43538453/i)
	{
		# Add article to the end of the list.
		$MUSEUM_ARTICLE = 1;
	}

	##################################################################
	if($argarg =~ /comart7895789235/i)
	{
		#
		print "Illegal function.<br>\n";
		die;
	}
	

	#
#	print "Osasto: $osasto.<br>\n<br>\n";

	#
	if($so{'osasto'} eq "" || $so{'osasto'} =~ /\?/g || $so{'osasto'} =~ /\.\./g ||
		$so{'osasto'} =~ /\// )
	{
		print "Error: No publishing section specified or invalid section specified ($osasto).<br>\n";
		die;
	}

	#
#	system("nice -n 20 /home/vai/cgi-bin/admin/update_titles.sh 2>&1 > /dev/null &");

	#
#	system("nice -n 20 /home/vai/cgi-bin/admin/CPtitles.pl 2>&1 > /dev/null &");

	#
	save_article();

	# Redirection.
#	print ("
#<IMG SRC=\"admin/promote.pl?file=$name&yes=1\">
#		");
#	<meta http-equiv=\"refresh\"
#	content=\"0; url=admin/promote.pl?file=$name&yes=1\">

	#
	print ("<H2>
<IMG SRC=\"$IMAGES_BASE/smiles/smile.gif\" valign=middle>
Kiitos. Artikkelinne on otettu vastaan. Hyv�� p�iv�n jatkoa!</H2><BR>\n");

	#
	print("
		");

	print "<a href=\"/cgi/viewarticle.pl?article=$so{'osasto'}/$name2\">\n";
	print "Klikkaa t�st� siirty�ksesi artikkeliin ...\n";
	print "</a>\n";

	#
	print "<hr><br>\n";

	#
	print $buffer;

	#
	print "</HTML>\n";
}