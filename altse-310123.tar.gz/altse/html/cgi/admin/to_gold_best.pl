#!/usr/bin/perl
#############################################################################
# to_gold.pl
#############################################################################

#
require "tools.pl";

#
print "Content-type: image/png\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
system("cat $ENV{'DOCUMENT_ROOT'}/images/gold_bar_icon.png");

#
main();

#
sub Bounce
{
	print ("<meta http-equiv=\"refresh\" content=\"0; url=http://www.kultakaivos.info/\">\n
		");
}

#
sub main
{
	#
	$DONT_AFFECT_DB = 1;
        # Load configuration & parse args.
        ArgLineParse();

	#
	$fn = "$ENV{'DOCUMENT_ROOT'}/articles/cfg/goldbest.txt";

	#
	open($f, ">>$fn") || die "unexpected error!";
	print $f "../$so{'pick'}\n";
	close($f);

	#
	Bounce();
}

#




