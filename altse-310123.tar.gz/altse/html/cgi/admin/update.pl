#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
chdir("/home/vai/cgi-bin/");

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
# Add main menu.
WebWalkTo("main-menu");
#
print inc_menu("", $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();

###########################################################################################################
#
sub step
{
	#
	$PASS = $so{'pass'}+1;

	#
	print("
<TABLE CELLSPACING=0 CELLPADDING=16 width=640>
<TR>
<TD>
<H2>
Updating portal, please wait ...<BR>
$PASS / 6
</H2>
</TD>
</TR>
</TABLE>
		");
}


###########################################################################################################
#
sub Step0
{
	#
	system("/home/vai/cgi-bin/admin/up2b.sh");
}

###########################################################################################################
#
sub Step1
{
	#
	system("/home/vai/cgi-bin/admin/upmain.sh");
}

###########################################################################################################
#
sub Step2
{
	#
	system("/home/vai/cgi-bin/admin/upsecs.sh");
}

###########################################################################################################
#
sub Step3
{
	#
	system("/home/vai/cgi-bin/analyze_vislogs.pl &");
}

###########################################################################################################
#
sub Step4
{
	#
}

###########################################################################################################
#
sub Step5
{
	#
}


###########################################################################################################
#
sub main
{
	#
	if($so{'stop'} ne "" && $so{'pass'} eq $so{'stop'}) { goto stop; }
	#
	step();
	#
	if($so{'pass'} eq "")
	{
		Step0();
	}
	#
	if($so{'pass'} eq "1")
	{
		Step1();
	}
	if($so{'pass'} eq "2")
	{
		Step2();
	}
	if($so{'pass'} eq "3")
	{
		Step3();
	}
	if($so{'pass'} eq "4")
	{
		Step4();
	}
	if($so{'pass'} eq "5")
	{
		Step5();
stop:
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/admin/center.pl\">
		"),
		return;
	}

	my ($x);

	#
	$x = $so{'pass'} + 1;
	print("
	<meta http-equiv=\"refresh\" content=\"0; url=/admin/update.pl?pass=$x&stop=$so{'stop'}\">
	"),

	#
}


