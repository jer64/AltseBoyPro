#!/usr/bin/perl
##########################################################
# Left main menu cached.
##########################################################
#
require "tools.pl";

#
$TM = (60*60*24*2);
#
$MAINMENU_CACHE_ON = 0;

#
main();

#
sub SaveCache
{
	my ($i,$i2,$str,$str2,$f,$f2);

	#
	open($f, ">$_[0]") || die "can't write cache on file '$_[0]'!!!!\n";
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/(\s*)\1/$1/g;
		$lst[$i] =~ s/\t/\ /g;
		$lst[$i] =~ s/\ \ /\ /g;
		$lst[$i] =~ s/^\s*//g;
		$lst[$i] =~ s/\s*$//g;
		print $f "$lst[$i]\n";
	}
	close($f);
}

#
sub main
{
	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();
	NoTracking();

	#
	$ENV{'CURSEC'} =~	s/[^a-z0-9]//gi;
	$ENV{'CURFPSEC'} =~	s/[^a-z0-9]//gi;

	#
	$fn = "cache/mm-$ENV{'CURSEC'}\_$ENV{'CURFPSEC'}-$ENV{'NO_TRACKING'}.txt";

	#
	if( !$MAINMENU_CACHE_ON || !(-e $fn) || FileAge($fn)>=$TM )
	{
		####if( !(-e $fn) ) { print "NOT FOUND $fn\n"; }
		####printf("Age %d/%d.\n", FileAge($fn), $TM);
		@lst = LoadList("./menu.pl|");
		if($#lst>5)
		{
			SaveCache($fn);
		}
		else
		{	
			system "./menu.pl";
		}
	}
	else
	{
		@lst = LoadList("$fn");
	}

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]\n";
	}

	#
}
