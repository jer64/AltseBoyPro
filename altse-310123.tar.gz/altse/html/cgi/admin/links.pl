#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "links";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex.html");
WireLogo();

                        # Add main menu.
                        WebWalkTo("main-menu");
			print inc_menu($ENV{'CURSEC'}, "english");
#
WebWalkTo("ENTERHERE_SECTION");
main();
#
HandleRest();
        EndBar();

#
sub main
{
	#
	@l = LoadList("2linklist.txt");

	#
        $l[0] =~ s/<!-A1->/\n/g;
        $l[0] =~ s/<!-A2->/\r/g;
        $l[0] =~ s/\\\"/\"/g;
        $l[0] =~ s/\\\'/\'/g;

	#
	print ("
		<table width=\"500\" cellspacing=0 cellpadding=16>
		<tr>
		<td>
		");

	#
	print ("
		<br>
		<img src=\"$IMAGES_BASE/links.jpg\">
		<br>
		");

	#
	for($i=0; $i<$#l; $i+=2)
	{
		print ("
			<img src=\"$IMAGES_BASE/artel.gif\">
			<a href=\"http://vunet.world?to=$l[$i+0]\"
				target=\"_blank\">
			$l[$i+1]
			</a><br>
			");
	}

	#
	print ("
		<a href=\"al.pl\">
		<br>
		> add new news site
		</a>


		</td>
		</tr>
		</table>
		");
}


