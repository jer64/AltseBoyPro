#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu("etusivu", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@ref,@art,@lst,@lst2,$str,$str2,$cap);

	#
	$fn = "$so{'article'}";
	$fn =~ s/\.txt$/.counter/;
	@ips = LoadList($fn);
	@ref = LoadList("$so{'article'}\_ref.txt");
	@art = LoadList("$so{'article'}");
	$cap = $art[0];
	$cap =~ s/<[^\>]+>//ig;

	#
	$qu = $so{'article'};
	$qu = BuildQuickUrl($qu);

	#
	$art[1] =~ s/<br>//gi;
	$art[2] =~ s/<br>//gi;

	$refcount = $#ref+1;
	$ipcount = $#ips+1;
	print("

<TABLE WIDTH=640 cellspacing=0 cellpadding=0>
<TR>
<TD>

<BR>
<DIV ALIGN=CENTER>
<A HREF=\"$qu\"><B>[LINK]: $cap</B></A>
<BR>
$art[1] $art[2] ...<BR>
<BR>
<B>$refcount referenssi�</B> tunnistettu.<BR>
<B>$ipcount eri IP-osoitetta</B> tunnistettu.<BR>
<BR>
</DIV>
");

	#
	for($i=0; $i<($#ref+1); $i++)
	{
		@sp = split(/ /, $ref[$i]);
		$alspo = "$sp[0]\_alspo";
		if($al{$sp[0]} ne "" && $al{$alspo} eq "" && $ll < 0)
		{
			$ll = 1;
			$al{$alspo}++;
			print "</A><FONT SIZE=1><B>- More similar references follow ...</B></FONT><BR><BR>";
		}
		if($al{$sp[0]} eq "")
		{
			$d = 0;
			$al{$sp[0]}++;
			$str = $sp[0];
			$str =~ s/[\<\>\?]/_/g;
			if($str=~/\.com/)
			{
				$str =~ s/([a-z0-9\-\.]+\.com)/<B>$1<\/B>/;
				$d = 1;
			}
			if($str=~/\.net/)
			{
				$str =~ s/([a-z0-9\-\.]+\.net)/<B>$1<\/B>/;
				$d = 1;
			}
			if($str=~/\.org/)
			{
				$str =~ s/([a-z0-9\-\.]+\.org)/<B>$1<\/B>/;
				$d = 1;
			}
			if($d!=1)
			{
				$str =~ s/([a-z0-9\-\.]+\.[a-z]{2}[^a-z]+)/<B>$1<\/B>/;
			}

			$str =~ s/^(.{35}).*(.{35})$/$1 ... $2/;
			$url = $sp[0];

			$host = $sp[2];
			$host =~ s/^.*(.{10})$/<B>\.\.<\/B>$1 ... $2/;

			print("
<LI>
<A HREF=\"$url\" title=\"$sp[2]\"> $str </A>
</LI>
			");
			$ll--;
		}
	}

	#
	print("
</TD>
</TR>
</TABLE>
		");

	#
}


