#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
main();

#################################################################################################
#
sub main
{
	my ($str,$str2,$str3,$str4,$i,$i2,$fn);

	#
	@GL_SECTIONS = LoadList("sections.txt");
	@GL_CACHE_24_H = LoadList("cache/chart-cache-86400-0.asc");

	#
	@GL_CACHE_24_H = reverse @GL_CACHE_24_H;

	#
	for($i=0; $i<($#GL_CACHE_24_H+1) && $i<20; $i++)
	{
		#
		if( !($GL_CACHE_24_H[$i]=~/^\s*[0-9]+\s\<([0-9]+)x[0-9]+\>\s*$/) )
		{
			goto skip;
		}

		#
		$str = $GL_CACHE_24_H[$i];
		$str =~ s/^\s*[0-9]+\s\<([0-9]+)x[0-9]+\>\s*$/$1/;
	
		$str2 = $GL_CACHE_24_H[$i];
		$str2 =~ s/^\s*[0-9]+\s\<[0-9]+x([0-9]+)\>\s*$/$1/;

		$str3 = $GL_CACHE_24_H[$i];
		$str3 =~ s/^\s*([0-9]+)\s\<[0-9]+x[0-9]+\>\s*$/$1/;

		$str4 = "$GL_SECTIONS[$str]/pub_artikkeli$str2.txt";
		print "$str4=1\n";

		if($str4 =~ /^[a-z]\/pub_artikkeli[0-9]*\.txt$/)
		{
			$GL_TOP20{$str4}++;
		}
skip:
	}

	#
#	open($f, ">cache/top20.txt");
#	$i=0; 
#	loop: foreach $key (keys %GL_TOP20)
#	{
#		if($i>=20) { last loop; }
#		$i++;
#		print $f "$key\=1\n";
#	}
#	close($f);

	#
}

