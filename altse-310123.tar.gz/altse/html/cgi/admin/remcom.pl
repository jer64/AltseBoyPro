#!/usr/bin/perl
#############################################################################
# remcom.pl
# Remove a comment (asks for an administration password).
#############################################################################

#
$NDB_ROOT = "$ENV{'DOCUMENT_ROOT'}/articles";

#
print "Content-type: image/gif\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
system("cat $ENV{'DOCUMENT_ROOT'}/images/nothing.gif");
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
#
sub RemoveComment
{
	my $found,f,$i,$i2,$i3,$i4;

	#
	AdminLog("User $ENV{'REMOTE_USER'} removed a comment.\n");

	#
	if( open(f, "$NDB_ROOT/$indexfname") )
	{
		#
		@index = <f>;
		close(f);

		#
		for($i=0,$found=0; $i<($#index+1); $i++)
		{
			if($index[$i] =~ /$fname/)
			{
				#
				$found=1;
				# Entry found.
				# Remove it (the comment file stays on the drive).
				$index[$i] = "";
			}
		}

		#
		if($found)
		{
			#
			open(f, ">$NDB_ROOT/$indexfname");
			for($i=0; $i<($#index+1); $i++)
			{
				if($index[$i] ne "")
				{
					print f $index[$i];
				}
			}
			close(f);	
		}
		else
		{
		}
	}
	else
	{
		die;
	}
}

#######################################################
#
sub main
{
	# Get raw query string.
	$cmd = $ENV{'QUERY_STRING'};
        # Fix string.
	$buffer = $cmd;
        $buffer =~ s/\%0D/<br>\n/ig;
        $buffer =~ s/\%0A//ig;
        $buffer =~ s/\+/ /ig;
        $buffer =~ s/%(..)/pack("C", hex($1))/eg;
	$buffer =~ s/kana\=//ig;
	@argarg = split("\&", $buffer);
	#
	$fname = $argarg[0];
	#
	@_origin = split("_comment", $fname);
	$origin = $_origin[0];
	$origin =~ s/\.//;
	# Seperate.
	@target = split("comment", $argarg[0]);
	# Build comindex -file name.
	$indexfname = "$target[0]comindex.txt";

	#
#	if($cmd eq "")
#	{
#		return false;
#	}

	# Got administration status.
	RemoveComment();
}


