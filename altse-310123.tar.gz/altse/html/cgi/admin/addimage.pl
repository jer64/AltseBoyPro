#!/usr/bin/perl
#############################################################################
# addimage.pl
# Adds image to an article.
# (C) 2004-2008 by Jari Tuominen (jari@vunet.world).
#############################################################################
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
#
sub ShowImageChoices
{
	my (@lst,@lst2,@lst3,@lst4,$i,$i2,$i3,$i4,@gr,$fn,$str,$str2,$cap);

	#
	if($so{'IML'} =~ /\.txt/ && !($so{'IML'}=~/\/content\//))
	{
		$fn = "$ENV{'DOCUMENT_ROOT'}/articles/cfg/$so{'IML'}";
	}
	else
	{
		$fn = "$so{'IML'}";
	}

	#
	$MAX = 11* 40;

	#
	if($so{'q'} ne "")
	{
		$str = $so{'q'};
		$str =~ s/[^a-zA-Z\ 0-9]������/ /g;
		$str =~ s/\'/\\\'/g;
		$str =~ s/\ /%/g;
                $WHERE = " WHERE fname LIKE '%$str%'";
        }

	#
	if($so{'tgroup'} ne "")
	{
		$str = $so{'tgroup'};
		$str =~ s/[^a-zA-Z\ 0-9]������/ /g;
		$str =~ s/\'/\\\'/g;
		$str =~ s/\ /%/g;
                $WHERE = " WHERE tgroup LIKE '%$str%'";
        }

	#
	if($so{'q'} eq "" && $so{'tgroup'} eq "")
	{
                $WHERE = " WHERE fname LIKE '%imperialism%' OR fname LIKE '%globe%' OR '%earth%' OR fname LIKE '%ocean%' OR fname LIKE '%sky%' OR fname LIKE '%nature%' OR fname LIKE '%planet%'";
	}

	#
	print("Making query, please wait ...<BR>\n");

	#
	my $query = "SELECT id,fname,category FROM imagelist$WHERE ORDER BY fname DESC$LIMIT;";
	####print "<LI>$query</LI><BR>";
	$sth = $dbh->prepare($query);
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";

	#
	@art = LoadList("$ENV{'DOCUMENT_ROOT'}/cgi/articles/$so{'article'}");
	$cap = $art[0];
	$cap =~ s/<br>//gi;

	#
	@lst3 = LoadList($fn);
	for($i=0,$i2=0; $i<($#lst3+1); $i++)
	{
#		$lst2[$i2++] = "%1.8d %s", 0, $lst3[$i];
		$lst2[$i2++] = sprintf "%1.8d %s", FileAge($lst3[$i]), $lst3[$i];
	}
	@lst2 = sort @lst2;
	for($i=0; $i<($#lst2+1); $i++)
	{
		@sp = split(/ /, $lst2[$i]);
		$lst[$i] = $sp[1];
	}

        #
        @gr = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/imggroups.txt");

	#
	$fn = "$so{'article'}_options.txt";
	if(-e $fn)
	{
		LoadVars($fn);
		if($so{'imageurl'} ne "")
		{
			$str = $so{'imageurl'};
			$str =~ s/([a-z0-9\-\(\)\_\ \!]*)\.([a-z]*)$/thumb\/th_$1.jpg/i;
			$IMGHTML = ("
				<FONT SIZE=1>Nykyinen valinta:<BR>
				<IMG SRC=\"$str\" border=1>
				</FONT>

				");
		}
	}

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = AutoDetermineImage($cap);
		if($so{'imageurl'} ne "")
		{
			$str = $so{'imageurl'};
			$str =~ s/([a-z0-9\-\ \(\)\_\!]+)\.([a-z]+)$/thumb\/th_$1.jpg/i;
			if(-e "$ENV{'DOCUMENT_ROOT'}/images/$str")
			{
			$IMGHTML = ("
				<FONT SIZE=3>Vunetti on tutkinut artikkelin otsikkoa ja ehdottaa seuraavaa kuvaa artikkelille:<BR>
				<A HREF=\"/cgi/admin/addimage.pl?article=$so{'article'}&cmd=addimage&url=$so{'imageurl'}&which=$so{'which'}\"
					class=news2>
				<IMG SRC=\"$str\" border=1 title=\"$str\"><BR>
				Klikkaa t�st� asettaaksesi kuvan.
				</FONT>

				");
			}
		}
	}

	#
	$q = $so{'q'};
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\///;
	}

	#
#	@lst = sort @lst;

	#
	$VH = ("
		<SCRIPT LANGUAGE=\"Javascript\">
		var checkflag = \"false\";
		function check()
		{
			form = document.getElementsByName('paaformi');
			field = form.value;
			if (checkflag == \"false\") {
			for (i = 0; i < field.length; i++) {
			field[i].checked = true;}
			checkflag = \"true\";
			return \"Uncheck All\"; }
			else {
			for (i = 0; i < field.length; i++) {
			field[i].checked = false; }
			checkflag = \"false\";
			return \"Check All\"; }
		}

		function NaytaKategorisointi()
		{
			t = document.getElementById('categ');
			t.style.visibility = 'visible';
		}
		</SCRIPT>

		<TABLE width=300 cellspacing=0 cellpadding=0
			style=\"visibility: hidden; position: absolute;\"
			id=categ>
		<TR>
		<TD>
		<FORM action=\"editimage.pl\" method=\"post\" target=\"_blank\" name=\"paaformi\">
		<INPUT TYPE=hidden name=cmd value=categorize>
		<INPUT TYPE=submit value=\"kategorisoi ryhm��n:\">
		<SELECT NAME=tgroup>
		");
	for($i=0; $i<($#gr+1); $i++)
	{
		if(!$i) { $str=" selected"; } else { $str = ""; }
	        $VH = ("$VH <OPTION name=\"$lst[$i]\"$str>$gr[$i]</OPTION>\n");
	}	
	$VH = ("$VH
		</SELECT>
<!--		<INPUT type=button value=\"Check All\" onClick=\"Javascript:this.value=check();\">  --->
		</TD>	
		</TR>
		</TABLE>
		<A HREF=\"Javascript:NaytaKategorisointi();\">
		> kategorisointi
		</A><BR><BR>
		");

	#
	for($i=0,$i2=0; $i2<$MAX && (@lq = $sth->fetchrow_array); $i++)
	{
		#
		#if($lst[$i] eq "" || ($so{'q'} ne "" && !($lst[$i]=~/$q/i) )) { goto skip; }

		#
		$path = $lq[1];
		$fn = $path;
		$fn =~ s/^\/.*\/([^\/]*)$/$1/;
		if( !($lst[$i]=~/^\//) ) { $fn = "$fn"; }
		#if( ! -e $path ) { print ".<BR>\n"; goto skip; }

		#
		if($so{'group'} ne "")
		{
			@sp = split(/\,/, $imd{$fn});
			$group = $sp[1];
			if(!($so{'group'}=~/[^\-a-z���]/) && $so{'group'} ne "" && $group ne $so{'group'})
			{
				goto skip;
			}
		}

		#
		if($so{'group'} eq "[NOIND]" && $group ne "")
		{
			goto skip;
		}

		#
		if(($i2%11)==0)
		{
			if( ($i2%20) > 9 ) { $c="#C0C0C0"; } else { $c="#E0E0E0"; }
			$VH =("$VH
				<table width=100% bgcolor=$c>
				<tr>
				<td>
			");
		}

		#
		$LIMZ = 16;
		$str = $fn;
		$str =~ s/^[0-9]//g;
		$str =~ s/[^0-9a-zA-Z������]/ /g;
		if( $str=~/\ / )
		{
			$str =~ s/\ /_/g;
			#$LIMZ = 8;
		}
		$str =~ s/^(.{$LIMZ}).*$/$1.../;
		$str =~ tr/[A-Z���]/[a-z���]/;
		$th = $fn;
		$th =~ s/([a-z0-9\-\ \(\)\_\!]*)\.([a-z]*)$/thumb\/th_$1.jpg/i;
		if($NEBASE eq "")
		{
			$NEBASE = "http://images.vunet.world";
		}
		$VH = ("$VH
			<TABLE width=80 height=80 align=left cellspacing=0 cellpadding=1
				bgcolor=#FFFFFF>
			<TR>
			<TD>

			<TABLE width=100% height=100% align=left cellspacing=0 cellpadding=1
				bgcolor=#C0C0C0>
			<TR>
			<TD>

			<TABLE width=100% height=100% align=left cellspacing=0 cellpadding=0
				bgcolor=#FFFFFF>
			<TR>
			<TD>

			<TABLE width=100% height=100% align=left cellspacing=0 cellpadding=2>

			<TR>
			<TD>
			<font size=1>
			<INPUT TYPE=\"checkbox\" name=\"selim_$i2\" value=\"$fn\">
			<A HREF=\"Javascript:OpenIt('/cgi/admin/editimage.pl?i=$fn');\"
				class=dark>
			muokkaa
			</A>
			</font>
			</TD>
			</TR>

			<TR>
			<TD>
				<font size=1>$str</font>
			</TD>
			</TR>

			<TR>
			<TD>
			<b><font size=1>
			$group
			</font></b>
			</TD>
			</TR>

			<TR height=72>
			<TD bgcolor=#C00000>
			<font size=1>

			<A HREF=\"Javascript:OpenIt2('/ifpreviewimage.pl?q=$NEBASE/$fn', 640,480);\">
			<IMG SRC=\"$IMAGES_BASE/icons4/vunet_icon_zoom.gif\" border=0
			style=\"position: absolute; width: 24px; height: 24px; margin: 0em auto;\"
			title=\"SUURRENNA KUVAA\"></A>

			<A href=\"addimage.pl?article=$so{'article'}&cmd=addimage&url=$NEBASE/$fn&which=$so{'which'}\"
				class=bright>
			<IMG src=\"$IMAGES_BASE/$th\"
				vspace=\"4\" title=\"VALITSE KUVA KLIKKAAMALLA\"
				hspace=\"4\"
				border=\"2\"
				width=70 height=70
				onMouseOver=\"this.vspace=2; this.hspace=2; this.border=4;\"
				onMouseOut=\"this.vspace=4; this.hspace=4; this.border=2;\">
			</A>
			</TD>
			</TR>

			</TABLE>

			</TD>
			</TR>
			</TABLE>

			</TD>
			</TR>
			</TABLE>

			</TD>
			</TR>
			</TABLE>
			");

		#
		if(($i2%11)==10)
		{
			$VH = ("$VH
				</td>
				</tr>
				</table>
				");
		}

		#
		$i2++;
skip:
	}

	#
	if($i2 >= $MAX)
	{
		$VH = ("$VH <BR>Huom. kaikkia kuvia ei n�ytet� koska hakutuloksia tuli liikaa haulla! ");
	}

	#
	$VH = ("$VH </FORM>");

	#
	print("
<TABLE width=400 cellspacing=0 cellpadding=0>
<TR valign=top>
<TD>
<TD>
		<font size=1>
		<A href=\"/$back\">
< palaa takaisin artikkeliin
		</a>
		</font>
</TD>

<TD>
		<font size=1>
		<A href=\"Javascript:OpenIt2('/cgi/admin/upload_image.pl',500,400);\">
> l�het� uusi JPEG-kuva
		</a>
		</font>
</TD>

<TD>
<form>
<input type=\"button\" value=\"P�ivit� thumbnailit\" onClick=\"OpenIt2('/thumbupd.pl', 300,200);\" />
</form>
</TD>

</TR>
</TABLE>

<TABLE width=800 bgcolor=#000000>
<TR>
<TD>

<TABLE width=100% bgcolor=#FFFFFF>
<TR>
<TD WIDTH=25%>
<FORM action=addimage.pl name=f>
<input type=text name=q value=\"$so{'q'}\">
<input type=hidden name=which value=$so{'which'}>
<input type=hidden name=article value=\"$so{'article'}\">
<input type=hidden name=IML value=\"$so{'IML'}\">
<BR>
Ryhm�: 
<SELECT name=group onChange=\"Javascript:this.form.submit();\">
<OPTION name=\"\">[kaikki]</OPTION>
");
for($i=0; $i<($#gr+1); $i++)
{
        if($gr[$i] eq $so{'group'})
        {
                $str = "selected";
        }
        else
        {
                $str = "";
        }
        print("<OPTION name=\"$gr[$i]\" $str>$gr[$i]</OPTION>\n");
}
print("
<OPTION value=\"[NOIND]\">[NOIND]</OPTION>
</SELECT>
<BR>
<input type=submit value=etsi>
</FORM>
</TD>
<TD WIDTH=25%>
<IMG SRC=\"$IMAGES_BASE/exclamation_mark.gif\">
Kokeile esimerkiksi hakusanoja 'blair', 'bush', 'war', 'dprk', 'usa'.
Tyhj� hakusana n�ytt�� kaikki kuvat.
</TD>

<TD width=50%>
$IMGHTML
</TD>

</TR>
</TABLE>

</TD>
</TR>
</TABLE>
<BR>

<script language=\"Javascript\">
function sf(){document.f.q.focus();}
sf();
</script>


<TABLE width=100% cellpadding=4 cellspacing=0>
<TR>

<TD width=20% bgcolor=#F0F0F0>
<DIV align=center>
$so{'group'} - $i2 kuvaa
</DIV>
</TD>

<TD bgcolor=#FFFF00 width=20%>

<DIV align=center>
<FONT SIZE=1>
Voit nyt valita listasta uuden kuvan:
</FONT>
</DIV>
</TD>

<TD bgcolor=#00FFFF width=60%>

<FONT SIZE=1>
<A HREF=\"addimage.pl?article=$so{'article'}&which=$so{'which'}&IML=imagelist.txt\">
<IMG src=\"$IMAGES_BASE/magnifier.gif\" border=0 align=center>
n�yt� kaikki kuvat
</A>

|

<A HREF=\"addimage.pl?article=$so{'article'}&which=$so{'which'}&IML=imagelist_dprk.txt\">
<IMG src=\"$IMAGES_BASE/magnifier.gif\" border=0 align=center>
n�yt� DPRK kuvat
</A>

|

<A HREF=\"addimage.pl?article=$so{'article'}&which=$so{'which'}&IML=imagelist_cuba.txt\">
<IMG src=\"$IMAGES_BASE/magnifier.gif\" border=0 align=center>
n�yt� Kuuba kuvat
</A>

|

<A HREF=\"addimage.pl?article=$so{'article'}&which=$so{'which'}&IML=imagelist_flags.txt\">
<IMG src=\"$IMAGES_BASE/magnifier.gif\" border=0 align=center>
n�yt� liput
</A>

</FONT>


</TD>

</TR>
</TABLE>
		");

	#
	print("
	$VH
		");

	#
}

####################################################################3
#
sub AddImageForm
{
	my ($str,$str2);

	#
	print("
		<TABLE width=100%>
		<TR>

		<TD WIDTH=70%>

		<FORM action=addimage.pl>
		Muuta artikkelin kuvaa numero ... 
		<SELECT name=which onChange='this.form.submit()'>
		<option>Valitse t�st�.</option>
");

	#
	for($i=1,$str=""; $i<10; $i++)
	{
		if($i==$so{'which'}) { $str = "selected"; } else { $str=""; }
		print("
			<option value=$i $str>kuva $i</option>
		");
	}
	print("
		</SELECT>
		<input type=hidden name=article value=\"$so{'article'}\">
		</FORM>

		</TD>

		<TD WIDTH=30%>
		<DIV align=right>
		<IMG src=\"$IMAGES_BASE/lisaa_kuva.gif\">
		</DIV>
		</TD>


		</TR>
		</TABLE>

		");

	#
	if($so{'which'} ne "")
	{
		ShowImageChoices();
	}
}

#######################################################
#
# The actual image adding process.
#
sub AddImage1
{
	my ($f,$str,$fn);

	#
	$str = "imageurl";
	if($so{'which'}>1)
	{
		$str = "imageurl$so{'which'}";
	}
	$so{$str} = $so{'url'};

	#
	save_iopts("$ENV{'DOCUMENT_ROOT'}/articles/$so{'article'}");
}

#######################################################
#
# Image add web form application.
#
sub AddImage
{
	#
	

	# Print form if no command detected.
	if( $so{'cmd'} ne "addimage" )
	{
		#
		AddImageForm();
	}
	else
	{
		#
		if( $so{'url'} eq "" )
		{
			goto past;
		}

		# Do some checks.
		#if( !( $so{'url'} =~ /http:\/\//i ) )
		#{
		#	print ("
		#		<blink>URL must begin with <b>http:// (error: \"$imageurl\") </b> !</blink>
		#		");
		#	AddImageForm();
		#	return true;
		#}

		# require gif jpg or jpeg
		if( !( $so{'url'} =~ /\.jpg/i ) &&
			!( $so{'url'} =~ /\.jpeg/i ) &&
			!( $so{'url'} =~ /\.gif/i ) &&
			!( $so{'url'} =~ /\.png/i )
			 )
		{
			print ("
				<blink><b>Unknown image format! (error: \"$imageurl\") </b> !</blink>
				");
			AddImageForm();
			return true;
		}

		# Do the operation.
		#if( !( $so{'url'} =~ /http:\/\//i ) )
		#{
		#	print ("
		#		<blink>URL must begin with <b>http:// (error: \"$imageurl\") </b> !</blink>
		#		");
		#	AddImageForm();
		#	return true;
		#}
past:

		################################################################################
		#
		# ESIKATSELU
		#
		if($so{'url'} ne "")
		{
			print("
				<b>Kuvan esikatselu</b>
				<br><br>
				<img src=\"$imageurl\" width=\"140\" height=\"140\"><br><br>
				");
		}	
		else
		{
			print("
				<b>Artikkelille m��ritelty kuva poistettiin k�yt�st�.</b>
					");
		}

		#
		AddImage1();

		#
		if($so{'url'} ne "")
		{
			print "Kuva on lis�tty onnistuneesti.<br>\n";
		}

		# Go back.
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/$back\">
		<script language=\"JavaScript\">
		location.href = '/$back';
		</script>
		");
		
	}
}

################################################################################################################################
#
sub main
{
	my ($i,$i2,$str,$str2,@lst,$key,$content);

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	if($so{'group'} eq "")
	{
#		$so{'group'} = "sosialismi";
	}

	#
	if($so{'which'} eq "")
	{
		$so{'which'} = 1;
	}

        #
	if($so{'group'}=~/kaikki/)
	{
        @lst = LoadList("cfg/imgdesc.txt");
        for($i=0; $i<($#lst+1); $i++)
        {
                @sp = split(/\=/, $lst[$i]);
                $key = $sp[0];
                $content = $sp[1];
                $imd{$key} = $content;
        }
	}


	#
	print("
<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

<script language=\"javascript\">
<!--
function OpenIt(URL)
{
	newWindow = window.open(URL, 'Preview', 'width=200,height=200');
}
function OpenIt2(URL,W,H)
{
	newWindow = window.open(URL, 'Preview', 'width='+W+',height='+H);
}
function OpenIt3(URL,W,H,TITLE)
{
	newWindow = window.open(URL, TITLE, 'width='+W+',height='+H);
}
// -->
</script>
</HEAD>

<BODY>
		");


	#
	print("


<TABLE CELLSPACING=0 CELLPADDING=4 WIDTH=100%
	bgcolor=#FFFFFF>
<TR>
<TD>

		");

	#
	if($so{'IML'} eq "" || $so{'IML'} =~ /imagelist\.txt/)
	{
		$so{'IML'} = ("$ENV{'DOCUMENT_ROOT'}/cache/IMGcache.txt");
	}

	#
	$back = $so{'article'};
	#$back = NiceArticleURL($back);
	$back =~ s/pub_artikkeli([0-9]*).*$/story-$1.html/;


	#
	$fname = $so{'file'};

	#
	if($so{'article'} eq "")
	{
		print "<h2>Error: ARTICLE not specified.</h2>\n";
		return false;
	}

	#
	AddImage();

	#
	print("
</TD>
</TR>
</TABLE>
	");

	#
	print("
</BODY>
		");
}


