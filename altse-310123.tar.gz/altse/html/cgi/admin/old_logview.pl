#!/usr/bin/perl
##########################################################################
#
# PORTAL LOG VIEWER/PARSER.
#
##########################################################################

#
require "admin.pl";

# Load configuration & parse args.
$DONT_AFFECT_DB = 1;
ArgLineParse();
if($so{'depth'} eq "")
{
	$so{'depth'} = 40;
}

#
$ENV{'CURSEC'} = "linkit";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex.html");
# Add main menu.
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
#
WebWalkTo("enterhere_section");
main();
#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
HandleRest();


################################################################
# Load & Parse Log !
#
sub LoadLog
{
	my (@log,$i,$i2,$i3,$i4,
		$str,$str2,$str3,$str4);

	#
	@log = LoadList($_[0]);

	#
	return @log;

	#
	for($i=0; $i<($#log+1); $i++)	
	{
		#
		$log[$i] =~ s/<br>//g;
		# Get subject.
		$str2 = $log[$i];
		$str2 =~ s/(.*)(')(.*)(')(.*)/$3/i;
		$str2 =~ s/ /_/g;

		# Get other.
		$str = $log[$i];
		$str =~ s/(.*)(')(.*)(')(.*)/$1/i;

		#
		@tab = split(" ", $log[$i]);
		#
		$IP = $tab[6];
		$IP =~ s/.*=//;
		#
		$HOST = $tab[7];
		$HOST =~ s/.*='(.*)'/$1/;

		#
		$log[$i] = "$str $str2";
	}

	#
	return @log;
}

################################################################
#
sub TableBeg
{
	#
	print("
		<table
			cellspacing=0 cellpadding=32>
		<tr>
		<td>
		");
}

################################################################
#
sub TableEnd
{
	#
	print("
		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub LogView
{
	my (@log,$str,$str2,$str3,$str4,$str5,
		$i,$i2,$i3,$i4,$i5,$i6,
		@spt,$CAP,$lhost,$chost,$fn);

	#
	$resfn = "cache/logview_resolved_ips.txt";
	#
	if(-e $resfn)
	{
		#
		@lst = LoadList($resfn);
		#
		for($i=0; $i<($#lst+1); $i++)
		{
			@sp = split(/\=/, $lst[$i]);
			$resolved{$sp[0]} = $sp[1];
		}
	}

	#
	$LOOK_FOR = $so{'SEARCH'};
	$LOOK_FOR =~ s/\"/\\\'/g;
	print("

		<center>
		<font size=\"6\">
		Article Reading History
		</font>
		</center>

		<br>
		<div>
		<form>
		<input type=hidden name=MAGIC value=\"32785782378523758\">
		article title: <input type=\"text\" name=\"SEARCH\" value=\"$LOOK_FOR\" size=20><BR>
		visitor host: <input type=\"text\" name=\"site\" value=\"$so{'site'}\" size=10><BR>
		section: <input type=\"text\" name=\"section\" value=\"$so{'section'}\" size=10><BR>
		log digging depth:
<select name=depth>
<option>40</option>
<option>200</option>
<option>400</option>
<option>800</option>
<option>1600</option>
<option>4000</option>
<option>8000</option>
<option>20000</option>
</select><BR>
		
		<input type=\"checkbox\" name=\"compact\" $c1>compact mode<BR>
		<input type=\"submit\" value=\"find\">
		<input type=\"hidden\" name=\"ignore_unknown\" value=\"$so{'ignore_unknown'}\">
		<br>
		");

	#
	$c1 = ""; $c2 = "";
	if($so{'compact'} ne "")
	{
		$c1 = "checked";
	}
	else
	{
		$c1 = "";
	}
	#
	print("
		</form>
		</div>

		$str
		");

	#
	print("
<FONT SIZE=5>
<CENTER>
$AVLOG_FN2 - $AVLOG_FN<BR>
</CENTER>
</FONT>
");

	#
	print("
		<table  style=\"vertical-align: top;\"
			cellspacing=0 cellpadding=4 width=100%>

		<tr style=\"vertical-align: top;\">
			<td width=14% bgcolor=\"#404040\">
			<font color=\"#FFFFFF\">
				TIME
			</font>
			</td>

			<td width=30% bgcolor=\"#606060\">
			<font color=\"#FFFFFF\">
				From Where
			</font>
			</td>

			<td width=32% bgcolor=\"#808080\">
			<font color=\"#FFFFFF\">
				Article Title
			</font>
			</td>

			<td width=24% bgcolor=\"#808080\">
			<font color=\"#FFFFFF\">
				Referer
			</font>
			</td>
		</tr>
		</table>
		");

	#
	$ct = time;

	#
	loop: for($lhost="",$i5=time,$i=$#lg-8,$i2=0; $i2<$so{'depth'} && $i>=0; $i-=8)
	{
		#
		$i6 = time;
		if( ($i6-$i5)>=6 )
		{
			last loop;
		}

again:
		#
		if( $lg[$i+1] eq "" || !($lg[$i+1] =~ /^[0-9]*$/) ) { $i--; goto again; }

		#
		$et = $lg[$i+1];
		($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime($et);

		#
		$Year += 1900;
		$Month++;

		#
		$Hour = sprintf "%.2d", $Hour;
		$Minute = sprintf "%.2d", $Minute;
		$Second = sprintf "%.2d", $Second;

		#
		$spt[0] = "$Day.$Month.$Year<br>$Hour:$Minute:$Second";

		#
		@sp = split(/\:/, $lg[$i+4]);
		$ip = $sp[0];
		$host = $lg[$i+5];
		$HOST = $host;
		$CAP = $lg[$i+3];
		#
#		print "$CAP ($host)<BR>";

		#
		if($resolved{$ip} ne "")
		{
			$host = $resolved{$ip};
		}
		if($host eq "")
		{
			@lst = ();
			open(PIPE, "host -Q $ENV{'REMOTE_ADDR'} 2>/dev/null|"); @lst = <PIPE>; close(PIPE);
			$hostname = $lst[0]; chomp $hostname; $hostname =~ s/name: //i;
			$host = $hostname;
			$resolved{$ip} = $host;
		}

		#
		if(
			$host =~ /googlebot/i ||
			$host =~ /msnbot/i ||
			$host =~ /betaspider\.com/i ||
			$host =~ /internetserviceteam\.com/i ||
			$host =~ /www\.gigablast\.com/i ||
			$host =~ /search\.com/i ||
			$host =~ /public\.alexa\.com/i ||
			$host =~ /.ask.com/i ||
			$lg[$i+6] =~ /MJ12bot/i ||
			IsBanned($host) ||
			$lg[$i+6] =~ /crawler/i )
		{
			goto past;
		}

		#
		if(	($host eq $lhost &&
			$CAP eq $lcap)	)
		{
			#
			goto past;
		}

		#
		$host =~ s/(.{20})/$1 /g;

		#
		$str5 = $lg[$i+7];
		$str5 =~ s/\s//g;

		#
		if($CAP eq "")
		{
			$CAP = $fn;
			$CAP =~ s/\|//g;
			if( open($f, "$CAP") )
			{
				$CAP = <$f>;
				close($f);
				$CAP =~ s/<br>//gi;
			}
		}
		$fn =~ s/^\/article//;
		if( !($fn=~/^\//) )
		{
			$fn = "/$fn";
		}

		#
		if( $so{'SEARCH'} ne "" && 
			($so{'SEARCH'}=~/^\// && $fn =~ /$so{'SEARCH'}/i) )
		{
			goto qskip;
		}

		###########################################################
		if( $so{'SEARCH'} ne "" &&
			!($CAP =~ /$so{'SEARCH'}/i) )
		{
			goto past;
		}

		#
		$str = $lg[$i+7];
		$str =~ s/^\/\?id\=([0-9]*)x.*$/$1/;
		if( $SEK ne "" && $seid{$SEK} ne $str )
		{
			goto past;
		}
qskip:

		# Compact filtering...
		$chost = $host;
		if($chost eq $lhost && $so{'compact'} ne "")
		{
			goto past;
		}

		#
		if($so{'site'} ne "" && !($host =~ /$so{'site'}/i))
		{
			goto past;
		}

		#
		$lg[$i+7] =~ s/pub_artikkeli([0-9]*)\.txt$/story$1.html/;

		#
		if( ($ct-(60*60*24)) > $et )
		{
			$b1 = "#40FFFF";
			$b2 = "#40A0C0";
			$b3 = "#A0A0C0";
			$b4 = "#C0FFFF";
			$b5 = "#E0FFFF";
		}
		else
		{
			$b1 = "#E04040";
			$b2 = "#C04040";
			$b3 = "#A04040";
			$b4 = "#704040";
			$b5 = "#807060";
		}

		#
		$CAP =~ s/^(.{40}).*$/$1.../;
		$REFURL = $lg[$i+4];
		$REFURL =~ s/^[^\:]*\:(.*)$/$1/;
		$REF = $REFURL;
		$REF =~ s/^http:\/\///;
		$REF =~ s/^(.{20}).*$/$1.../;
		$QSTR = $REFURL;
		if($QSTR=~/q\=/)
		{
			$QSTR =~ s/^.*q\=([^\&]*).*$/$1/;
			$QSTR =~ s/%(..)/pack("C", hex($1))/eg;
			$QSTR =~ s/[^a-zA-Z�������0-9\ \?\+]/_/g;
			$QSTR =~ s/[\?\+]/ /g;
			$QSTR = ("$QSTR<BR>");
		}
		else
		{
			$QSTR = "";
		}

		#
		$lg[$i+7] =~ s/\.txt/.html/;
		$lg[$i+7] = "http://www.vunet.world$lg[$i+7]";
		
		print ("
			<div>
			<table cellspacing=0 cellpadding=4 width=100%>
			<tr valign=top>

			<!---- TIME --------->
			<td bgcolor=\"$b1\" width=13%>
				<font size=\"2\">
					$spt[0]
				</font>
			</td>

			<td width=1% bgcolor=\"$b2\"></td>

			<!---- USERID --------->
			<td bgcolor=\"$b3\" width=30%>
				<font size=\"1\">
				<a href=\"$str4\" class=\"dark\" title=\"$lg[$i+6]\">
					$ip ($host)
				</a>
				</font>
			</td>

			<td bgcolor=\"$b4\" width=1%></td>

			<!---- ARTICLE TITLE --------->
			<td bgcolor=\"$b5\" width=30%>
			<a href=\"$lg[$i+7]\" class=dark title=\"$fn\">
			$CAP
			</a>
			</td>

			<!---- ARTICLE TITLE --------->
			<td bgcolor=\"$b3\" width=25%>
			<FONT COLOR=WHITE>$QSTR</FONT>
			<A HREF=\"$REFURL\" class=yellow title=\"$REFURL\">$REF</A>
			</td>

			</tr>
			</table>
			</div>

			<table width=100% cellpadding=0 cellspacing=0 height=4
				bgcolor=\"#000000\">
			<tr>
			<td valign=top>
			</td>
			</tr>
			</table>

			");

		#
		$i2++;
		$lhost = $HOST;
		$lcap = $CAP;
past:
	}

	#
	if($so{'SEARCH'} ne "")
	{
		#
		print("<br>$i2 results");
	}

	#
	open($f, ">$resfn") || die "can't write resolved ips file";
	flock $f, LOCK_EX;
	foreach $key (keys(%resolved))
	{
		if($key ne "")
		{
			print $f "$key=$resolved{$key}\n";
		}
	}
	flock $f, LOCK_UN;
	close($f);	

	#
}

################################################################
#
sub main
{
	my ($str,$str2,$str3,$str4,
		$i,$i2,$i3,$i4,@sl);

	#
	print("
<TABLE cellpadding=32 cellspacing=0 width=100%>
<TR>
<TD>
		");

	#
	@sl = LoadList("sections.txt");

	#
	for($i=0; $i<($#sl+1); $i++)
	{
		$seid{$sl[$i]} = $i;
	}
	$SEK = $so{'section'};

	#
	$so{'SEARCH'} =~ s/\W/\.\*/g;
	$so{'SEARCH'} =~ s/\.\*\.\*/\.\*/g;

	#
	if($so{'SEARCH'} =~ /site:/)
	{
		#
		$so{'site'} = $so{'SEARCH'};
		$so{'site'} =~ s/.*site:(.*)$/$1/;
		$so{'SEARCH'} =~ s/site:.*$//;
	}

	#
	$so{'SEARCH'} =~ s/\\\'/\"/g;
	#
	if( !($so{'SEARCH'} =~ /^\//) )
	{
		$so{'SEARCH'} =~ s/[:|\\|\/|;|\"|'|\(|\)|\&|\%]/\.\*/g;
	}

	#
	if($so{'ignore_unknown'} eq "") { $so{'ignore_unknown'} = 'false'; }

	#
	print("
<TABLE width=750>
<TR>
<TD>
		");

	#
	@lg = GetAvlog();

	#
	LogView(@lg);

	#
	print("
</TD>
</TR>
</TABLE>
		");


	#
	print("
</TD>
</TR>
</TABLE>
		");

	#
}
