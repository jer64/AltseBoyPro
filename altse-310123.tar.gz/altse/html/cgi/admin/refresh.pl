#!/usr/bin/perl
# OBSOLETE, USE CRONTAB
for(;;)
{
	chdir("/home/vai/public_html/cgi-bin/admin");
	system("nice -n 20 /home/vai/public_html/cgi/admin/online.pl");
	system("nice -n 20 /home/vai/public_html/cgi/admin/up2b.sh");
	system("cd ..; ./TopTen.pl");
	print("Sleeping two hours ...\n");
	sleep(60*60*2);
}
