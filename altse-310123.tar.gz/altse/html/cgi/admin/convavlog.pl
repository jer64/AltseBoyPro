#!/usr/bin/perl
use DBI;

#
require "tools.pl";

#
main();

sub avlog_to_mysql
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4);

	#
	open($f, $_[0]);

	#
	for($i=0; !eof($f); $i++)
	{
# 1: 1202774415
# 2: 
# 3: Mit<E4> Googlella haetaan eniten Suomessa?
# 4: 38.99.13.122:
# 5: crawl-1.cuill.com
# 6: Mozilla/5.0_(Twiceler-0.9_http://www.cuill.com/twiceler/robot.html)
# 7: /?id=2x437
# 8: tiede/pub_artikkeli437.txt

		# 1
		$con="x"; $time="y";
		for(; ($time ne $con) && !eof($f); )
		{
			$time = <$f>; chomp($time);
			$con = sprintf "%d", $time;
		}
		$time =~ s/\'/\\\'/g;
		# 2
		$uid = <$f>; chomp($uid); 
		$uid =~ s/\'/\\\'/g;
		# 3
		$article_title = <$f>; chomp($title);
		$article_title =~ s/[^a-zA-Z������0-9_\-\+\ \.]/ /g;
		# 4
		$str2 = <$f>; chomp($str2);
		$ip = $str2;
		$ip =~ s/^([^\:]*).*$/$1/;
		$ip =~ s/\'/\\\'/g;
		$referer = $str2;
		$referer =~ s/^[^\:]*\:(.*)$/$1/;
		$referer =~ s/\'/\\\'/g;
		# 5
		$host = <$f>; chomp($host);
		$host =~ s/\'/\\\'/g;
		if($host ne "") { $ip = "$ip ($host)"; }
		$ip =~ s/\'/\\\'/g;
		# 6
		$web_browser = <$f>; chomp($web_browser);
		$web_browser =~ s/\'/\\\'/g;
		# 7
		$url = <$f>; chomp($url);
		$url =~ s/\'/\\\'/g;
		# 8
		$local_file = <$f>;
		$local_file =~ s/\'/\\\'/g;
		# SQL COMMAND
		$sth = $dbh->prepare("INSERT INTO visitors
				(ip,web_browser,time,referer,url,article_title,local_file_name,host,uid)
				values
				('$ip', '$web_browser', '$time', '$referer', '$url', '$article_title', '$local_file', '$host', '$uid');");
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();
		#print "$ip, $article_title\n";
	}
#	$dbh->commit();

	#
	close($f);
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);

	#
	@lst = LoadList("find logs/avlog/*.txt|sort|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print "($i / $#lst) $lst[$i]\n";
		avlog_to_mysql($lst[$i]);
	}

	#
	#my $query = qq{ SELECT ip,web_browser,time,referer,article_file_name,article_title,cookie_info FROM visitors };

	#
}
