#!/bin/bash

#
cd /home/vai/public_html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
touch /home/vai/cache/reades_online.txt
chmod a+rw /home/vai/cache/reades_online.txt

#
/home/vai/public_html/cgi/admin/genranklist.pl > \
/home/vai/public_html/cache/top20.txt
lynx -source http://www.vunet.world/osastot.pl > /tmp/index-osastot.html
cp /tmp/index-osastot.html /home/vai/public_html/cache/index-osastot.html

#
echo "Updating Todays TOP 20"
lynx -source \
"http://www.vunet.world/chart.pl?MAGIC=32785782378523758&TLI=86400" \
> /tmp/index-top.html
cp /tmp/index-top.html /home/vai/public_html/cache/index-top.html

#
echo "Done."

