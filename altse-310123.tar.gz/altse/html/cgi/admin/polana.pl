#!/usr/bin/perl
#################################################################
#								#
# POLIITTINEN ANALYYSI 1.1					#
# (C) 2002-2003 Jari Tuominen(jari@vunet.world)			#
#								#
#################################################################

#
require "tools.pl";

# Negatiivinen numero tarkoittaa vasemmistoa, positiivinen taas oikeistoa
$suuntaus=0;
$kysymysNr=0;

# ASETUKSET
$DEBUGMODE=0;
$NR_ANSWERS_WANTED=40;
$MY_URL="http://www.saunalahti.fi/ehc50/webpolana/webpolana.htm";
$GIF_BANNER="http://www.saunalahti.fi/ehc50/webpolana/puolueita1.gif";
$ALT_BANNER="Poliittinen Analyysi 1.1";
$HINT_LINK="http://directory.google.com/Top/World/Suomi/Yhteiskunta/Politiikka/Puolueet/";

########### RESURSSIT ##############################################
@titteli=(
       "kommunisti","sosiaalidemokraatti",
       "keskustalainen","kokoomuslainen","��rioikeistolainen"
       );
$titteleidenmaara2=5;
@titteli2=(
       "Yrj� Hakanen(SKP)","Erkki Tuomioja(SDP)",
       "Esko Aho(KES)","Sauli Niinist�(KOK)","Adolf Hitler"
       );

#############################################################################
# Ohjelma alkaa
main();

# strKysymys sis�lt�� itse kysymyksen.
#
#
# "oikeistonVastaus" m��rittelee mik� vastaus on l�hinn�
# oikeiston arvioitua vastausta kyseiseen kysymykseen.
# Esim. 5 tarkoittaa ett� vastaamalla kysymykseen
# vastauksella numero 5 johtaa suuntauksen siirt�misen
# oikeistoon p�in.
#
# $_[0]		vastaus 1-5
# $_[1]		vaikutin: oikeisto tai vasemmisto (1 tai 5)
#
sub Vaikuta
{
 #
 local $i;

 # Hae parametrit
 $i = $_[1];
 $oikeistonVastaus = $_[0];

 #
 if($DEBUGMODE) { print "( '$_[0]' + '$_[1]' \n"; }
 #
 if($i==1) { $vaikutusVoima=-2; }
 if($i==2) { $vaikutusVoima=-1; }
 if($i==3) { $vaikutusVoima=0; }
 if($i==4) { $vaikutusVoima=1; }
 if($i==5) { $vaikutusVoima=2; }

 #
 $i4 = $vaikutusVoima;

 # Muunna vaikutusvoima korrektiksi
 if($oikeistonVastaus==1) {
	$vaikutusVoima = -i4;
			}

 # DEBUG DEBUG DEBUG
 if($DEBUGMODE) {
	print "Kysymys \#$kysymysNr vastaus=$vaikutusVoima - suuntaus=$suuntaus<br>\n";
	}

 # Vaikuta suuntaukseen
 $suuntaus = $suuntaus+$vaikutusVoima;

 # Seuraava kysymys
 $kysymysNr++;

 # Palaa takaisin
}

#
sub main
{
 #
 print "Content-type: text/html\n\n";
 print "<pre>";

 # Tuota vastaus joka kertoo poliittisen
 # suuntauksen vasemmisto,keskusta,oikeisto akselilla
 #
 $argus1 = $ENV{'QUERY_STRING'};
 @argus = split /\&/,$argus1;
 for($i=0; $i<$#argus; $i++)
 {
	$argus[$i] =~ s/\+/\=/ig;
	$argus[$i] =~ s/\=/\ /ig;
 }

 #
 for($i=1,$i2=0; $i<($NR_ANSWERS_WANTED+1); $i++)
 {
	if( !($argus[($i-1)] =~ /K/ig) )
	{
		print "- tarvitsen vastauksen kysymykseen #$i\n";
		$i2=1;
	}
 }

 #
 if($i2)
 {
	print "<center>Jotta voin arvioida tuloksen, tarvitsen vastaukset kaikkiin kysymyksiin.</center>\n";
	die;
 }

 #
# for($i=0; $i<$#argus; $i++) { print "$argus[$i]\n"; }

 #
 print ("
	<center>
	<a href=\"$MY_URL\"><img src=\"$GIF_BANNER\" alt=\"$ALT_BANNER\"></a>
	</center>
	");

 #
 print "Vastaanotin $#argus kpl kysymyksia<br>\n";
 for($i=0; $i<$#argus; $i++)
 {
	#
	$ii=$i+1;
	#
	@kohta = split /\ /,$argus[$i];
	#
	# 0 = KYSYMYKSEN NUMERO
	# 1 = KYSYMYKSEN NUMERO
	# 2 = VASTAUKSEN NUMERO
	if($DEBUGMODE) { print "$kohta[0] $kohta[1] $kohta[2]\n"; }
	#
	if( !($kohta[0] eq "K$ii") )
	{
	 print "<center>Ohjelma virhe, pahoittelemme tapahtunutta.</center>\n";
	 die;
	}
	#
	Vaikuta( $kohta[2], $kohta[1] );
 }

 #
 $suuntaus = $suuntaus * 3;

 #
 $kysymysNr = $NR_ANSWERS_WANTED;

 #
 printf("<center><h2>Tulos %d</h2></center>\n", $suuntaus);
 printf("<big><b>Selitys</b></big>\n");
 printf("<0 = vasemmisto\n");
 printf(" 0 = keskusta\n");
 printf(">0 = oikeisto\n\n");
 printf("<b>esimerkkej� suuntauksista</b>\n");
 printf("��rivasemmisto(SKP, KTP, SL, jne.)			= %d\n", -$kysymysNr*2);
 printf("vasemmisto(SDP, vasemmistoliitto)			= %d\n", -$kysymysNr*1);
 printf("keskusta(keskusta)					= %d\n", 0);
 printf("oikeisto(kokoomus)					= %d\n", $kysymysNr*1);
 printf("��rioikeisto(Hitler, Mussoliini, Thatcher, jne.)	= %d\n\n", $kysymysNr*2);
 printf("<b>poliittinen suuntauksesi vastauksista arvioituna on:</b>\n");
 #
 $i2 = ($suuntaus+($kysymysNr*2))/($kysymysNr*4/5);
	if($i2>=2 && $i2<3)
	{
		if($suuntaus>=0)
		{
			print "keskusta(oikeisto)\n\n";
		}
		else
		{
			print "keskusta(vasemmisto)\n\n";
		}
	}
	else
	{
 		if($i2>=0 || $i2<=4)
		{
			printf("%s\n\n", $titteli[$i2]);
		}
 		else
		{
			printf("[Virhe #2]\n\n");
		}
	}

 #
 printf("<b>Poliittista suuntaustasi kannattaa:</b>\n");
 #
 $i2 = ($suuntaus+($kysymysNr*2))/($kysymysNr*4/$titteleidenmaara2);
 if($i2>=0 || $i2<=4)
	{
		print "$titteli2[$i2]\n";
	}
 else
	{
		printf("[Virhe #3]\n\n");
	}
 #
 printf("
Google: <a href=\"$HINT_LINK\">World > Suomi > Yhteiskunta > Politiikka > Puolueet</a>
<hr>
Kiitos kiinnostuksesta ohjelmaan!\nKommentit, jne. osoitteeseen <a
href=\"mailto\:ehc50\@kanetti.net\">ehc50\@kanetti.net</a>
	");

 #
}

#
