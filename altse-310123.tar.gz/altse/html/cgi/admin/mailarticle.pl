#!/usr/bin/perl
#########################################################
#
# mailarticle.pl
#
#########################################################

#!/usr/bin/perl
#
require "inc.pl";
main();

# Confirm sending of the message.
sub Confirmation
{
	# Get article headline.
	open(f, $article) || die "Can't find article $article ...";
	$viesti = <f>;
	chomp $viesti;
	$viesti =~ s/<br>//g;
	close(f);

	#
	print ("
		<table width=\"500\">
		<tr>
		<td>

		<center>
		<h2>Vaihtoehtouutiset-postituslista - postitus</h2>
		</center>

		Haluatko todella postittaa viestin \"$viesti\" listalle?

		<form action=\"mailarticle.pl\" method=\"get\">
		<input type=\"hidden\" value=\"mailmsg559\" 
						name=\"verify\">
		<input type=\"hidden\" value=\"$article\" 
						name=\"article\">
		Otsikko: <input name=\"subject\" size=\"85\" type=\"text\"
			value=\"$viesti\"><br>
		<input type=\"submit\" value=\"L�het� edell� mainittu viesti listalle\">
		<a href=\"../newswire.pl\">Peruuta</a>
		</form>

		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>

		</td>
		</tr>
		");
}

# Post to the mailing list.
sub Postita
{
	my $i,$i2,$i3,$i4,$found,$tname,$str,$str2,@ql,$f;

        # Load quote lines.
        if( open($f, "$article\.quote") )
        {
                close($f);
                @ql = LoadList("$article\.quote");
        }

	# Generate two temporary file names.
	$_tname = rand(1000000000000000);
	$tname = "./$_tname";
	$_tname2 = rand(1000000000000000);
	$tname2 = "./$_tname2";

	#
	if( open(f, "$article\_imageurl.txt") )
	{
		$imurl = <f>;
		close(f);
	}

	# Parse article HTML.
	open(f, $article) || die "Can't open article file $article !";
	@art = <f>;
	close(f);
	for($i=0; $i<($#art+1); $i++)
	{
		chomp $art[$i];
	}

	####################################################################################
	#
	# Generate readable HTML.
	#

	#
	open(f, ">$tname2") || die "Can't write article temporay file $tname2";

	##########################################################
	# Add article table.
	print f ("
<table style=\"width: 600px; text-align: left;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">
<tbody>
<tr>
<td style=\"vertical-align: top;\"><br>
		");

	##########################################################
	# Mailing list announcement table.
	#
	print f ("
<table style=\"width: 100%; text-align: left; margin-left: auto; margin-right: auto;\" border=\"0\" cellpadding=\"2\" 
cellspacing=\"2\">


<tbody>
<tr>
<td style=\"background-color: rgb(0, 102, 0); vertical-align: top;\"><big style=\"font-weight: bold; color: rgb(255, 
255, 255);\">
<center>
Vaihtoehtouutiset-postituslista
</center>
</big>
</td>
</tr>
</tbody>
</table>
<br>
		 ");

	#
	for($i=0,$got=0,$otstxt=0,$quoteit=1; $i<($#art+1); $i++)
	{
		#
		$str = $art[$i];
		#
		$str2 = $str;
		$str2 =~ s/<br>//i;
		#
		$str3 = $str2;	
		$str3 =~ s/\ //;

		# First line?
		if(!$i)
		{
			$str = "<center><b><big>$str2</big></b></center><br>";
		}

		#
		if($got!=0 || $str3 ne "")
		{
			#
			if( $str2 =~ /<!--/)
			{
				$str = "";
			}

			#
			if( $str2 =~ /http\:\/\// &&
			    !($str2 =~ /\<img src/i) &&
			    !($str2 =~ /\<a href/i) )
			{
                                $tep = $str2;
                                $tep =~ s/(.{40})/$1<br>/g;
				$str = "<a href=\"$str2\">$tep</a><br>";
			}
	
			#
			$got = 1;

			#
			if(!$otstxt && $i)
			{
				#
				$otstxt = 1;

				#
				print f ("
				<table border=\"0\" cellpadding=\"0\" cellspacing=\"8\">
				<tr><td>
				");

				if($imurl ne "")
				{
					print f ("
					<img src=\"$imurl\" align=\"left\"
						vspace=\"8\" hspace=\"8\">
						");
				}

				#
				print f ("
				<b>$str</b>
				</td></tr></table>
				\n");
			}
			else
			{
				#
                                # QUOTE
                                if( ($quoteit--)==0 && $ql[0] ne "")
                                {
                                        #
                                        print f ("
                                                <table width=\"150\" align=\"right\"
                                                        bgcolor=\"#FFFFCC\" hspace=\"2\" vspace=\"2\"
                                                        cellspacing=\"0\" width=\"150\" border=\"0\"
                                                        cellpadding=\"3\" align=\"RIGHT\"
                                                        >
                                                <tr><td>

                                                <img src=\"http://www.saunalahti.fi/ehc50/uutiset/1startquote.gif\"><br>
                                                <font size=\"2\">
                                                $ql[0]
                                                </font><br>
                                                <img src=\"http://www.saunalahti.fi/ehc50/uutiset/1endquote.gif\" align=\"right\">

                                                </td></tr>

                                                <tr bgcolor=\"#000060\"><td>
                                                <font color=\"#FFFFFF\">
                                                $ql[1]<br>
                                                </font>
                                                </td></tr>

                                                </table>
                                                ");
                                }

				#
				print f "$str\n";
			}
		}
	}

	# Some trailing text.
	print f ("
<br><br><hr color=\"D0F0D0\"><br>
<center>
<img src=\"http://www.saunalahti.fi/ehc50/uutiset/mainos.jpg\"><br>
</center>
<center>
Julkaistu Vaihtoehtouutisissa.<br>
<a href=\"http://vaihtoehtouutiset.tux.nu\">http://vaihtoehtouutiset.tux.nu</a>
<br></center>
</td></tr>
		");

	# Add table.
	print f ("
		</td></tr></tbody></table>
		");

	#
	close(f);

	#
        system "echo \"Subject: [VAI] $subject\" > $tname";
        system "echo \"From: Vaihtoehtouutiset <vaihtoehtouutiset\@sci.fi>\" >> $tname";
        system "echo \"To: Progressive Reader <dear\@reader.com>\" >> $tname";
        system "cat ../eka.txt >> $tname";

	#
	for($i=0; ($i<$#lst+1); $i++)
	{
		#
		MailMessage($tname, "$tname2", $lst[$i], "[Vaihtoehtouutiset] $viesti");
	}

	#
	system "rm -f $tname";
	system "rm -f $tname2";
}

# Add address to the mailing list.
sub ProcessAddress
{
	local $i,$i2,$i3,$i4,$found;

	#########################################################################
	#
	open(f, "../mail.lst") || die "Can't find mail.lst";
	@lst = <f>;
	close(f);
	for($i=0; $i<($#lst+1); $i++)
	{
		chomp $lst[$i];
	}

	#########################################################################
	# Lis�� listalle.
	#
	if($action eq "mailmsg")
	{
		#
		if($article eq "" || $subject eq "")
		{
			die "Artikkelia tai otsikkoa ei m��ritelty ($article/$subject).";
		}

		#########################################################################
		#
		Postita();

		#
		print "<i><b>Artikkeli l�hetetty listalle onnistuneesti!</b></i>";
	}

	#
}

#
sub main
{
	#
	$all = $ENV{'QUERY_STRING'};
        $all =~ s/article=//;
        $all =~ s/subject=//;
        $all =~ s/\%0D/<br>\n/ig;
        $all =~ s/\%0A//ig;
        $all =~ s/\+/ /ig;
        $all =~ s/%(..)/pack("C", hex($1))/eg;
	$article = $all;

	#
	OpenWebIndex("./webindex2.html");
	WebWalkTo("main-menu");
	print ("
		<a style=\"color: rgb(255, 255, 255);\"
		href=\"../newswire.pl\">Paluu loppuk�ytt�j�n n�kym��n ...</a>
		");

	#
	WebWalkTo("enterhere_section");
	if($all =~ /mailmsg559/)
	{
		@spt = split("\&", $all);
		$article = $spt[1];
		$subject = $spt[2];
		$subject =~ s/<br>//;
		chomp $subject;
		$action = "mailmsg";
		ProcessAddress();
	}
	else	
	{
		Confirmation();
	}
	
	#
	HandleRest();
}

#



