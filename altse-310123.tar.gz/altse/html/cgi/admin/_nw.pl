#!/usr/bin/perl
#######################################################
# nw.pl - Newswire Publishing System 1.0.
# MAIN NEWS WIRE.
# (C) 2004-2005 by Jari Tuominen.
#######################################################

#
if($ENV{'newswire_conset'} eq "")
{
	#
	print "Content-type: text/html\n\n";
	# Send error messages to the user, not system log
	open(STDERR,'<&STDOUT');  $| = 1;
}

#
require "tools.pl";
#
#use Time::localtime;
#use File::stat;
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
$TFO = "<img src=$IMAGES_BASE/tiny_folder.gif border=0 align=center>";
#
$TXT_NEWS_SERVICES = "uutispalveluja";
$TXT_CALENDAR = "kalenteri";
$ADVERT_SEC = "poimitut";
$TXT_SEND_TIP = "l�het� juttuvinkki";
$ADVERT_SEC_DESCRIPTION = "poimitut";
$NO_SECTION_HL = 0;
$CHARS_SHOWN_BREAD_TEXT = 500;
# Shorten captions.
$SHORTENCAPTIONS = 1;
#
$ARTVIEWER = "/article/";

#
$ARTEL_GIF = "$IMGBASE/vpalk.gif";
$BDR_COLOR = "#FFFFFF";
$ABSOLUTE_LIMIT_CAPTION_LENGTH = 75;

#
$SCROLLER_ENABLED = 0;

# Viewing method.
# Valid values: VARIOUS / LATEST
$VIEWING_METHOD = "VARIOUS";

#######################################################
# PREFERENCES
#
#
$MAX_ADVERTSEC_TO_SHOW = 20;
# Number of the first article to show on the listing.
$BEGART = 0;
# Max. number of stories to show at once.
$MAX_STORIES_TO_SHOW = 10;
# Max. number of headlines to show at once.
$MAX_HEADLINES_TO_SHOW = 4;
$MAXHESO = $MAX_HEADLINES_TO_SHOW;
$MAX_PRV_ARTICLE_CHARS = 200;
#
$WEBINDEX = "webindex.html";
$FILEINDEX = "./fileindex.txt";
$PROGRAM_NAME = "Newswire Publishing System";

#######################################################
# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#######################################################
# Go to main loop.
#
main();

##########################################################
sub _OpenIndex
{
	my ($i,$ff);

	#
	@fileindex = LoadList($_[0]);
}

##########################################################
sub ViewArticleFile
{
	my ($i,$f);

	# READ ARTICLE FILE.
	open($f, $_[0]);
	@lines = <$f>;
	close($f);

	# CHOP LINES.
	for($i=0; $i<($#lines+1); $i++) { chop $lines[$i]; }

	# VIEW ARTICLE.
	for($i=0; $i<($#lines+1); $i++)
	{
		print "$lines[$i]<br>\n";
	}
}

###########################################################################
#
# The actual function that is used to view the article in newswire.pl
# If $FNSIZE is set, it is used as the font size.
#
# Params:
# [article file name] [stream] [table width]
#
sub ViewArticleFileHeadline
{
	my ($i,$i2,$i3,$i4,$found,$str,$str2,$size,$bo,
		$imageurl,$tep,$_tep,
		$of);

	###################################################################
	#
	# Determine output stream.
	#
	if($_[1] ne "") { $of=$_[1]; } else { $of=stdout; }

	###################################################################
	#
	# READ ARTICLE FILE.
	#
	@lines = LoadList($_[0]);

	###################################################################
	#
	# VIEW ARTICLE HEADLINE.
	#
	if($section eq "" && $coz!=1 && !$FNSIZE || $supersmall)
	{
		##
		## LESS DETAILED VIEW.
		##
		#################################
		$size3 = $FNSIZE-1;

		# Produce link to it.
		printf $of "<font size=\"$size3\">\n";
		if(!$supersmall) { printf $of "<br>"; }
		if($NO_ICON ne "1")
		{
			printf $of ("
			<br>
				<img 
				src=\"$ARTEL_GIF\" alt=\"-\">
			");
		}
		if($NO_ICON ne "1")
		{
			$bo = Bonus1($_[0], $of);
			print $bo;
		}
		$tep = $lines[0];
		$tep =~ s/<br>//ig;
		$arturl = $_[0];
		$arturl =~ s/\/$ADVERT_SEC\/\.\.//g;

		#
		if($LIMIT_CAPTION_LENGTH ne "")
		{
			if($SHORTENCAPTIONS)
			{
				$raj = 0;
				$_tep = $tep;
				$tep = substr($tep, 0, $LIMIT_CAPTION_LENGTH);
				if( length($_tep) > length($tep) ) { $raj = 1; }
				if($raj) { $tep = "$tep..."; }
				$tep = ">$tep";
				$tep =~ tr/[a-z���]/[A-Z���]/;
			}
		}
		else
		{
			if($tep =~ /[A-Z���][A-Z���][A-Z���][A-Z���]/ && $SHORTENCAPTIONS)
			{
				$tep =~ tr/[A-Z���]/[a-z���]/;
			}
		}
		if($SHORTENCAPTIONS)
		{
			$tep =~ s/(\S{18})/$1- /g;

			$_tep = $tep;
			$tep = substr($_tep, 0, $ABSOLUTE_LIMIT_CAPTION_LENGTH);
			if( length($_tep) > length($tep) )
			{
				$tep = "$tep...";
			}
		}

		#
		printf $of ("<a href=\"$ARTVIEWER$arturl\"
			style=\"color: rgb($LINKCOLOR);\"
			class=\"news1\">
			");
		# ARTICLE CAPTION.
		printf $of ("
				$tep<br>
				");
		printf $of "</a>\n";
		printf $of "</font>\n";

		# Show if there is any comments for the article
		AnyComments($arturl);
		
		# Show creation date.
		if(!$supersmall)
		{
			CrDate($_[0]);
			printf $of "<font color=\"#C0C0C0\" size=\"1\">\n";
			printf $of $aika;
			printf $of "</font>\n";
		}
	}
	else
	{
		##
		## More detailed view.
		##
		#####################################

		#
		printf $of ("
				<table
				BORDERCOLOR=\"$BDR_COLOR\"
				BORDERCOLORDARK=\"$BDR_COLOR\"
				BORDERCOLORLIGHT=\"$BDR_COLOR\"  ");
		
		if($_[2] ne "")
		{
			printf $of ("
					width=\"$_[2]\"
					");
		}
	
		printf $of ("	>   \n");
		printf $of "<tr><td>\n";

		#
		$size = $FNSIZE-1;
		if(!$size)
		{
			$size = 4;
		}
		printf $of "<font size=\"$size\">\n";
		if($FNSIZE) {
		#	printf $of "<center>\n";
			printf $of "<b>";
		}

		#
		$tep = $lines[0];
		$tep =~ s/<br>//g;
		if($SHORTENCAPTIONS)
		{
			$tep =~ s/(\S{18})/$1- <br>/g;

			#
			$_tep = $tep;
			$tep = substr($_tep, 0, $ABSOLUTE_LIMIT_CAPTION_LENGTH);
			if( length($_tep) > length($tep) )
			{
				$tep = "$tep...";
			}
		}

		#
		if($section ne "" && !$supersmall)
		{
	#		print("TEST TEST TEST TEST 1234567890<br>\n");
		}

		#
		if(!$supersmall)
		{
			# ARTICLE SECTION TABLE.
			#
			if($FNSIZE && !$NO_SECTION_HL)
			{
				printf $of ("
					<table width=\"224\" bgcolor=\"#E0F8E0\"
						cellspacing=0 cellpadding=2>
					<tr>
					<td class=\"tdSelector1\"
						onMouseOver=\"ArtTab(this,1);\"
						onMouseOut=\"ArtTab(this,0);\"
			onClick=\"Clixxor(0, '/?section=$sect&FP_SECTION=$so{'FP_SECTION'}');\">

					<font size=\"2\">
						");
				printf $of ("
					<b>$sect</b>\n
					</font>
					<br>\n

					</td>
					</tr>
					</table>

					<table cellpadding=0 cellspacing=0>
					<tr height=\"6\">
					<td>
					</td>
					</tr>
					</table>
					");
			}
			printf $of "</a>\n";
		#	if(!$FNSIZE) { printf $of "<br>\n"; }
		#	if($section ne "" ) { printf $of "<br>\n"; }
		}

	       	# Print image, if any.
		#
	        if( open(f4, "$_[0]\_imageurl.txt") )
	        {
	                # Got image url!
	                $imageurl = <f4>;
	                close(f4);
		}
		else
		{
			$imageurl = "";
		}

		#
		if($ARTICLE_PRV_EXTEND != 0 && IsImage($imageurl)
			&& $so{'section'} eq "")
		{
				$WID = 268;
				$HEI = 268;
		                printf $of ("
				<center>
				<a href=\"$ARTVIEWER$_[0]\" 
					class=\"news1\">
				<img src=\"$imageurl\" width=\"$WID\" height=\"$HEI\"
		                        border=\"1\" hspace=\"0\" 
					vspace=\"0\">
				</a>
				</center>
				<br>
				\n");
		}

		# jumbo321
		print Bonus1($_[0]);
		printf $of "<a href=\"$ARTVIEWER$_[0]\" class=\"news1\">";
		$lines[0] =~ s/<br>//ig;
		$tep =~ s/\n//g;
		$tep =~ s/\r//g;
		# PRINT ARTICLE CAPTION.
		printf $of "<!---click1---><b>$tep</b>";
		printf $of "</a><!----- test 1040960 --->\n";
		printf $of "<!---click2---></font>\n";
		if($FNSIZE) {
			printf $of "</b>\n";
		}
		printf $of "<br><!---click3--->\n";
		# Show if there is any comments for the article
		AnyComments($_[0]);
		# PRINT ARTICLE DATE.
		printf $of "<font color=\"#C0C0C0\" size=\"1\">\n";
		$tiedaika = CrDate($_[0]);
		printf $of $tiedaika;
		printf $of "</font>\n";
		printf $of "<br>\n";

		#
		if($ARTICLE_PRV_EXTEND == 0)
		{
			#
			if($_[1] eq "small")
			{
				$WID = 70;
				$HEI = 70;
			}
			else
			{
				$WID = 70;
				$HEI = 70;
			}
	
	                #
			if($so{'hideimages'} ne "true" && $imageurl ne "")
			{
		                printf $of ("
					<a href=\"$ARTVIEWER$_[0]\" 
						class=\"news1\">
					<img src=\"$imageurl\" width=\"$WID\" height=\"$HEI\" align=\"left\"
		                        border=\"1\" hspace=\"4\" vspace=\"4\">
					</a>
					");
			}
	        }
		else
		{
			# No image.
			$imageurl = "";
		}

		#
		$size2 = $size-1;

		#
		printf $of " <font size=\"$size2\"> \n";

		#
		test: for($i=1,$found=0; $i<($#lines+1);
			$i++)
		{
			$str = $lines[$i];
			$str =~ s/<br>//ig;
			$str =~ s/\xa0//g;
			$str =~ s/\s//g;
			if($str ne "")
			{
				$found=1;
				last test;
			}
		}
		if($found)
		{
			# How many chars per article headline text?
			if($imageurl eq "")
			{
				$LIMIT1 = $MAX_PRV_ARTICLE_CHARS;
			}
			else
			{
				$LIMIT1 = $MAX_PRV_ARTICLE_CHARS/2;
			}
			#
			if($SHORTENCAPTIONS)
			{
				$str = $lines[$i];
				$str =~ s/<br>//ig;
				$str = substr($str, 0, $LIMIT1);
				if(length($str)>($LIMIT1-2))
				{
					$str = "$str...";
				}
			}

			#######################################################################3
			#
			# Print article bread text.
			#

			#
			if($ARTICLE_PRV_EXTEND)
			{
				print ("
						<a name=\"$_[0]\" class=\"plain\">
					");
				loopx: for($x9=0,$len=0; $x9<20; $x9++)
				{
					$len = $len + length($lines[$i+$x9]);
					print ("
						$lines[$i+$x9]
						");
					if($len>$CHARS_SHOWN_BREAD_TEXT)
					{
						last loopx;
					}
				}
			}
			else
			{
				#
				printf $of ("
				<a name=\"$_[0]\" class=\"plain\">$str\n
				");
			}

			#
			print "</a>\n";
		}

		#
		printf $of "<br>";
		printf $of "<!---analyze1006437--->\n";

		# jumbo123
		if($ARTICLE_PRV_EXTEND && $section eq "")
		{
			printf $of "<a href=\"$ARTVIEWER$_[0]\" class=\"dark\">";
			printf $of ("
				<div align=right>
				 Jatkuu ...
				</div>
				");
			printf $of "</a>\n";
		}

		#
		if($section ne "")
		{
			if($so{'FP_SECTION'} eq "english")
			{
				$LUE = "read more";
			}
			else
			{
				$LUE = "lue lis��";
			}
			printf $of "<a href=\"$ARTVIEWER$_[0]\" style=\"color: rgb($LINKCOLOR);\">";
			printf $of ("<img src=\"$IMGBASE/dokumentti.gif\" alt=\">>\" border=\"0\" align=\"center\">
				 $LUE\n
				");
			printf $of "</a><br><br>\n";
		}

		#
		printf $of " </font> \n";
		
		#
		print $of "</td></tr>\n";
		print $of "</table>\n";
	}
}

#
sub Headline
{
		print ("
		<table width=\"100%\"
	BORDERCOLOR=\"$BDR_COLOR\"
	BORDERCOLORDARK=\"$BDR_COLOR\"
	BORDERCOLORLIGHT=\"$BDR_COLOR\"
	background=\"$IMGBASE/sm_gradient.png\" border=\"0\"
			cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		<td>
		<center><b>$_[0]</b></center>
		</td>
		</tr>
		</table>
			");
}

#
sub katkos 
{
				#
				print("
					<table width=\"100%\">
					<tr>
					<td background=\"$IMGBASE/katkoviiva.gif\" height=\"2\">
					</td>
					</tr>
					</table>
					");
}

################################################################
sub MenuSystem
{
	#
	print("
		<script language=\"Javascript\">
			function Action123(i, active)
			{
			//	window.status = i;
				e2 = document.getElementById(i);
				if(active)
				{
				//	e2.innerHTML = 'hello!!!!!!!!!!!!!';
				}
			}
		</script>
		");
}

################################################################
#
# News Images
#
sub NewsImages
{
	my ($i,$i2,$lst,$str,$str2,$f,$f2,$imgurl,$url,$cap,$url);

	#
	@lst = LoadList("$ADVERT_SEC/fileindex.txt");

	#
	print("
		<div>
		<table cellpadding=1 cellspacing=0>
		<tr valign=top>
		");

	#
	for($i=$#lst,$i2=0; $i2<10 && $i!=0; $i--)
	{
		#
		$lst[$i] =~ s/..\///;
		$url = $lst[$i];

		#
		$str = "$lst[$i]\_imageurl.txt";

		#
		if( open($f, $str) )
		{
			$imgurl = <$f>;
			close($f);

			#
			$url = UrlFix($url);

			#
			if(!IsImage($imgurl)) { goto past; }
	
			#
			if( open($f, $lst[$i]) )
			{
				$cap = <$f>;
				$cap =~ s/<br>//g;
				$cap =~ s/\"/\\\"/g;
				$cap =~ s/'/\\\'/g;
				$cap =~ s/[\n|\r]//g;
				close($f);
			}
			else
			{
			}

			#
			$_cap = $cap;
			$_cap =~ s/\\\"/\"/g;
			$_cap =~ s/\"/'/g;
			print("
				<td>
				<a href=\"$ARTVIEWER$url\" class=\"dark\">
				<img src=\"$imgurl\" width=58 height=58
				alt=\"$_cap\"
				title=\"$_cap\"></a>
				</td>
			");

			#
			$i2++;
			if( ($i2%5)==0 )
			{
				print("
					<br>
					");
			}

		}
past:
	}

	#
	print("
		</tr>
		</table>
		</div>
		");

	#
	print("
		<font size=2>
		<a href=\"/newsimages.pl\" class=dark>
		> lis�� uutiskuvia
		</a><br>
		</font>
		");

	#
}

################################################################
#
sub ViewPick
{
	my ($i,$i2,$f,$img,$str,$str2,@art,$url);

	#
	$url = "/article/$_[0]";
	$url = UrlFix($url);

	##################################################################################3
	#
	$img = "";
	#
	if( open($f, "$_[0]\_imageurl.txt") )
	{
		#
		$img = <$f>;
		#
		close($f);
	}

	##################################################################################3
	#
	print("
		<table cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	print("
		<a href=\"$url\" class=\"dark\">
		");

	#
	if(IsImage($img))
	{
		print("
			<img src=\"$img\" width=30 height=30 align=\"left\">
			");
	}

	#
	print("
		<font size=\"1\">
		");
	if( open($f, "$_[0]") )
	{
		#
		$str = <$f>;
		print $str;
		#
		close($f);
	}

	# Show number of comments, if any.
	AnyComments($_[0]);

	#
	print("
		</font>
		");


	#
	print("
		</a>

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub ViewPicks
{
	my (@picks,$i,$i2);

	#
	@picks = LoadList("picks.txt");

	#
	print("
		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>
		");

	#
	for($i=$#picks,$i2=0; $i2<2; $i2++,$i--)
	{
		#
		print("
			<td width=50% valign=top>
			");
		if(-e $picks[$i]) {
			ViewPick($picks[$i]);
		}
		print("
			</td>
			");
	}

	#
	print("
		</tr>
		</table>
		<br>
		");
}

#########################################################################################
#
sub PreviewArticle
{
	my (@l,$i,$i2,$i3,$i4,$str,$str2,$JATKUU,$len,$showi,$f,
		$iurl,$WID,$HEI,$opt,$cap,$cap2,$alg,$VS,$HS,$pm,$t,
		$MORE);

	#
	$url = "/article/$_[0]";
	$url = UrlFix($url);

	#
	if($_[2] eq "")
	{
		$len = 250;
	}
	else
	{
		$len = $_[2]/1;
	        $t = (stat($_[0]))[9];
	        $pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	}
	$showi = $_[3];

	#
	$iurl = "";
	if(open($f, "$_[0]\_imageurl.txt"))
	{
		#
		$iurl = <$f>;
		$iurl =~ s/\s//g;
		$iurl =~ s/<br>//ig;
		$opt = <$f>;
		close($f);

		# No animations for front page.
		if($iurl =~ /\/anim/) { $iurl=""; }

		#
		if($_[4] ne "")
		{
			$len /= 2;
			$WID = 64; $HEI = 64;
			$alg = "left";
			$VS = 4;
			$HS = 4;
		}
		else
		{
			$len /= 2;
			$WID = 268; $HEI = 268;
			$alg = "";
			$VS = 8;
			$HS = 0;
		}

		#
		if($_[5]==1)
		{
			$WID = 64;
			$HEI = 64;
		}
	}

	#
	@l = LoadList($_[0]);

	#
	for($i=0; $i<($#l+1); $i++)
	{
		$l[$i] =~ s/<br>//g;
	}

	#
	$cap = $l[0];

	#
	if($_[1] ne "")
	{
		$cap2 = $_[1];
		$cap2 =~ tr/[a-z���]/[A-Z���]/;
		$MORE = ("
		<a href=\"/finnish/$_[1]\" class=news3><b><font size=5>$cap2</font></b></a><br>
		<table width=100% height=4 cellpadding=0 cellspacing=0 bgcolor=#000000>
		<tr>
		<td>
		</td>
		</tr>
		</table>
		<br>
		");
	#	EXPRESS("$TFO $_[1]", "/finnish/$_[1]", "left", $BGBAK2);
	}

	#
	print("
		<table cellpadding=8 cellspacing=0 width=100%>
		<tr>
		<td>

		$MORE
		");
	if($so{'urlp'} eq "") { print Bonus1("$_[0]"); }

	#
	if($_[5] ne "")
	{
		if($so{'urlp'} eq "") {$cap = ("[$pm] $cap");}
		$cap =~ s/^(.{70}).*$/$1\.\.\./g;
	}

	#
	print("
		<a href=\"$url\" class=\"news2\">
		<font size=3>
		<b>
			$cap
		</b>
		</font>
		</a>
		");

	#
	if($_[5] eq "")
	{
		print("<br>");
		print("<font size=1>$pm</font>");
	}

	#
	if($_[5] eq "")
	{
		CrDate($_[0]);
		print "<font color=\"#C0C0C0\" size=\"1\">\n";
		print $aika;
		print "</font><br>\n";
	}

	# Show number of comments, if any.
	AnyComments($_[0]);

	#
	print("
		<table width=100% cellpadding=0 cellspacing=0 bgcolor=#E0E0E0>
		<tr>
		<td>
		");

	# Print image.
	#
	if($iurl ne "" && $showi && $_[5] eq "")
	{
		print("
		<a href=\"$url\" class=\"news1\">
			<img src=\"$iurl\"
				vspace=0 hspace=0 border=1
				width=$WID height=$HEI align=$alg>
		</a>
			");
	}

	# Print any related links.
	#
	if($so{'section'} eq "" && open($f, "$_[0]\_links.txt"))
	{
		print("
<font size=1><b>Aiheeseen liittyv�t:</b></font><br>
		");
		#
		for(; !eof($f); )
		{
			#
			$des1 = <$f>; chomp $des1;
			$url1 = <$f>; chomp $url1;
			$des1 =~ s/^(.{42}).*$/$1.../;
			$des1 =~ s/^\s*//g;
			$des1 =~ s/\s*$//g;
			#
			print("
<font size=1><a href=\"$url1\" class=news2><li>$des1</li></a></font>
				");
		}
		close($f);
	}

	# Print article content.
	#
	loop: for($i=1,$str="",$JATKUU=0; $i<($#l+1); $i++)
	{
		if( length($str) > $len )
		{
			$JATKUU = 1;
			last loop;
		}
		$str2 = $l[$i];
		if(!($str2 =~ /<[x]embed/))	{ $str2 =~ s/http:\/\/(\S)*[\"|\s]//g; }
		$str2 =~ s/<.*?>//g;
		$str = "$str\n$str2";
	}

	#
	if($_[5] eq "")
	{
		#
		$str = substr($str, 0, $len);

		#
		print("

			<table cellpadding=8 cellspacing=0 width=100%>
			<tr>
			<td>

			<font size=2>
			");
		print $str;

		#
		if($JATKUU==1 && $_[5] eq "")
		{
			print "...";
		}

		#
		print("
			</font>

			</td>
			</tr>
			</table>
			");
	}

	print("
			</td>
			</tr>
			</table>
		");



	#
	if($so{'FP_SECTION'} eq "english")
	{
		$STR_VIEW = "View article ...";
	}
	else
	{
		$STR_VIEW = "N�yt� artikkeli ...";
	}

	#
	if($so{'urlp'} eq "")
	{
		print("
			<table width=100% cellpadding=4 cellspacing=0
				bgcolor=\"#800000\">
			<tr>
			<td>
			<div align=right>
				<font size=2>
				<a href=\"$url\" class=\"bright\">
				$STR_VIEW
				</a>
				</font>
				</div>
			</td>
			</tr>
			</table>
			");
	}

	#
	if($so{'urlp'} ne "")
	{
		print("
			<table width=100% cellpadding=4 cellspacing=0
				bgcolor=\"#800000\">
			<tr>
			<td>
			<div>
				<font size=2>
				<a href=\"$url\" class=\"bright\">
				http://www.vunet.world$url
				</a>
				</font>
				</div>
			</td>
			</tr>
			</table>
			");
	}

	#
	print("
		</td>
		</tr>
		</table>
		");
}

#########################################################################################
#
sub IsGoodContent
{
	#
	if($_[0] =~ /\//) { return 0; }
	if($_[0] =~ /\[/) { return 0; }
	if($_[0] =~ /Via Ny Transfer/i) { return 0; }
	if($_[0] =~ /_/) { return 0; }
	if($_[0] =~ /By [a-zA-Z]*/) { return 0; }
	if($_[0] =~ /[0-9]{2}\:[0-9]{2}/) { return 0; }
	if($_[0] =~ /\.htm/) { return 0; }
#	if($_[0] =~ /[a-zA-Z]{3}\s[0-9]*\, [0-9]*\,/) { return 0; }

	#
	return 1;
}

#########################################################################################
#
sub PreviewArticle2
{
	my (@l,$i,$i2,$i3,$i4,$str,$str2,$JATKUU,$len,$showi,$f,
		$iurl,$WID,$HEI,$opt,$cap,$cap2,$alg,$VS,$HS,$pm,$t,
		$MORE);

	#
	$url = "/article/$_[0]";
	$url = UrlFix($url);

	#
	$len = $_[2]/1;
        $t = (stat($_[0]))[9];
        $pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$showi = $_[3];

	#
	$iurl = "";
	if(open($f, "$_[0]\_imageurl.txt"))
	{
		#
		$iurl = <$f>;
		$iurl =~ s/\s//g;
		$iurl =~ s/<br>//ig;
		$opt = <$f>;
		close($f);

		# No animations for front page.
		if($iurl =~ /\/anim/) { $iurl=""; }

		#
		$len /= 2;
		$WID = 64; $HEI = 64;
		$alg = "left";
		$VS = 4;
		$HS = 4;
	}

	#
	@l = LoadList($_[0]);

	#
	for($i=0; $i<($#l+1); $i++)
	{
		$l[$i] =~ s/<br>//g;
	}

	#
	$cap = $l[0];

	#
	if($_[1] ne "")
	{
		$cap2 = $_[1];
		$cap2 =~ tr/[a-z���]/[A-Z���]/;
		$MORE = ("
		<a href=\"/finnish/$_[1]\" class=news3><b><font size=5>$cap2</font></b></a><br>
		<table width=100% height=4 cellpadding=0 cellspacing=0 bgcolor=#000000>
		<tr>
		<td>
		</td>
		</tr>
		</table>
		<br>
		");
	#	EXPRESS("$TFO $_[1]", "/finnish/$_[1]", "left", $BGBAK2);
	}

	#
	print("
		<table cellpadding=8 cellspacing=0 width=100%>
		<tr>
		<td>

		$MORE
		");
	print Bonus1("$_[0]");

	#
	if($_[5] ne "")
	{
		if($so{'urlp'} eq "") {$cap = ("[$pm] $cap");}
		$cap =~ s/^(.{70}).*$/$1\.\.\./g;
	}

	#
	print("
		<a href=\"$url\" class=\"news2\">
		<font size=2>
		<b>
			$cap
		</b>
		</font>
		</a>
		");

	#
	if($_[5] eq "")
	{
		print("<br>");
		print("<font size=1>$pm</font>");
	}

	#
	if($_[5] eq "")
	{
		CrDate($_[0]);
		print "<font color=\"#C0C0C0\" size=\"1\">\n";
		print $aika;
		print "</font><br>\n";
	}

	# Show number of comments, if any.
	AnyComments($_[0]);

	#
	print("
		<table width=100% cellpadding=0 cellspacing=0 bgcolor=#E0E0E0>
		<tr>
		<td>
		");

	#
	if($iurl ne "" && $showi && $_[5] eq "")
	{
		print("
<!--		<a href=\"$url\" class=\"news1\">
			<img src=\"$iurl\"
				vspace=0 hspace=0 border=1
				width=$WID height=$HEI align=$alg>
		</a> ------->
			");
	}

	#
	loop2: for($i=1; $i<($#l+1); $i++)
	{
		if( IsGoodContent($l[$i]) )
		{
			last loop2; 
		}
	}

	#
	loop: for($str="",$JATKUU=0; $i<($#l+1); $i++)
	{
		if( length($str) > $len )
		{
			$JATKUU = 1;
			last loop;
		}
		$str2 = $l[$i];
		if(!($str2 =~ /<[x]embed/))	{ $str2 =~ s/http:\/\/(\S)*[\"|\s]//g; }
		if($str2=~/[A-Z���]{5}/)
		{
			$str2 =~ tr/[A-Z���]/[a-z���]/;
		}
		$str2 =~ s/[\[|\]]//g;
		$str2 =~ s/<.*?>//g;
		$str = "$str\n$str2";
	}

	#
	if($_[5] eq "")
	{
		#
		$str = substr($str, 0, $len);
		$str =~ s/(\S{14})/$1 /g;

		#
		print("

			<table cellpadding=8 cellspacing=0 width=100% height=64>
			<tr valign=top>
			<td>

			<font size=2>
			");
		print $str;

		#
		if($JATKUU==1 && $_[5] eq "")
		{
			print "...";
		}

		#
		print("
			</font>

			</td>
			</tr>
			</table>
			");
	}

	print("
			</td>
			</tr>
			</table>
		");

	#
	if($_[5] eq "")
	{
	}
	else
	{
		if($so{'urlp'} eq "") { print("</li>"); }
	}
	print("
		</td>
		</tr>
		</table>
		");
}

##########################################################
#
sub ViewTopPickFrom
{
	my (@lst,$art,$i,$i2,$i3,$i4,$str,$str2);

	#
	@lst = LoadList("$_[0]/fileindex.txt");

	#
	$art = $lst[$#lst];

	#
	PreviewArticle("$_[0]/$art", "$_[0]");
}

###################################################################################################
#
sub NewsViews
{
	my (@lst,$iq,$i2);
	
	#
	@ls = LoadList("important-sections.txt");

	#
	print("
		<table cellpadding=4 cellspacing=0 width=100%>
		");

	#
	for($iq=0; $iq<($#ls); $iq+=2)
	{
		#
		print("
			<tr valign=top>
			");

		#
		print("<td valign=top width=50%>");
		ViewTopPickFrom($ls[$iq+0]); print("<br>");
		print("</td>");

		#
		print("<td valign=top width=50%>");
		ViewTopPickFrom($ls[$iq+1]); print("<br>");
		print("</td>");

		#
		print("
			</tr>
			");
	}

	#
	print("
		</table>
		");
}

################################################################
sub PrintLinksCalendar
{
		#
		print("
			<table>
			<tr>

			<td width=140 valign=top>
			");

			########## ADD TINY LINK LIST
			Headline($TXT_NEWS_SERVICES);
			ViewLinkList();

			#
			print("
				</td>

				<td width=140 valign=top>
				");

			########## ADD CALENDAR HERE
			Headline($TXT_CALENDAR);
			open(CAL, "./calendar.cgi|");
			@cal = <CAL>;
			close(CAL);
			print (" <font size=\"2\">  ");
			print @cal;
			print (" </font> ");
			print "<br>\n";		
			print("</td>
				</tr>
				</table>");
}

################################################################
sub BigPicksList
{
		my (@adm,$i,$i2,$i3,$i4,$str,$str2,$fz,$fz2,
			$tep,$tep2,$subject,$url);

		#
		@adv = LoadList("$ADVERT_SEC/fileindex.txt");

		#
		print("<br>");
		#
		print("
			<table width=525 cellpadding=0 cellspacing=0>
			<tr>
			<td>
			");
		EXPRESS("$TFO menneet", "/finnish/poimitut");
		OPENTABLE($TABCOL);

		#
        	$NO_ICON = 1;
	        $supersmall = 1;
		$FNSIZE = 3;

		#
		print("
			<table width=510>
			<tr>
			");

		#
		for($i=$#adv-8,$i2=0; $i2<(8*2); $i2++,$i--)
		{
			#
			$url = UrlFix("$adv[$i]");

			#
			if(($i2%8)==0)
			{
				print("<td valign=top width=50%>");
			}

			#
			open($fz, "$ADVERT_SEC/$adv[$i]");
			$subject = <$fz>;
			$subject =~ s/<br>//gi;
			$subject =~ s/\"/''/g;
			close($fz);

			#
			$raj = 0;
			$_tep = $subject;
			$subject = substr($subject, 0, 35);
			if( length($_tep) > length($subject) ) { $raj = 1; }
			if($raj) { $subject = "$subject..."; }

			#
			print("	
				<div>
				");

			#
			print("
				<font size=2>
				<a href=\"/article/$ADVERT_SEC/$url\" class=news1 title=\"$_tep\">
				<img src=\"$ARTEL_GIF\" align=center border=0>
				$subject
				</a>
				</font>
				");

			#
			print("	
				<table width=\"100%\" cellpadding=0 cellspacing=0>
				<tr height=\"1\"><td></td></tr></table>
				</div>
				");

			#
			if(($i2%8)==7)
			{
				print("</td>");
			}
		}

		#
		print("
			</tr>
			</table>
			");

		#
		CLOSETABLE($TABCOL);

		#
		print("
			</td>
			</tr>
			</table>
			");
}

################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$f,$imgurl,$url,
		$str,$str2,$lim,$pm);

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "/article/$_[0]";
	$url = UrlFix($url);

        #
	if(-e $_[0])
	{
	        @art = LoadList("$_[0]");
	}
	else
	{
		return "";
	}

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	$cap =~ s/^(.{$lim}).*$/$1.../;
#	$cap =~ tr/[a-z���]/[A-Z���]/;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#        $cap =~ s/(.{40})/$1<br>/g;

	#
	if( open($f, "$_[0]\_imageurl.txt") )
	{
		$imgurl = <$f>;
		close($f);
		# No animations for front page.
		if($imgurl =~ /\/anim/ || !IsImage($imgurl)) { $imgurl=""; }
	}
	else
	{
		$imgurl = "";
	}

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<table cellpadding=4 cellspacing=0 width=100%>
		<tr>
		");

	#
	$str = ("$str
		<td width=0%>
		");
#	$str = sprintf "$str %s ", Bonus1($_[0]);
	$str = ("
		$str
		</td>	
		");


	#
	$str = ("$str <td valign=top width=10%>");
	if($imgurl eq "")
	{
		$imgurl = "$IMAGES_BASE/document.gif";
	}
	if($imgurl ne "")
	{
		$str = ("$str
			<a href=\"$url\" class=news1>
			<img src=\"$imgurl\" border=0 width=24 height=24>
			</a>
			");
	}
	else
	{
	}
	$str = ("$str </td>");

	#
	$str = ("$str
		<td valign=top width=90%>
                <div>
		<font size=2 face=Times Roman>
		<a href=\"$url\" class=$_[1]>
                $cap
		</a>
		");
	$t = (stat($_[0]))[9];
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($_[0], "news3");
	$str = ("$str
		</font>
                </div>
		</td>


		</tr>
		</table>
                ");

	#
	return $str;
}

###############################################################################################################
#
# [match string] [caption] [max. articles to show] [max. age of an article, in hours]
#
sub NaytaUutisotsikot
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,@adv,$old,
			$fn,$str,$age,$cl,$durl);

		#
		$durl = "$_[0]";
		if($durl=~/\|/)
		{
			$durl = "poimitut";
		}
		$durl = "/finnish/$durl";

		#
		print("
			<table width=100% cellpadding=0 cellspacing=0>
			<tr>
			<td>
			<a href=\"$durl\">$_[1]</a>
			</td>
			</tr>
			</table>

			<table width=100% height=2 cellpadding=0 cellspacing=0 bgcolor=\"#000000\">
			<tr>
			<td>
			</td>
			</tr>
			</table>
			");
##		EXPRESS("$TFO $_[1]", "/finnish/poimitut");
		print("
			<table cellpadding=0 cellspacing=0 width=100%>
			<tr>
			<td>
			");

		#
		if($_[4] ne "")
		{
			$as = $_[4];
		}
		else
		{
			$as = "poimitut"; #$ADVERT_SEC;
		}
		#
		@adv = LoadList("$as/fileindex.txt");
		#
        	$NO_ICON = 1;
	        $supersmall = 1;
		$FNSIZE = 3;
		#
		for($i=$#adv,$i2=0,$i3=0; $i2<1000 && $i3<$_[2]; $i2++,$i--)
		{
			#
			$fn = "$as/$adv[$i]";

			#
			if( !($fn =~ /$_[0]/) ) { goto skip; }

			#
			$age = FileAge($fn);

			#
			$cl = "news2";
			if( $age>=(3600*24) )
			{
			#	$cl = "dark";
			}

			#
			if( ($str=ViewHL($fn,$cl,90)) ne "" )
			{
				$i3++;
				print("	
					$str
				");
			}
skip:
		}	

		#
		if($so{'FP_SECTION'} eq "english")
		{
			$ots = "more items";
		}
		else
		{
			$ots = "lis�� otsikoita";
		}

		#
		print ("
				<a href=\"$durl\" class=dark>
				<font size=\"2\">
				> $ots ...
				</font>
				</a>
			");

		#
		print("
			</td>
			</tr>
			</table>
			");

		#
		return();
}

#
sub Erikoinen2
{
	#
	print("
		<a href=\"http://www.vunet.world/?id=4x65\" class=news2>
		<img src=\"$IMAGES_BASE/vappu.jpg\" border=1>
		</a><br><br>
		");
}

#
sub VideoArkistoAd
{
	my @lst,$PAIVAN;

	#
	@lst = LoadList("cfg/pilakuva.txt");
	$PAIVAN = $lst[0];

	#
	print("

<table width=164 cellpadding=0 cellspacing=0>
<tr>
<td>

<font size=1>
<div align=center>
<a href=\"/?to=$IMAGES_BASE/pilakuva$PAIVAN.jpg\" class=news2>
P�iv�n Pilakuva:
<img src=\"$IMAGES_BASE/sm_pilakuva$PAIVAN.gif\"
	border=4>
</a>
</div>
<br>
</font>

</td>
</tr>
</table>

<font size=1>

<a href=\"http://www.vunet.world/?q=Video%3A&maxts=80&page=0&section=viihde&FP_SECTION=finnish\" class=news2>
<img src=\"$IMAGES_BASE/anim_videoita.gif\" border=4>
</a>
</font>

<a href=\"/finnish/tyopaikat\" class=news2>
<img src=\"$IMAGES_BASE/banneri_tyopaikat2.gif\" border=4>
</a>

		");

}

################################################################
#
sub Hullut
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,@adv);

		#
		print("
			<table cellpadding=4 cellspacing=0
				width=400>
			<tr>
			<td>
			");

		#
		EXPRESS("$TFO muistoja menneisyydest�", "/finnish/poimitut");
		OPENTABLE($TABCOL);

		#
		@adv = LoadList("hullut.txt");
		#
        	$NO_ICON = 1;
	        $supersmall = 1;
		$FNSIZE = 3;
		#
		loop: for($i=$#adv,$i2=0; $i2<8; $i2++,$i--)
		{
			if($adv[$i] eq "" || $i<0) { last loop; }
			ViewHL( "$adv[$i]");
			print("	
				<table cellpadding=0 cellspacing=0 width=\"100%\"><tr height=\"2\"><td></td></tr></table>
				");
		}			

		#
		CLOSETABLE($TABCOL);

		#
		print("
			</td>
			</tr>
			</table>
			");

		#
		return 0;
}

################################################################
#
sub BannerBlock
{
	#
	print("<br>");

	#
	print("
<div align=center>
<a href=\"http://www.vunet.world/music.pl\" class=news2>
<font size=1>
<img src=\"$IMAGES_BASE/jukebox.gif\" border=2>


		<a href=\"/C/top/index.html\">
<img src=\"$IMAGES_BASE/suosituimmat2.gif\" class=news1>
</a>
		<div align=center>
		<a href=\"/C/alltop/index.html\">
<img src=\"$IMAGES_BASE/suosituimmat.gif\" class=news1>
</a>
		</div>
		<br>
	");
}

#######################################################################################
#
sub AdditionalFrontPage
{
		#
		Hullut();
		NewsImages();
		#
		BigPicksList();
		print("<br>");
		NewsViews();

		#
		print("<br><br>");
		if($so{'FP_SECTION'} eq "english")
		{
			VTVBAN2();
		}
		else
		{
			VTVBAN();
		}
}

#################################################################################################################
#
sub FinnishFP1
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10);

		#
		$sav1 = $MAX_PRV_ARTICLE_CHARS;
		$sav2 = $ARTICLE_PRV_EXTEND;
		$sav3 = $NO_SECTION_HL;
        	$sav4 = $NO_ICON;
	        $sav5 = $supersmall;
		$sav6 = $SHORTENCAPTIONS;
		$MAX_PRV_ARTICLE_CHARS = 800;
		$ARTICLE_PRV_EXTEND = 1;
		$NO_SECTION_HL = 1;
		$SHORTENCAPTIONS = 0;

		###################################################################################
		#
		# CENTER ALIGNMENT BEGINS
		#
		print("
			<div align=center>
			");

		###################################################################################
		#
		print("

		<table width=100% cellpadding=4 cellspacing=0>
		<tr>
		<td>

		<table width=100%
			bgcolor=\"#00C0FF\"
			cellpadding=8
			cellspacing=0>
		<tr valign=top>
		<td width=50%>
		<form action=\"http://www.vunet.world/?\" name=FORM1>
		<input type=text name=q value=\"\" size=30>
		<input type=submit value=\"Hae\">
		<input type=hidden name=cmd value=go>
		</td>
		<td width=50%>
		Etsi:
		<input type=radio name=site value=\"www.vunet.world\" 
				checked> Vunetin uutisia
		<input type=radio name=site value=\"\"> Webist�
		</form>
		</td>
		</tr>
		</table>

 		<script language=\"javascript\">
			function sf()
			{
				document.FORM1.q.focus();
			}
		</script>

		</td>
		</tr>
		</table>

		<table cellpadding=0 cellspacing=0>
		<tr>
		");

		# MAIN ARTICLE, FRONT PAGE ARTICLE.
		@pick = LoadList("pick.txt");

		###################################################################################
		print ("
			<td width=280 style=\"vertical-align: top;\">
			");
		$FNSIZE = "4";
		$i = $#adv;
		print("
			<table cellspacing=0 cellpadding=0 width=100%>
			<tr><td>
			");
		PreviewArticle($pick[0], "", "1000", "TRUE", "");
		print("
			</td></tr>
			</table>
			");

		#
		print "</td>\n";

		###################################################################################
		print ("
			<td width=360 style=\"vertical-align: top;\">


			<table cellspacing=0 cellpadding=8 width=\"100%\">
			<tr>
			<td style=\"vertical-align: top;\">

			");

		#
NaytaUutisotsikot("tiedotteet|ulkomaat|tiede|kotimaa|talous", "Uutiss�hkeet", 15, 
1600);


		#
		print("<br>");
		#
		print("
			<table width=100% cellpadding=4 cellspacing=0
				bgcolor=\"#0000FF\">
			<tr>
			<td>
			<font color=\"#FFFF00\"><i>Kaksi mielenkiintoista</i></font>
			</td>
			</tr>
			</table>

			");
		OPENTABLE($TABCOL);
		print("
			<br>
			<div align=center>
			");
		ViewPicks();
		print("
			</div>
			");
		CLOSETABLE($TABCOL);


		#
#		BannerBlock();

		###################################################################################
		#
		print("		
					</td>
					</tr>
					</table>


				</td>

			");

		###################################################################################
		#
		print("
		</tr>
		</table>
		");

		###################################################################################
		#
		# CENTER ALIGNMENT ENDS
		#
		print("
			</div>
			");



		#
		$ARTICLE_PRV_EXTEND = $sav2;
		$MAX_PRV_ARTICLE_CHARS = $sav1;
		#
		$NO_SECTION_HL = $sav3;
		$NO_ICON = $sav4;
		$supersmall = $sav5;
		$SHORTENCAPTIONS = $sav6;
}

#################################################################################################################
#
sub ESecView
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,$se);

		# MAIN ARTICLE, FRONT PAGE ARTICLE.
		$se = $_[0];
		@pick = LoadList("$se/fileindex.txt");
		@pick = reverse @pick;

		###################################################################################
		#
		print("
<table width=100% cellpadding=8 cellspacing=0
	bgcolor=#0080FF>
<tr>
<td>
<font size=6 class=Caps color=#00FFFF>
$_[2]
</font>
</td>
</table>
			");

		###################################################################################
		$FNSIZE = "4";
		#
		for($i=0; $i<($#pick+1) && $i<$_[1]; $i+=4)
		{
			print("
				<table cellspacing=0 cellpadding=0 width=100%>
				<tr valign=top>
				");

			#
			for($i2=0; $i2<4; $i2++)
			{
				print("
					<td width=25%>
						");
				PreviewArticle2("$se/$pick[$i+$i2]", "", "100", "TRUE", "");
				print("	
					</td>
					");
			}

			#
			print("
				</tr>
				</table>
				");
		}
}

#################################################################################################################
#
sub EnglishFP1
{
		my ($i,$i2,$i3,$i4,@adv,$sav1,$sav2,$sav3,$sav4,
			$sav5,$sav6,$sav7,$sav8,$sav9,$sav10,$se);

		#
		$sav1 = $MAX_PRV_ARTICLE_CHARS;
		$sav2 = $ARTICLE_PRV_EXTEND;
		$sav3 = $NO_SECTION_HL;
        	$sav4 = $NO_ICON;
	        $sav5 = $supersmall;
		$sav6 = $SHORTENCAPTIONS;
		$MAX_PRV_ARTICLE_CHARS = 800;
		$ARTICLE_PRV_EXTEND = 1;
		$NO_SECTION_HL = 1;
		$SHORTENCAPTIONS = 0;

			print("
		<table width=750 cellpadding=0 cellspacing=0>
		<tr>
		<td>
			<div align=center>
			<br>
			<font size=5>
			Vunet News Delivery 24H.
			</font>
			<br>
			<a href=\"/english/english\" class=news1>
			See also editor's picks.</a><br>
			<a href=\"/C/finnish/index.html\" class=news1>
			Looking for <b>Finnish</b> news?</a><br>
			<a href=\"http://www.vunet.world/?q=Video%3A&maxts=80&page=0&section=viihde&FP_SECTION=finnish\" class=news1>
			Also see our very popular <b>video archive</b>.</a>
			</div>
		</td>
		</tr>
		</table>
		<br>
					");

	
		###################################################################################
		#
		# CENTER ALIGNMENT BEGINS
		#
		print("
			<div>
			");

		###################################################################################
		#
		print("
		<table cellpadding=16 cellspacing=0 width=750>
		<tr>
		<td>
		");

		#
		print("
			<table width=100% cellpadding=8 cellspacing=0>
			<tr valign=top>
			");

		#
		print("
			<td width=50%>
			");
		NaytaUutisotsikot("viihde", "Videos", 15, 24*3600);
		print("
			</td>
			");

		#
		print("
			<td width=50%>
			");
		NaytaUutisotsikot("progressive", "Latest news", 15, 24*3600, "progressive");
		print("
			</td>
			");

		print("
			</tr>
			</table>
			");

		#
		print("<br>");
		ESecView("progressive", 16,	"Progressive news");
		ESecView("english", 8,		"Editor's picks");
		ESecView("global", 8,		"Global warming");

		###################################################################################
		#
		print("
		</td>
		</tr>
		</table>
		");

		###################################################################################
		#
		# CENTER ALIGNMENT ENDS
		#
		print("
			</div>
			<br>
			");



		#
		$ARTICLE_PRV_EXTEND = $sav2;
		$MAX_PRV_ARTICLE_CHARS = $sav1;
		#
		$NO_SECTION_HL = $sav3;
		$NO_ICON = $sav4;
		$supersmall = $sav5;
		$SHORTENCAPTIONS = $sav6;
}

#
sub NewsScroller
{
	print("
<center>
<APPLET CODE=\"short_ticker.class\" CODEBASE=\"http://newsticker.shortnews.com/com/newsticker/\" WIDTH=\"335\" HEIGHT=\"18\"><PARAM NAME=\"RUBRIK1\"       VALUE=\"default\"><PARAM NAME=\"SORT\"          VALUE=\"1\"><PARAM NAME=\"SPARTE\"        VALUE=\"4\"><PARAM NAME=\"BGCOLOR\"       VALUE=\"FFFFFF\"><PARAM NAME=\"FGCOLOR\"       VALUE=\"6633FF\"><PARAM NAME=\"LINKCOLOR\"     VALUE=\"000088\"><PARAM NAME=\"HOVERCOLOR\"    VALUE=\"0000ff\"><param name=\"UNDERLINELINKS\"  value=\"1\"><param name=\"FONTTYPE\"    value=\"arial\"><PARAM NAME=\"FONTSIZE\"      VALUE=\"11\"><PARAM NAME=\"MOUSEOVERHOLD\" VALUE=\"1\"><PARAM NAME=\"SPEED\"         VALUE=\"17\"><PARAM NAME=\"U_ID\"          VALUE=\"58471\"></APPLET>
</center>
		");
}

################################################################
#
# CNN stylish front page.
#
sub FinnishFP
{
		my ($i,$i2,$i3,$i4,@adv);

		###################################################################################
		#
		print("

		<table cellpadding=8 cellspacing=0>
		<tr>
		<td>
		");

		###################################################################################
		#
		FinnishFP1();

		###################################################################################
		#
		print("
		</td>
		</tr>
		</table>
		");
}

################################################################
#
# VAI FINNISH NEWS FRONT PAGE
#
# args: [file stream] [important sections .txt]
#
sub FinnishNews
{
		my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$keyword,$sta,$fz,@il,
			$of);

		#
		if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

		#####################################################
		if( NoTracking() )
		{
			#
			MenuSystem();
		}

		#####################################################
		# UUSIMMAT UUTISET
		#####################################################

		#
		open($fz, "important-sections.txt");
		@isections = <$fz>;
		for($i=0; $i<($#isections+1); $i++) { chomp $isections[$i]; }
		close($fz);

		# Search for the latest article.
		for($i=0; $i<($#isections+1); $i++)
		{
			$lat[$i] = huntn($isections[$i]);
			if($lat[$i] eq "")
			{
				die "empty string returned by huntn on \"$isections[$i]\" i=$i";
			}
		}

		#
		$FNSIZE = "4";
		$BDR_COLOR1 = "#F0F0F0";
		$BDR_COLOR2 = "#408040";

		## TABLE BEGINS (1)
		printf $of ("
			<table
				cellpadding=\"8\"
				cellspacing=\"0\"
				style=\"border:0px solid $BDR_COLOR1;\">
			");

		###############################################################################
		# PICK UP THE SECTIONS
		#
		if($VIEWING_METHOD eq "VARIOUS")
		{
			# Latest from all sections.
			for($i=0,$i2=0; $i2<($#isections+1); $i+=2,$i2++)
			{
				$il[$i+0] = $lat[$i2];
				$il[$i+1] = $isections[$i2];
			}
		}
		else
		{
			# Pick from "poimitut" section.
			@poi = LoadList("poimitut/fileindex.txt");
			for($i=0,$i2=0,$i3=$#poi; $i2<14; $i+=2,$i2++,$i3--)
			{
				$il[$i+0] = $poi[$i3];
				$il[$i+0] =~ s/\.\.\///;
				$il[$i+1] = PathToSection($il[$i+0]);
			}
		}

		###############################################################################
		#
		for($i=0; $i<($#il/2); $i++)
		{
			#
			if( !($i&1) )
			{
				printf $of "<tr>";
			}

			#
			if($i&1)
			{
			#	katkos();
			}

			#
			printf $of ("
	<!--- test lala -->
	<td style=\"vertical-align: top; text-align: center; border:0px solid $BDR_COLOR2;\"
		width=\"50%\">
				");

			#
			$sect = $il[$i*2+1];
			ViewArticleFileHeadline( "$il[$i*2+0]", $of );

			#
			printf $of ("</td> <!--- test lala II --->");

			#
			if( ($i&1) )
			{
				printf $of "</tr>";
			}
		}

		# TABLE ENDS (1)
		#
		printf $of ("</table>");
		$FNSIZE = "";

		#
}

##########################################################
#
# ENGLISH NEWS
#
sub EnglishNews
{
	my ($of);

	#
	if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

	#
	FreeNews($of);
}

##########################################################
sub TableBeg
{
	print("
		<table
			cellspacing=2
			cellpadding=0>

		<tr valign=top>

		<td></td>
		</tr>

		<tr>

		<td width=28>
		</td>

		<td>
		");
}

##########################################################
sub TableEnd
{
	print("
		</td>
		</tr>
		</table>
		");
}

##########################################################
sub JS_UserIDGenerator
{
	#
	print("
		<script language=\"javascript\">
		
		jobjob();
		
		function jobjob()
		{
		        if(document.cookie==\"\")
		        {
		                x = Math.random()*10000000;
		                setCookie(\"userid\", x, 3600);
		        }
		        else
		        {
		        }
		}
		
		function setCookie(NameOfCookie, value, expiredays)
		{
		
		var ExpireDate = new Date ();
		ExpireDate.setTime(ExpireDate.getTime() + (expiredays * 24 * 3600 * 1000));
		
		document.cookie = NameOfCookie + \"=\" + escape(value) + ((expiredays == null) ? \"\" : \"; expires=\" + ExpireDate.toGMTString());
		}
		</script>
	");
}


##########################################################
sub FinnishNewsPipe
{
	my ($fin1,$fh);

	#
	open($fh, '>', \$fin1) || die "can't create pipe fin1";
	FinnishNews($fh);
	close($fh);

	#
	return $fin1;
}

##########################################################
sub JSFriendly
{
	my ($str);

	#
	$str = $_[0];
	#
	$str =~ s/\n/ /g;
	$str =~ s/\r/ /g;
	$str =~ s/\\/\\\\/g;
	$str =~ s/\"/\\\"/g;
	$str =~ s/\'/\\\'/g;
	$str =~ s/\%/\\\%/g;

	#
	return $str;
}

##########################################################
sub ActiveFinSections
{
	my ($i,@lst,$ac1,$ac2,$def);

	#
	$ac1 = "#F0F0F0";
	$ac2 = "#C0C0C0";

	#
	$VIEWING_METHOD = "VARIOUS";
	$fin[0] = FinnishNewsPipe();
	$def = $fin[0];
	$fin[0] = JSFriendly($fin[0]);
	$VIEWING_METHOD = "LATEST";
	$fin[1] = FinnishNewsPipe();
	$fin[1] = JSFriendly($fin[1]);

	#
	@lst = LoadList("fpsubsecs.txt");
	print("
			<script language=\"javascript\">


			function Call1(e, c, h)
			{
				e.style.cursor=h;
				e.style.backgroundColor = c;
			}
			function ChangeContents(t, wh, txt, which)
			{
				o = document.getElementById(t);
				o.innerHTML = wh;
				if(which==0) { o.style.backgroundColor = '#FFFFFF'; }
				if(which==1) { o.style.backgroundColor = '#E0FFFF'; }

				o = document.getElementById('status1');
				o.innerHTML = txt;
			}

			</script>




			<center>
			<table
				cellpadding=\"0\"
				cellspacing=\"0\">
			<tr>
				<td>
				<center>
				<font size=\"6\">
				<div id=\"status1\">$lst[0]</div>
				</font>
				</center>
				</td>
			</tr>

			</table>

			<table width=\"100%\"
				cellpadding=\"0\"
				cellspacing=\"0\">	
			<tr>


			<!--BINGOBINGO-->
		");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		print("
				<script language=\"javascript\">
				function ClickHandler$i(th, name, which)
				{
					ChangeContents('newsview1', '$fin[$i]', name, which);
				}
				</script>
		");

		#
		printf("
				<td width=\"50%\"
					bgcolor=\"$ac1\"
					onMouseOver=\"Call1(this, '$ac2', 'hand');\"
					onMouseOut=\"Call1(this, '$ac1', 'arrow');\"
					onClick=\"ClickHandler$i(this, '$lst[$i]', $i);\">
				<center>
				<font size=\"1\">
				> $lst[$i]
				</font>
				</center>
				</td>
			");
	}

	#
	print("	
			</center>

			</tr>
			</table>
		");

	#
	print("
		<table
				cellpadding=\"0\"
				cellspacing=\"0\">
		<tr>
		<td id=\"newsview1\">
		$def
		</td>
		</tr>
		</table>
		");
}

##########################################################
#
# FP_SECTION=shop
#
sub VAIShop
{
	my ($i,$i2,$i3,$i4,
		$str,$str2,
		@lst);

	#
	@lst = LoadList("shop/fileindex.txt");

	#
	$FNSIZE = 4;
	$NO_SECTION_HL = 1;

	#
	print("
		<table>
		");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		if( ($i%3)==0 ) { print "<tr>"; }
		print "<td width=\"33%\">\n";
		ViewArticleFileHeadline("shop/$lst[$i]");
		print "</td>\n";
		if( ($i%3)==2 ) { print "</tr>"; }
	}

	#
	print("
		</table>
		");
}

#################################################################################################
#
#
sub Controls
{
		my ($fn,$f,$i,$i2,$str,@lst,$c1,$c2,$c3,$c4,$c,@sp,@sp2,@sp3,@sp4,$var,$pg);
		my @opt = (
			"text q ",
			"select maxts 10,10 20,20 40,40 80,80 200,200 2000,2000",
			"checkbox ho compact",
			"checkbox urlp URLs"
			);

		#
		$c = "#00F8F8";
		$c1 = $c;
		$c2 = $c;
		$c3 = $c;
		$c4 = $c;

		#
		print ("
			<table cellpadding=4 cellspacing=0 width=100%>
			<tr valign=top>

			");

		# Tell user the range of articles currently being shown.
		$alku = $BEGART+1;
		#####$loppu = $MAX_HEADLINES_TO_SHOW+$BEGART;
		$loppu = $so{'maxts'}+$BEGART;
		$ARTS_HTML = "$ARTIK <b>$alku-$loppu</b>";
		print "<td width=20% bgcolor=\"$c1\"><font size=2>$ARTS_HTML</font></td>";

		#
		$str = "/$so{'FP_SECTION'}/$section";
####		$str = "/?section=$so{'section'}&FP_SECTION=$so{'FP_SECTION'}";


		#
		if( $so{'FP_SECTION'} eq "english" )
		{
			$NAKY = "Max. articles per view:";
			$NKAI = "Show all";
			$PIIL = "Hide images";
			$PIIL2= "Show images";
			$HO =  "Less verbose";
			$HO2 = "More verbose";
		}
		else
		{
			$NAKY = "Max. artikkeleita n�kym�ss�:";
			$NKAI = "N�yt� kaikki";
			$PIIL = "Piilota kuvat";
			$PIIL2= "N�yt� kuvat";
			$HO =  "Otsikot";
			$HO2 = "Jutut";
		}

		#
		$ho_url  = "$str&maxts=$so{'maxts'}&ho=1";
		$ho2_url = "$str&maxts=$so{'maxts'}&ho=";
		if($so{'ho'}!=1) { $oho=$HO; $oho_url = $ho_url; } else { $oho = $HO2; $oho_url = $ho2_url; }

		#
		print("
			<td width=60% bgcolor=\"$c2\" class=formx>
			<font size=2>

<form action=\"/?\">	");

		#
		for($i=0; $i<($#opt+1); $i++)
		{
			#
			@sp = split(" ", $opt[$i]);

			#
			if($sp[0] eq "select")
			{
				#
				$var = $sp[1];
				print("<select name=$var>");
				for($i2=2; $i2<($#sp+1); $i2++)
				{
					@sp2 = split(",", $sp[$i2]);
					if($so{$var}==$sp2[0]) { $str="selected"; } else { $str=""; }
					print("<option value=\"$sp2[0]\" $str>$sp2[1]</option>");
				}
				print("</select");
			}

			#
			if($sp[0] eq "text")
			{
				print("<input type=$sp[0] name=$sp[1] value=$so{$sp[1]}>");
			}

			#
			if($sp[0] eq "checkbox")
			{
				if($so{$sp[1]}!=0){$var="checked";} else {$var="";}
				print("<input type=$sp[0] name=$sp[1] value=1 $var>$sp[2] ");
			}
		}
		

		#
		$pg = sprintf "%d", $so{'page'};
		print("
<input type=\"hidden\" name=\"page\" value=\"$pg\">
<input type=\"hidden\" name=\"section\" value=\"$so{'section'}\">
<input type=\"hidden\" name=\"FP_SECTION\" value=\"$so{'FP_SECTION'}\">
<input type=\"submit\">
</form>

			<!---
			$NAKY<br>
			<a href=\"$str&maxts=10000000&ho=$so{'ho'}\" class=news2>$NKAI</a> - 
			<a href=\"$str&maxts=10&ho=$so{'ho'}\" class=news2>10</a> - 
			<a href=\"$str&maxts=20&ho=$so{'ho'}\" class=news2>20</a> - 
			<a href=\"$str&maxts=40&ho=$so{'ho'}\" class=news2>40</a> - 
			<a href=\"$str&maxts=80&ho=$so{'ho'}\" class=news2>80</a> - 
			<a href=\"$str&maxts=200&ho=$so{'ho'}\" class=news2>200</a> 
			<a href=\"$oho_url\" class=news2>$oho</a> 
			<a href=\"$str&printable=1&maxts=$so{'maxts'}&ho=$so{'ho'}\" target=\"_blank\"
			class=news2>PRINT</a>
			<a href=\"$str&printable=$so{'printable'}&urlp=1&maxts=$so{'maxts'}&ho=$so{'ho'}\"
			class=news2>URLs</a>
			--->
			</td>
			");
	
		# Previous page link.
		print("
				<td width=10% bgcolor=\"$c3\">
				<font size=1>
			");
		$i = $BEGART-$so{'maxts'};
		if($i>=0 || $BEGART!=0)
		{
			if($i<0) { $i=0; }
			print ("
<a href=\"/?section=$keyword&page=$i&FP_SECTION=$so{'FP_SECTION'}&maxts=$so{'maxts'}&ho=$so{'ho'}\"
				class=news2>
				<< last $so{'maxts'}
				</a>
				");
		}
		print("
				</font>
				</td>
			");

		#
		if( ($so{'maxts'}+$BEGART) <= $#fileindex)
		{
			#
			$SEU = "next $so{'maxts'} >>";

			# Next page link.
			$i = $BEGART+$so{'maxts'};
			# FIX THIS
			$NEXT_PAGE_HTML = sprintf("
				<div align=right>
<a href=\"/?section=$keyword&page=$i&FP_SECTION=$so{'FP_SECTION'}&maxts=$so{'maxts'}&ho=$so{'ho'}\"
					class=news2>
				$SEU
				</a>
				</div>
				");
		}
		else
		{
			$NEXT_PAGE_HTML = "";
		}

		#
		print("
			<td width=10% bgcolor=\"$c4\">
			<font size=1>$NEXT_PAGE_HTML</font>
			</td>
			");

		#
		print("
			</tr>
			</table>
			");
}

##########################################################
#
# Display information for a section.
#
sub DisplayInfo
{
	my ($fn,$f,$i,$i2,$str,@lst);

	#
	$fn = "$_[0]/description.nfo";

	#
	if(!-e $fn)
	{
		#
		open($f, ">$fn");
		close($f);
	}

	#
	@lst = LoadList($fn);

	#
	print("
		<table width=100%>
		<tr valign=top>
		");

	#
	print("
		<td width=60%>
		<font size=2>
		");
	if($so{'page'} eq "")
	{
		for($i=0; $i<($#lst+1); $i++)
		{
			print "$lst[$i]\n";
		}
	}
	print("
		</td>
		");

	#
	print("<td width=10%>");
	if(NoTracking())
	{
		#
		print("
			<div align=right>
			<font size=1>
			<a href=\"http://www.vunet.world/~vai/cgi-bin/admin/editart.pl?FILE=$_[0]/description.nfo&BAREHTML=true&PLAIN=true&RETURL=/$so{'FP_SECTION'}/$_[0]\">
			> muokkaa
			</a>
			</font>
			</div>
			");
	}
	print("</td>");

	#
	print("
		<td width=30%>
			<div align=right>
			<font size=2>($_[0]: <b>$#fileindex</b> artikkelia)</font>
			</div>
		</td>
		");

	#
	print("
		</tr>
		</table>
		<br>
		");
}

##########################################################
#
sub arthl
{
	my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$sta,
		$fz,@il,$str,$str2,$f,@lst);

	#
	if( !(-e $_[0]) ) { return(); }
	@lst = LoadList($_[0]);

	#
	for($i=0, $str=""; $i<($#lst+1); $i++)
	{
		#
		$str = "$str $lst[$i] ";
	}
	##open($f, "$_[0]") || return "";
	##$str = <$f>;
	##$str = "$str <$f>";
	##$str=~s/<.*?>//g;
	return $str;
}

##########################################################
#
sub SeHead
{
	my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$sta,$fz,@il,$cap);

	#
	$cap = $so{'section'};
#	$cap =~ tr/[a-z���]/[A-Z���]/;	

	#
	print("
<table width=100% cellpadding=0 cellspacing=0>
<tr>
<td>
	<font size=6 class=Caps color=#C00000>
	<b>$cap</b>
	</font>
</td>
</tr>
</table>

<table width=100% height=6 cellpadding=0 cellspacing=0
	bgcolor=\"#000000\">
<tr>
<td>
</td>
</tr>
</table>
		");
}

##############################################################################################################
#
# Render articles section for specified section.
#
sub HandleSection
{
	my ($i,$i2,$i3,$i4,$co,$alku,$loppu,$sta,$fz,@il);

	##########################################################################
	if($so{'maxts'} eq "")
	{
		$so{'maxts'} = "10";
	}

	##########################################################################
	$keyword = $_[0];

	##########################################################################
	# Let's see what kind of articles we have on the list.
	if(!($keyword =~ /\&/)) { OpenIndex("./$keyword/fileindex.txt"); }

	#
	if($section ne "")
	{
		#
		$MAX_HEADLINES_TO_SHOW = $MAX_STORIES_TO_SHOW;
	}

	#
	if($MAX_HEADLINES_TO_SHOW > ($#fileindex))
	{
#		$MAX_HEADLINES_TO_SHOW = ($#fileindex)+1;
	}

	#
	if($SKIP_HUNT) { goto pasthunt; }

	#########################################################################
	# Print until "$keyword" is found.
	loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
	{
		if($section eq "")
		{
			if($web[$i] =~ /ENTERHERE_$keyword/i)
			{
				$found=1;
				last loop1;
			#	print "Found ENTERHERE_$keyword.\n";
			}
		}
		else
		{
			if($web[$i] =~ /enterhere_section/i)
			{
				$found=1;
			}
		}
		print $web[$i];
	}
	$wherebe=$i;


	#
	if($section ne "") { TableBeg(); }

	#
	if( !($keyword =~ /\&/) )
	{
		SeHead();
	}

	#
	if( $keyword =~ /\&/ )
	{
		JS_UserIDGenerator();
	}


pasthunt:

	###############################################################
	#
	# Main section
	#
	if($keyword =~ /\&/)
	{
		#
		if($so{'FP_SECTION'} eq "finnish")
		{
			#
			$VIEWING_METHOD = "VARIOUS";

			#
#			print("	
#				<center>
#				<font size=5 color=\"#FF0000\">
#				Osaa portaalista kirjoitetaan uudelleen....
#				</font>
#				</center>
#				");

			#
		#	open($fh, '>', \$fin1) || die "can't create pipe fin1";
		#	FinnishNews($fh);
		#	close($fh);
		#	print $fin1;
		}

		# ENGLISH NEWS
		if($so{'FP_SECTION'} eq "english")
		{
	               # NewsScroller();
		       # EnglishNews();
		}

		# VAI SHOP
		if($so{'FP_SECTION'} eq "shop")
		{
			VAIShop();
		}

		#
		return false;
	}

	#########################################################################
	#
	# << PREVIOUS 5  >> NEXT 5
	#
	# View article catalog view range.
	#

	#
	print("
		<br>
		<table cellpadding=8 cellspacing=0 width=100%>
		<tr>
		<td width=75%>
		");

	#
	if($section ne "")
	{
		#
		if( $so{'FP_SECTION'} eq "english" )
		{
			$ARTIK = "articles";
		}
		else
		{
			$ARTIK = "artikkelit";
		}


		#
		DisplayInfo($_[0], $#fileindex);
		Controls();

		#
		print "</center>\n";
	}

	#########################################################################
	#
	# <				> [section name]
	# Add section's own image to the right.
	#
	if($section ne "")
	{
	#	print "<img src=\"$IMGBASE/$keyword.jpg\" align=\"right\"\n";
	#	print " alt=\"$keyword\">\n";


	#	print "<center>\n";
	#	print "<b><h2>$section</h2></b>\n";
	#	print "</center>\n";
	}

	# DESCRIPTION.
	if($section eq "" || ($supersmall))
	{
		print(" <div><a href=\"/?section=$_[0]&FP_SECTION=$so{'FP_SECTION'}\"> ");
		Headline($_[0]);
		print(" </a></div> ");
	}


	#########################################################################
	# View article headlines.
	# XAF123
loopo: for($coz=1,$i=$#fileindex-$BEGART;
		$i>=0;
			$i--)
	{

		#
		if( $_[0] eq $ADVERT_SEC || $_[0] ne "" ) {
			#
			if( $_[0] eq $ADVERT_SEC && $supersmall )
			{
				if( $coz > $MAX_ADVERTSEC_TO_SHOW )
				{
					last loopo;
				}
			}

			else
			{
				#
				#####	if( $coz > $MAX_STORIES_TO_SHOW ) { last loopo; }
				if( $coz > $so{'maxts'} )
				{	
					# Last article on newswire.pl?section=something
					#
					last loopo;
				}
			}
		}
		else
		{
			#
			if( 	($coz>($MAX_HEADLINES_TO_SHOW+1) && $supersmall) )
			{
				last loopo;
			}
			#
			if($coz>4 && !$supersmall)
			{
				last loopo;
			}
		}

		#
		if($_[0] eq $ADVERT_SEC && $coz > $MAX_ADVERTSEC_TO_SHOW
			&& $supersmall)
		{
			last loopo;
		}
		#
		if( $fileindex[$i] ne "" )
		{
			#
			if( $so{'q'} eq "" || arthl("$keyword/$fileindex[$i]")=~/$so{'q'}/i )
			{
				# View the article partly.
				if($section ne "")
				{
					$ARTICLE_PRV_EXTEND = 0;
					print("
						<table width=100% bgcolor=#F0FFFC border=0
							cellpadding=0 cellspacing=0>
						<tr>
						<td>
						");
				}
				PreviewArticle("$keyword/$fileindex[$i]", "", "200", "TRUE", "TRUE", $so{'ho'});
				$coz++;
				if($section ne "")
				{
					print("
						</td>
						</tr>
						</table>
						");
				}
			}
		}

	}

	#
	if($coz<=1)
	{
			print "No result(s).\n";
	}

	#
	if($section ne "")
	{
		Controls();

	#
	print("
		</td>

		<td width=25>
		</td>

		</tr>
		</table>
		");
	}

	#
	if(!$supersmall)
	{
		print "<br>\n";
		print "<br>\n";
	}

	#########################################################################
	# For main page view. Add link to the news section.
	if($section eq "" && !$supersmall)
	{
		print ("<a href=\"/?section=$keyword&page=0&FP_SECTION=$so{'FP_SECTION'}\" style=\"color: rgb($LINKCOLOR);\">
			<img src=\"$IMGBASE/kansio.gif\" alt=\">>\" border=\"0\" align=\"center\">
			 $keyword</a>
			");
		print "<br>";
	}
	if(!$supersmall) { print "<br>\n"; }


	#
	if($section ne "") { TableEnd(); }
}






###########################################################################################################
#
# VIEW LINK LIST
#
sub ViewLinkList
{
		#################### SMALL LINK LIST
		#
		print ("
			<table align=\"center\"
				bgcolor=\"#F8F8FF\"
				border=\"1\"
				vspace=\"4\" hspace=\"4\"
				cellpadding=\"4\" cellspacing=\"0\">
				<tr>
				<td>

				<div align=\"left\">
			");

		#
		open($fzz, "2linklist.txt");
		@tmp = <$fzz>;
		for($i=0; $i<($#tmp+1); $i++) { chomp $tmp[$i]; }
		close($fzz);
		@l = @tmp;

		#
		print(" <font size=\"1\"> ");

		#
		for($i=0,$co=0; $i<$#l,$co<10; $i+=2,$co++)
		{
			#
			if($i) { print "-"; }

			#
			if( ($l[$i+1] =~ /http\:\/\//i) )
			{
				#
				print("
					<a href=\"$l[$i+1]\"
						target=\"_blank\">
					$l[$i+0]
					</a>
					");
			}
			else
			{
				$i++;
			}
		}

		#
		print("<br>
				<center>
				<a href=\"/links.pl\">
				> more links
				</a>
				</center>
		
				</font>


				</div>
				</td>
				</tr>
			</table>
			");

		#
	#	print("
	#		<center>
	#		Ilmoitus, 9.6.2004:<br>
	#		VAI on kes�lomalla pari viikkoa.<br>
	#		Kirjoittelua jossain m��rin v�hemm�n loma-aikana.<br>
	#		Edistyksellist� kes��, toivottaa VAI-toimituskunta !
	#		</center>
	#		
	#		");

		#################### BIG LINK LIST
		#
		#
		$SCROLLER = "";

		#
		######### FOREIGN NEWS WIRE #################################

		#
		$scr[0] = sprintf ("
		<h4>
		<b>200 most recent foreign news:</b><br>
		<br>
		");

		#
		open($fzz, "linklist.txt");
		@tmp = <$fzz>;
		for($i=0; $i<($#tmp+1); $i++) { chomp $tmp[$i]; }
		close($fzz);
		@l = @tmp;

		#
		$SCROLLER = "$scr[0]\n\n";

		#
		for($i2=($#l-1),$cozz=0; $i2>-1 && $cozz<200; $i2-=2,$cozz++)
		{
			#
			$CURIMG = "";

			#
			if($l[$i2+0] =~ /commondreams/i)
			{
				$CURIMG = 
				"<img src=\"$IMGBASE/commondreams.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /independent\.co\.uk/i)
			{
				$CURIMG = 
				"<img src=\"$IMGBASE/independent.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /xinhua/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/vpalk.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /informationclearinghouse/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/vpalk2.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /guardian/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/guardian.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /communist/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/communist.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /reuters\.com/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/reuters.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /cbsnews\.com/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/cbsnews.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /english\.pravda\.ru/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/pravda.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /abcnews/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/abcnews.gif\" border=\"0\">";
			}

			#
			if($l[$i2+0] =~ /english.aljazeera.net/i)
			{
				$CURIMG = 
				"<img src=\"$NEBASE/aljazeera.gif\" border=\"0\">";
			}

			#
			$EXTR = "";
			if( ($cozz % 10)==9 )
			{
				$EXTR = "<br>\n";
			}

		        #
		        $SCROLLER = sprintf ("
				$SCROLLER
		                <li>
		                <a href=\"$l[$i2+0]\" target=\"_blank\">
				$CURIMG
		                $l[$i2+1]
				</a>
		                </li>
				$EXTR
				$EXTR
		                ");

			#
			if($cozz<4)
			{
				$SCROLLER2 = $SCROLLER;
			}
		}



skip123:
}

#
sub CostOfWar
{
	#
	print("

<center>
<!-- include cost of war javascript; this runs the counter -->
<script language=\"JavaScript\" src=\"http://costofwar.com/costofwar.js\"></script>
<!-- the elements 'row' and 'alt' will be changed by the javascript to contain
     the correct numbers -->
<div><b>Cost of the War in Iraq</b></div>
<div id=\"raw\">(JavaScript Error)</div>
<div><a href=\"http://costofwar.com\" target=\"_top\">To see more details, click here.</a></div>
<!-- this line triggers the counter to start -->
<script language=\"JavaScript\">
inc_totals_at_rate(100);
</script>
</center>
		");

	#
	katkos();
}

#
sub kulma
{
	#
	print("
		<table vspace=\"8\" hspace=\"8\" align=\"center\">
		<tr>
		<td>
			<a href=\"/hint.pl\">$TXT_SEND_TIP</a>
		</td>
		</tr>
		</table>

		<br>
		<br>
		<center>
		<font size=2>
		<!--(C) 2004-2005 Vaihtoehtouutiset organization-->
		</font>
		</center>
		");
}

##########################################################
#
sub TekstiVersio
{
	#
	print "<center>\n";

	#
	if( $so{'low_graphics'} ne "true" )
	{
		print("
			<a href=\"textversion.pl\">
			> ulkoasu: tekstiversio
			</a>
			<br>
			");
	}
	else
	{
		print("
			<a href=\"graphicversion.pl\">
			> ulkoasu: graafinen versio
			</a>
			");
	}

	#
	print ("
		</center>\n
			<br>
		");
}

##########################################################
sub AdminTracker
{
	print("
<!-- Begin Nedstat Basic code -->
<!-- Title: VAI (administration users) -->
<!-- URL: $NEBASECGI/newswire.pl -->
<script language=\"JavaScript\" type=\"text/javascript\" 
src=\"http://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC+YJg+qDjiUqWpqWJnCYSv9CRuw\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" 
href=\"http://www.nedstatbasic.net/stats?AC+YJg+qDjiUqWpqWJnCYSv9CRuw\"><img
src=\"http://m1.nedstatbasic.net/n?id=AC+YJg+qDjiUqWpqWJnCYSv9CRuw\"
border=\"0\" width=\"18\" height=\"18\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->
	");
}

##########################################################
sub PrimaryTracker
{
	my ($str);
	my ($i,@igl);

	#
	$str = GetUserID();

	#
	if( NoTracking($str) ) { 
		#AdminTracker(); 
			return 1;
		}

	#
	print("
<center>
<small>
(C) 2000-2004 by Jari Tuominen.</small><br>
      </div>
<!-- Begin Nedstat Basic code -->
<!-- Title: Alternative News Agency - VAI -->
<!-- URL: $NEBASECGI/newswire.pl -->
<script language=\"JavaScript\" type=\"text/javascript\" src=\"http://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC3zLQsItf3Zve1qO+opNi34AEQQ\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/stats?AC3zLQsItf3Zve1qO+opNi34AEQQ\"><img
src=\"http://m1.nedstatbasic.net/n?id=AC3zLQsItf3Zve1qO+opNi34AEQQ\"
border=\"0\" width=\"18\" height=\"18\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"http://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->


<!-- START OF ADDME LINK -->
<a href=\"http://www.addme.com\"><img src=\"http://www.addme.com/button2.gif\" 
alt=\"Search Engine Submission and Internet Marketing\" width=\"88\" height=\"31\" border=\"0\"></a> 
<!-- END OF ADDME LINK -->
</center>


	");

	#
	return 0;
}

##########################################################
#
# [ L��PPI ]                   [IDBOX]
#
sub NotIdentified
{
	#
	if($so{'firstname'} ne "")
	{
		$COLR = "F0F0F0";
	}
	else
	{
		$COLR = "E0E0FF";
	}

	#
	print("
			<table width=\"665\" bgcolor=\"#$COLR\"
				cellpadding=\"2\" cellspacing=\"0\">
			<tr>
			<td width=\"85%\" bgcolor=\"#FFFFFF\" ID=\"CCCP\">
		");

	#
	@capt = LoadList("$so{'FP_SECTION'}_captext.txt");

	#
	$str = "";
	for($i=0; $i<($#capt+1); $i++)
	{
		$str = "$str $capt[$i]";
	}
	print("
		$str
		");

	#
	print("
			</td>
			<td width=\"15%\" bgcolor=\"#FFFFFF\">
			<font size=\"1\">
		");

	#
	if($so{'firstname'} eq "")
	{
	#	print("
	#		Tunnistaudu <a href=\"identify.pl\">t�st�</a>, niin voit kommentoida VAI:ssa.
	#		");
	}
	else
	{
	#	print("
	#		status: kirjautunut<br><br>
	#		$so{'lastname'}, $so{'firstname'}<br>
	#		$so{'profession'}<br>
	#		");
	}

	#
	print("
			</font>
			</td></tr>
			</table>
			</div>
	");
}

######################################################################################
sub OnTopOfImage
{
	my ($i,$i2,$n,$sec);

	#
	print("

		<p id=\"ne\">

		<table width=\"332\"
			cellpadding=\"0\" cellspacing=\"0\">
		<tr>
		<td class=\"trans\" id=\"NEWSTABLE\"
			onMouseOver=\"MouseOverNewstable(this, 'trans2');\"
			onMouseOut=\"MouseOutNewstable(this, 'trans');\">

		<font face=\"Lucida Console\" class=\"super\">

		<script language=\"javascript\" src=\"$IMGBASE/newstable.js\"></script>
		");

	#
	$NO_ICON = 1;
	$supersmall = 1;
	$OLD_LINKCOLOR = $LINKCOLOR;
	$LINKCOLOR = "255, 255, 255";
	$LIMIT_CAPTION_LENGTH = 37;

	#
	$sec = $ADVERT_SEC;

	#
	OpenIndex("./$sec/fileindex.txt");

	#
	for($i=$#fileindex,$i2=0; $i>0 && $i2<9; $i--,$i2++)
	{
		#
		$n = "./$sec/$fileindex[$i]";

		#
		ViewArticleFileHeadline($n);
	}

	#
	print("
		</font>

		</td>
		</tr>
		</table>

		</p>
	");

	#
	$LIMIT_CAPTION_LENGTH = "";
	$NO_ICON = 0;
	$supersmall = 0;
	$LINKCOLOR = $OLD_LINKCOLOR;

	#
	print("
		<script language=\"javascript\">

		function looppi()
		{
		//	document.ne.border = 8;
		}

		//setTimeout('looppi()', 50);
		
		</script>
		");
}

######################################################################################
sub OnTopOfImage2
{
	my ($i,$i2,$n,$sec,@txt);

	#
	print("

		<script language=\"javascript\" src=\"$IMGBASE/newstable.js\"></script>

		<p id=\"ne3\" class=\"super\">

		<table width=\"308\"
			cellpadding=\"0\" cellspacing=\"0\">
		<tr>
		<td id=\"NEWSTABLE2\">

		<font face=\"Lucida Console\">

		");

	#
	@txt = LoadList("commercial.txt");

	#
	print("
	");

	#
	print("
		</font>
		</td>
		</tr>
		</table>

		</p>
	");
}

#
sub FreeNews
{
	my ($of);

	#
	if($_[0] ne "") { $of=$_[0]; } else { $of=stdout; }

	#
	printf $of ("
	<br>
	<center>
	<table>
	<tr>
	<td>

	<SCRIPT language=\"javascript\" SRC=http://interestalert.com/cgi-bin/rmt/siteia/nph-sitenews.js?Sys=jer64&Sum=yes&Date=yes&From=0&Cnt=2&Cols=1&St=Style4&Type=News&Fid=LATEBRKN,WORLDNEW,NATIONAL,WOMNEWS1,OPINIONS,BUSINESS></SCRIPT>

	</td>
	</tr>
	</table>
	</center>
	");
}

##########################################################
#
# Image News.
#
# News focused with images.
#
sub ImageNews
{
	my ($i,$i2,$i3,$i4,$c);

	#
	@news = LoadList("imagenews.txt");

	#
	print("
		<!----------------------------------------------------------->
		<script>
		function ImagenewsMouseout(e)
		{
			o = document.getElementById('TOOLTIP1');
			if(o)
			{
				o.style.backgroundColor = '#FFFFFF';
				o.display = 'none';
				o.innerHTML = '';
			}
		}

		function ImagenewsMouseover(e, msg, locy)
		{
			o = document.getElementById('TOOLTIP1');
			n = document.getElementById('ne2');
			if(o)
			{
				n.style.left = 152+48;
				n.style.top = 320+locy;
				o.style.backgroundColor = '#E0E0E0';
				o.display = 'block';
				o.innerHTML = msg;
			}
		}
		</script>


		<!----------------------------------------------------------->
		<p id=\"ne2\">
		<table bgcolor=#FFFFFF border=0 cellpadding=4 cellspacing=0
			width=\"300\">
		<tr>
		<td id=\"TOOLTIP1\">
		</td>
		</tr>
		</table>
		</p>


		<br>
		<br>
		<br>

		");

	#
	for($i=0,$c=0; $i<($#news),$c<10; $i+=3,$c++)
	{
		#
		$i2 = $c*40;

		#
		print("
			<a href=\"$news[$i+2]\">
			<img src=\"$news[$i+1]\"
				width=\"40\" height=\"40\" border=\"0\"
				onMouseover=\"ImagenewsMouseover(this, '$news[$i+0]', $i2);\"
				onMouseout=\"ImagenewsMouseout(this);\">
			</a>
			<br>
			");
	}
}

##########################################################
sub Scripts
{
	#
	print("
			<script language=\"javascript\">

			//
			function ArtTab(e, w)
			{
				if(w==0)
				{
					e.className = 'tdSelector1';
				}
				if(w==1)
				{
					e.className = 'tdSelector2';
				}
			}

			</script>
		");

	#
}

##########################################################
sub ShowJsNews
{
	my ($i,$i2,$i3,$i4,$str,$str2,$fn,$fn2,@lst,$f,$f2);

	#
	$fn = "/home/vai/public_html/js/$_[0].js";
	$fn2 = "/home/vai/public_html/js/\_$_[0].js";
	$fn2b = "/~vai/js/\_$_[0].js";

	#
	if(!(-e $fn2) || FileAge($fn2)>120)
	{
		#
		@lst = LoadList($fn);

		#
		open($f, ">$fn2") || die "Oops... Something bad happended, mail LST\@VUNET.ORG";
		for($i=0; $i<($#lst+1); $i++)
		{
			#
			if( !($lst[$i] =~ /\{/)) {
				$lst[$i] =~ s/(http.*\")/http:\/\/vunet.world\?to\=$1/;
			}
			else
			{
				if($lst[$i]=~/www\.plenglish\.com/i)
				{
	$lst[$i] =~ s/http:\/\/\S*ID=\{(.*)\}\S*\=EN/http:\/\/vunet.world\?pl\=$1/;
				}
			}
			#
			print $f "$lst[$i]\n";
		}
		close($f);
	}

	#
	print("
		$str
		<script language=\"JavaScript\" src=\"$fn2b\"></script>
		");
}

##########################################################
sub VTVBAN2
{
	#
	print("
				<a href=\"http://tv.vunet.world\" class=dark>
				<img src=\"$IMAGES_BASE/vunet-tv-banner-en.gif\">
				</a>
		");
}

##########################################################
sub VTVBAN
{
	#
	print("
					<a href=\"http://www.kominf.pp.fi\" target=\"_blank\" class=dark>
					<img src=\"$IMAGES_BASE/oikea.jpg\" border=1>
					</a>
		");
}

##########################################################
sub NoteInEnglish
{
				#
				print("

					<center>					
					<table width=300 cellpadding=1 cellspacing=0 align=center
						bgcolor=\"#000000\">
					<tr>
					<td>

					<table width=300 cellpadding=8 cellspacing=0 align=center
						bgcolor=\"#00FFFF\">
					<tr>
					<td>
					<font size=2>
					<font size=4>VUnet.org</font> primarily concretes on creating Finnish news content.
					The secondary task is the English reporting cause. We wish that you
					<b>enjoy your time</b> on our news site, and hope that you
					find these alternative news from the world useful.<br>
					<br>
					We're deeply sorry about any technical inconveniences such as broken URLs. Everything should be fixed now.<br>
					<br>
					<i>With best regards,<br>
					VUnet.org staff.</i><br>
					</font>
					</td>
					</tr>
					</table>

					</td>
					</tr>
					</table>

					<br>
					</center>

				");
}

######################################################################################################################
#
sub EnglishFrontpage
{

			#
			EnglishFP1();

			#
			if($so{'FP_SECTION'} eq "english")
			{

		#	VTVBAN2();
				#
				print("
<div>
<table cellpadding=16 cellspacing=0 width=750>
<tr valign=top>
<td bgcolor=#CCFFCC>
					");
				ShowJsNews("XinhuaWorld");
				print("

<br>

<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = \"728x90_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"FF4500\";
google_color_bg = \"FFEBCD\";
google_color_link = \"DE7008\";
google_color_url = \"E0AD12\";
google_color_text = \"8B4513\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

<br>
<br>

				");
				ShowJsNews("PLAT");
				print("
</td>

</tr>
</table>
</div>
<br>
					");
			#	NoteInEnglish();
			}
}

#######################################################################################
#
sub FrontPage
{
		my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co);

 		#####################################################
		#
		if($so{'FP_SECTION'} eq "finnish")
		{
			FinnishFP();
		}
}

###########################################################################################################
#
sub VoteThing
{
			my ($f,$i,$i2,$str,$str2);

			#
			if( open($f, "current-poll.txt") )
			{
				$ENV{'POLLNR'} = sprintf("%d", <$f>);
				close($f);
			}
			else
			{
				$ENV{'POLLNR'} = 6;
			}
	
			#
			$ENV{'newswire_conset'} = "TRUE";
			$ENV{'BOUNCE_TO'} = "/article/$_[0]";
	                if( open(CAL, "./poll.pl|") )
			{
		                @form = <CAL>;
		                close(CAL);
			}
	                print(" 
				
				<center>
				<table width=140 bgcolor=\"#00C0FF\" cellpadding=1 cellspacing=0>
				<tr>
				<td>

				<table width=100% bgcolor=\"#00FFFF\" cellpadding=0 cellspacing=0>
				<tr valign=top>
				<td>

				<div align=center>
				@form
				</div>

				</td>
				</tr>
				</table>
				</td>
				</tr>
				</table>
				</center>
<br>
				");
}

#######################################################################################
#
sub Weather
{
		#
		@lst = LoadList("cfg/brief_weather.txt");

		#
		print("
<table width=170 height=100% cellpadding=0 cellspacing=0
background=\"$IMAGES_BASE/bgx.png\">
			<tr valign=top>

			<td width=100%>

<br>

<table width=100% cellpadding=4 cellspacing=0>
<tr>
<td>
");

VoteThing();

print("

<div align=center>
<table width=140 cellpadding=0 cellspacing=0 align=center>
<tr>
<td>
<b>S��tiedot</b><br>
			");

		#
		for($i=0; $i<($#lst+1); $i++)
		{
			@sp = split(" ", $lst[$i]);
			
			print("
		<table width=100% cellpadding=0 cellspacing=0>
		<tr>
		<td width=60%>
		<font size=2>$sp[2]</font><br>
		</td>

		<td width=40%>
		<font size=2>$sp[0] $sp[1]</font><br>
		</td>
		</tr>
		</table>
		");
		}

		#
		print("
<font size=1><a href=\"http://www.vunet.world/saa.pl?q=Jyv%E4skyl%E4\" class=news3>> lis��</a></font>
			</td>
			</tr>
			</table>
</div>

<br>
<div align=center>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = \"120x600_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"DFF2FD\";
google_color_bg = \"DFF2FD\";
google_color_link = \"0000CC\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</div>

	<br>
<!---------<div align=center>
<a href=\"http://www.vunet.world/search.pl\"><img src=\"$IMAGES_BASE/altse_banner.jpg\" border=0 align=center
		vspace=0 hspace=0></a>
</div> ---------->
			");

		#
		print("




			</td>
			</tr>
			</table>

<br>

			</td>
			</tr>
			</table>
			");
}

##################################################################################################
#
sub ShowIndex
{
	my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co);

	# Get section argument.
	$tmp = $ENV{'QUERY_STRING'};
	@tmp2 = split("\&", $tmp);
	$section = $so{'section'};

	#
	$ENV{'CURSEC'} = $section;
	if($section eq "")
	{
		$ENV{'CURSEC'} = "etusivu";
	}

	#
	$BEGART = $so{'page'};

	# Section specified?
	if($section ne "")
	{
		$MAX_HEADLINES_TO_SHOW = 200;
	}

	#
	if($section eq "")
	{
		#
		@web = OpenWebIndex($WEBINDEX);
		$wherebe = 0;

		# TRANSPARENT TABLE
		WebWalkTo("before-uusilogo2");
		OnTopOfImage2();
	###	OnTopOfImage();
	}
	else
	{
		@web = OpenWebIndex($WEBINDEX);
		$wherebe = 0;
	}

	#
#	if($so{'printable'} eq "") { WireLogo(); } else { WireLogo("x"); }

	#
	$ix = 0;

	# Got specific section?
	if($section eq "")
	{
		# NOT SPECIFIC SECTION.
		#############################################################

		# Add main menu.
		HandleExternal("main-menu", "./mainmenu.pl");
		#
		if($so{'FP_SECTION'} eq "english")
		{
			print("
<br>
<div align=center>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = \"120x600_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"FDFFCA\";
google_color_bg = \"FDFFCA\";
google_color_link = \"0000CC\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</div>
			");
		}
		#
		WebWalkTo("-before-corner-");

		#
		if($so{'FP_SECTION'} eq "finnish")
		{
			#
			print("
				<table width=100%>
				<tr valign=top>

				<td width=70%>
				");

			#
			FrontPage();

			#
			print("
				<!--- valitaulukko!!! -->
				<table width=650 
					cellpadding=8 cellspacing=0>
				<tr valign=top>
				");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("tyopaikat", "Ty�paikat", 20, 24*1200, "tyopaikat");
			print("</td>");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("myydaan", "Myyd��n", 10, 24*3600, "myydaan");
			print("<br>");
			NaytaUutisotsikot("ostetaan", "Ostetaan", 10, 24*120, "ostetaan");
			print("</td>");
			#
			print("
				</tr>
				</table>
				");

			#
			print("
				<!--- valitaulukko!!! -->
				<table width=650 
					cellpadding=8 cellspacing=0>
				<tr valign=top>
				");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("kummalliset", "Hupijutut", 20, 24*1200);
			print("</td>");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("kolumnit", "Kolumnit", 5, 24*120);
			print("<br>");
			NaytaUutisotsikot("viihde", "Viihde", 15, 24*3600);
			print("</td>");
			#
			print("
				</tr>
				</table>
				");

			#
			print("
				<!--- valitaulukko!!! -->
				<table width=650 
					cellpadding=8 cellspacing=0>
				<tr valign=top>
				");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("kotimaa", "Kotimaan jutut", 20, 24*1200, "kotimaa");
			print("</td>");
			#
			print("<td width=50%>");
			NaytaUutisotsikot("ajatelmat", "Aforismi", 5, 24*120, "ajatelmat");
			print("<br>");
			NaytaUutisotsikot("yhteiskunta", "Yhteiskunnalliset", 15, 24*3600, "yhteiskunta");
			print("</td>");
			#
			print("
				</tr>
				</table>
				");

			#
			print("
				</td>
				");


			##############################################
			#
			# BANNERS ON RIGHT CORNER
			#
			print("

				<td width=30%>
				<br>
				");
			#
			VideoArkistoAd();
			Weather();
			print("
				</td>
				</tr>
				</table>
				");
		}
		else
		{
			#
			EnglishFrontpage();
		}

		############################################################
		#
		Scripts();
	}
	else
	{
	        #
		$str = $so{'section'};
		$str =~ tr/[a-z���]/[A-Z���]/;
	        WebWalkTo("CHOOSE-TITLE1");
		print("<title>$str</title>");
	        print("
	<meta name=\"description\" content=\"$str\">
	                ");
	        SkipTo("CHOOSE-TITLE2");

		# VIEW SPECIFIC SECTION.
		#############################################################
                if($so{'plainoutfit'} eq "true")
                {
                        SkipTo("past-uusilogo2");
                }

                # add main menu
                #
                if($so{'plainoutfit'} ne "true" && $so{'printable'} eq "")
                {
                        HandleExternal("main-menu", "./mainmenu.pl");
                }
                else
                {
                }

		#
		HandleSection($section);
	}

	#
	WebWalkTo("ALAPALKKITAHAN");
	#
	EndBar();

	#
	HandleRest();
}

##########################################################
sub LoadSections
{
	my ($i,$f);

	#
	if( !open($f, "sections.txt") )
	{
		print "Error: Can't find sections.txt\n";
		die;
	}

	#
	@sections = <$f>;

	#
	for($i=0; ($i<$#sections+1); $i++)
	{
		chomp $sections[$i];
	}

	#
	close($f);
}

##########################################################
#
# Handles an external section.
#
# [section trigger], [perl program to make the output]
#
sub _HandleExternal
{
        my ($i,$i2,$found);

        # Print until "$_[0]" is found.
        loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
        {
                if($web[$i] =~ /$_[0]/i)
                {
                        $found=1;
                }
                print $web[$i];
        }
	if($found) { system $_[1]; }
        $wherebe=$i;
}

#
sub LanguageEnglish
{
	#
	$TXT_NEWS_SERVICES = "news services";
	$TXT_CALENDAR = "calendar";
	$ADVERT_SEC = "english";
	$ADVERT_SEC_DESCRIPTION = "recent picks";
	$TXT_SEND_TIP = "send a tip";
}

##########################################################
# Apply configuration newswire.pl settings.
sub ApplyConfiguration
{
	#
	$ENV{'CURFPSEC'} = $so{'FP_SECTION'};

	#
	if($so{'printable'} ne "")
	{
		$WEBINDEX = "index1.html";
		$WEBINDEX2 = "index1.html";
	}
	else
	{
		$WEBINDEX = "webindex.html";
		$WEBINDEX2 = "webindex2.html";
	}

	#
	if($so{'FP_SECTION'} eq "english")
	{
		LanguageEnglish();
	}
}

##############################################################################################################
#
sub SectionSpecificView
{
		#
		$ENV{'CURSEC'} = $so{'section'};
		OpenWebIndex("./webindex2.html");
		HandleExternal("main-menu", "./mainmenu.pl");
		#
		WebWalkTo("ENTERHERE_SECTION");
		#
		print("
			<table width=100% cellpadding=16 cellspacing=0>
			<tr valign=top>

			<td width=80%>
			");
		NewsViews();
		BigPicksList();
		#
		print("
			</td>

			<td width=20%>
<br>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = \"120x600_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"DFF2FD\";
google_color_bg = \"DFF2FD\";
google_color_link = \"0000CC\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
			</td>

			</tr>
			</table>
			");
		#
		WebWalkTo("ALAPALKKITAHAN");
		#
		EndBar();
		#
		HandleRest();
}

########################################################################################
#
sub main
{
	#
	if($so{'FP_SECTION'} eq "vunet.world" || $so{'FP_SECTION'} eq "" ||
		$so{'FP_SECTION'} eq "portal")
	{
		#
		if($ENV{'REMOTE_HOST'}=~/\.fi$/)
		{
			ViewCachePage("index-finnish.html");
			exit();
		}
		else
		{
			ViewCachePage("index-english.html");
			exit();
		}

		#
		@WHART = LoadList("pick2.txt");
		$ENV{'VIEW_THIS_ARTICLE'} = $WHART[0];
		$ENV{'newswire_conset'} = "TRUE";
		$ENV{'FRONT_PAGE_MODE'} = "TRUE";
	
		#
		system "./viewarticle.pl";
		exit();
	}
	
	#
	if($so{'FP_SECTION'} eq "search" )
	{
		# Tell frontpage.pl that the content /html blabla is already set.
		$ENV{'newswire_conset'} = "TRUE";
		system "./search.pl";
		exit;
	}

	# Default to FINNISH news.
	if($so{'FP_SECTION'} eq "")
	{
		$so{'FP_SECTION'} = "finnish";
	}
	#
	ApplyConfiguration();

	#
	LoadSections();

	###########################################################

	# Show the index.
	if($so{'section'} eq "secspe")
	{
		SectionSpecificView();
	}
	else
	{
		ShowIndex();
	}

	#
}


