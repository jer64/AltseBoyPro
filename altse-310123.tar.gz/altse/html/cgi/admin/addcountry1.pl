#!/usr/bin/perl
#############################################################################
# (C) 2004 by Jari Tuominen.
#############################################################################

# Form sent article data is HTML?
$IS_HTML = 0;

#
$RETURL = "addcountry.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
#
sub read_input
{
	# Read in text
	$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
	if ($ENV{'REQUEST_METHOD'} eq "POST")
	{
		@__buffer = split(/\&/, $all);
	}
	else
	{
		print "Error: Post method required.<br>\n";
		die;
		#$buffer = $ENV{'QUERY_STRING'};
	}

	#
	$NIM =	$__buffer[0];
	$NIM =~ s/\+/ /ig;
	$NIM =~ s/%(..)/pack("C", hex($1))/eg;
	$NIM =~ s/nimi\=//;
	$NIM =~ s/\n//g;
	$NIM =~ s/\r//g;

	#
	$KUV =	$__buffer[1];
	$KUV =~ s/\+/ /ig;
	$KUV =~ s/%(..)/pack("C", hex($1))/eg;
	$KUV =~ s/kuvaus\=//;
	$KUV =~ s/\s//g;
	$KUV =~ s/\n//g;
	$KUV =~ s/\r//g;
}

#
sub CreateCountry
{
	my $x;

	# Add to the country list.
	system "echo \"$NIM\" >> countries.txt";

	# Create appropriate subdirs.
	system "mkdir fb/$NIM";

	# Create template document.
	system "echo \"Ei kuvausta.\" > fb/$NIM/pub_info.txt";

	#
	$x = time;

	#
	system "cat countries.txt | sort > /tmp/$USER$x\.txt";
	system "cp /tmp/$USER$x\.txt countries.txt";
	system "rm -f /tmp/$USER$x\.txt";
}

##########################################################
sub changes
{
	local $i;

	# Write the article on drive.
	print ("
		nimi = $NIM<br>
		kuvaus = $URL<br>
		");

	#
	@t = LoadList("countries.txt");

	#
	for($i=0; $i<($#t+1); $i++)
	{
		if($t[$i] eq $NIM) { die "MAA ON JO LISTATTU."; } 
	}

	#
	CreateCountry($NIM);
}

##########################################################
sub main
{
	#
	print "<html>\n";

	#
	$argarg = $ENV{'QUERY_STRING'};
	read(STDIN, $all, $ENV{'CONTENT_LENGTH'});
	#
	@__buffer = split(/\&/, $all);
	$temppi = $__buffer[1];
	@temppi2 = split(/\=/, $temppi);

	##################################################################
	if($all =~ /ishtml78458132751764/)
	{
		#
		$IS_HTML = 1;
	}

	# Detect correct password always.
	if($all =~ /$ADMINPASSWORD/)
	{
		# Enable administration mode.
		$admin = 1;
	}

	# Password check.
	if($REQUIREPASSWORD!=0 && !$admin)
	{
		print "Error: Invalid password.<br>\n";
		die;
	}

	##################################################################
	if($all =~ /archivei43538453/i)
	{
		# Add article to the end of the list.
		$MUSEUM_ARTICLE = 1;
	}

	##################################################################
	if($argarg =~ /comart7895789235/i)
	{
		#
		print "Illegal function.<br>\n";
		die;
	}
	

	#
	read_input();

	#
	changes();

	#
	print "<meta http-equiv=\"refresh\" content=\"0; url=$RETURL\">\n";

	#
	print "<h2>Link successfully added. Thank you.<br>\n";
	print "<a href=\"$RETURL\">\n";
	print "Returning to A.N.A.<br>\n";
	print "</a>\n";

	#
	print "<hr><br>\n";

	#
	print $buffer;

	#
	print "</html>\n";
}


