#!/usr/bin/perl
require "tools.pl";

#
main();

#
sub main
{
	#
	chdir("/home/vai/public_html/cgi-bin");

	#
	@lst = LoadList("find articles/ -name 'titles.txt' -type f|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		$str =~ s/^.*\/([^\/]*)$/$1/;
		$str2 = $lst[$i];
		$str2 =~ s/^.*\/([^\/]*)\/([^\/]*)$/$1_$2/;
		$str2 = "cache/$str2";
		$age1 = FileAge($lst[$i]);
		$age2 = FileAge($str2);
		if( !(-e $str2) || ($age2 > 60) || 1==1 )
		{
			#print "$age1 > $age2";
			$cmd = "cp $lst[$i] $str2";
			#print "$cmd\n";
			system($cmd);
		}
		else
		{
			#print "$str2 is up to date, no update needed.\n";
		}
	}

	#
}

#
