#!/usr/bin/perl
print crypt("engels", "jt");
