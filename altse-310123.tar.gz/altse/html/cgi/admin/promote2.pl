#!/usr/bin/perl
#############################################################################
# promote2.pl
#############################################################################

require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
main();

#
sub isPromoted
{
	local $i,$i2,$i3,$i4,@ind;

	#
	$_fn = $fname;
	$_fn =~ s/\.\///g;
	$_fn =~ s/\.//g;
	$_fn =~ s/poimitut\///g;
	$_fn =~ s/txt/\.txt/g;
	@tmp = split("\/", $_fn);
	$fn = $tmp[1];
	$ifn = "picks.txt";

	# Load index.
	open(f, $ifn) || die "can't open index file $ifn";
	@ind = <f>;
	close(f);
	for($i=0; $i<($#ind+1); $i++)
	{
		chomp $ind[$i];
	}

	# Hunt for fn.
	for($i=0; $i<($#ind+1); $i++)
	{
	#	print "$ind[$i]<br>\n";
		if( $ind[$i] =~ "$_fn" )
		{
			return 1;
		}
	}

	#
	return 0;
}

# Undo article's promotion.
sub UnpromoteArticle
{
	local $i,$i2,$i3,$i4,@ind;

	#
	$fn = $fname;
	$fn =~ s/\.\///g;
	$fn =~ s/\.//g;
	$fn =~ s/poimitut\///g;
	$fn =~ s/txt/\.txt/g;
	$ifn = "picks.txt";

	# Load index.
	open(f, $ifn) || die "can't open index file $ifn";
	@ind = <f>;
	close(f);
	for($i=0; $i<($#ind+1); $i++)
	{
		chomp $ind[$i];
	}

	# Hunt for fn.
	open(f, ">$ifn") || die "can't write index file $ifn";
	for($i=0; $i<($#ind+1); $i++)
	{
		if( !($ind[$i] =~ "$fn") )
		{
			print f "$ind[$i]\n";
		}
	}
	close(f);

	#
	return 0;
}

#
sub RequestConfirmation
{
	#
	print("
		Haluatko <b>lis�t�</b> artikkelin erityisn�kym��n?<br>
		<b>\"$headline\"</b>
		<br>
		<form action=\"promote2.pl\" method=\"get\">
		<input type=\"hidden\" value=\"$fname\" name=\"target\">
		<input type=\"hidden\" value=\"confirmation32634\" 
			name=\"con\">
		<input type=\"submit\" value=\"kyll�\">
		<a href=\"../newswire.pl\">ei</a>
		</form>
		");
}

#
sub RequestConfirmation2
{
	#
	print("
		Artikkeli on <b>erityisn�kym�ss�</b>.<br>
		Haluatko <b>poistaa</b> artikkelin erityisn�kym�st�?<br>
		<b>\"$headline\"</b>
		<br>
		<form action=\"promote2.pl\" method=\"get\">
		<input type=\"hidden\" value=\"$fname\" name=\"target\">
		<input type=\"hidden\" value=\"confirmation32634\" 
			name=\"con\">
		<input type=\"submit\" value=\"kyll�\">
		<a href=\"../newswire.pl\">ei</a>
		</form>
		");
}

#
sub Bounce
{
	print ("<meta http-equiv=\"refresh\" content=\"0;
		url=../viewarticle.pl?$fname\">\n
		");
}

# Promote article.
sub PromoteArticle
{
	#
	$fn = $fname;
	$fn =~ s/\.\///g;
	$fn =~ s/\.//g;
	$fn =~ s/poimitut\///g;
	$fn =~ s/txt/\.txt/g;

	#
	system "echo \"$fn\" >> picks.txt";
}

#
sub main
{
        # Load configuration & parse args.
        ArgLineParse();

	# Figure out arguments.
	$__all = $ENV{'QUERY_STRING'};
        $__all =~ s/\+/ /ig;
        $__all =~ s/%(..)/pack("C", hex($1))/eg;
	@_all = split("\&", $__all);
	$frst = $_all[0];
	$frst =~ s/target=//;
	@s = split("\/pub_", $frst);
	$artdir = $s[0];
	$fname = $frst;
	if($fname =~ /poimitut\//)
	{
		$fname =~ s/poimitut\///;
		$fname =~ s/\.\.//g;
		$fname =~ s/\///;
	}
	$ifname = "$artdir/fileindex.txt";
	$confirmation = 0;
	if($__all =~ /confirmation32634/)
	{
		$confirmation = 1;
	}

	# Get article headline.
	open(f, $fname) || die "file not found ($fname)";
	$headline = <f>;
	chomp $headline;
	$headline =~ s/<br>//g;
	close(f);

	#
	#
	if(!isPromoted())
	{
		#
		if( !$confirmation )
		{
			#
			RequestConfirmation();
		}
		else
		{
			#
			PromoteArticle();
			Bounce("../newswire.pl");
		}
	}
	else
	{
		#
		if( !$confirmation )
		{
			#
			RequestConfirmation2();
		}
		else
		{
			#
			UnpromoteArticle();
			Bounce("../newswire.pl");
		}
	}
	
	#
}

#




