#!/bin/bash

#
cd /home/vai/public_html/cgi-bin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
echo "3"
lynx -source http://www.vunet.world/finnish/ > /tmp/index-finnish.html
cp /tmp/index-finnish.html /home/vai/public_html/cache/index-finnish.html
#
echo "4"
lynx -source http://www.vunet.world/english/ > /tmp/index-english.html
cp /tmp/index-english.html /home/vai/public_html/cache/index-english.html
