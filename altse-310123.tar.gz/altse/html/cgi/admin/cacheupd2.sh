#!/bin/bash
/home/vai/cgi-bin/cacheupd.sh
/home/vai/cgi-bin/up3.sh
/home/vai/cgi-bin/up2.sh

