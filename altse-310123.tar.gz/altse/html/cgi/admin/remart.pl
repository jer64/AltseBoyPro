#!/usr/bin/perl
#############################################################################
# remcom.pl
# Remove a comment (asks for an administration password).
#############################################################################

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
print "Content-type: image/gif\n\n";
#print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
main();

#
sub RequestConfirmation
{
	#
	AdminLog("User $ENV{'REMOTE_USER'} attempts to remove article \"$fname\".\n");

	#
	print("
		Oletko varma, ett� haluat poistaa artikkelin?<br>
		<b>\"$headline\"</b>
		<br>
		<form action=\"remart.pl\" method=\"get\">
		<input type=\"hidden\" value=\"$fname\" name=\"file\">
		<input type=\"hidden\" name=\"confirmation32634\" 
			value=\"TRUE\">
		<input type=\"submit\" value=\"poista\">
		<a href=\"../newswire.pl\">peruuta</a>
		</form>
		");
}

#
sub Bounce
{
	print ("<meta http-equiv=\"refresh\" content=\"0;
		url=$_[0]\">\n
		");
}

# Remove article from newswire.
sub RemoveArticle
{
	my $f;

	#
	AdminLog("User $ENV{'REMOTE_USER'} removed article \"$fname\".\n");

	# Open index.
	open($f, $ifname) || die "UNABLE TO OPEN NEWSWIRE INDEX FILE: $ifname";
	@ind = <$f>;
	close($f);

	#
	for($i=0; $i<($#ind+1); $i++)
	{
		chomp $ind[$i];
	}

	#
	$_fn = $fname;
	$_fn =~ s/\.\///g;
	@tmp = split("\/", $_fn);
	$fn = $tmp[1];

	#
	open($f, ">$ifname") || die "UNABLE TO WRITE NEWSWIRE INDEX $ifname";
	for($i=0; $i<($#ind+1); $i++)
	{
		if(!($ind[$i] eq $fn))
		{
			print $f "$ind[$i]\n";
		}
	}
	close($f);

	#
	chomp $fname;
	$cmd = ("mv -f $fname /tmp");
	#print "$cmd<BR>\n";
	system($cmd);
	#die "shit";
}

#
sub main
{
	my $f;

	# Load configuration & parse args.
	$DONT_AFFECT_DB = 1;
	ArgLineParse();
	$so{'confirmation32634'} = 1;

	# Figure out arguments.
	$frst = "$so{'file'}";
	@sp = split(/\//, $so{'file'});
	@s = split("\/pub_", $frst);
	$artdir = $sp[$#sp-1];
	$fname = $frst;
	$artdir =~ s/(^[^\/]+)[\/].*/$1/;
	$ifname = "$ENV{'DOCUMENT_ROOT'}/articles/$artdir/fileindex.txt";
	$confirmation = 0;
	if($so{'confirmation32634'} ne "")
	{
		$confirmation = 1;
	}
	if( !($fname =~/^articles\//) )
	{
		$fname = "$ENV{'DOCUMENT_ROOT'}/articles/$fname";
	}
	# Get article headline.
	if( !(-e $fname) )
	{
		#
		system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/544.gif");
		exit;
	}
	else
	{
		open($f, $fname);
		$headline = <$f>;
		chomp $headline;
		$headline =~ s/<br>//g;
		close($f);
	}

	#
	RemoveArticle();

	#
	system("cat $ENV{'DOCUMENT_ROOT'}/images/smiles/anim_nodding_cat.gif");

	#
}

#
