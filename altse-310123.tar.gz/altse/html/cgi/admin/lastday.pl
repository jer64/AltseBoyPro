#!/usr/bin/perl
#
# lastday.pl
#
# Report sent via mail at 03:00 FINNISH time.
#
##############################################################################################################

#
require "tools.pl";
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@lst2,@ips,$i,$i2,$i3,$i4,$str,$str2,$fn,$age,$lfn);

	#
	chdir("/home/vai/cgi-bin");

	#
	$fn = "cfg/vistat.txt";

	#
#	$age = FileAge($fn);
#	if($age < (60*60*12)) { print STDERR "no update necessary ($age)\n"; exit; }

	#
	@lst = LoadList("find logs/ -maxdepth 1 -name 'vislog-*.txt'|");
	@lst = sort @lst;
	@lst = reverse @lst;

	#
	%countries = ("");

	#
	if(1)
	{
		$lfn = $lst[1];
		$str = $lfn;
		$str =~ s/^[^0-9]*([0-9]*).*$/$1/;
		#print "$str ";
		print STDERR "$lfn\n";
		@lst2 = LoadList($lfn);
		%ips = ();
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			@sp = split(/\;/, $lst2[$i2]);
			if( !($sp[2]=~/google\.[a-z]*$/) && !($sp[2]=~/google\.[a-z]*\.[a-z]*$/) 
				&& !($sp[2]=~/inktomisearch\.[a-z]*$/)
				&& !($sp[2]=~/ask\.com$/)
				&& !($sp[2]=~/picsearch\.com$/)
				&& !($sp[2]=~/googlebot\.com$/)
				&& !($sp[2]=~/vunet\.org$/)
				)
			{
				$ips{$sp[1]}++;
				if($sp[2]=~/\.[a-z]*$/)
				{
					$str = $sp[2];
					$str =~ s/^.*\.([a-z]*)$/$1/;
					$str =~ tr/[a-z���]/[A-Z���]/;
					$countries{$str}++;
				}
			}
		}
		#$tama = sprintf "%d\n", keys %ips;
		#print STDOUT $tama;
	}

	#
	$t = $lfn;
	$t =~ s/[^0-9]//g;

	#
	$pvm = POSIX::strftime("%d.%m.%Y", localtime($t*60*60*24));
	$ct = time;
	$nt = sprintf "%d", $ct/(60*60*24);
	$nt++;
	$nt = $nt*60*60*24;

	#
#	print "\n";

	#
	@lst = LoadList("countrycodes.txt");
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\ \ \ /, $lst[$i]);
		$cc{$sp[0]} = $sp[1];
	}

	#
	@lst = ();
	$i=0;
	$foreign = 0;
	$total = 0;
	$fin = 0;
	foreach $key (sort(keys %countries))
	{
		if($countries{$key}>0)
		{
			if($key eq "FI") { $fin+=$countries{$key}; } else { $foreign+=$countries{$key}; }
			$total+=$countries{$key};
			$lst[$i++] = sprintf "%1.8d %s", $countries{$key}, $cc{$key};
		}
	}
	if(!$total) { $total++; }
	if(!$fin) { $fin++; }
	if(!$foreign) { $foreign++; }
	@lst = sort @lst;
	@lst = reverse @lst;

	$per = ($fin/$total)*100;
	$per = sprintf "%d", $per;

	print "VAIHTOEHTOUUTISTEN K�VIJ�RAPORTTI $pvm ($per% suomalaisia k�vij�it�)<BR>\n";

	$str = sprintf "%s: Uniikit k�vij�t maittain (www.vunet.world)<BR>\n", $pvm;
	print $str;
	print "====================================================================<BR>\n<BR>\n";


	print "$per% suomalaisia k�vij�it�<BR>\n";
	print "yhteens� ...<BR>\n";
	print "$fin		suomalaista<BR>\n";
	print "$foreign	ulkomaalaista<BR>\n";
	print "$total	kokonaisuudessaan<BR>\n<BR>\n";

	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]<BR>\n";
	}

#	print "\n$ct -> $nt (",$nt-$ct," sekuntia seuraavaan p�ivitykseen)<BR>\n";

	#
}


