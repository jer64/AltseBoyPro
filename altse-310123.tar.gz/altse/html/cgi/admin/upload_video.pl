#!/usr/bin/perl
#
# upload_image.pl
#
##############################################################################################################

#
require "tools.pl";
use CGI;

#
$query = new CGI;

#
if( $query->param("datafile") )
{
	#
	SaveFile();
}
else
{
	print "Content-type: text/html\n\n";
	main();
}

#

###########################################################################################################
#
sub UploadForm
{
	my ($r);

	#
	$r = $query->param("r");

	#
	print("
<H1><I>
Vunet Video Upload Form
</I></H1><BR>

Please note: file <i>must be</i> in AVI, ASF, ASX, WMV, MPG/MPEG, FLV or SWF format.

<FORM action=\"https://www.vunet.world/upload_video.pl\"
	enctype=\"multipart/form-data\" method=\"post\">
Choose a file from your computer to upload:<BR>
<input type=file name=datafile size=40 id=fo><BR>
<input type=submit value=\"upload video\">
<input type=hidden name=r value=\"$r\">
</FORM>

<SCRIPT LANGUAGE=\"Javascript\">
//document.getElementById('fo').focus();
</SCRIPT>

<DIV ALIGN=RIGHT>
<H3>
<A HREF=\"$r\">
> return
</A>
</H3>
</DIV>
		");
}


###########################################################################################################
#
sub SaveFile
{
	my ($up,$f,$i,$i2,$str,$str2,$fn,$ok,$r);
	my @accept = (
	"avi", "asf", "asx", "wmv", "mpg", "mpeg", "flv", "swf",
	);

	#
	$r = $query->param("r");
	$r =~ s/\^/\=/g;
	$r =~ s/\~/\&/g;

	#
	$fn = $query->param("datafile");
	$fn =~ s/[^a-zA-Z������0-9\-_\ \.]/_/g;
	$fn =~ tr/[A-Z���]/[a-z���]/;

	#
	if( !($fn=~/^[a-zA-Z������0-9\-_\ ]*\.[a-zA-Z]*$/) )
	{
		#
		print "Content-type: text/html\n\n";
		$MSG = "<BLINK>Illegal file name. <i>Please</i> change file name to contain <u>no special marks</u>, thank you!</BLINK><BR>\n";
		main();
		exit;
	}

	#
	for($i=0,$ok=0; $i<($#accept+1); $i++)
	{
		$str = $accept[$i];
		if($fn=~/\.$str$/i)
		{
			$ok=1;
		}
	}
	#
	if(!$ok)
	{
		#
		print "Content-type: text/html\n\n";
		$MSG = "<BLINK>Illegal file type. <i>Please</i> upload <u>only allowed video formats</u>, thank you!</BLINK><BR>\n";
		main();
		exit;
	}

	#
	$up = $query->upload("datafile");

	#
	open($f, ">/home/public/public_html/contributions/$fn");
	binmode $f;
	while( <$up> )
	{
		print $f $_;
	}
	close($f);
	#
	print "Content-type: text/html\n\n";

	#
	$sz = sprintf "%d", ((stat($fn))[7]/1024)+1;

	#
	print("
<H3>File successfully uploaded ($fn, $sz K bytes).</H3>
		");

	#
	print("
		<meta http-equiv=\"refresh\" content=\"0; url=$r\">
	");
}

###########################################################################################################
#
sub main
{
	#
	print("
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

<TABLE width=100% height=100% cellspacing=0 cellpadding=0
	bgcolor=#000000>
<TR valign=top>
<TD>

<TABLE width=640 height=100% cellspacing=0 cellpadding=32>
<TR>
<TD>
$MSG
		");

	#
	if( $query->param("datafile") && $MSG eq "" )
	{
	}
	else
	{
		UploadForm();
	}

	#
	print("
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>

</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
		");

	#
}


