#!/usr/bin/perl
#
# Update news every 30 minutes.
$INTERVAL = 60*30;

#
main();

#
sub main
{
	#
	for(;;)
	{
		print "Getting news ...\n";
		system "./getnews.pl";
		print "Sleeping ...\n";
		sleep($INTERVAL);
	}
}

