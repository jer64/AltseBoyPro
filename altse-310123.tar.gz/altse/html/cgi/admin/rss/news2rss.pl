#!/usr/bin/perl
#
# News2RSS -- Get Usenet posts and convert them to RSS feeds
#
# Programmed by Bastian Ballmann [ Crazydj@chaostal.de ]
# http://www.chaostal.de
#
# Last Update: 03.04.2004
#
# This code is licensed under the GPL


###[ Loading modules ]###

use Net::NNTP;   
use CGI;         

# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;
#
my $cgi = new CGI;


###[ Config ]###

# Usenet server to connect to
my $server = "uutiset.saunalahti.fi";

# Username to use
my $user = "";

# And the password
my $pass = "";


#
if( $ARGV[0] eq "" || $ARGV[1] eq "" )
{
	#
	print("news2rss.pl 1.0 (command line edition)\n");
	print("Usage: news2rss.pl [group name] [amount of articles to fetch]\n");
	die "Atleast two arguments required.\n";
}

#
$group = $ARGV[0];
$max = $ARGV[1];
##print "group=$group  max=$max\n";

###[ MAIN PART ]###

# Read CGI data
#my $group = $cgi->param("group");
#my $max = $cgi->param("max");

#
$max = 10 if $max eq "";

# Print HTML page
if($group eq "")
{
    print "Content-type: text/html\n\n";
    print <<HTML
	<html>
	<head>
	<title>News2RSS</title>
	</head>
	<body>
	<p align="center">News2RSS</p><br><br>
	<form action="news2rss.pl" method="post">
	<p align="center">
        Newsgroup: <input type="text" name="group"><br>
        Anzahl: <input type="text" name="max"><br> 
	<input type="submit" value="ok">
	</p>
	</form>
	</body>
	</html>
HTML
;
}

# Fetch news and convert them to RSS
else
{
past1:
    # Connect to news server
    my $agent = Net::NNTP->new($server, Timeout => 10) || die("Cannot connect to $server\n$!\n");

    # Login
    $agent->authinfo($user,$pass) or die "login failed!\n$!\n";

    # Fetch all available articles
    my $news = $agent->listgroup($group) or die "cannot list group $group!\n$!";

##    print "Content-type: text/xml\n\n";
    print "<rss version='2.0'>\n";
    print "<channel>\n";
    print "<title>$group</title>\n";

    $count = 0;

    foreach my $msg (@{$news})
    {
	last if $count == $max;

	for(@{$agent->head($msg)})
	{
	    if($_ =~ /^From\:\s+/i)
	    {
		$_ =~ /^From\:\s+\"?(.*)\"?\s+\<(.*)\>/i;
		$from = $1;
	    }
	    elsif($_ =~ /^Subject\:\s+(.*)/i)
	    {
		$subject = $1;
		$subject =~ s/\&/\&amp\;/g;
		$subject =~ s/\@/ at /g;
		$subject =~ s/\</\&lt\;/g;
		$subject =~ s/\>/\&gt\;/g;
	    }
	}

	print "<item>\n";
	print "<title>$from: $subject</title>\n";
	print "<description>\n";
	foreach my $line (@{$agent->body($msg)}) 
	{ 
	    $line =~ s/\&/\&amp\;/g;
	    $line =~ s/\@/ at /g;
	    $line =~ s/\</\&lt\;/g;
	    $line =~ s/\>/\&gt\;/g;
	    print $line; 
	}
	print "</description>\n";
	print "</item>\n";
	
	$count++;
    }
    
    print "</channel>\n";
    print "</rss>\n";
    $agent->quit();	
}
