#!/usr/bin/perl
#
#################################################################################

#
require "../admin.pl";

#
main();

################################################################################
#
sub dw
{
	my $str;

	#
	$str = $_[0];
	$str =~ s/'/\\'/g;
	$str =~ s/\"/\\'/g;
	$str =~ s/\\/\\\\/g;
	print("document.write('$str');\n");
}

################################################################################
#
sub ViewHL
{
	my @art,$cap;

	#
	@art = LoadList("$NWPUB_CGIBASE/poimitut/$_[0]");

	#
	$cap = substr($art[0], 0, 200);

	#
	$str = sprintf("<li class=rss_item><a class=rss_item_link href=viewarticle.pl?poimitut/$_[0] class=dark>$cap</a></li>");
	dw($str);
}

################################################################################
#
sub ViewNewStuff
{
	my @lst,$i,$i2;

	#
	@lst = LoadList("$NWPUB_CGIBASE/poimitut/fileindex.txt");

	#
	dw("<div class=rss_feed>");
	dw("<div class=rss_feed_title>VAI (vunet.world):</div>");
	dw("<ul class=rss_item_list>");

	#
	for($i=$#lst,$i2=0; $i2<10; $i2++,$i--)
	{
		#
		ViewHL($lst[$i]);
	}

	#
	dw("</ul>");
	dw("</div>");
}

################################################################################
#
sub main
{
	###############################################################3
	#
	ViewNewStuff();

}

