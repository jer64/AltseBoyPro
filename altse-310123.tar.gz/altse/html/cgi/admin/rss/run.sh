#!/bin/bash
#
for ((  i = 0 ;  ;  i++  ))
do
	printf "Getting news ...\n";
	./getnews.pl
	printf "Sleeping ...\n";
	sleep 600;
done
