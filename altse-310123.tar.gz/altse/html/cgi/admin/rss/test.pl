#!/usr/bin/perl
print "$ENV{'PATH_INFO'}\n";
