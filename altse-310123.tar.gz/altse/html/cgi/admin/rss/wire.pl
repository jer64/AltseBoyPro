#!/usr/bin/perl
use XML::RSS::JavaScript;
use LWP::Simple;

#
main();

#
sub main
{
	#
	my $xml = get( $ARGV[0] );
	my $rss = XML::RSS::JavaScript->new();
    
	#
	$rss->parse( $xml );
	print $rss->as_javascript();
}

