#!/usr/bin/perl
#
if( $ARGV[0] =~ /^\//)
{
	chdir($ARGV[0]);
}

#
require "tools.pl";

#
main();

#
sub Handle
{
	my @lst,$i,$i2,$i3,$i4;

	#########################################################################
	#
	@lst = LoadList($_[0]);

	#
	print "Generating JavaScript files ($_[0]) ...\n";
	for($i=0; $i<($#lst); $i+=2)
	{
		if(length($lst[$i+1])>1)
		{
			print "\"$BAS/$lst[$i].js\"\n";
			system "./wire.pl $lst[$i+1] > \"$BAS/$lst[$i].js\"";
		}
	}
}

#
sub Usenet
{
	#
	system "./news2rss.pl $_[0] 10 > $_[1]";
}

#
sub main
{
	my @lst,$i,$i2,$i3,$i4,$f;

	#########################################################################
	#
	chdir("$NWPUB_CGIBASE/rss");

	#########################################################################
	#
	open($f, ">>getnews.log") || die "can't write log!!!";
	$t = time;
	print $f "$t\n";
	close($f);

	#
	$BAS = "$NWPUB_WWWBASE/js";

	#########################################################################
	#
	@lst = LoadList("./convert.txt");

	#
	if($ARGV[0] eq "quick")
	{
		goto past12;
	}
	print "Converting ...\n";
	for($i=0; $i<($#lst); $i+=3)
	{
		if(!($lst[$i] =~ /^!/))
		{
			print "./html2rss.pl \"$lst[$i]\" $BAS/$lst[$i+2] \"$lst[$i+1]\"\n";
			system "./html2rss.pl \"$lst[$i]\" $BAS/$lst[$i+2] \"$lst[$i+1]\"";
		}
	}
past12:

	# Convert from usenet to RSS.
	Usenet("alt.politics.bush", "$BAS/Usenet_Bush.rss");
	Usenet("misc.activism.progressive", "$BAS/Usenet_Proge.rss");

	# Convert from RSS to JavaScript.
	Handle("rss.txt");
	Handle("alternative_rss.txt");

	#
	system "./vaiwire.pl > $BAS/vai.js";
}


