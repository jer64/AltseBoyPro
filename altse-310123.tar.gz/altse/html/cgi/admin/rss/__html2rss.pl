#!/usr/bin/perl
######################################################################
use XML::RSS::SimpleGen;
use LWP::UserAgent;
use LWP::Simple;
use Data::Dumper;
use HTML::LinkExtor;
use URI::URL;
require HTML::TokeParser;
#
main();

######################################################################
#
sub GetBaseUrl
{
	my $str;

	#
	$str = $_[0];
	$str =~ s/[^\/]*\z//;
#	$str =~ s/(http:\/\/.*\/)[a-zA-Z]*\.[a-zA-Z]*/$1/;
	return $str;
}

#
sub GetIt
{
	use LWP::UserAgent;
	my $ua = LWP::UserAgent->new();
	my $request = HTTP::Request->new(GET => $_[0]);
	my $response = $ua->request($request);
	die "Error fetching '$_[0]': " . $response->status_line unless $response->is_success;
	return $response->content();
}

#
sub ParseHTML
{
	my $i,$i2,$i3,$i4,$str,$str2,$l,$url;

	#
	my $content = GetIt($_[0]); #Get web page in content
	die "get failed $!" if (!defined $content);

	#
	my $p = HTML::TokeParser->new(\$content) || die "wtf? $!";
	$i=0;
	while (my $a = $p->get_token("a"))
	{
		my ($type, $tag, $attr) = @$a;
		if ($type eq 'S')
		{
			print Dumper($type);
			print Dumper($tag);
			print Dumper($attr);
			@db_href[$i] = $attr->{href};
			$str = $p->get_text("/a");
			@db_text[$i] = $str;
			if($db_href[$i] ne "")
			{
				print("*** @db_href[$i] = \"@db_text[$i]\"\n\n\n");
				$i++;
			}
		}
	}

	#
}

######################################################################
#
sub main
{
	my $i,$i2,$i3,$i4,$href,$text;

	#
	if($ARGV[0] eq "" || $ARGV[1] eq "")
	{
		print("html2rss.pl [file name]\n");
		return;
	}

	# Read the html and parse it into db_href and db_text database..
	ParseHTML($ARGV[0]);
	return;

	#
	my $url = $ARGV[0];
	my $base,$str="";
	rss_new( $url, $ARGV[2]);

	#
	$base = GetBaseUrl($url);
	print "*** base URL = $base ***\n";
	if($base eq "")
	{
		return;
	}

	#
	rss_language( 'en' );
	rss_webmaster( 'vai@vunet.world' );
	rss_twice_daily();

	#
	rss_get_url( $url );

	#
	rss_item("$ARGV[0]", "[Index]", "");

	#
	for($i=0; $i<($#db_href+1); $i++)
	{
		#
		$text = $db_text[$i];
		$href = $db_href[$i];

		#
		$des = $text;
		$des =~ s/\n//g;
		$des =~ s/\r//g;
		$des =~ s/\s{2}/\ /g;
		$ur = $href;
		$ur =~ s/[\n|\r]//g;
		$ur =~ s/\ /%%020/g;

		#
		if($ur eq "")
		{
			goto past;
		}

		# Remove all tags from the description.
		$des =~ s/<.*?>//g;
		$des =~ s/<\/.*?>//g;
#		$des =~ s/<(.*?)>(.*?)<\/\1>/$2/g;

		#
		$ur =~ s/^\s//g;
		$des =~ s/^\s//g;

		#
		if(length($des)<3)
		{
			$des = "";
		}

		#
		$ur2 = $ur;
		$ur2 =~ s/\W//g;
		#
		$des2 = $des;
		$des2 =~ s/\W//g;

		#
		if( !($ur =~ /mailto:/i) && length($des2)>4 && length($ur2)>4 )
		{
			#
			if($des =~ /[\<|\>]/)
			{
				#
			}
			elsif($ur =~ /http\:/i)
			{
				rss_item("$ur", $des, "");
			}
			else
			{
				if($ur =~ /\.htm/i)
				{
					rss_item("$base$ur", $des, "");
				}
				else
				{
					rss_item("$ARGV[0]$ur", $des, "");
				}
			}
		}
		else
		{
			print stderr "Unable to handle (2): '$ur' ** '$des'\n";
		}
past:
	}				


	#
	print "No items in this content?\n"
	unless rss_item_count();

	#
	rss_save("$ARGV[1].rss", 1);
}


