#!/usr/bin/perl
##########################################################################
#
# PORTAL LOG VIEWER/PARSER.
# TEXT ONLY.
#
##########################################################################

#
require "admin.pl";

# Load configuration & parse args.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$ENV{'CURSEC'} = "linkit";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
main();


################################################################
# Load & Parse Log !
#
sub LoadLog
{
	my (@log,$i,$i2,$i3,$i4,
		$str,$str2,$str3,$str4);

	#
	@log = LoadList($_[0]);

	#
	return @log;

	#
	for($i=0; $i<($#log+1); $i++)	
	{
		#
		$log[$i] =~ s/<br>//g;
		# Get subject.
		$str2 = $log[$i];
		$str2 =~ s/(.*)(')(.*)(')(.*)/$3/i;
		$str2 =~ s/ /_/g;

		# Get other.
		$str = $log[$i];
		$str =~ s/(.*)(')(.*)(')(.*)/$1/i;

		#
		@tab = split(" ", $log[$i]);
		#
		$IP = $tab[6];
		$IP =~ s/.*=//;
		#
		$HOST = $tab[7];
		$HOST =~ s/.*='(.*)'/$1/;

		#
		$log[$i] = "$str $str2";
	}

	#
	return @log;
}

################################################################
sub TableBeg
{
	#
	print("
		<table
			cellspacing=0 cellpadding=32>
		<tr>
		<td>
		");
}

################################################################
#
sub TableEnd
{
	#
	print("
		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub LogView
{
	my (@log,$str,$str2,$str3,$str4,$str5,
		$i,$i2,$i3,$i4,$i5,$i6,
		@spt,$CAP,$lhost,$chost,$fn);

	#
	$LOOK_FOR = $so{'SEARCH'};
	$LOOK_FOR =~ s/\"/\\\'/g;

	#
	$c1 = ""; $c2 = "";
	if($so{'compact'} ne "")
	{
		$c1 = "checked";
	}
	else
	{
		$c1 = "";
	}

	#
	$ct = time;

	#
	loop: for($lhost="",$i5=time,$i=$#lg-8,$i2=0; $i2<10 && $i>=0; $i-=8)
	{
		#
		$i6 = time;
		if( ($i6-$i5)>=5 )
		{
			last loop;
		}

again:
		#
		if( $lg[$i+1] eq "" || !($lg[$i+1] =~ /^[0-9]*$/) ) { $i--; goto again; }

		#
		$et = $lg[$i+1];
		($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime($et);

		#
		$Year += 1900;
		$Month++;

		#
		$Hour = sprintf "%.2d", $Hour;
		$Minute = sprintf "%.2d", $Minute;
		$Second = sprintf "%.2d", $Second;

		#
		$spt[0] = "$Day.$Month.$Year<br>$Hour:$Minute:$Second";

		#
		$ip = $lg[$i+4];
		$host = $lg[$i+5];
		$HOST = $host;
		$CAP = $lg[$i+3];
		#
		if(
			($host eq $lhost &&
			$CAP eq $lcap) 
			||
			$host =~ /error\.static\.otenet\.gr/i ||
			$host =~ /googlebot/i || $host =~ /msnbot/i
			|| $host =~ /crawl/i
			|| $host =~ /internetserviceteam\.com/i
			|| $host =~ /www\.gigablast\.com/i
			|| $host =~ /search\.com/i
			|| $host =~ /user-200-47/i
			|| $host =~ /crs032\.goo\.ne\.jp/i
			|| $host =~ /public.alexa.com/i
			|| $host =~ /.ask.com/i
			|| $lg[$i+6] =~ /MJ12bot/i
			|| $host eq ""
			|| IsBanned($host)
			|| $lg[$i+6] =~ /crawler/i )
		{
			goto past;
		}

		#
		$host =~ s/(.{20})/$1 /g;

		#
		$str5 = $lg[$i+7];
		$str5 =~ s/\s//g;
		if(!($str5 =~ /^\/article/))
		{
			$fn = ResolveQuickUrl($str5);
		}
		else
		{
			$fn = $str5;
		}
		if($CAP eq "")
		{
			$CAP = $fn;
			$CAP =~ s/\|//g;
			if( open($f, "$CAP") )
			{
				$CAP = <$f>;
				close($f);
				$CAP =~ s/<br>//gi;
			}
		}
		$fn =~ s/^\/article//;
		if( !($fn=~/^\//) )
		{
			$fn = "/$fn";
		}

		#
		if( $so{'SEARCH'} ne "" && 
			($so{'SEARCH'}=~/^\// && $fn =~ /$so{'SEARCH'}/i) )
		{
			goto qskip;
		}

		###########################################################
		if( $so{'SEARCH'} ne "" &&
			!($CAP =~ /$so{'SEARCH'}/i) )
		{
			goto past;
		}

		#
		$str = $lg[$i+7];
		$str =~ s/^\/\?id\=([0-9]*)x.*$/$1/;
		if( $SEK ne "" && $seid{$SEK} ne $str )
		{
			goto past;
		}
qskip:

		# Compact filtering...
		$chost = $host;
		if($chost eq $lhost && $so{'compact'} ne "")
		{
			goto past;
		}

		#
		if($so{'site'} ne "" && !($host =~ /$so{'site'}/i))
		{
			goto past;
		}

		#
		$lg[$i+7] =~ s/pub_artikkeli([0-9]*)\.txt$/story$1.html/;

		#
		if( ($ct-(60*60*24)) > $et )
		{
			$b1 = "#40FFFF";
			$b2 = "#40A0C0";
			$b3 = "#A0A0C0";
			$b4 = "#C0FFFF";
			$b5 = "#E0FFFF";
		}
		else
		{
			$b1 = "#E04040";
			$b2 = "#C04040";
			$b3 = "#A04040";
			$b4 = "#704040";
			$b5 = "#807060";
		}

		#
		$lg[$i+7] =~ s/\.txt/.html/;
		$spt[0] =~ s/<br>/ /ig;
		print ("
			<font color=black>- 
			$spt[0]:<br>
			$host:<br>
			\"$CAP\"<br>
			</font>
			");

		#
		$i2++;
		$lhost = $HOST;
		$lcap = $CAP;
past:
	}

	#
	if($so{'SEARCH'} ne "")
	{
		#
		print("<br>$i2 results");
	}

	#
}

################################################################
#
sub main
{
	my ($str,$str2,$str3,$str4,
		$i,$i2,$i3,$i4,@sl);

	#
	@sl = LoadList("sections.txt");

	#
	for($i=0; $i<($#sl+1); $i++)
	{
		$seid{$sl[$i]} = $i;
	}
	$SEK = $so{'section'};

	#
	$so{'SEARCH'} =~ s/\W/\.\*/g;
	$so{'SEARCH'} =~ s/\.\*\.\*/\.\*/g;

	#
	if($so{'SEARCH'} =~ /site:/)
	{
		#
		$so{'site'} = $so{'SEARCH'};
		$so{'site'} =~ s/.*site:(.*)$/$1/;
		$so{'SEARCH'} =~ s/site:.*$//;
	}

	#
	$so{'SEARCH'} =~ s/\\\'/\"/g;
	#
	if( !($so{'SEARCH'} =~ /^\//) )
	{
		$so{'SEARCH'} =~ s/[:|\\|\/|;|\"|'|\(|\)|\&|\%]/\.\*/g;
	}

	#
	if($so{'ignore_unknown'} eq "") { $so{'ignore_unknown'} = 'false'; }

	#
	@lg = LoadLog("tail -n80000 avlog.txt|");

	#
	LogView(@lg);

	#
}
