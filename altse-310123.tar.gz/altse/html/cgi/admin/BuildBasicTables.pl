#!/usr/bin/perl
#
# Warning: WILL DESTROY ALL DATA FROM VISITORS "LOG" -TABLE.
#
use DBI;

#
require "$ENV{'HOME'}/cgi/tools.pl";

#
main();

# my $query = "SELECT time, referer, article_title, ip, host,
# web_browser, url, local_file_name FROM visitors ORDER BY ID DESC LIMIT 0,40000";
sub create_visitors_table
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4,
		@age,@fn);

	# Delete table first.
	# SELECT title,section,artid FROM visitors
	# ip,web_browser,time,referer,url,article_title,local_file_name,cookie_info,host,uid

	# $querystr = ("INSERT INTO visitors
	#	(ip,web_browser,time,referer,url,article_title,local_file_name,cookie_info,host,uid)
	#	values
	#	('$ENV{'REMOTE_ADDR'}', '$AGENT', '$Date', '$ENV{'HTTP_REFERER'}', '$str', '$ac', '$_[0]', '', '$hostname', '$uid');");

	$sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`visitors`;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
	# Create it.
	$sth = $dbh->prepare("
CREATE TABLE `vunet`.`visitors` (
  `ID` bigint(20) unsigned NOT NULL auto_increment,
  `web_browser` varchar(255) default NULL,
  `time` varchar(50) default NULL,
  `url` varchar(2048) default NULL,
  `article_title` varchar(512) default NULL,
  `referer` varchar(255) default NULL,
  `local_file_name` varchar(255) default NULL,
  `cookie_info` varchar(255) default NULL,
  `ip` varchar(255) default NULL,
  `host` varchar(255) default NULL,
  `uid` varchar(255) default NULL,
  `date` varchar(50) default NULL,
 PRIMARY KEY USING BTREE (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	# Delete table first.
	$sth = $dbh->prepare("DELETE FROM ArticleDetails;");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
}

#
sub create_articledetails_table
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4,
		@age,@fn);

	# Delete table first.
	# SELECT title,section,artid FROM ArticleDetails
	$sth = $dbh->prepare("
DROP TABLE IF EXISTS `vunet`.`ArticleDetails`;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
	# Create it.
	$sth = $dbh->prepare("
CREATE TABLE `vunet`.`ArticleDetails` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `title` char(255) default NULL,
  `section` char(255) default NULL,
  `artid` char(255) default NULL,
  `date` bigint(20) default NULL,
 PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();

	# Delete table first.
	$sth = $dbh->prepare("DELETE FROM ArticleDetails;");
	$sth->execute() or print "failed on $i ($DBI::errstr)\n";
	$sth->finish();
}

#
sub main {
	my ($i,$i2,$i3,$i4,@lst);

	#
	create_articledetails_table();
	create_visitors_table();

	#
}
