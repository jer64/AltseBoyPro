#!/bin/bash
/home/vai/public_html/cgi-bin/admin/update_titles.sh
/home/vai/public_html/cgi-bin/admin/CPtitles.sh
