#!/usr/bin/perl
#
$NWPUB_CGIBASE =        "/home/vai/public_html/cgi-bin";
#
chdir("/home/vai/public_html/cgi-bin/admin");
main();


#
sub main
{
	#
	system("./nu.pl");
	system("../up2b.sh");
}

