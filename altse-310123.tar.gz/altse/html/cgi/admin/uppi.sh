#!/bin/bash

#
cd /home/vai/public_html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
echo "7"
lynx -source "http://www.vunet.world/chart.pl?MAGIC=32785782378523758&TLI=86400" > /tmp/index-top.html
cp /tmp/index-top.html /home/vai/public_html/cache/index-top.html 
