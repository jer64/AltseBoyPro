# Polling System Configuration
######################################################3

# UNIX world path to the script base.
$POLL_BASE =	"/home/vai/public_html/cgi-bin";
# Directory of vote database.
$VDB = "$POLL_BASE/votes";
# WWW address to this script.
$SCRIPT =	"/poll.pl";
$SCRIPT_ADM =	"/admin/polladm.pl";
$SCRIPT_MAIN =  "/pollmain.pl";

