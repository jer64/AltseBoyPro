#!/usr/bin/perl
#
# polladm.pl - Poll Administration.
# (C) 2005-2006 Jari Tuominen.
#
####################################################################

#
require "tools.pl";
require "poll-cfg.pl";

#
$ENV{'CURSEC'} = "aanestykset";
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
# Add main menu.
WebWalkTo("main-menu");
#
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
EndBar();
#
HandleRest();

##################################################
#
sub CountPolls
{
	my ($i,$i2,$i3,$i4);

	#
	loop: for($i=1; $i<10000; $i++)
	{
		if( open($f, "$VDB/poll$i\.form") )
		{
			close($f);
		}
		else
		{
			last loop;
		}
	}

	#
	return $i-1;
}

##################################################
#
sub PollEditor
{
	my ($i,$i2,$i3,$i4,$fn,$str,$str2);

	#
	if($so{'POLL'} eq "")
	{
		$so{'POLL'} = $cnt+1;
	}

	#
	if($so{'POLL'} ne "")
	{
		$fn = "$VDB/poll$so{'POLL'}\.form";
		if( -e $fn )
		{
			@form = LoadList($fn);
			for($i=0; $i<($#form+1); $i++) { VarSet($form[$i]); }
		}
		else
		{
			$CREATE_NEW = 1;
		}
	}

	#
	print("
		<a href=\"$SCRIPT_ADM\" class=dark>
		< Back to Poll Administration.
		</a>
		<br><br>

		<div align=center>
		<a name=\"CREATION\"></a>
		<b>
		Poll Editor
		</b><br>
		</div>

		<br>");

	#
	print("
		<form action=\"$SCRIPT_ADM?CMD=CHANGE&POLL=$so{'POLL'}\" class=formx>
		<table cellpadding=4 cellspacing=4 bgcolor=\"#FF4040\" width=100%>
		<tr>
		<td>
			<b>$VDB/poll$so{'POLL'}\.form</b>
		</td>
		</tr>
		</table>
		");

	#
	print("
		<form action=\"$SCRIPT_ADM\">
		<input type=\"hidden\" name=\"POLL\" value=\"$so{'POLL'}\">
		<input type=\"hidden\" name=\"CMD\" value=\"SAVE\">
		<table cellpadding=4 cellspacing=4 bgcolor=\"#FF8080\" width=100%>
		");

	#
	print("

		<tr valign=top>
		<td>question:</td>
		<td><input type=\"text\" name=\"form0\" value=\"$form[0]\" size=40></td>
		</tr>
		");

	#
	for($i=1,$i2=1; $i<20+1; $i++)
	{
		#
		if($form[$i2] ne "")
		{
			$str = $form[$i2];
			$i2++;
		}
		else
		{
			$str = "";
		}

		#
		print("
			<tr valign=top>
			<td>answer $i:</td>
			<td><input type=\"text\" name=\"form$i\" value=\"$str\" size=30></td>
			</tr>
			");
	}

	#
	print("
			<tr valign=top>
			<td>
			<div align=center><b>OPTIONAL</b></div>
			</td>
			</tr>

			<tr valign=top>
			<td>poll <b>image</b> URL:</td>
			<td><input type=\"text\" name=\"formimage\" value=\"$so{'formimage'}\" size=40></td>
			</tr>

			<tr valign=top>
			<td>reference URL <b>description</b>:</td>
			<td><input type=\"text\" name=\"formreftext\" value=\"$so{'formreftext'}\" size=40></td>
			</tr>

			<tr valign=top>
			<td>reference <b>URL</b>:</td>
			<td><input type=\"text\" name=\"formrefurl\" value=\"$so{'formrefurl'}\" size=40></td>
			</tr>

			");
	

	#
	if($CREATE_NEW)
	{
		$str = "CREATE NEW POLL";
	}
	else
	{
		$str = "SAVE MODIFICATIONS";
	}

	#
	print("	
		</table>

		<table cellpadding=4 cellspacing=4 bgcolor=\"#0080FF\" width=100%>
		<tr>
		<td>
		<div align=right>
		<input type=\"submit\" value=\"$str\">
		</div>
		</td>
		</tr>

		</table>
		");

	#
	print("

		</form>
		
		");

}

##################################################
#
sub RedMessage
{
		#
		print("
			<font color=\"#FF4020\">
			$_[0]<br>
			</font>
			<br>
			");
}

##################################################
#
sub SavePollForm
{
	my ($i,$i2,$i3,$i4,$str,$str2,$f);

	#
	open($f, ">$_[0]") || die "CAN'T SAVE POLL FILE";
	loop: for($i=0; $i<1000; $i++)
	{
		$str2 = "form$i";
		$str = $so{$str2};
		if($str eq "") { last loop; }
		print $f "$str\n";
	}
	print $f "\n";
	print $f "formimage=$so{'formimage'}\n";
	print $f "formreftext=$so{'formreftext'}\n";
	print $f "formrefurl=$so{'formrefurl'}\n";
	close($f);
}

##################################################
#
sub PerformCommand
{
	#
	if($so{'CMD'} eq "SAVE")
	{
		# Discard illegal polls.
		if($so{'form0'} eq "" || $so{'form1'} eq "" || $so{'form2'} eq "")
		{
			#
			RedMessage("Please verify your poll data.");
			RedMessage("The poll must have AT LEAST two possible answers and a question.");
		}
		else
		{
			#
			SavePollForm("$VDB/poll$so{'POLL'}\.form");

			#
			RedMessage("Poll Saved.");

			#
		        print("
		        <meta http-equiv=\"REFRESH\"
		        content=\"0;url=$SCRIPT_ADM\">
	                ");

		}
	}
}

##############################################################################################################
#
sub PollAdmMain
{
	my ($i,$i2,$i3,$i4);
	my @langs = (
		"fi", "suomi",
		"en", "englanti"
		);

	#
	$lang = $so{'lang'};
	if($so{'lang'} eq "")
	{
		$lang = "fi";
	}

	#
	$cnt = CountPolls();

	#
	if($so{'START'} ne "")
	{
		if( open($f, ">$POLL_BASE/cfg/current-poll_$lang.txt") )
		{
			print $f "$so{'START'}\n";
			close($f);
			$so{'POLL'} = $so{'START'};
			print "Default changed.<br>";
		}
	}

	#
	if($so{'CMD'} ne "")
	{
		PerformCommand();
	}

	#
	if($so{'CMD'} eq "")
	{
	print("
		<div align=center>
		<font size=4>
		<B>
		POLL ADMINISTRATION
		</B>
		</font>
		</div>

		<br>
		<div align=right>
		$cnt poll(s) registered. <br>
		</div>
		<BR>
		<FORM action=polladm.pl>
		<TABLE width=100%>
		<TR>
		<TD width=50%>Valitse kieli:
		<select name=lang onChange='this.form.submit()'>
		");
	for($i=0,$sel=""; $i<($#langs); $i+=2)
	{
		if($langs[$i+0] eq $lang)
		{
			$sel = "selected";
		}
		else
		{
			$sel = "";
		}
		print("
		<option value=$langs[$i+0] $sel>$langs[$i+1]</option>
			");
	}
	print("
		</select
		</TD>

		<TD width=50%>
		<DIV align=right class=caps>$lang</DIV>
		</TD>
		</TR>
		</TABLE>
		</FORM>
		");

		#
		if( open($f, "$POLL_BASE/cfg/current-poll_$lang.txt") )
		{
			$WHICH = <$f>;
			close($f);
		}

		#
		for($i=1; $i<($cnt+1); $i++)
		{
			#
			@poll = LoadList("$VDB/poll$i\.form");

			#
			if($i==$WHICH)
			{
				$STR = "<font color=\"#FF2020\">active</font>";
			}
			else
			{
				$STR = "<a href=\"$SCRIPT_ADM?START=$i&lang=$lang\">start</a>";
			}
	
			#
			print("
				<table width=500 cellpadding=0 cellspacing=4>
				<tr valign=top>

				<td width=60%>
				$i\. $poll[0]
				</td>
	
				<td width=10%>
				</td>

				<td width=10% bgcolor=\"#E0E0E0\">
				<a href=\"$SCRIPT_ADM?CMD=EDIT&POLL=$i\"><div align=center>edit</div></a>
				</td>

				<td width=10% bgcolor=\"#E0E0E0\">
				<a href=\"$SCRIPT?POLL=$i\"><div align=center>test</div></a>
				</td>

				<td width=10% bgcolor=\"#E0E0E0\">
				<div align=center>$STR</div>
				</td>

				</tr>
				</table>


				<table width=500 cellpadding=0 cellspacing=0 height=1
					bgcolor=\"#000000\">
				<tr>
				<td>
				</td>
				</tr>
				</table>
	
				");
		}
	
		#
		print("
			<br>
			Click on <b>START</b> to activate the poll.<br>
			<br>
			<a href=\"$SCRIPT_ADM?CMD=CREATE\" class=dark>> Create New Poll</a><br>
			<a href=\"$SCRIPT_MAIN\" class=dark>> Voting Center</a><br>
			");
	}


	#
	if($so{'CMD'} eq "EDIT" || $so{'CMD'} eq "CREATE")
	{
		PollEditor();
	}
}

##################################################
sub main
{
        #
        $DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	print ("
		<table cellpadding=32 cellspacing=0 width=70%>
		<tr>
		<td>
		");

	#
	PollAdmMain();

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
}


