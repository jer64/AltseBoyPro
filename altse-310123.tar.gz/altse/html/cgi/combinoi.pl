#!/usr/bin/perl

#
require "tools.pl";

#
@lst = LoadList("$ARGV[0]");

#
for($i=0; $i<($#lst+1); $i++)
{
	if($i%4==3) { print "\n"; }
	print ("$lst[$i]; ");
}
