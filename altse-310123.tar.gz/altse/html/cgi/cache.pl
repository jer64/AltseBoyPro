#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	#
	$so{'q'} =~ s/[^a-zA-Z0-9\_\-]/_/g;

	#
	ViewCachePage($so{'q'});

	#
}


