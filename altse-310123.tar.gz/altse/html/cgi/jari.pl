#!/usr/bin/perl
#############################################################################
# top20.pl - ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use DateTime;
use Time::Moment;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseBoyMenu.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://ww&#128513;w.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
JariPage();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub JariPage
{
        #
        my $HTML_MENU = AltseBoyMenu();


        #
        print("
$HTML_MENU
	");
	
	#
	print("
<TABLE width=\"640\" align=\"center\" bgcolor=\"black\">
<TR>

<TD>

<FONT STYLE=\"color: LIGHTBLUE;\">
<A HREF=\"https://www.facebook.com/jari.t.tuominen\">
<DIV ALIGN=\"CENTER\">
<IMG SRC=\"/images/jari.jpg\"
	alt=\"Facebook - Jari Tapio Tuominen\" title=\"Click Here For Jari's Facebook - Klikkaa Tasta Paastakseis Jarin Facebookiin!\"
	width=\"256\" height=\"350\">
</DIV>
</A>

<H1>&#128513; E-Mail: <a href=\"mail-to:jari.t.tuominen\@gmail.com\">jari.t.tuominen\@gmail.com</a></H1>
<H1>&#128513; WhatsApp/Telephone: +358449259932</H1>
</FONT>
	");
	
	#
	print("
</TD>
</TR>
</TABLE>
	");
}


1;
