#!/usr/bin/perl
# P�IVIT� ETUSIVU

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
sub main
{
	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
document.title = 'Updating front pages ...';
</SCRIPT>
	");
	print("Updating front pages ... <br>");
	system "bash ./cacheupd.sh";
	print("<br>Done.<br>");
	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
document.title = 'Done.';
</SCRIPT>
	");
}

