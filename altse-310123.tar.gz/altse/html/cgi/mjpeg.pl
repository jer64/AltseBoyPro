#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	#
	print("
<IMG SRC=\"\" id=kuva>

<SCRIPT LANGUAGE=\"Javascript\">
var frame=0;

function movie()
{
	i = document.getElementById('kuva');
	kuva.src='$IMAGES_BASE/mjpeg/com ' + frame + '.jpg';
	frame++;
	setTimeout('movie()', 500);
}
setTimeout('movie()', 500);
</SCRIPT>
		");

	#
}


