#!/usr/bin/perl
require "/home/vai/public_html/cgi-bin/tools.pl";

#
@lst = LoadList("fileindex.txt");

#
for($i=0; $i<($#lst+1); $i++)
{
	#
	if(-e $lst[$i])
	{
		print "$lst[$i]\n";
	}
}

#

