#!/usr/bin/perl
# whatsnew.pl
##############################################################################################################

#
require "tools.pl";
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
$ENV{'CURSEC'} = "kaksiviikkoa";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub WhatsNew
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,@age,$str,$str2);

	#
	@lst = LoadList("kaikki/fileindex.txt");

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\.\///;
		if(-e $lst[$i])
		{
			$age[$i2++] = sprintf "%1.10d %d $lst[$i]", FileAge($lst[$i]), (stat($lst[$i]))[9];
		}
	}

	#
	@age = sort @age;
	#@age = reverse @age;

	#
	loop: for($i=0,$str=""; $i<($#age+1); $i++)
	{
		@sp = split(/ /, $age[$i]);
		if($sp[0] >= $_[0]) { $count = $i; last loop; }
		$str = ("$str
			<DIV ALIGN=CENTER>
			<TABLE cellspacing=0 cellpadding=0 width=400>
			<TR>
			<TD>
			");
		$date = POSIX::strftime("%d.%m.%Y", localtime($sp[1]));
		if($date ne $ldate)
		{
			$str = ("$str
<font class=major_headline size=4>$date</font><BR>
<TABLE cellspacing=0 cellpadding=0 width=100% height=4
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>
");
		}
		$str = sprintf "$str %s", ViewHL($sp[2], "news1");
		$str = ("$str
			</TD>
			</TR>
			</TABLE>
			</DIV>
			");
		$ldate = $date;
	}

	#
	$str = ("$str
<DIV align=center>$count uutista julkaistu viimeisten 2 viikon aikana</DIV><BR>

$str
		");

	#
	return $str;
}

###########################################################################################################
#
sub main
{
	my ($str,$str2,$i,$i2);

	#
	$str = ("
<TABLE class=whats_new_window width=640>
<TR>
<TD>

<div align=center>
<font class=section_headline>
Kahden Viikon Uutuudet
</font>
</div>
<BR>
");

	#
	$str = sprintf "%s %s", $str, WhatsNew(60*60*24*7*2);

	#
	$str = ("$str

</TD>
</TR>
</TABLE>
		");

	#
        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;	
        #
        print("  document.write(\"$str\");  \n");

	#
}


################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
		$alt,$ifn,$i,$i2,@thu,@ips);

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "/$_[0]";
	$url = UrlFix($url);

        # If article text file exists...
	if(-e $_[0])
	{
		$fn_counter = $_[0];
		$fn_counter =~ s/\.txt$/.counter/;
		$fn_thumbs = $_[0];
		$fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
		$fn_com = $_[0];
		$fn_com =~ s/\.txt$/.txt_comindex.txt/;
	        @art = LoadList("$_[0]");
		@ips = ();
	        if(-e $fn_counter) { @ips = LoadList("$fn_counter"); }
		$thumbs = GenThumbHtml($_[0]);
		@kom = ();
		$comments="";
		if(-e $fn_com)
		{
			@kom = LoadList($fn_com);
			$i = $#kom+1;
			if($i != 0)
			{
				if( $ENV{'REMOTE_HOST'}=~/\.fi$/ )
				{
					$comments = "($i kommenttia)";
				}
				else
				{
					$comments = "($i comments)";
				}
			}
		}
	}
	else
	{
		return "";
	}

	#
	$score = sprintf "%d", ($#ips+1)/2;
	if($score>99) { $score="medal.gif"; $alt="very popular article"; }
	if($score>7 && $score<100) { $score="7_beyond"; $alt="popular article"; }
	if($score<0) { $score=0; $alt="article($score)"; }

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#	$goo = Googler($cap);

	#
	ParseOptions("$_[0]\_options.txt");

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>


		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>

		<TD valign=top width=32>");

	#
	$url = CapUrl($url, $cap);

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = "$IMAGES_BASE/document.gif";
		if($url=~/software/)
		{
			$so{'imageurl'} = "$IMAGES_BASE/software.gif";
		}
	}
	else
	{
		$so{'imageurl'} =~ s/^(.*[\/])([a-z0-9\-\_\!]*)\.([a-z])*$/$1thumb2\/th_$2.png/i;
	}
	if($so{'imageurl'} ne "")
	{
		$str = ("$str
			<!---- ARTICLE IMAGE ---->
			<A HREF=\"http://www.vunet.world$url\" class=news1>
			<IMG SRC=\"$so{'imageurl'}\" border=0>
			</A>
			");
	}
	else
	{
	}
	$str = ("$str </TD>");

	#
	$str = ("$str
		<TD width=4>
		</TD>

		<TD valign=top width=250>
                <div>
		<font size=3>
		<a href=\"http://www.vunet.world$url\" class=$_[1]>
		<!---- ARTICLE CAPTION ---->
                $cap
		$thumbs</a>
		$comments
		");
	$t = (stat($_[0]))[9];
	$ct = time;
	$age = $ct-$t;
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($_[0], "news3");
	#
	if($score=~/\./)
	{
		$ifn = $score;
	}
	else
	{
		$ifn = "meter$score.gif";
	}
	if($age < (60*60*16))
	{
		$ifn = "uusi1.gif";
	}
	#
	$str = ("$str
		</font>
                </div>
		</TD>

		<TD width=24>
		<!---- ARTICLE RANKING ---->
		<IMG SRC=\"$IMAGES_BASE/$ifn\" alt=\"$alt\" title=\"$alt\">
		</TD>


		</tr>
		</table>

		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>
                ");

	#
	return $str;
}

#
sub GenThumbHtml
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
                $str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
                $alt,$ifn,$i,$i2,@thu,@ips,$thumbs,
                $fn_thumbs,@lst);

        #
        $fn_thumbs = $_[0];
        $fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
        if(-e $fn_thumbs) { @lst = LoadList("$fn_thumbs"); @thu = split(/\ /, $lst[0]); }
        for($thumbs="",$i=0; $i<($#thu+1); $i++)
        {
                $thumbs = ("$thumbs<IMG SRC=\"$IMAGES_BASE/thumb_up_c.gif\" border=0>");
        }

        #
        return $thumbs;
}

