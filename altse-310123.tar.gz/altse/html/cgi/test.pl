#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
use Time::localtime;
use File::stat;

#
main();

##############################################################
sub Examine
{
	my $fh;

	#
	$fh = $_[0];

	#
	printf $fh $_[1];
}

##############################################################
#
# Main
#
sub main
{
	my (@lst);

	#
	@lst = GetLatestArticles();

	#
	for($i=0; $i<($#lst); $i+=3)
	{
		#
		print("
$lst[$i+0]
$lst[$i+1]
$lst[$i+2]
");
	}

	#
}
