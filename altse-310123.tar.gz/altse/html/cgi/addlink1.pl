#!/usr/bin/perl
#############################################################################
# (C) 2004 by Jari Tuominen.
#############################################################################

# Form sent article data is HTML?
$IS_HTML = 0;

#
$RETURL = "viewall.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#######################################################
# Go to main loop.
#
main();

#######################################################
#
sub read_input
{
	# Read in text
	$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
	if ($ENV{'REQUEST_METHOD'} eq "POST")
	{
		@__buffer = split(/\&/, $all);
	}
	else
	{
		print "Error: Post method required.<br>\n";
		die;
		#$buffer = $ENV{'QUERY_STRING'};
	}

	#
	$DESCRIPTION =	$__buffer[0];
	$DESCRIPTION =~ s/\+/ /ig;
	$DESCRIPTION =~ s/%(..)/pack("C", hex($1))/eg;
	$DESCRIPTION =~ s/description\=//;
	$DESCRIPTION =~ s/\n//g;
	$DESCRIPTION =~ s/\r//g;

	#
	$URL =	$__buffer[1];
	$URL =~ s/\+/ /ig;
	$URL =~ s/%(..)/pack("C", hex($1))/eg;
	$URL =~ s/url\=//;
	$URL =~ s/\s//g;
	$URL =~ s/\n//g;
	$URL =~ s/\r//g;
}

##########################################################
sub save_article
{
	local $i;

	# Write the article on drive.
	print ("
		description = $DESCRIPTION<br>
		url = $URL<br>
		");

	#
	if( length($DESCRIPTION) > 300 )
	{
		die "<H1>Description is too long. It can be at most 300 characters !</H1>";
	}

	#
	if( $URL eq "" || $DESCRIPTION eq "" )
	{
		die "<H1>DESCRIPTION or URL can not be empty !</H1>";
	}

	#
	if( !($URL =~ /http\:\/\/+./) )
	{
		die "<H1><blink>error: \"$URL\"</blink></H1><H1>URL must begin with <u>http:\/\/</u> !</H1>Please click back button on the browser and retry.";
	}

	#########################################################

	#
	system "echo \"$URL\" >> linklist.txt";
	system "echo \"$DESCRIPTION\" >> linklist.txt";
}

##########################################################
sub main
{
	#
	print "<html>\n";

	#
	$argarg = $ENV{'QUERY_STRING'};
	read(STDIN, $all, $ENV{'CONTENT_LENGTH'});
	#
	@__buffer = split(/\&/, $all);
	$temppi = $__buffer[1];
	@temppi2 = split(/\=/, $temppi);

	##################################################################
	if($all =~ /ishtml78458132751764/)
	{
		#
		$IS_HTML = 1;
	}

	# Detect correct password always.
	if($all =~ /$ADMINPASSWORD/)
	{
		# Enable administration mode.
		$admin = 1;
	}

	# Password check.
	if($REQUIREPASSWORD!=0 && !$admin)
	{
		print "Error: Invalid password.<br>\n";
		die;
	}

	##################################################################
	if($all =~ /archivei43538453/i)
	{
		# Add article to the end of the list.
		$MUSEUM_ARTICLE = 1;
	}

	##################################################################
	if($argarg =~ /comart7895789235/i)
	{
		#
		print "Illegal function.<br>\n";
		die;
	}
	

	#
	read_input();

	#
	save_article();

	#
	print "<meta http-equiv=\"refresh\" content=\"0; url=$RETURL\">\n";

	#
	print "<h2>Link successfully added. Thank you.<br>\n";
	print "<a href=\"$RETURL\">\n";
	print "Returning to A.N.A.<br>\n";
	print "</a>\n";

	#
	print "<hr><br>\n";

	#
	print $buffer;

	#
	print "</html>\n";
}


