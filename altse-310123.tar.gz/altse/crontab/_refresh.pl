#!/usr/bin/perl
# OBSOLETE, USE CRONTAB
for(;;)
{
	chdir("/home/vai/sdb/crontab/crawl_news.sh");
	print STDERR "Crawling news ...\n";
	system("nice -n 20 /home/vai/sdb/crontab/crawl_news.sh");
	print STDERR "Updating news database ...\n";
	system("nice -n 20 /home/vai/sdb/crontab/update_news_db.sh");
	print STDERR "Sleeping 30 minutes and runnning crawl & update again ...\n";
	sleep(60*10);
}
