#!/bin/bash
iconv -t ISO-8859-1 -f UTF-8 < maat.txt > 	maat_iso.txt
iconv -t ISO-8859-1 -f UTF-8 < talous.txt >	talous_iso.txt
