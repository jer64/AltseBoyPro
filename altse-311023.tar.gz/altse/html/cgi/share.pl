#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "videos";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, "english");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	#
	print("
<TABLE width=500 cellspacing=0 cellpadding=32>
<TR>
<TD>
<IMG SRC=\"$IMAGES_BASE//soviet-symbol.png\" align=right>
<FONT size=5>Share The Fun !</FONT><BR>
<BR>
It is possible to share the video on your website by inserting following piece of HTML code into your website.<BR>
<BR>
<TEXTAREA cols=80 rows=5>
<script src=\"http://www.vunet.world/jsvideo.pl?v=$so{'v'}\">
</script>
</TEXTAREA>
<BR>
<BR>
The video should appear in a following way on your website:<BR>
<BR>
<script src=\"http://www.vunet.world/jsvideo.pl?v=$so{'v'}\">
</script>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</TD>
</TR>
</TABLE>
		");

	#
}


