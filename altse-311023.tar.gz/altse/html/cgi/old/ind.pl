#!/usr/bin/perl
######################################################################
#
# Vunet Search Engine
# Single file dictionary creator.
#
######################################################################
require "/home/vai/public_html/cgi-bin/tools.pl";

#
main();

##############################################################################
#
sub GetWordIndexNumber
{
	my ($i,$i2,$str,$str2,@sp,$a1,$a2);

	#
	for($i=0; $i<($#wo+1); $i++)
	{
		if($wo[$i] eq $_[0]) { return $i; }
	}
	reutrn -1;
}

##############################################################################
#
# CountWords1 [prize factor]
#
sub CountWords1
{
	my ($i,$i2,$str);

	##########################################################
	# Count amount of each word.
	#
	for($i=0; $i<($#WORDS+1); $i++)
	{
		if( length($WORDS[$i])>2 && length($WORDS[$i])<45 )
		{
			$dic{$WORDS[$i]} += $_[0];
		}
	}
}

##############################################################################
#
sub CountWords
{
	my ($i,$i2,$str);

	##########################################################
	# Split into words.
	#
	@WORDS = split(" ", $_[0]);

	#
	CountWords1($_[1]);
}

##############################################################################
#
sub IndexThis
{
	my ($i,$i2,$str,$str2,@sp,$a1,$a2,$body,$head);

	################################################
	#
	# Load source file.
	#
	@src = LoadList($_[0]);


	##########################################################
	# Make the whole article a single string.
	#
	for($i=0,$body=""; $i<($#src+1); $i++)
	{
		$body = "$body $src[$i] ";
	}

	#
	$body =~ tr/[A-Z���]/[a-z���]/;
	$body =~ s/[^a-z���0-9\:\-\ ]/ /g;

	# Article body.
	CountWords($body, 1);

	# Article headlines (give extra points).
#	loopx: for($i=0; $i<($#src+1); $i++) {  if(length($src[$i])>2 && $src[$i]=~/\S/) { last loopx; }  }
#	CountWords($src[$i], 100);
#	loopx2: for($i++; $i<($#src+1); $i++) {  if(length($src[$i])>2 && $src[$i]=~/\S/) { last loopx2; }  }
#	CountWords($src[$i], 10);
#	loopx3: for($i++; $i<($#src+1); $i++) {  if(length($src[$i])>2 && $src[$i]=~/\S/) { last loopx3; }  }
#	CountWords($src[$i], 2);

	##########################################################
	# Display results.
	#
        foreach $key (keys %dic)
        {
		$str = sprintf "$key %d\n", $dic{$key};
		print $str;
        }
}

##############################################################################
#
sub main
{
	my ($fn,$str,$fn);


	#
	if( !($ARGV[0] =~ /^\s$/) && -e $ARGV[0] )
	{
		# Create text version of the HTML page (needed later on, too!).
		$fn = $ARGV[0];
		$fn =~ s/\.[a-z]*$//;
		$fn = "$fn\_asc.txt";
		$str = "lynx -dump -image_links \"$ARGV[0]\" > \"$fn\""; # also include all links.
		system($str);
		# Index the text version.
		IndexThis("$fn");
	}
}

