#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";
#
#print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
Trends();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


####################################################################################################
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub Trends
{
        #
        my $HTML_MENU = AltseMenu();


        #
        print("
$HTML_MENU
	");

	#
	print("
<TABLE width=\"640\" align=\"center\" bgcolor=\"black\">
<TR>

<TD>

<DIV ALIGN=\"CENTER\">
<FONT COLOR=\"#FFFFFF\">
<H1>Trendikkaimmat haut</H1>
</FONT>
</DIV>
	");
	
	#
	my @trends = LoadList("/usr/bin/perl $DB/altse/bin/trends|");
	
	#
	for(my $i=0; $i<($#trends+1) && $i<500; $i++)
	{
		my $str = $trends[$i];
		my $s1 = $str; $s1 =~ s/^([0-9]+)\s.*$/$1/;
		my $s2 = $str; $s2 =~ s/^[0-9]+\s(.*)$/$1/;
		my $viewstr = $s2; $viewstr =~ s/^(.{25}).*/$1 .../;
		
		print("
<TABLE WIDTH=\"100%\">
<TR>

<TD WIDTH=\"25%\">
<FONT color=\"#FFFFFF\" size=\"14\">
" . sprintf("%d", $s1) . "
</FONT>
</TD>

<TD WIDTH=\"75%\">
<A HREF=\"/?q=$s2\"><FONT SIZE=\"14\">$viewstr</FONT></A>
</TD>

</TR>
</TABLE>
		");
	}
	

	#
	print("
</TD>
</TR>
</TABLE>
	");
}


1;
