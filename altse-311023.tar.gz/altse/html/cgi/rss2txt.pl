#!/usr/bin/perl

# Convert rss to text - rss2txt.pl
#
# Usage  : rss2txt.pl <RSS file> > textfile.txt
#
# Author : Kyo Nagashima
# E-Mail : kyo@hail2u.net
# URL    : http://hail2u.net/
#
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.

use strict;

die "Usage: rss2txt.pl <RSS file> > textfile.txt\n" unless @ARGV == 1;

use Jcode;
use XML::RSS;
use LWP::Simple;

my $rss = new XML::RSS;
my $j = new Jcode;

my $content;
my $text;

my $arg = shift;
if ($arg =~ /http:/i) {
	$content = get($arg);
	die "Error: Cannot find $arg\n" unless $content;
	eval {
		$rss->parse($content);
	};
	die "Error: Cannot parse $arg\n$@\n" if $@;
}
else {
	$content = $arg;
	die "Error: Cannot find $arg\n" unless -e $content;
	eval {
		$rss->parsefile($content);
	};
	die "Error: Cannot parse $arg\n$@\n" if $@;
}

my $chname = &trim($rss->{'channel'}->{'title'});
my $chlink = &trim($rss->{'channel'}->{'link'});
my $chdesc = &trim($rss->{'channel'}->{'description'});
$text .= qq|$chname\n|;
$text .= qq|$chlink\n|;
$text .= qq|$chdesc\n|;
$text .= qq|\n|;

for my $item (@{$rss->{'items'}}) {
	my $itemname = &trim($item->{'title'});
	my $itemlink = &trim($item->{'link'});
	my $itemdesc = &trim($item->{'description'});
	$text .= qq|$itemname\n|;
	$text .= qq|$itemlink\n|;
	$text .= qq|$itemdesc\n\n|;
}

print STDOUT $j->set(\$text)->sjis;

exit;

# ---------------------------------------------------------------------------- #

sub trim{
	my $value = $_[0];
	if ($value) {
		$value =~ s/^\s+//;
		$value =~ s/\s+$//;
	}
	return $value;
}

