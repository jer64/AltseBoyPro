#!/bin/bash
rm -f cache/mm-*; ./up2.sh
