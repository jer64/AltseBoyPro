#!/usr/bin/perl
######################################################################################
#
require "tools.pl";
require "modules/poll-cfg.pl";
require "modules/chat.pm";

#
$ENV{'CURSEC'} = "vote";
#
if($ENV{'newswire_conset'} eq "")
{
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
if($so{'embed'} eq "" && $ENV{'newswire_conset'} eq "")
{
	OpenWebIndex("./webindex.html");
WebWalkTo("CHOOSE-TITLE1");
print("
<TITLE>Vaihtoehtouutiset - ��NESTYS</TITLE>
<meta name=\"keywords\" content=\"��nestys, ��ni, demokratia, kansanvalta, kansandemokratia, ��nest�, nyt, chat, online chat, online, chat, chatti, ch�tti\">
");
SkipTo("CHOOSE-TITLE2");

	# Add main menu.
	WebWalkTo("main-menu");
	print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
	WebWalkTo("ENTERHERE_SECTION");
}
else
{
	print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<HTML>

<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\"
href=\"$IMAGES_BASE/uutiset.css\"
title=\"Cool\">
</HEAD>

<BODY topmargin=\"0\" leftmargin=\"0\"
marginheight=\"0\" marginwidth=\"0\">
");
}
main();

#
if($so{'embed'} eq "" && $ENV{'newswire_conset'} eq "")
{
	#
	WebWalkTo("ALAPALKKITAHAN");
	#
	print EndBar();
	#
	HandleRest();
}
else
{
	#
	print("
</BODY>
	");
}

##################################################
#
sub LoadQuestions
{
	my ($i);

	# LOAD FORM.
	if(-e "$_[0]\.form")
	{
		@questions = LoadList("$_[0]\.form");
	}
	# PARSE FORM.
	for($i=1; $i<($#questions+1); $i++)
	{
		VarSet($questions[$i]);
	}
}

##################################################################################################
#
# The actual vote form.
#
sub VoteForm
{
	my ($i,$i2,$i3,$i4,$SZ);

	#
	PollImage();

	#
	print("

		<form action=\"$SCRIPT\" class=formx method=post>

		<input type=\"hidden\" name=\"embed\" value=\"$so{'embed'}\">

		<input type=\"hidden\" name=\"POLL\" value=\"$POLLNR\">

		<input type=\"hidden\" name=\"BOUNCE_TO\" value=\"$ENV{'BOUNCE_TO'}\">
		");

	#
	Question($questions[0], "$SCRIPT?VIEW=TRUE&POLL=$POLLNR&BOUNCE_TO=$ENV{'BOUNCE_TO'}");

	#
	if($ENV{'newswire_conset'} ne "") { $SZ=1; } else { $SZ=3; }


	#
	loop: for($i=1; $i<($#questions+1); $i++)
	{
		#
		if($questions[$i] eq "") { last loop; }
		print("
			<div align=left>
			<font color=\"#000000\" size=$SZ>
			<input type=\"radio\" name=\"VOTE\" value=\"$i\">
			$questions[$i]
			</font>
			</div>
			");
	}

	#
	print("
		<input type=\"submit\" value=\"$W_VOTE\"><br>

		<div align=center>
		<font size=1>
		<a href=\"$SCRIPT?VIEW=TRUE&POLL=$POLLNR&BOUNCE_TO=$ENV{'BOUNCE_TO'}&embed=$so{'embed'}\" class=dark>
		<img src=\"$IMAGES_BASE/red-ball.gif\" border=0 align=center>
		n�yt� tulokset
		</a>
		</font>
		</div>
		");

	#
	if($so{'formrefurl'} ne "")
	{
		print("
		<br>
		<font size=3><b>referenssi</b></font><br>
		<font size=2><a href=\"$so{'formrefurl'}\">$so{'formreftext'}</a></font><br><br>
			");
	}


	#
	print("
		</form>
		");
}

################################################################################################
#
sub Question
{
	my ($url);

	#
	$url = $_[1];

	#
	print("
		<TABLE width=$WID cellpadding=2 cellspacing=0
			bgcolor=\"#C0E0FF\">
		<tr>
		<td>

		<div align=left>
		<font size=3>
		<a href=\"$url\" class=news2>
		<b>
		$_[0]
		</b>
		</a>
		</font>
		</div>

		</td>
		</tr>
		</table>
		");
}

##################################################
#
sub ConsumeVoteRight
{
	my ($f);

	#
	open($f, ">>$POLL\.ip") || die "ConsumeVoteRight error ...";
	print $f "$ENV{'REMOTE_ADDR'}\n";
	close($f);
}

##################################################
#
sub AlreadyVoted
{
	my ($f,$i,$i2);

	#
	#
#	if( !($ENV{'HTTP_REFERER'} =~ /vunet\.org/i) )
#	{
#	        return 1;
#	}
	#
	if($ENV{'REMOTE_HOST'} =~ /google/i) { return 1; }

	#
	if( open($f, "$POLL\.ip") )
	{
		#
		close($f);
		@ips = LoadList("$POLL\.ip");

		#
		for($i=0; $i<($#ips+1); $i++)
		{
			if($ips[$i] eq $ENV{'REMOTE_ADDR'})
			{
				return 1;
			}
		}
	}

	#
	return 0;
}

##################################################
#
sub VoteNow
{
	#
	open($f, ">>$POLL\.votes") || die "UNABLE TO OPEN VOTES FILE FOR APPENDING";
	print $f "$so{'VOTE'}\n";
	close($f);
}

##################################################
#
sub ShowMeter
{
	my ($i,$i2,$i3,$i4,$total,$cur,$per,$IMG1,$IMG2);

	#
	$IMG1 = "$IMAGES_BASE/bar8.gif";
	$IMG2 = "$IMAGES_BASE/bar9.gif";
	##$IMG2 = "";

	#
	$cur =   $_[0];
	$total = $_[1];

	# Convert to percentage.
	$per = sprintf("%d", ($cur/$total)*100);

	#
	print("
		<TABLE cellpadding=1 cellspacing=0 bgcolor=\"#000000\" width=$_[2]>
		<tr>
		<td>
		");

	#
	$i = 100-$per;
	print("
		<table cellpadding=0 cellspacing=0 width=$_[2] height=12>
		<tr>
			<td background=\"$IMG1\" width=$per%>
			</td>

			<td background=\"$IMG2\" width=$i%>
			</td>
		</tr>
		</table>
		");

	#
	print("
		</td>
		</tr>
		</table>
		");
}

##################################################
#
sub BlackSpace
{
	my ($BGC,$HEIGHT);

	#
	if($_[1] eq "")
	{
		$BGC = "#000000";
	}

	#
	$HEIGHT = $_[2];
	if($HEIGHT eq "")
	{
		$HEIGHT = 2;
	}

	#
	print("
			<table cellpadding=0 cellspacing=0
				width=$_[0] heigth=$HEIGHT
				bgcolor=\"$BGC\">
			<tr height=$HEIGHT>
			<td>
			</td>
			</tr>
			</table>
		");
}

##################################################
#
sub DisplayVoteCaption
{
	#
	@q = LoadList("$POLL\.form");

	#
	print("
		<font size=1 color=\"#0080FF\">
		<div align=center>
		UUSIN ��NESTYS
		</div>
		<a href=\"$SCRIPT?POLL=$POLLNR&BOUNCE_TO=$so{'BOUNCE_TO'}\">
		<div align=center>$q[0]</div>
		</a>
		</font>
		<div align=center>
		<font size=1 color=\"#40A0FF\">
		<i>Olet jo osallistunut.</i>
		</font>
		</div>
		");
}

##################################################
#
sub PollImage
{
	#
	if($so{'formimage'})
	{
		print("
			<div align=center>
			<a href=\"$SCRIPT?VIEW=TRUE&POLL=$POLLNR&BOUNCE_TO=$ENV{'BOUNCE_TO'}\" class=dark>
			<img src=\"$so{'formimage'}\" border=1 vspace=4><br>
			</a>
			</div>
			");
	}
}

##################################################
#
sub ViewResults
{
	my ($i,$i2,$i3,$i4,$str,$str2,@q,$v,@votes,$total,$per,$SZ,$fpp);

	#
	if( -e "$POLL\.form" ) { @q = LoadList("$POLL\.form"); }
	if( -e "$POLL\.votes" ) { @votes = LoadList("$POLL\.votes"); }

	#
	LoadQuestions($POLL);

	#
	print("
		<table width=350>
		<tr>
		<td>
		");

	## TAKEN

	#
	if($#votes < 0)
	{
		print("
		<TABLE width=100% cellpadding=4 cellspacing=0>
		<TR>
		<TD>
		Kukaan ei viel� ole ��nest�nyt!<br>Voit ��nest�� nyt.
		</TD>
		</TR>
		</TABLE>
		<BR>
		<BR>
		");
		VoteForm();
		return();
	}
	else
	{
	}

	#
	if( !AlreadyVoted() )
	{
		print("
			<div align=center>
			<a href=\"$SCRIPT?POLL=$POLLNR&BOUNCE_TO=$so{'BOUNCE_TO'}\">
			Tietokantamme mukaan et ole viel� ��nest�nyt, klikkaa t�st� ��nest��ksesi!
			</a>
			</div>
			<br>
			");
	}

	#
	if($ENV{'newswire_conset'} ne "") { $SZ=1; } else { $SZ=2; }

	#
	Question($q[0]);

	#
	$total = $#votes+1;
	if($total==0)
	{
		$total=1;
	}
	for($i=1; $i<($#votes+2); $i++)
	{
		#
		$v = "entry$votes[$i-1]";
		$so{$v}++;
	}

	#
	BlackSpace($WID, "$MAINBGC", "8");

	#
	loop: for($i=1; $i<($#q+1); $i++)
	{
		#
		if($q[$i] eq "") { last loop; }

		#
		$v = "entry$i";
		$votes = sprintf("%d", $so{$v});

		# Convert to percentage.
		$per = sprintf("%d", ($votes/$total)*100);

		#
		BlackSpace($WID, $MAINBGC);

		#
		print("

			<table cellpadding=2 cellspacing=0 width=100%
			bgcolor=\"$MAINBGC2\">

			<tr>

			<td width=100% valign=top>
			<font color=\"$MAINFGC\" size=$SZ>
			$q[$i]
			</font>
			</td>

			<table cellpadding=0 cellspacing=0 width=$WID>
			<tr width>

			<td width=50%>
			<font color=\"$MAINFGC\" size=$SZ>
			<div align=left>
			$per%
			</div>
			</font>
			</td>


			<td width=50% valign=top>
			");
		ShowMeter($votes, $total, "100%");
		print("
			</td>

			</tr>
			</table>

			<table cellpadding=0 cellspacing=0 width=100%>
			<tr width=100%>
			<td width=50% valign=top>
			<font color=\"#FFFFFF\">
			");
		#
		BlackSpace($WID, "$MAINBGC");

		#
		BlackSpace($WID, "$MAINBGC", "2");

		#
		print("
			</font>
			</td>
			</tr>

			</table>

			");
	}

	#
	if($#votes >= 0)
	{
		print("
			<font size=1 color=\"$MAINFGC\">total $total votes</font>
			");
	}

	#
	print("
			</td>
			</tr>
			</table>
		");
}

##################################################
#
sub ExitOption
{
	my ($str,$str2);

	#
	if($ENV{'newswire_conset'} eq "")
	{
		#
		if($so{'BOUNCE_TO'} eq "")
		{
			$str = "> return to vote center";
			$str2 = "$SCRIPT_MAIN";
		}
		else
		{
			$str = "> return back to article / palaa takaisin";
			$str2 = "$so{'BOUNCE_TO'}";
		}
		print("
			<div align=center>
			<a href=\"$str2\">
			$str
			</a>
			</div>
			");
	}
}

##################################################
#
sub EmbeddedCall
{
	#
	if( $ENV{'POLLNR'} eq "")
	{
		$POLLNR = 1;
	}
	else
	{
		$POLLNR = $ENV{'POLLNR'};
	}

	#
	LoadQuestions("$VDB/poll$POLLNR");

	# Is there a POLL form assigned yet?
	#
	if($so{'POLL'} eq "")
	{
		# Default to poll1.txt.
		$POLL = "$VDB/poll$POLLNR";
	}
	else
	{	
		# Assign vote form file.
		$POLL = "$VDB/poll$so{'POLL'}";
		$POLLNR = $so{'POLL'};
	}

	#
	$MAINBGC2 = "#C0C0C0";
	$MAINFGC =  "#000000";
	
	#
	if(($so{'VOTE'} eq "" || $so{'POLL'} eq "") && AlreadyVoted()==0)
	{
		VoteForm();
	}
	else
	{
		if(!AlreadyVoted())
		{
			# Add to the statistics.
			VoteNow();
			# Allow voting only once.
			ConsumeVoteRight();
			print("
				KIITOS OSALLISTUMISESTA!!!!<br>
				<br>
				");
		}
		else
		{
			# Show some message if can't vote.
			DisplayVoteCaption();
		}

ViewNow:
	}
past:
}

################################################################################################
#
sub main
{
	#
	if($ENV{'REMOTE_HOST'} =~ /.fi$/)
	{
		$W_VOTE = "��nest�";
	}
	else
	{
		$W_VOTE = "vote";
	}

	#
	if($ENV{'newswire_conset'} ne "")
	{
		EmbeddedCall();
		exit();
	}

	#
	$WID = "100%";
	print("
		<TABLE width=100% cellspacing=0 cellpadding=0>
		<TR>
		<TD>

		<table cellpadding=16 cellspacing=0 width=600>
		<tr valign=top>
		<td width=50% valign=top>

<A HREF=\"/pollmain.pl\">
> palaa ��nestyksiin
</A>
		");

	#
	MainPoll();

	#
	print("
		</td>
		");

	#
	print("
		<td width=50%>
		");
	Keskustelu();
	print("
		</td>
		");

	print("

		</tr>
		</table>


		</td>
		</tr>
		</table>
		");
}

##################################################################
#
sub MainPoll
{
	#
	LoadQuestions("$VDB/poll$so{'POLL'}");

	# Is there a POLL form assigned yet?
	#
	if($so{'POLL'} eq "")
	{
		#
		if( $ENV{'POLLNR'} eq "")
		{
			$POLLNR = 1;
		}
		else
		{
			$POLLNR = $ENV{'POLLNR'};
		}

		# Default to poll1.txt.
		$POLL = "$VDB/poll$POLLNR";
	}
	else
	{	
		# Assign vote form file.
		$POLL = "$VDB/poll$so{'POLL'}";
		$POLLNR = $so{'POLL'};
	}

	#
	$MAINBGC =  "#FFFFFF";
	$MAINBGC2 = "#C0C0C0";
	$MAINFGC =  "#000000";
	
	#
	AddChatMessage();

	#
	#
	if($so{'VIEW'} ne "")
	{
		goto ViewNow;
	}
	if(($so{'VOTE'} eq "" || $so{'POLL'} eq "") && AlreadyVoted()==0)
	{
		VoteForm();
	}
	else
	{
		if(!AlreadyVoted())
		{
			# Add to the statistics.
			VoteNow();
			# Allow voting only once.
			ConsumeVoteRight();
			print("
				KIITOS OSALLISTUMISESTA!!!!<br>
				<br>
				");
			#
			if($so{'BOUNCE_TO'} ne "")
			{
				#
	                #        print("
	                #        <meta http-equiv=\"REFRESH\"
	                #        content=\"0;url=$so{'BOUNCE_TO'}\">
	                #        ");
			#	goto past;
			}
		}
		else
		{
		}

ViewNow:
		# View results
		ViewResults();
	}
past:
}

#
sub AddChatMessage
{
	#
	my ($str,$str2,$i,$i2,$f);

	#
	if($so{'SAY'} ne "")
	{
		#
		$so{'SAY'} =~ s/\s$//g;
		$so{'SAY'} =~ s/\$//g;
		$so{'SAY'} =~ s/\|//g;
		$so{'SAY'} =~ s/\"//g;
		$t = time;
		if( length($so{'SAY'}) >= 300 ||
			$ENV{'REMOTE_HOST'} =~ /\.pl$/ )
		{
			system "echo \"$t $so{'SAY'} <$ENV{'REMOTE_ADDR'}>\" >> talk_censored.txt";
			goto past1;
		}
		$so{'SAY'} =~ s/(\S{40})//g;
		$so{'SAY'} =~ s/(\S{20})/$1- /g;

		#
		open($f, ">>talk.txt") || die "can't open talk.txt";
		print $f "\n$t $so{'SAY'} <$ENV{'REMOTE_ADDR'}>\n";
		close($f);
past1:
        print("
        <meta http-equiv=\"REFRESH\"
        content=\"0;url=$SCRIPT?POLL=$POLLNR&VIEW=TRUE&embed=$so{'embed'}\">
                ");
		exit();		
	}
}

##################################################################
#
sub Unworking
{
	###############################################################
	#


}

