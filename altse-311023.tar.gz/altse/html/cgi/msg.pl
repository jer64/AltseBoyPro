#!/usr/bin/perl
#
# msg.pl?id=1
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

#
sub main
{
	$so{'id'} = s/[^0-9]//g;
	my $fn = "msgs/".$so{'id'}.".txt";
	if(-e $fn) {
		my @lst = LoadList($fn);
		foreach(@lst) {
			print $lst[$i]."\n";
		}
	}

	#
}

