#!/usr/bin/perl
# contact.pl
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
# Add main menu.
WebWalkTo("main-menu");
print inc_menu($so{'section'}, $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#<SCRIPT LANGUAGE=\"Javascript\">
#document.write('<A HREF=\"mailto:jari.t.');
#document.write('tuominen\@gmail.com\" class=dark>');
#</SCRIPT>
#</A>
#<SCRIPT LANGUAGE=\"Javascript\">
#document.write('<A HREF=\"mailto:jari.t.');
#document.write('\tuominen@gmail.com\" class=dark>');
#</SCRIPT>
#> S�hk�postita p��toimittajalle / E-mail Editor-in-Chief: <b>Mr. JARI TUOMINEN</b>
#</A>
#<BR>

###########################################################################################################
#
sub main
{
	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR>
<TD>
<TABLE width=700 cellspacing=0 cellpadding=32>
<TR>
<TD>
<DIV ALIGN=CENTER>
<FONT class=major_headline>Vaihtoehtouutiset<BR>
Alternative News<BR>
YHTEYSTIEDOT - CONTACT INFORMATION</FONT><BR><BR>
</DIV>


<SCRIPT LANGUAGE=\"Javascript\">
document.write('<A HREF=\"mailto:vaihtoehtouutiset');
document.write('\@gmail.com?subject=Yleinen\" class=dark>');
</SCRIPT>
> Hallinto / Administration: <b>Contact Now - Ota Yhteytt�</b>
</A>
<BR>

<DIV ALIGN=RIGHT>
<TABLE width=200>
<TR>
<TD>
<IMG SRC=\"$IMAGES_BASE/jari_hot.jpg\">
<DIV ALIGN=RIGHT><FONT SIZE=1>Editor-in-Chief, Mr. Jari Tuominen</FONT></DIV>
<DIV ALIGN=RIGHT><FONT SIZE=1>P��toimittaja, Herra Jari Tuominen</FONT></DIV>
</TD>
</TR>
</TABLE>
</DIV>

<DIV ALIGN=RIGHT>
<TABLE width=200>
<TR>
<TD>
<A HREF=\"http://www.kominf.pp.fi\">
<IMG SRC=\"http://images.vunet.world/heikki_sipila_kominform.jpg\">
</A>
<DIV ALIGN=RIGHT><FONT SIZE=1>Fas.Cor., Mr. Heikki Sipil�</FONT></DIV>
<DIV ALIGN=RIGHT><FONT SIZE=1>Ulk.vast., Herra Heikki Sipil�</FONT></DIV>
</TD>
</TR>
</TABLE>
</DIV>

<BR><BR><BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR><BR><BR>

</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</DIV>

<!---- di fflil no,Jtmos 
http://www.glin.gov/download.action?fulltextId=46959&documentId=15456.
---->
		");

	#
}


