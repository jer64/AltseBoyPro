#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@lst2,@ips,$i,$i2,$i3,$i4,$str,$str2,$fn,$age);

	#
	chdir("/home/vai/cgi-bin");

	#
	$fn = "cfg/vistat_avlogs.txt";

	#
	#$age = FileAge($fn);
	#if($age < (60*60*12)) { print STDERR "no update necessary ($age)\n"; exit; }

	#
	@lst = LoadList("find articles/logs/ -maxdepth 1 -name 'avlog-*.txt'|");
	@lst = sort @lst;

	#
	%countries = ("");

	#
	open($f, ">$fn") || die "can't write $fn\n";

	#
	for($i=0; $i<($#lst); $i++)
	{
		print STDERR ("$i/$#lst    \r");
		$str = $lst[$i];
		$str =~ s/^[^0-9]*([0-9]*).*$/$1/;
		@lst2 = LoadList($lst[$i]);
		%ips = ();
		for($i2=0; $i2<($#lst2); $i2+=8)
		{
			$host = $lst2[$i2+4];
			if( !(($host=~/google\.[a-z]+$/) && !($host=~/google\.[a-z]+\.[a-z]+$/) 
				&& !($host=~/inktomisearch\.[a-z]+$/)
				&& !($host=~/ask\.com$/)
				&& !($host=~/picsearch\.com$/)
				&& !($host=~/googlebot\.com$/)
				&& !($host=~/vunet\.org$/))
				)
			{
				if($host ne "")
				{
					print "$host\n";
					$hosts{$host}++;
					print keys %hosts . "\n";
				}

				$ip = $sp[2];
				$ip =~ s/^([^\:]+)\:.*$/$1/;
				$ips{"$ip"}++;
				if($host=~/\.[a-z]+$/)
				{
					$str = $host;
					$str =~ s/^.*\.([a-z]*)$/$1/;
					$countries{$str}++;
				}
			}
			else
			{
				if($host ne "")
				{
					#print "IGNORING: $host\n";
				}
			}
		}
		$fn = $lst[$i];
		$str4 = $lst[$i];
		$str4 =~ s/[^0-9]//g;
		$tama = sprintf "%s: %d\n", POSIX::strftime("%d.%m.%Y", localtime($str4*86400)), keys %hosts;
		print $f $tama;
		print $tama;
		@hosts = ();
	}

	#
	print $f "\n";

	#
	foreach $key (sort(keys %countries))
	{
		print $f "$key ";
	}

	#
	close($f);

	#
}


