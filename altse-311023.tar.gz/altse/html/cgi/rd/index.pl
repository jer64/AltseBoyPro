#!/usr/bin/perl
#################################################################################
#
# VUNET.org director script. 
#
#################################################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "frontpage";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

############################################################################
#
sub main
{
		#
	        ###################################################################
	        # Search arguments line for options.
	        $DONT_AFFECT_DB = 1;
	        ArgLineParse();

                #
                print("
        <meta http-equiv=\"REFRESH\"
                content=\"0;url=$so{'to'}\">
                        ");
}

