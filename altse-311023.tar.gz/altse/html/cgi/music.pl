#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT'); $| = 1;

#
$ENV{'CURSEC'} = "musiikki";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");

# Add main menu.
WebWalkTo("main-menu");
print inc_menu($so{'section'}, $so{'FP_SECTION'});

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

##################################################
#
sub Ohjelma
{
	my ($i,$i2,$str,$str2,@lst);

	#
	print("
		<table width=800 height=264 background=\"$IMAGES_BASE/nauti.jpg\"
			cellpadding=0 cellspacing=0>

		<tr width=100% height=76 valign=top>
		<td>
		</td>
		</tr>

		<tr valign=top height=180>
		<td>
		");

	#
	@lst = LoadList("cfg/pls.txt");

	#
	print("
		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>
		<td>


<table width=100% cellpadding=8 cellspacing=0>
		");

	#
	$val = 4;

	#
	for($i=0,$i2=0; $i<($#lst); $i+=2,$i2++)
	{
		#
		if(($i2%$val)==0)
		{
			print("
				<tr valign=top height=50>
				");
		}

		print("
			<td>
			<font size=2>
			<a href=\"$lst[$i+1]\" class=news3>
			<img src=\"http://www.sky.fm/images/icon_mp3.gif\" align=center border=0>
			$lst[$i+0]
			</a>
			</font>
			</td>
			");

		#
		if(($i2%$val)==($val-1))
		{
			print("
				</tr>
				");
		}
	}

	#
	print("

</table>

<table width=100% cellpadding=8 cellspacing=0>
<tr>
<td>
<font size=2>
Remember that for listenning you will need Winamp media player.<br>
</font>
Load Winamp from <a href=\"http://download.nullsoft.com/winamp/client/winamp5092_full_emusic-7plus.exe\" 
class=news3><i>this link</i></a>.
<BR>

<br>
<font size=2>
Muistathan ett� tarvitset kuuntelua varten erinomaisen <a href=\"http://www.winamp.com\">WINAMP</a> -mediasoittimen, joka on eritt�in helppo asentaa.<br>
</font>
Lataa Winamp <a href=\"http://download.nullsoft.com/winamp/client/winamp5092_full_emusic-7plus.exe\" class=news3><i>t�st� linkist�</i></a>.
</td>
</tr>
</table>


</td>


<td width=288>
<img src=$IMAGES_BASE/mahtavaa.jpg align=right>
</td>

		</tr>
		</table>
		");

	#
	print("
		</td>
		</tr>
		</table>
		");
}

##################################################
#
sub main
{
	#
	print("
		<table cellpadding=16 cellspacing=0 width=100%>
		<tr valign=top>
		<td>
		");

	#
	Ohjelma();

	#
	print("
		</td>
		</tr>
		</table>
		");
}


