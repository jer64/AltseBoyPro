##########################################
# PUBLISHING SETTINGS
##########################################

###########################################
$LOGO = "http://www.saunalahti.fi/ehc50/uutiset/uusilogo2.jpg";
$LOGOURL = "http://www.saunalahti.fi/ehc50/uutiset";

#


