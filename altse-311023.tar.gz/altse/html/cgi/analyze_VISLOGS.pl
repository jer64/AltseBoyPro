#!/usr/bin/perl
# 2007-2013 JT
##############################################################################################################

#
require "tools.pl";
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@lst2,@ips,$i,$i2,$i3,$i4,$str,$str2,$fn,$age);

	#
	chdir("/home/vai/cgi-bin");

	#
	$fn = "cfg/vistat.txt";

	#
	#$age = FileAge($fn);
	#if($age < (60*60*12)) { print STDERR "no update necessary ($age)\n"; exit; }

	#
	@lst = LoadList("find articles/logs/ -maxdepth 1 -name 'vislog-*.txt'|");
	@lst = sort @lst;

	#
	%countries = ("");

	#
	open($f, ">$fn") || die "can't write $fn\n";

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print STDERR ("$i/$#lst    \r");
		$str = $lst[$i];
		$str =~ s/^[^0-9]*([0-9]*).*$/$1/;
		@lst2 = LoadList($lst[$i]);
		%ips = ();
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			@sp = split(/\;/, $lst2[$i2]);
			if( !($sp[2]=~/google\.[a-z]*$/) && !($sp[2]=~/google\.[a-z]*\.[a-z]*$/) 
				&& !($sp[2]=~/inktomisearch\.[a-z]*$/)
				&& !($sp[2]=~/ask\.com*$/)
				&& !($sp[2]=~/picsearch\.com*$/)
				&& !($sp[2]=~/googlebot\.com*$/)
				&& !($sp[2]=~/vunet\.org*$/)
				)
			{
				$host{"$sp[2]"}++;
				$ips{"$sp[1]"}++;
				if($sp[2]=~/\.[a-z]*$/)
				{
					$str = $sp[2];
					$str =~ s/^.*\.([a-z]*)$/$1/;
					$countries{$str}++;
				}
			}
		}
		$fn = $lst[$i];
		$str4 = $lst[$i];
		$str4 =~ s/[^0-9]//g;
		$tama = sprintf "%s: %d\n", POSIX::strftime("%d.%m.%Y", localtime($str4*86400)), keys %ips;
		print $f $tama;
		print $tama;
		@hosts = ();
	}

	#
	print $f "\n";

	#
	foreach $key (sort(keys %countries))
	{
		print $f "$key ";
	}

	#
	close($f);

	#
}


