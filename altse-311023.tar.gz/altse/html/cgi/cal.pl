#!/usr/bin/perl
#####################################################################
#
# P E R S O N A L
#
# W E B   A L M A N A C 
#
#####################################################################


#
if($ENV{'DOCUMENT_ROOT'} eq "")
{
        $ENV{'DOCUMENT_ROOT'} = "/home/vai/altse/html";
}
#
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/Calendar.pm";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
exit;

#
main();

######################################################################################
sub LoadSave
{
	#
	if( ArgLineParse() eq "POST" )
	{
		#
		SaveCalendarEntry( $so{'day'}, $so{'month'}, $so{'year'} );
	}
	else
	{
		$so{'CALENDAR_CONTENT'} = "";
		LoadCalendarEntry( $so{'day'}, $so{'month'}, $so{'year'} );
	}
}
	
######################################################################################
sub Almanac
{
	#
	SectionHeadline("calendar");
	print "<br><br>";

	#
	print Calendar();

	#
	LoadSave();

	#
	print("
		$so{'day'}.$so{'month'}.$so{'year'}

		<form action=\"/cal.pl\" method=\"post\">
			<textarea name=\"CALENDAR_CONTENT\" cols=\"60\" rows=\"20\">");

	#
	print "$so{'CALENDAR_CONTENT'}";

	#
	print("</textarea>

		<br>
		<input type=\"submit\" name=\"submit\"
			value=\"SAVE\">
		</form>
		");

	#
	
}

##########################################################################
sub TableBeg
{
	#
	print("
		<table
			cellspacing=\"0\"
			cellpadding=\"0\"
			width=\"100%\">

		<tr heigth=\"36\">
			<td width=\"36\">
			<br>
			</td>
		</tr>

		</table>

		<table>
		<tr>

		<td width=\"36\">
		</td>

		<td width=\"500\">
		");
}

##########################################################################
sub TableEnd
{
	#
	print("
		</td>
		</tr>
		</table>
		");
}

##########################################################################
sub SaveCalendarEntry
{
	my $f,$str,$str2;

	#
	$fn = "./cal/$_[0]_$_[1]_$_[2].txt";
	open($f, ">$fn") || die "can't write calendar file";
	$str = $so{'CALENDAR_CONTENT'};
	$str =~ s/\n/<-br->/g;
	print $f $str;
	close($f);
}

##########################################################################
sub LoadCalendarEntry
{
	my $f,$fn;

	#
	$fn = "./cal/$_[0]_$_[1]_$_[2].txt";
	open($f, $fn) || return "";
	$so{'CALENDAR_CONTENT'} = <$f>;
	close($f);

	#
	$so{'CALENDAR_CONTENT'} =~ s/<-br->/\n/ig;
}

#
sub main
{
	my $tmp, @ar;

	#
	$ENV{'CURSEC'} = "almanac";
	
	#
	print Calendar();
	#
#	TableBeg();
#	Almanac();
#	TableEnd();
}


