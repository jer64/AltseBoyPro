package DADA::App::Error;


=pod

=head1 NAME 

DADA::App::Error

=head1 SYNOPSIS

	use DADA::App::Error

This module basically has error messages in HTML and spits 'em back at ya.

=cut


use lib './'; 
use lib '../'; 

use DADA::Config; 
use DADA::App::Guts; 
use DADA::Template::HTML;

require Exporter; 
@ISA = qw(Exporter); 
@EXPORT = qw(cgi_user_error);
use strict; 
use vars qw(@EXPORT);
my %error;

require CGI;
my $q = new CGI; 

if(($PROGRAM_URL eq "") || ($PROGRAM_URL eq 'http://www.changetoyoursite.com/cgi-bin/dada/mail.cgi')){ 
			$PROGRAM_URL = $q->url(); 
}

if(($S_PROGRAM_URL eq "") || ($S_PROGRAM_URL eq 'http://www.changetoyoursite.com/cgi-bin/dada/mail.cgi')){ 
			$S_PROGRAM_URL = $q->url(); 
}



$error{no_list} = <<EOF

<h1>I Couldn't Find List ([list_name])</h1> 

<p>I had trouble fetching [list_name] from this server. 
It's possible that it has been deleted or moved 
and the form you used is a bit out of date.</p> 

EOF
;


$error{no_list_password} = <<EOF

<h1>Problem Logging In</h1>

<p>Please refer to the error logs for more information.</p>

<form action="$S_PROGRAM_URL" method="post"> 
 <input type="hidden" name="flavor" value="email_password" />
 <input type="hidden" name="list" value="[list]" />
 <p align="center">
  <input type="submit" class="plain" value="Mail [list_owner_email] a new password" />
 </p>
</form> 

EOF
;


$error{invalid_password} = <<EOF

<h1>Your Password is Incorrect</h1> 

<p>The password you gave me doesn't seem to be correct. 
You might have typed it in wrong. Try typing it in again. 
If you forgot your password, have it emailed back to you.</p> 

<p><strong>Try signing into [list_name] again</strong></p>

<form action="$S_PROGRAM_URL" method="post">
 <input type="hidden" name="flavor" value="login" />
 <input type="hidden" name="admin_list" value="[list]" />
 <input type="hidden" name="referer" value="$ENV{'SCRIPT_URI'}" />
 <p>
  <input type="password" name="admin_password" maxlength="24" /> 
  <input type="submit" class="plain" value="Login" />
 </p>
</form> 

<form action="$S_PROGRAM_URL" method="post"> 
 <input type="hidden" name="flavor" value="email_password" />
 <input type="hidden" name="list" value="[list]" />
 <p align="center">
  <input type="submit" class="plain" value="Mail [list_owner_email] a new password" />
 </p>
</form> 

<p>If you keep getting bounced back to this screen, 
make sure that cookies are turned 'on' in your Web browser.</p> 

EOF
; 


$error{need_to_login} = <<EOF

<h1>You Need to Log In</h1> 

<p>I didn't catch the name of your list or its password.
I need those to let you into your administration control panel.</p>

[list_login_form]

EOF
;


$error{email_in_list} = <<EOF  

<h1>You're already subscribed!</h1>

<p>Your email address, <strong>[email]</strong>, has already been subscribed to: <br /><br /> <strong>[list_name]</strong>.</p>

<p>This may be because:</p>

<ul>
 <li>You've successfully subscribed to this list in the past.</li>
 <li>You clicked the subscription confirmation link that was mailed to you, twice.</li>
 <li>The list owner has already subscribed your email address.</li>
</ul>

<p>If you would like to subscribe to a different list, please visit the $PROGRAM_NAME <a href="$PROGRAM_URL?email=[email]">main screen</a>, 
which will have a list of all available lists.</p>

<p>If you want to unsubscribe from this list instead, please visit 
<a href="$PROGRAM_URL?f=list&amp;l=[list]&amp;email=[email]&amp;set_flavor=u">this list's main screen</a>.
</p>

EOF
;


$error{email_not_in_list} = <<EOF  

<h1>You're not subscribed!</h1>

<p>Your email address, <strong>[email]</strong>, is not subscribed to: <br /><br /> 
<strong>[list_name]</strong>.</p>

<p>This may be because:</p>

<ul>
 <li>You've successfully unsubscribed to this list in the past.</li>
 <li>You clicked the unsubscription confirmation link that was mailed to you, twice.</li>
 <li>The list owner has already unsubscribed your email address.</li>
</ul>

<p>If you would like to unsubscribe from a different list, please visit the $PROGRAM_NAME <a href="$PROGRAM_URL?email=[email]&amp;set_flavor=u">main screen</a>, 
which will have a list of all available lists.</p>

<p>If you want to subscribe to this list instead, please visit 
<a href="$PROGRAM_URL?f=list&amp;l=[list]&amp;email=[email]&amp;set_flavor=s">this list's main screen</a>.
</p>

EOF
;


$error{invalid_email} = <<EOF 

<h1>Invalid Email Address</h1> 

<p>The address you gave, <strong>[email]</strong>, 
doesn't seem to pass verification. It's possible that you just typed it in
incorrectly. You may <a href="#" onclick="history.back(); return false">go back</a> and 
resubmit your address or use the form below:</p> 

[list_popup_subscription_form]

EOF
; 


$error{unsub_invalid_email} = $error{invalid_email};
$error{unsub_invalid_email} =~ s/list_popup_subscription_form/list_popup_unsubscription_form/g; 


$error{mx_lookup_failed} = <<EOF 

<h1>Invalid Email Address</h1> 

<p>The address you gave, <a href="mailto:[email]">[email]</a>,
doesn't seem to pass our verification because we couldn't find the hostname.
It's possible that you just typed it in
incorrectly. You may <a href="#" onclick="history.back(); return false">go back</a> 
and resubmit your address or use the form below:</p> 

[list_popup_subscription_form]

EOF
; 


$error{pass_no_match} = <<EOF 

<h1>Your New Password Doesn't Match</h1> 

<p>The new password you typed isn't the same as the second time you typed it, 
or you didn't enter a new password at all.</p> 

<p>Press the <a href="#" onclick="history.back(); return false">back button</a> 
to fix the problem.</p> 

EOF
; 


$error{invalid_pin} = <<EOF 

<h1>Invalid Pin Number</h1> 

<p>The pin number you gave wasn't correct for your email address. 
You might have copied the confirmation or unsubscription address incorrectly. 
Be sure to copy the entire address into the address bar in your browser.</p> 

<p>If you'd like, you may resubmit your email address:</p>

[list_popup_subscription_form]

EOF
; 


$error{invalid_root_password} = <<EOF 

<h1>Your Root Password is Incorrect</h1> 

<p>The root password you gave me didn't match up to the one one I have for 
your $PROGRAM_NAME script. Please try again:</p> 

<form action="$S_PROGRAM_URL" method="post">


<p><strong>Root Password</strong><br /> 
 <input type="hidden" name="flavor" value="new_list" />
 <input type="password" name="root_password" maxlength="24" /> 
 <input type="submit" class="plain" value="log in as $PROGRAM_NAME root" /> 
</p>

</form>


EOF
;


$error{bad_ip} = <<EOF

<p>You are not allowed to log into your list control panel from your present IP Address.</p> 

EOF
; 


$error{no_archive_entry} = <<EOF

<h1>Entry Not Available</h1> 

<p>The archived message you're trying to find isn't there. It may have been removed by the list owner.</p>

EOF
; 


$error{no_archive} = <<EOF

<h1>No Archive for [list_name]</h1> 

<p>I couldn't find an archive for [list_name]. Either the archive database 
is corrupted, or you never sent a message to be archived.</p>     

EOF
; 


$error{list_already_exists} = <<EOF

<h1>The List Name [list_name] Already Exists</h1> 

<p>So as not to overwrite the list that's already set up, please pick a new name.</p> 

EOF
; 


$error{no_show_archives} = <<EOF 

<h1>No Archived Messages</h1> 

<p>There are no messages archived for this list that are available to be viewed.</p>

EOF
; 

$error{no_display_attachments} = <<EOF 

<h1>Sorry,</h1> 

<p>Attachments for messages of this list are not displayed.</p>

EOF
; 



$error{closed_list} = <<EOF 

<h1>Unable to Subscribe</h1> 

<p>This list you are trying to subscribe to is closed. Only the list administrator can 
subscribe people to the list.</p>

EOF
; 


$error{over_subscription_quota} = <<EOF 

<h1>Unable to Subscribe</h1> 

<p>This list currently cannot have any more subscribers.</p>

EOF
; 


$error{over_list_quota} = <<EOF 

<h1>Unable to Create a New List</h1> 

<p>The limit to the amount of lists that can be created has been reached.</p>

EOF
; 


$error{stupid_programmer} = <<EOF 

<h1>Stupid, Stupid Programmer</h1> 

<p>Um, I have no idea whats wrong with what, whatever you did, um.... 
I'd close all programs and restart, usually that does the trick. You might 
want to give me a word or two about my laziness - write to:
<a href="mailto:justin\@skazat.com">justin\@skazat.com</a> and tell me how 
I should just stick to drawing pretty pictures.</p> 

<p>*thanks*</p> 

EOF
; 


$error{no_permissions_to_write} = <<EOF 

<h1>Can't Create a New List</h1> 

<p>It seems I'm having trouble writing a new list to the 
directory you specified your lists to be: </p> 

<p><strong>$FILES</strong></p> 

<p>this might be because that directory doesn't exist, or 
I don't have permission to write to it. Make sure the directory path is
correct. If your still getting this error, chmod 777 the directory
and then setup a new list.</p> 

EOF
; 


$error{black_listed} = <<EOF 


<h1>You Are Unable to Subscribe</h1> 

<p>It seems that your not allowed to subscribe to [list_name] for some reason or another.
This list may be closed to particular participants.</p> 

EOF
;


$error{too_busy} = <<EOF 

<h1>$PROGRAM_NAME - Too Busy</h1> 

<p>Our apologies, but the server is too overloaded to take your request. 
Please try again in a few minutes and see if the server status has cleared up.</p> 

EOF
;


$error{no_admin_permissions} = <<EOF

<h1>Sorry,</h1> 

<p>It seems that you have not been given the permission to use/view this screen. 
It's most likely that this feature has been shut off by the Main Administrator.</p>

EOF
; 


$error{no_root_password} = <<EOF

<h1>No Root Password Set</h1> 

<p>The $PROGRAM_NAME Root Password has <strong>not</strong> been set to a valid value. List creation is not 
allowed with the $PROGRAM_NAME Root Password left blank.</p> 

EOF
; 


$error{bad_setup} = <<EOF

<h1>
 Welcome to $PROGRAM_NAME.
</h1> 

<p>
 $PROGRAM_NAME is running correctly, but is not configured properly - if you haven't 
configured the program, please do so now. 
</p>
<p>
 <a href="$S_PROGRAM_URL?f=setup_info">
  Click here
 </a> 
 for more information.
</p>
 
EOF
; 


$error{settings_possibly_corrupted} = <<EOF

<p>Please contact the Server Administrator at: 
<a href=mailto:$ENV{SERVER_ADMIN}>$ENV{SERVER_ADMIN}</a> 
detailing the problem you are having with this request.</p>

EOF
; 




$error{already_sent_sub_confirmation} = <<EOF


<h1>Problems with Confirmation Request</h1> 

<p>
 It seems that you were recently sent a confirmation to subscribe to: 
</p>


<p>
 <blockquote> 
   <strong>
    [list_name]
   </strong>
 </blockquote> 
 
<p>
 Please double-check your inbox for this confirmation email. 
</p>

<p>If you did not receive this confirmation, make sure that this email 
address: </p>

 <blockquote>
 <p>
  <strong>
   <a href=mailto:[list_owner_email]>[list_owner_email]</a>
  </strong>
 </p>
</blockquote>


<p>is in your 
 <strong> 
  address book
 </strong> 
 or 
 <strong> 
  whitelist
 </strong>
 .
</p>

<p>
 <strong> 
  <a href="[program_url]/subscriber_help/[list]/">
   How to add [list_owner_email] to your address book/white list
  </a>
 </strong> 
</p>

<p>
 You may resend this confirmation by clicking the button below:
</p>

<form action="$PROGRAM_URL" method="POST"> 
<input type="hidden" name="f" value="resend_conf" />

<input type="hidden" name="list" value="[list]" />
<input type="hidden" name="email" value="[email]" /> 
<input type="hidden" name="rm" value="s" /> 
<input type="hidden" name="auth_code" value="[auth_code]" /> 

<div style="text-align:center">
 <input type="submit" value="Resend Subscription Confirmation" /> 
</div> 
</form> 

EOF
;

# me being crafty

$error{already_sent_unsub_confirmation} = $error{already_sent_sub_confirmation}; 

$error{already_sent_unsub_confirmation} =~ s/subs/unsubs/g;

$error{already_sent_unsub_confirmation} =~ s/unsubscribe to/unsubscribe from/gi;

$error{already_sent_unsub_confirmation} =~ s/Subs/Unsbs/g; 
$error{already_sent_unsub_confirmation} =~ s/name\=\"rm\" value\=\"s\"/name="rm" value="u"/g; 


$error{no_support_for_displaying_message_source} = <<EOF


<h1>Sorry,</h1> 

<p>
 Viewing the message source of an archived message is not supported.
</p>

EOF
; 


=pod

=head1 SUBROUTINES

=head2 cgi_user_error

 print cgi_user_error(-List  => 'my_list', 
                      -Error => 'some_error', 
                      -Email => 'some@email.com'); 

Gives back an HTML friendly error message.

=cut


sub cgi_user_error { 
	my %args = (-List => undef, 
     			-Error => undef, 
     			-Email => undef, 
     			@_); 
    my $return_html;  			 
	
	my  $available_lists_ref; 
	my $li              = {}; 
	my $list_exists     = 0;
	my $list_login_form = ""; 

	my $auth_code     = '';
	
	if($args{-Error} ne 'bad_setup'){			
		$list_exists = check_if_list_exists( -List=> $args{-List}) || 0;
		if($list_exists > 0) { 
			require  DADA::MailingList::Settings; 
			my $ls = DADA::MailingList::Settings->new(-List => $args{-List}); 
			   $li = $ls->get; 
		}
	}
	
	$return_html .= (the_html(-Part       => "header",
							  -Title      => "There seems to be a problem", 
							  -List       => $li->{list},
							  -Start_Form => 0,
					));
	

    if(defined($error{$args{-Error}})) { 
         my $error_msg = $error{$args{-Error}}; 
            
         require DADA::Template::Widgets; 
		 
		 if($args{-Error} ne 'bad_setup'){ 
		 	if($LOGIN_WIDGET eq 'popup_menu'){ 
				$list_login_form =  DADA::Template::Widgets::list_popup_login_form();
			} elsif($LOGIN_WIDGET eq 'text_box') { 
				$list_login_form = DADA::Template::Widgets::screen(-screen => 'text_box_login_form.tmpl', -expr => 1);	
			}else{ 
				warn "'$LOGIN_WIDGET' misconfigured!"
			}
		}
		
		if($args{-Error} eq 'already_sent_sub_confirmation' || $args{-Error} eq 'already_sent_unsub_confirmation'){ 
		 	my ($sec, $min, $hour, $day, $month, $year) = (localtime)[0,1,2,3,4,5];

			$auth_code = DADA::App::Guts::make_pin(-Email => $month . '.' . $day . '.' . $args{-Email});
			
		}
		
        
        my $list_popup_subscription_form; 
        my $list_popup_unsubscription_form;
        
        if($args{-List}){ 
  			$list_popup_subscription_form    = DADA::Template::Widgets::screen(-screen => 'list_subscribe_form.tmpl', -list => $args{-List}, -expr => 1,  -vars => {-email => $args{-Email}}); 
        	$list_popup_unsubscription_form  = DADA::Template::Widgets::screen(-screen => 'list_subscribe_form.tmpl', -list => $args{-List}, -expr => 1, -vars => {-email => $args{-Email}, -set_flavor => 'u'} ); 
        }else{ 
        	$list_popup_subscription_form   = DADA::Template::Widgets::list_popup_subscription_form(-email => $args{-Email}, -show_hidden =>1);
        	$list_popup_unsubscription_form = DADA::Template::Widgets::list_popup_subscription_form(-email => $args{-Email}, -set_flavor => 'u', -show_hidden => 1);
        }
        
          	$error_msg =~ s/\[list_popup_subscription_form\]/$list_popup_subscription_form/g;
            $error_msg =~ s/\[list_popup_unsubscription_form\]/$list_popup_unsubscription_form/g;
            $error_msg =~ s/\[list_login_form\]/$list_login_form/g;
            $error_msg =~ s/\[email\]/$args{-Email}/g;   
            
            $error_msg =~ s/\[auth_code\]/$auth_code/g;   
            
            $error_msg = interpolate_string(-String => $error_msg, -List_Db_Ref => $li);
        	            
         $return_html .= $error_msg;
    }else{ 
         $return_html .= $args{-Error};        
    } 

	if($args{-Error} eq 'bad_setup'){ 
	
		my $error_report; 
		my @tests = ($FILES, $TEMPLATES, $TMP);
		if($PROGRAM_CONFIG_FILE_DIR){ 
			push(@tests, $PROGRAM_CONFIG_FILE_DIR);
		}
		my %sift; 
		foreach(@tests){$sift{$_}++}
		@tests = keys %sift; 
		
		foreach my $test_dir(@tests){ 
			
			unless(-d $test_dir){ 
				$error_report .= "<p>'$test_dir' is <strong>NOT</strong> a directory.</p>\n"; 
			}
			unless(-e $test_dir){ 
				$error_report .= "<p>'$test_dir' <strong>DOES NOT</strong> exist.</p>\n"; 			
			}
		}
		
		$return_html .= $error_report;
	}
	
	if(keys %$li){ 
		if (($list_exists > 0) && ($li->{list_owner_email})) { 
			 $return_html .= '<p>If you would like to receive more assistance, please email the '; 
			 $return_html .= '<a href="mailto:' . $li->{list_owner_email} . '">list owner</a> with your problem.</p>'; 
		}
	}

 $return_html .= (the_html(
					-Part      => "footer",
					-List      => $li->{list},
					-End_Form  => 0,
					-Site_Name => $li->{website_name},
					-Site_URL  => $li->{website_url},
					 ));


return $return_html;
}
