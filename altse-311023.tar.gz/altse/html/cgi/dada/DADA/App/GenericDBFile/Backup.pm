package DADA::App::GenericDBFile::Backup;
use lib qw(./ ../../  ../../DADA ../perllib); 


use DADA::Config;

use Fcntl qw(	O_WRONLY	O_TRUNC		O_CREAT		);

sub backupToDir { 

	my $self    = shift;
		
	return if ! exists $BACKUP_HISTORY{$self->{function}}; 
	return if          $BACKUP_HISTORY{$self->{function}} < 1; 

	my $li      = $self->get(-Format => 'unmunged');
	my $t       = time; 
	
	if(! -d $self->rootBackupDirPath){ 
		warn "$PROGRAM_NAME $VER warning! Could not create, '$self->rootBackupDirPath'- $!" 
			unless mkdir ($self->rootBackupDirPath, $DIR_CHMOD);
		chmod($DIR_CHMOD, $self->rootBackupDirPath)
			if -d $self->rootBackupDirPath; 
	}
	
	my $backup_dir = $self->backDirPath;
	if(! -d $backup_dir){ 
		warn "$PROGRAM_NAME $VER warning! Could not create, '$backup_dir'- $!" 
			unless (mkdir $backup_dir, $DIR_CHMOD);
		chmod($DIR_CHMOD, $backup_dir)
			if -d $backup_dir; 
	}
	
	my $new_dir = $self->_safe_path($backup_dir . '/' . $t); 
	
	warn "$PROGRAM_NAME $VER warning! Could not create, '$new_dir'- $!" 
		unless mkdir ( $new_dir, $DIR_CHMOD );
		chmod($DIR_CHMOD, $new_dir)
			if -d $new_dir; 
		
		
	if(-d $new_dir){
		foreach my $setting(keys %$li){	
			next if ! $setting;
			sysopen(KEY, $self->_safe_path($new_dir . '/' . $setting),  O_WRONLY|O_TRUNC|O_CREAT,  $FILE_CHMOD) 
				or warn "$PROGRAM_NAME $VER error! Can't write key/value file at: '" . $self->_safe_path($new_dir . '/' . $setting) . "' $!";  
			print KEY $li->{$setting};
			close(KEY) or warn $!;
			chmod($FILE_CHMOD, $self->_safe_path($new_dir . '/' . $setting)); 
		}
		$self->removeOldBackupsToDir;
	}else{ 
		warn "$PROGRAM_NAME $VER warning! $backup_dir wasn't created! Backup failed.";
	}	
}


sub removeAllBackups { 

	my $self = shift; 
	my $all  = shift; 
	
	$self->removeOldBackupsToDir((-1));
	if( -d $self->backDirPath){ 
	
	# This zaps any files that are saved if a restore from backup takes place. 
	#
	#
	my $backup_of_backup_file; 
		if(opendir(BUOBU, $self->backDirPath)){ 
		
			while(defined($backup_of_backup_file = readdir BUOBU) ) {
				next if $backup_of_backup_file   =~ /^\.\.?$/;
				$backup_of_backup_file           =~ s(^.*/)();
				
				next if -d 	$self->backDirPath . '/' . $backup_of_backup_file;
				
				my $n = unlink($self->_safe_path($self->backDirPath . '/' . $backup_of_backup_file)); 
					warn $self->backDirPath . '/' . $backup_of_backup_file . " didn't go quietly" if $n == 0; 
			}
		closedir(BUOBU) or warn "couldn't close: " . $self->backDirPath; 
	}else{
		warn "could not open " . $self->backDirPath . " $!"; 
	}
	#
	#
	# and enough of that. 
	
		warn 'Couldn\'t remove, '. $self->backDirPath . " - $!"
			unless rmdir ($self->backDirPath);
		}
		
	if($all){
		if(-d $self->_safe_path($self->rootBackupDirPath)){ 
			warn 'Couldn\'t remove, '. $self->_safe_path($self->rootBackupDirPath) . " - $!"
				unless rmdir ($self->_safe_path($self->rootBackupDirPath));
		}
	}
}




sub removeOldBackupsToDir { 

	my $self    = shift;
	my $depth   = shift || $BACKUP_HISTORY{$self->{function}};
	my $backups = $self->backupDirs; 
	my $i = -1; 
	foreach(@$backups){
		$i++;
		next if $i < $depth; 	
		$self->removeBackupDir($backups->[$i]);
	}
	
}




sub backupDirs { 
	
	my $self = shift; 
	
	my $backups; 
	my $backup; 
	
	if(-d $self->backDirPath){ 
		if(opendir(DIR, $self->backDirPath)){ 
			while(defined($backup = readdir DIR) ) {
		
				next if ! -d $self->backDirPath . '/' . $backup;
				next if $backup =~ /^\.\.?$/;
				next if (($backup eq '') || ($backup eq ' ')); 
				
				$backup         =~ s(^.*/)(); 
		
				push(@$backups, $backup);
			}
			closedir(DIR) or warn "didn't close properly... $!"; 
			
			#desc
			@$backups = sort {$b <=> $a} @$backups;
			return $backups; 
		}else{ 
			warn "$PROGRAM_NAME $VER warning! Could not open backup directory: '" . $self->backDirPath ."' $!";
			return [];
		}
	}else{ 
		# backupdir not even there...
		return [];
	}
}




sub removeBackupDir { 
	
	my $self = shift;
	my $dir  = shift; 
	
	my $deep_six_dir = $self->backDirPath . '/'. $dir;
	
	my $bufile; 
	if(opendir(BUFILES, $deep_six_dir)){ 
	
		while(defined($bufile = readdir BUFILES) ) {
			next if $bufile =~ /^\.\.?$/;
			$bufile         =~ s(^.*/)();
			
			my $n = unlink($self->_safe_path($deep_six_dir . '/' . $bufile)); 
			warn $deep_six_dir . '/' . $bufile . " didn't go quietly" if $n == 0; 
		}
		closedir(BUFILES) or warn "couldn't close: " . $deep_six_dir; 
		warn "couldn't remove $deep_six_dir $!"
			unless rmdir($self->_safe_path($deep_six_dir));
	}else{ 
		warn "couldn't open: " . $deep_six_dir; 
	}
}


sub rootBackupDirPath { 
	my $self = shift; 
	return $self->_safe_path($BACKUPS . '/' . $self->{name}); 
}





sub backDirPath { 
	my $self = shift;
	return $self->_safe_path($self->rootBackupDirPath . '/' . $self->{function}); 
}




sub restoreFromFile { 
	my $self         = shift; 
	my $restore_dir  = shift; 
	
	my $function = '';
	   $function = '-archive'  if $self->{function} eq 'archives';
   
	my $Path = $FILES; 
	   $Path = $ARCHIVES       if $self->{function} eq 'archives';    
	   
	require File::Copy; 
	

	if(-e $Path . '/mj-' . $self->{name} . $function){ 
		File::Copy::copy($self->_safe_path($Path . '/mj-' . $self->{name} . $function),        $self->_safe_path($self->backDirPath .  '/backup_of_mj-' . $self->{name} . $function . '-' . time));
		warn "$PROGRAM_NAME $VER  warning! removing list file didn't work... $!"
			unless unlink $self->_safe_path($Path . '/mj-' . $self->{name} . $function);
	}
	
	if(-e $Path . '/mj-' . $self->{name} . $function . '.db'){ 
		File::Copy::copy($self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.db'), $self->_safe_path($self->backDirPath .  '/backup_of_mj-' . $self->{name} . $function . '.db-' . time));
		warn "$PROGRAM_NAME $VER  warning! removing list  file didn't work... $!"
			unless unlink $self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.db');
	}
	
	if(-e $Path . '/mj-' . $self->{name} . $function . '.pag'){ 
		File::Copy::copy($self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.pag'), $self->_safe_path($self->backDirPath .  '/backup_of_mj-' . $function . $self->{name} . '.pag-' . time));
		warn "$PROGRAM_NAME $VER  warning! removing list  file didn't work... $!"
			unless unlink $self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.pag');
	}
	
	if(-e $Path . '/mj-' . $self->{name} . $function . '.dir'){ 
		File::Copy::copy($self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.dir'), $self->_safe_path($self->backDirPath .  '/backup_of_mj-' . $self->{name} . $function . '.dir-' . time));
		warn "$PROGRAM_NAME $VER  warning! removing list setting file didn't work... $!"
			unless unlink $self->_safe_path($Path . '/mj-' . $self->{name} . $function . '.dir');
	}
	
	my %new_values; 
	my $value; 
	
	if ($restore_dir ne 'just_remove_blank'){ 
	
		if(opendir(BACKUPDIR, $self->backDirPath .  '/' . $restore_dir)){  	
			while(defined($value = readdir BACKUPDIR) ) { 		
				next if $value =~ /^\.\.?$/;
				$value         =~ s(^.*/)();
				
				my $value_file = $self->backDirPath .  '/' . $restore_dir . '/' . $value;
				if(-e $value_file){ 
					open(VALUE, $value_file) or warn $!; 
					{
						local $/ = undef; 
						$new_values{$value} = <VALUE>;    
						#warn $value . '  =>  ' .  $new_values{$value};
					}
					close(VALUE) or warn $!; 
				}else{ 
					warn $value_file . "doesn't exist?!";
				}
				
				
			}
			closedir(BACKUPDIR); 
			$self->save({%new_values});
			
		}else{ 
			warn "$PROGRAM_NAME $VER warning! opening the backup dir: '" . $self->backDirPath . '/' . $restore_dir . "' didn't work!";
			return undef;
		}
	}
}




sub uses_backupDirs { 
	return 1; 
}





1;
