#!/usr/bin/perl
require "/home/vai/public_html/cgi-bin/tools.pl";

#
@lst = LoadList("grep -Ri \"hannu rainesto\" articles/*|grep -v \"titles\.txt\" 2>/dev/null|");

#
for($i=0; $i<($#lst+1); $i++)
{
	#
	$str = $lst[$i];
	$str =~ s/^([^\:]+).*$/$1/;
	print "rm -f \"$str\"\n";
}

#

