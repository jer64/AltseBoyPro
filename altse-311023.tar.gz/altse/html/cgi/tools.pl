# tools.pl - Vunet Information System 2013 - Article and other tools.
################################################################
my (@web);

#
#use Time::localtime;
#use File::stat;
use CGI;
use DBI;

# Simulate WWW-server if necessary.
if($ENV{'DOCUMENT_ROOT'} eq "") {
	$ENV{'DOCUMENT_ROOT'} = "$ENV{'HOME'}/public_html";
}

$CGIROOT1 = $ENV{'DOCUMENT_ROOT'};
if($CGIROOT1 eq "") {
  $CGIROOT1 = $ENV{'HOME'};
}
require "$CGIROOT1/cgi/modules/sqlfunctions.pm";
require "$CGIROOT1/cgi/modules/ArgLineParse.pm";
require "$CGIROOT1/cgi/modules/MenuSystem.pm";
require "$CGIROOT1/cgi/modules/MenuSystemGoldenChinaTV.pm";
require "$CGIROOT1/cgi/modules/MenuSystemGold.pm";
require "$CGIROOT1/cgi/modules/MenuSystemGeo.pm";
require "$CGIROOT1/cgi/modules/EndBar.pm";
require "$CGIROOT1/cgi/modules/CookieTools.pm";
require "$CGIROOT1/cgi/modules/LoadList.pm";
require "$CGIROOT1/cgi/modules/AutoDetermineMapImage.pm";

#
if($ENV{'SERVER_NAME'} ne "" && $ENV{'DOCUMENT_ROOT'} eq "") {
        $ENV{'DOCUMENT_ROOT'} = "/home/vai/public_html";
}

#
$CACHE_STAT_INTERVAL = (60*60*1);
#
$GLOBALW =  "100%";
$GLOBALW2 = "100%";
$UUSI_IKA = 60*60*24;
#
@iopt_keys = ("specialreport", "icap", "icap2", "ontop", "imageurl", "imageurl2", "imageurl3", "imageurl4",
                "NO_FLY_FIX", "full", "dontembed", "COMMENTS_ENABLED",
                "swfurl", "quote_loc", "w_below_cap",
		"geoloc");

#
################################################################
# Your home computer's IP (for master access in some cases).
$MASTER_IP=             "";
#
@MASTER_IPS=(
		);
@PERKELE_IPS=(
);
# Remove remark below to disable the search service for public users.
$SDB_SERVICE_OFF = 0;
#
if($ENV{'DOCUMENT_ROOT'} ne "") {
	# Good guess, it's an Apache.
	$ARTBASE = "$ENV{'DOCUMENT_ROOT'}/articles";
} else {
	# Guessing, it's a shell.
	$ARTBASE = "$ENV{'HOME'}/public_html/articles";
}
$IMAGES_BASE = "http://www.VAI.News/images";
$IMAGES_LOCAL_BASE = "$ENV{'DOCUMENT_ROOT'}/images";
$NWPUB_WWWBASE =        "$ENV{'DOCUMENT_ROOT'}";
$NWPUB_CGIBASE =        "$ENV{'DOCUMENT_ROOT'}/cgi";
$ENV{'NWPUB_WWWBASE'} = $NWPUB_WWWBASE;
$ENV{'NWPUB_CGIBASE'} = $NWPUB_CGIBASE;


#
$VAI_PROF_DIR = "$NWPUB_CGIBASE/user/";
$IMGBASE = "$IMAGES_BASE";
$NEBASE = "$IMAGES_BASE";
$NEBASECGI = "/cgi";
#
$BGBAK1 = "$IMAGES_BASE/bakki5.gif";
$BGBAK2 = "$IMAGES_BASE/bakki6.gif";
$BGBAK3 = "$IMAGES_BASE/bg26.png";
$TABCOL = "40E0FF";
#
$PRIM_ADMIN_EMAIL = "seuranta\@vunet.world";

#
require "/home/vai/cgi/config.pl";

#
sub GenArticleHTMLPreview
{
		my ($str,$vuneturl,$artfn,@art_content,$art_cap,$art_th_url,$link_explanation);

		#
		$str = $_[0];
		$str =~ s/^\.\.\///;
		my $url = BuildQuickUrl($str);
                if(1) {
                        @art_content = LoadList("$ARTBASE/$str");
                        $art_cap = $art_content[0];
                        $art_cap =~ s/\<[^\>]+\>//g;
                        LoadVars_so2("$ARTBASE/$str\_options.txt");
			$so{'imageurl'} =~ s/http:\/\/[^\/]+\/([^\/]+)$/$1/;
			$so2{'imageurl'} =~ s/http:\/\/[^\/]+\/([[^\/]+)$/$1/;
			#$so{'imageurl'} = $IMAGES_BASE . "/" . $so{'imageurl'};
			#$so2{'imageurl'} = $IMAGES_BASE . "/" . $so{'imageurl2'};
                        $art_th_url = $so2{'imageurl'};
			if(!($art_th_url =~ /\/thumb[0-9]*\//)) {
	                        $art_th_url =~ s/(\/images)\/(.+)(\.jpg)/$1\/thumb\/th_$2\.jpg/;
			}
                        $link_explanation = (
"<A HREF='$url'><IMG SRC='$art_th_url' border=1 class=darkul><\/a><BR><a href='$url' class=darkul><B> $art_cap</B><\/a>");
                } else {
                        $link_explanation = ("[No EXP.]");
		}
		return $link_explanation;
}

#
sub GoodImageURL
{
	my $ifn = $_[0];
	$ifn =~ s/^http:\/\/.+\/(.+)$/$1/;
	return $ifn;
}

#####################################################################################################
#
sub DetermineURLIconImage
{
	my ($str);

	#
	$str = $_[1];
	$str =~ s/^http:\/\/[a-z]+\.vunet\.org[^\/]*[\/]//;
	$str =~ s/^http:\/\/[a-z]+\.kultakaivos\.info[^\/]*[\/]//;
	$str =~ s/^http:\/\/[a-z]+\.vaihtoehtouutiset\.info[^\/]*[\/]//;
	$str =~ s/([a-z]+)\/[^0-9]+([0-9]+).*$/$1\/pub_artikkeli$2.txt/;
	#
	if($str=~/pub_artikkeli/)
	{
		#
		$so{'imageurl'} = "";
		if(-e "$str\_options.txt")
		{
			LoadImageURL("$str\_options.txt");
		}
		if($so{'imageurl'} eq "") { goto past; }
		$so{'imageurl'} =~ s/\.jpg$/\.png/;
		$so{'imageurl'} =~ s/^.*\/([^\/]+)$/$1/;
		$so{'imageurl'} = "$IMAGES_BASE/thumb2/th_$so{'imageurl'}";
		return $so{'imageurl'};
	}
	else
	{
past:
		#
		return "$IMAGES_BASE/icons1/golden_ball.gif";
	}

	#
}




#####################################################################################################
#
sub GetArticlesOptions
{
	my (@lst);

	#
	$so{'imageurl'} = "";
	$so{'imageurl2'} = "";
	$so{'imageurl3'} = "";
	$so{'imageurl4'} = "";
	$so{'icap'} = "";
	$so{'icap2'} = "";
	LoadVars("$_[0]\_options.txt");
	$so{'imageurl'} =~ s/vuutiset.info/vunet.world/g;
}

#####################################################################################################
#
sub GetArticleIPs
{
	my (@lst,$str);

	#
	$str = $_[0];
	$str =~ s/\.txt$/\.counter/;
	@lst = LoadList("$str");
	return @lst;
}

#####################################################################################################
#
sub GetArticleReferences
{
	my (@lst,$str);

	#
	$str = $_[0];
	@lst = LoadList("$str\_ref.txt");
	return @lst;
}

#####################################################################################################
#
sub GetArticleIPs
{
	my (@lst,$str);

	#
	$str = $_[0];
	@lst = LoadList("$str\_thumbs.txt");
	return @lst;
}

#####################################################################################################
#
sub vis_log
{
        my ($f,$f2,$str,$str2,$t,$pm);

        #
        $t = time;

        #
        $pm = sprintf("%d", $t/86400);

        #
        open($f, ">>articles/logs/vislog/vislog-$pm.txt");
        flock $f, LOCK_EX;
        print $f "$t;$ENV{'REMOTE_ADDR'};$ENV{'REMOTE_HOST'};\n";
        flock $f, LOCK_UN;
        close($f);
}

#############################################################################
#
sub save_iopts
{
        my ($i,$i2,$str,$str2,$f,$fn);

        #
        $fn = "$_[0]\_options.txt";
        if(-e $fn)
        {
                # Get existing variables which aren't changed now.
                LoadNewVars($fn);
        }
        open($f, ">$fn") || die "can't open $fn for writing";
        for($i=0; $i<($#iopt_keys+1); $i++)
        {
                #
		if($iopt_keys[$i]=~/imageurl/)
		{
			# Accept only jpegs as imageurls.
			if( !($so{$iopt_keys[$i]}=~/\.jpg/) )
			{
				$so{$iopt_keys[$i]} = "";
			}
		}
                $so{$iopt_keys[$i]} =~ s/\n/<BR>/g;
                #print "$iopt_keys[$i] = $so{$iopt_keys[$i]}<BR>\n";
                print $f "$iopt_keys[$i]=$so{$iopt_keys[$i]}\n";
		#print "$iopt_keys[$i]=$so{$iopt_keys[$i]}<BR>\n";
        }
	print $f "lyrics=$so{'lyrics'}\n";
	print $f "stream=$so{'stream'}\n";
	print $f "mirror=$so{'mirror'}\n";
	print $f "commir=$so{'commir'}\n";
	print $f "release_date=$so{'release_date'}\n";
        close($f);
}

######################################################################################################
#
sub isAutoSection
{
	my ($i,$i2,$f,@ql,$quoteit,$tep,$author,$cap,@art,$x);
	my @asecs=(
        "ostetaan",
        "myydaan",
        "kannettavat",
        "valokuvaus",
        "asunnot",
        "tyopaikat",
        "tyonhakijat",
        "komponentit",
        "elokuvat",
        "veneily",
        "huumori",
        "ruokailu",
	"progressive",
	"bush",
	);

        #
        for($i=0; $i<($#asecs+1); $i++)
        {
                if($asecs[$i] eq $_[0]) { return 1; }
        }

        #
        return 0;
}

######################################################################################################
#
sub isEnglishSection
{
	my ($i,$i2,$f,@ql,$quoteit,$tep,$author,$cap,@art,$x);
	my @esecs=(
	"progressive",
	"bush",
	"picks",
	"videos"
	);

        #
        for($i=0; $i<($#esecs+1); $i++)
        {
                if($esecs[$i] eq $_[0]) { return 1; }
        }

        #
        return 0;
}

######################################################################################################
#
sub isSwedishSection
{
	my ($i,$i2,$f,@ql,$quoteit,$tep,$author,$cap,@art,$x);
	my @esecs=(
	"nyheter",
	);

        #
        for($i=0; $i<($#esecs+1); $i++)
        {
                if($esecs[$i] eq $_[0]) { return 1; }
        }

        #
        return 0;
}

######################################################################################################
#
sub isDutchSection
{
	my ($i,$i2,$f,@ql,$quoteit,$tep,$author,$cap,@art,$x);
	my @esecs=(
	"dutch",
	);

        #
        for($i=0; $i<($#esecs+1); $i++)
        {
                if($esecs[$i] eq $_[0]) { return 1; }
        }

        #
        return 0;
}

######################################################################################################
#
# CapUrl [URL] [CAP].
#
sub CapUrl
{
	my ($url,$urlcap);

	# ALSO.
	$urlcap = $_[1];
	$urlcap =~ s/�/a/g;
	$urlcap =~ s/�/o/g;
	$urlcap =~ s/�/a/g;
	$urlcap =~ s/�/a/g;
	$urlcap =~ s/�/o/g;
	$urlcap =~ s/�/a/g;
	$urlcap =~ s/[^a-z0-9]/_/gi;
	$urlcap =~ s/_*$//g;
	$urlcap =~ s/^_*//g;
	$urlcap =~ s/__/_/g;
	$urlcap =~ s/^(.{70}[a-z0-9]*).*$/$1/;

	$url = $_[0];

	## WRONG:
	$url =~ s/^.+[^a-z]+([a-z]+\/[a-z_0-9\-]+\.[a-z]+)/$1/;

	$url =~ s/pub_artikkeli([0-9]*).txt/story$1.html/;
	$url =~ s/\/english\//\/picks\//;
	$url =~ s/\/article//;
	$url =~ s/(\-[0-9]+\.html)$/$1/g;
	if($urlcap eq "") { $urlcap = "story"; }
	$url =~ s/story([0-9]*)/$urlcap\-$1/;
	if($HOSTI ne "") {
		#$url = $HOSTI . $url;
	}
#	$url =~ s/^([^a-z]+)([a-z]+\/[a-z_0-9]\.[a-z]+)/$2/;
	#print "<P>ORIG: \"$_[0]\"</P>";
	#print "<P>NEW: \"$url\"</P>";
	return $url;
}

################################################################
#
sub GenName
{
	my ($num,$tm);

	#
	$num = rand(100000000000000);
	$num =~ s/\.//;
	$tm = time;
	return "_$tm$num$num2.tmp";
}

#
sub gotUserFile
{
	my ($f);

        #
        open($f, "$NWPUB_CGIBASE/user/user_$_[0].txt") || return 0;
        $userid = <$f>;
        $firstname = <$f>;
        $lastname = <$f>;
        $email = <$f>;
        $profession = <$f>;
        close($f);
        return 1;
}

# PostMessage file1.txt file2.txt address@host.com subject_here
sub MailMessage
{
	my ($viesti);

	#
	$viesti = $_[3];
	$viesti =~ s/<br>//i;
	$viesti =~ s/<br>//i;
	$viesti =~ s/<hr>//i;
	system "cat $_[0] $_[1] | mail $_[2] Subject: $viesti";
}

# Write a string to the administration log.
sub AdminLog
{
	#
	system "echo \"$_[0]\" >> ./admin-log.txt";
}

#
sub OpenWebIndex
{
	my ($f,$i);

        #
	@web = LoadList($_[0]);
	#
	$wherebe = 0;

	#
	return @web;
}

##########################################################
sub HandleRest
{
	my ($ix);

        # Print until end of the web text.
        for($ix=$wherebe; $ix<($#web+1); $ix++)
        {
                print "$web[$ix]\r\n";
        }
#	print ">\n";
}

##########################################################
sub OpenIndex
{
        my ($i,$ff);

	#
	@fileindex = LoadList($_[0]);
}


##########################################################
#
# Handles an external section.
#
# [section trigger], [perl program to make the output]
#
sub HandleExternal
{
        my ($i,$i2,$found);

        # Print until "$_[0]" is found.
        loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
        {
                if($web[$i] =~ /$_[0]/i)
                {
                        $found=1;
                }
                print "$web[$i]\r\n";
        }
        if($found) { system $_[1]; }
        $wherebe=$i;
}

#
sub WebWalkTo
{
        my ($i,$i2,$loytyi);

        # Print until "$_[0]" is found.
        loop1: for($i=$wherebe,$loytyi=0; $i<($#web+1) && !$loytyi; $i++)
        {
                if($web[$i] =~ /$_[0]/i)
                {
                        $loytyi=1;
                }
                print "$web[$i]\r\n";
        }
	if(!$loytyi)
	{
		#print "<div>\"$_[0]\" NOT FOUND, \#web = $#web, i=$i </div>";
	}
        $wherebe=$i;
}

#
sub SkipTo
{
        my ($i,$i2,$found);

        # Print until "$_[0]" is found.
        loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
        {
                if($web[$i] =~ /$_[0]/i)
                {
                        $found=1;
                }
   #             print "$web[$i]\r\n";
        }
        $wherebe=$i;
}

#
sub WebModif
{
	my ($z);

	#
	for($z=0; $z<($#web+1); $z++)
	{
	        $web[$z] =~ $_[0];
	}
}

#
sub Corner
{
        #
        print("
                <table width=\"100%\">
                <tr>
                        <td>
                ");

        #
        print("

                <table width=\"100%\" vspace=\"8\" hspace=\"32\" align=\"center\">
                <tr><td>

		<center>
                <form method=\"get\" action=\"search.pl\" name=\"search\">
                <input type=\"text\" name=\"searchstring\" size=\"8\" value=\"\">
                <input type=\"hidden\" name=\"cmd\" value=\"searchnow\">
                <option selected>
                <input type=\"submit\" value=\"Etsi\" style=\"background-color: #FFC0C0\">
                </form>
		</center>

<SCRIPT LANGUAGE=\"JavaScript\">
document.forms[0].elements[0].focus();
</script>


                </td></tr>
                </table>
                ");

        #
        print("
                        </td>
                </tr>
                </table>
                ");
}

# Load variables to %so tree.
sub LoadVarsRegex
{
        my ($i,$str,$str2,$str3,$str4,@tmp,$f,@opt);

        $so{'imageurl'} = "";
        $so{'imageurl2'} = "";
        $so{'imageurl3'} = "";
        $so{'imageurl4'} = "";
        $so{'icap'} = "";
        $so{'icap2'} = "";

        #
	if( !open($f, "$_[0]") )
	{
		#print "NOT FOUND $_[0]\n";
		return;
	}
        close($f);
        @opt = LoadList("$_[0]");

        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname ne "" && $varvalue ne "")
                {
			$varname =~ s/^[0-9]+\s+//;
			$varname =~ s/^$ARTBASE\/*//;
                        $so{$varname} = $varvalue;
			#if(NoTracking()) {
			#	print "<LI>$varname</LI>";
			#}
			$varname =~ s/$_[1]/$_[2]/;
                }
        }

	#
	FixImageUrl();

	#
        return 1;
}

# Load variables to %so tree.
sub LoadVars
{
        my ($i,$str,$str2,$str3,$str4,@tmp,$f,@opt);

        $so{'imageurl'} = "";
        $so{'imageurl2'} = "";
        $so{'imageurl3'} = "";
        $so{'imageurl4'} = "";
        $so{'icap'} = "";
        $so{'icap2'} = "";

        #
	if( !open($f, "$_[0]") )
	{
		#print "NOT FOUND $_[0]\n";
		return;
	}
        close($f);
        @opt = LoadList("$_[0]");

	# Empty article property variables first.
$so{'specialreport'} = "";
$so{'icap'} = "";
$so{'icap2'} = "";
$so{'ontop'} = "";
$so{'imageurl'} = "";
$so{'imageurl2'} = "";
$so{'imageurl3'} = "";
$so{'imageurl4'} = "";
$so{'NO_FLY_FIX'} = "";
$so{'full'} = "";
$so{'dontembed'} ="";
$so{'COMMENTS_ENABLED'} = "";
$so{'swfurl'} = "";
$so{'quote_loc'} = "";
$so{'w_below_cap'} = "";
$so{'geoloc'} = "";
$so{'lyrics'} = "";
$so{'stream'} = "";
$so{'mirror'} = "",
$so{'commir'} = "";
$so{'release_date'} = "";


        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname ne "" && $varvalue ne "")
                {
                        $so{$varname} = $varvalue;
                }
        }

	#
	FixImageUrl();

	#
        return 1;
}





# Load variables to %so tree.
sub LoadVars_so2
{
        my ($i,$str,$str2,$str3,$str4,@tmp,$f,@opt);

        $so2{'imageurl'} = "";
        $so2{'imageurl2'} = "";
        $so2{'imageurl3'} = "";
        $so2{'imageurl4'} = "";
        $so2{'icap'} = "";
        $so2{'icap2'} = "";

        #
	if( !open($f, "$_[0]") )
	{
		#print "NOT FOUND $_[0]\n";
		return;
	}
        close($f);
        @opt = LoadList("$_[0]");

	# Empty article property variables first.
$so2{'specialreport'} = "";
$so2{'icap'} = "";
$so2{'ontop'} = "";
$so2{'imageurl'} = "";
$so2{'imageurl2'} = "";
$so2{'imageurl3'} = "";
$so2{'imageurl4'} = "";
$so2{'NO_FLY_FIX'} = "";
$so2{'full'} = "";
$so2{'dontembed'} ="";
$so2{'COMMENTS_ENABLED'} = "";
$so2{'swfurl'} = "";
$so2{'quote_loc'} = "";
$so2{'w_below_cap'} = "";
$so2{'geoloc'} = "";
$so2{'lyrics'} = "";
$so2{'stream'} = "";
$so2{'mirror'} = "",
$so2{'commir'} = "";
$so2{'release_date'} = "";


        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname ne "" && $varvalue ne "")
                {
                        $so2{$varname} = $varvalue;
                }
        }

	#
	FixImageUrl();

	#
        return 1;
}





# Load variables to %so tree.
sub LoadImageURL
{
        my ($i,$str,$str2,$str3,$str4,@tmp,$f,@opt);

        #
	if( !open($f, "$_[0]") )
	{
		#print "NOT FOUND $_[0]\n";
		return;
	}
        close($f);
        @opt = LoadList("$_[0]");

        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname eq "imageurl" && $varvalue ne "")
                {
                        $so{$varname} = $varvalue;
                }
        }

	#
        return 1;
}

# Load variables to %so tree.
sub LoadNewVars
{
        my ($i,$str,$str2,$str3,$str4,@tmp,$f,@opt);

        #
	if( !(-e $_[0]) ) {
		#print "NOT FOUND $_[0]\n";
		return;
	}

	#
        @opt = LoadList("$_[0]");
        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname ne "" && $varvalue ne "")
                {
                        if($so{$varname} eq "") { $so{$varname} = $varvalue; }
                }
        }

	#
        return 1;
}

#
sub PathToSection
{
	my (@s);

        #
        @s = split "\/", $_[0];
        return $s[$#s-1];
}

# Types in a html code of 1 pixel height line by using a table.
sub Line
{
        print("
                        <table width=\"$_[1]\"
                        cellpadding=\"0\" cellspacing=\"0\">
                        <tr>
                        <td width=\"100%\" bgcolor=\"$_[0]\" height=\"1\">
                        </td>
                        </tr>
                        </table>
                ");
}

# SelectionBox
# Requires four parameters:
# AC, AC2, String To Show, URL To Link, table alignment (alignment is optional)
sub SelectionBox
{
                #
                Line("$_[0]", "120");
                print("
                        <table
                        cellpadding=\"0\" cellspacing=\"0\" align=\"$_[4]\">


                        <tr class=\"withLink\" bgcolor=\"$_[1]\">
                        <td width=\"16\" bgcolor=\"$_[0]\">
                        </td>

                        <td width=\"4\">
                        </td>

                        <td width=\"100\">
                        <a href=\"$_[3]\" style=\"color: rgb(255, 255, 255);\">
                        <font size=\"1\">
                        $_[2]
                        </font>
                        </a>
                        </td>

                        </tr>


                        </table>

                        ");

                #
                Line("", 120);
}

# Hunt for most recently updated file.
sub huntn
{
	my ($i,$i2,$i3,$i4,$fname,@li,$f,$ff);
	
	#
#	@li = LoadList("./$_[0]/fileindex.txt");

	#
	open($f, "./$_[0]/fileindex.txt") || die "can't open important-sections.txt";;
	@li = <$f>;
	for($i=0; $i<($#li+1); $i++) { chomp $li[$i]; }
	close($f);

	#
	return "./$_[0]/$li[$#liz]";
}

##########################################################
sub BigText
{
        my ($str,$str2,$i,$i2);

        #
        $str = $_[0];
        $str =~ tr/[a-z���]/[A-Z���]/;

        #
        print("
                <font color=\"#C00000\" size=\"6\" face=\"Arial\">
		<b>$str</b>
                </font>
                ");
}

###########################################################################################
#
sub Seperator
{
        #
        print("
                <table bgcolor=\"0\" width=640 height=4
                        cellspacing=\"0\"
                        cellpadding=\"0\">
                <tr valign=top>
                        <td bgcolor=\"#002000\">
                        </td>
                </tr>
                </table>
                ");
}

###########################################################################################
#
sub SectionHeadline
{
	#
	if($_[0] eq "")
	{
	        #
        	BigText($ENV{'CURSEC'});

		#
		Seperator();
	}
	else
	{
	        #
        	BigText($_[0]);

		#
		Seperator();
	}
}

###########################################################################################
#
sub DetectLanguage
{
        my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,@s,@s2,$change,$r,@sp);

	#
	$r = $ENV{'REMOTE_HOST'};
	if($r=~/\.cn$/)
	{
		return "cn";
	}
	if($r=~/\.nl$/)
	{
		return "nl";
	}
	if($r=~/\.se$/)
	{
		return "se";
	}
	if($r=~/\.fi$/)
	{
		return "fi";
	}

	#
	@sp = split(/[\,\;]/, $ENV{'HTTP_ACCEPT_LANGUAGE'});
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] eq "nl") { return "nl"; }
		if($sp[$i] eq "cn") { return "cn"; }
		if($sp[$i] eq "fi") { return "fi"; }
		if($sp[$i] eq "se") { return "se"; }
		if($sp[$i] eq "en") { return "en"; }
	}

	return "en";
}

#
sub GoogleAds_2
{
	#
	print("
<table align=\"right\">
<tr>
<td>

<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 125;
google_ad_height = 125;
google_ad_format = \"125x125_as\";
google_ad_channel =\"\";
google_ad_type = \"text\";
google_color_border = \"336699\";
google_color_bg = \"FFFFFF\";
google_color_link = \"0000FF\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

</td>
</tr>
<table>
	");
}

#
sub GoogleAds_3
{
	#
	print("
<table align=\"center\">
<tr>
<td>


<div class=\"supah\">

<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 300;
google_ad_height = 250;
google_ad_format = \"300x250_as\";
google_ad_channel =\"\";
google_ad_type = \"text_image\";
google_color_border = \"E0FFE3\";
google_color_bg = \"E0FFE3\";
google_color_link = \"0000CC\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

</div>

</td>
</tr>
<table>
	");
}

#
sub detout
{
	if($_[0] eq "")
	{
		return stdout;
	}
	else
	{
		return $_[0];
	}
}

#
sub GoogleAds
{
        #
	printf("
<table align=\"right\">
<tr>
<td>

<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>

<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = \"120x600_as\";
google_ad_channel =\"\";
google_color_border = \"336699\";
google_color_bg = \"FFFFFF\";
google_color_link = \"0000FF\";
google_color_url = \"008000\";
google_color_text = \"000000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

</td>
</tr>
<table>
	");
}

#
sub CustomTimeString
{
	my ($Second,$Minute,$Hour,$Day,$Month,
		$Year,$WeekDay,$DayOfYear,$IsDST,
		$Year1,$Month1,$Day1,
		$str,$str2);

	#
	($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

	#
	$Year1 = $Year + 1900;
	$Month1 = $Month+1;

	#
	$str = "$Hour:$Minute, $Day.$Month1.$Year1";
	return $str;
}

#
sub WebStart
{
	#
	OpenWebIndex("./webindex.html");
	#
	WebWalkTo("past-uusilogo2");
	if($_[0] ne "")
	{
		print("
			<img src=\"$_[0]\" alt=\"$_[0]\" border=0>
			");
	}
	#
	HandleExternal("main-menu", "./mainmenu.pl");
}






#
sub WireLogo
{
		my $LOGO;

		#
		if($_[0] ne "x")
		{
			$LOGO = "$IMGBASE/bg2.gif";
		}
		else
		{
			$LOGO = "$_[0]";
		}

                #
		if($so{'printable'} eq "")
		{
	                # ============ Vaihtoehtouutiset -logo. =============
	                #print("<img src=\"$LOGO\" alt=\"Vaihtoehtouutiset\" border=0>    ");
		}
}

#
sub ULTRAPARSE
{
	my ($str,$i,$i2,$i3,$i4,$str2);

	#
	$str = $_[0];
	$str =~ s/^IMAGE:\"(.*)\"/<img src=\"$1\">/g;
	$str =~ s/^LINK:\"(.*)\"/<a href=\"$1\" class=\"dark\" target=\"_blank\">/g;
	$str =~ s/^CLOSELINK\:/<\/a>/g;
	$str =~ s/^STARTBOX(.*):/<table align=\"right\" cellpadding=4 cellspacing=0 width=$1> <tr><td>/g;
	$str =~ s/^ENDBOX\:/<\/td><\/tr><\/table>/g;

	#
#	if($ENV{'CURSEC'} eq "")
#	{
#		return "";
#	}

	#
	if($str =~ /^{\s/)
	{
		#
		$str2 = $str;
		$str2 =~ s/^{\s(.*)/$1/;
		$str2 =~ s/\s$//g;
		$str2 =~ s/<.*?>//g;
		#
		$str = ("
			<table align=right cellpadding=4 cellspacing=0 
				border=0 $str2>
			<tr>
			<td valing=top>
			<font size=1>
			");
	}

	#
	if($str =~ /^}/)
	{
		#
		$str = ("
			</td>
			</tr>
			</table>
			");
	}
past:

	#
	return $str;
}

#################################################################################
#
sub BuildQuickUrl
{
        my ($v,$i,$i2,$str,$str2,$str3,$str4,@sec,@sp,
		$found,@glose,$org);
        my ($f,@lst);

	return UrlFix($_[0]);

	#
	if( !($_[0] =~ /x/) )
	{
		return $_[0];
	}

        #
	if($#glose <= 0)
	{
		@glose = LoadList("sections.txt");
	}

        #
	$str = $_[0];
	$org = $_[0];
	$str =~ s/kaikki//g;
	$str =~ s/\/\.\.//g;
	#
	$str =~ s/^\///;
	@sp = split("\/", $str);
	$str2 = $sp[0];
	#
	$str3 =	$str;
	if($str3 =~ /\S*\.\S*\.txt/)
	{
		return "/article/$org";
	}
	else
	{
		$str3 =~ s/^.*pub_artikkeli(.*)\.txt$/$1/;
	}

	#
	loop1: for($i=0,$found=-1; $i<($#glose+1); $i++)
	{
		if($glose[$i] eq $str2)
		{
			$found = $i;
			last loop1;
		}
	}

	#
	if($found==-1)
	{
		return "/404.pl";
	}

	#
	$str = "x";
	return "/?id=$found$str$str3";
}

#################################################################################
#
sub ResolveQuickUrl
{
        my ($v,$i,$i2,$str,$str2,$str3,$str4,@sec);

	#
	if( !($_[0] =~ /x/) )
	{
		return $_[0];
	}

	#
	if($#SECTIONS1<2)
	{
		@SECTIONS1 = LoadList("sections.txt");
	}

        #
	$str2 = "$_[0]";
	$str2 =~ s/^.*=(.*x.*)$/$1/;
        @v = split("x", $str2);
	$i = sprintf "%d", $v[0];

        #
	$str = "$SECTIONS1[$i]/pub_artikkeli$v[1].txt";

	# No spaces allowed.
	$str =~ s/\s//g;

	#
	return $str;
}

################################################################
#
sub OPENTABLE
{
	my ($WIDD);

	#
	$COL = $_[0];

	#
	if($_[1] eq "")
	{
		$WIDD = "100%";
	}
	else
	{
		$WIDD = $_[1];
	}

	#
	print("
		<table cellpadding=2 cellspacing=0
			width=$WIDD>
		<tr>
		<td witdh=100% height=1 bgcolor=\"$COL\">



		<table cellpadding=0 cellspacing=0
			width=100%
			bgcolor=\"#F0FFFF\">
		<tr>

		<td>

		<table cellpadding=4 cellspacing=0 bgcolor=\"#E0FFFF\" width=100%>
		<tr>
		<td>
		");
}

################################################################
#
sub CLOSETABLE
{
	my ($WIDD);

	#
	$COL = $_[0];

	#
	if($_[1] eq "")
	{
		$WIDD = "100%";
	}
	else
	{
		$WIDD = $_[1];
	}

	#
	print("

		</td>
		</tr>
		</table>
		</td>
		</tr>
		</table>


		</td>
		</tr>
		</table>

		");
}

################################################################
#
sub EXPRESS
{
	my ($ALG,$BAK);

	#
	if($_[2] eq "")
	{
		$ALG = "left";
	}
	else
	{
		$ALG = $_[2];
	}

	#
	if($_[3] eq "")
	{
		$BAK = $BGBAK1;
	}
	else
	{
		$BAK = $_[3];
	}

	#
	print("
		<table cellpadding=4 cellspacing=0 width=100% height=28
			bgcolor=\"#2080C0\">
		<tr>
		<td>

		<a href=\"$_[1]\" class=dark>
		<div align=$ALG>
		<font color=\"#0000FF\" size=1>
		$_[0]
		</font>
		</div>
		</a>

		</td>
		</tr>
		</table>
		");
}

################################################################
#
sub EXPRESS2
{
	my ($ALG,$BAK);

	#
	if($_[2] eq "")
	{
		$ALG = "left";
	}
	else
	{
		$ALG = $_[2];
	}

	#
	if($_[3] eq "")
	{
		$BAK = $BGBAK3;
	}
	else
	{
		$BAK = $_[3];
	}

	#
	print("
		<table cellpadding=4 cellspacing=0 width=100% height=26
			bgcolor=\"#2080C0\"
			background=\"$BAK\">
		<tr>
		<td>

		<a href=\"$_[1]\" class=dark>
		<div align=$ALG>
		<font color=\"#80F0C0\" size=2>
		$_[0]
		</font>
		</div>
		</a>

		</td>
		</tr>
		</table>
		");
}

##########################################################
#
sub creation_date
{
        my ($testf,$taika);
        my ($Second, $Minute, $Hour, $Day, $Month, $Year,
                $WeekDay, $DayOfYear, $IsDST);

        #
        if( open($testf,"$_[0]") )
        {
                close($testf);
                ($Second, $Minute, $Hour, $Day, $Month, $Year, $Weekday, $DayOfYear, $IsDST) = localtime(time);
        #       $taika = ctime(creation_date1($_[0]));
                $aika = "$Second";
                ##$aika = "$Day/$Month/$Year  $Hour:$Minute:$Second";

        }
        $aika;
}

##########################################################
#
sub CrDate
{
        my ($testf,$taika,$aika);
        my ($Second, $Minute, $Hour, $Day, $Month, $Year,
                $WeekDay, $DayOfYear, $IsDST);

        #
        if( open($testf, "$_[0]") )
        {
                close($testf);
                $taika = CreationDate1($_[0]);
                $aika = ctime($taika);
        }
        return $aika;
}

#
sub CreationDate1
{
        my ($aika);

	#
	$aika = 0;

	#
        if( -e $_[0] )
        {
                $aika = (stat($_[0]))[9];
        }
	return $aika;
}

# Tells file age in seconds.
sub FileAge
{
	my ($aik,$taik);

	#
        $taik = time;
        $aik = CreationDate1("$_[0]");
	return $taik-$aik;
}

#
sub Bonus1
{
        my ($aik,$taik,$of,$ero);

        #
        $aik = CreationDate1("$_[0]");
        $taik = time;
	$ero = $taik-$aik;
        if( ($aik+(60*60*12)) > $taik )
        {
                # "NEW ARTICLE" ICON.
                $of = sprintf ("<img src=\"$IMGBASE/uusi.gif\" alt=\"* New! *\" align=\"center\" title=\"$ero\"
				title=\"Artikkeli on uusi!\" border=0>
                ");
                return $of;
        }
        else
        {
                if( ($aik+(60*60*48)) > $taik )
                {
                        # "PRETTY NEW ARTICLE" ICON.
                        $of = sprintf("
                                        <img src=\"$IMGBASE/uusi2.gif\" alt=\"* Pretty new! *\" align=\"center\"
					title=\"$ero\">
                        ");
                        return $of;
                }
        }
        return "";
}

#
sub NumberToDate
{
	my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST,$str);

	#
	($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime($_[0]);

	#
	$Year += 1900;
	$Month++;

	#
	$Hour = sprintf "%.2d", $Hour;
	$Minute = sprintf "%.2d", $Minute;
	$Second = sprintf "%.2d", $Second;

	#
	$str = "$Day.$Month.$Year - $Hour:$Minute:$Second";

	#
	return $str;
}

#
sub IsBanned
{
	my ($host);

	#
	$host = $_[0];

	#
	if($host eq "vunet.world"
		|| $host =~ /\.dl\.dl\.cox\.net/i
		|| $host =~ /googlebot/i
		|| $host =~ /msnbot/i
		|| $host =~ /search\.com/i
		|| $host =~ /user-200-47/i
		|| $host =~ /public.alexa.com/i
		|| $host eq "")
	{
		return 1;
	}

	#
	return 0;
}

# so varset
sub VarSet
{
	my ($str,@tmp,$varname,$varvalue);

	#
	$str = $_[0];
	if(!($str=~/\=/)) { return; }
	@tmp = split("\=", $str);
	$varname = $tmp[0];
	$varvalue = $tmp[1];
	if($varname ne "" && $varvalue ne "")
	{
		$so{$varname} = $varvalue;
	}

	#
}

#
sub rot
{
	my $rot13 = new Crypt::Rot13;

	#
	$rot13->charge ($_[0]);
	return $rot13->rot13();
}

##########################################################
#
sub RollThrough
{
        my ($i,$i2,$i3,$i4,$str,$str2,@l);

	#
	@l = LoadList($_[0]);
	for($i=0; $i<($#l+1); $i++)
	{
		VarSet($l[$i]);
	}

	#
}

##########################################################
#
sub PURL
{
        my ($U);

        #
        $U = $_[0];
        if(!($U=~/\=|\&/) && !NoTracking() && !($U=~/\.nsv$/i) )
        {
                $U=sprintf "http://www.VAI.News/?to=%s", $U;
        }
        return $U;
}

#
sub IsImage
{
	#
	if($_[0]=~/\.jpg$/) { return 1; }
	if($_[0]=~/\.gif$/) { return 1; }
	if($_[0]=~/\.png$/) { return 1; }
	if($_[0]=~/\.jpeg$/) { return 1; }

	#
	return 0;
}

#
sub tyhja
{
	#
	if($_[0]=~/^\s$/ || $_[0] eq "") { return 1; }
	return 0;
}

#
sub Special
{
	#
	if($_[0] =~ /http\:\/\//) { return 1; }
	if($_[0] =~ /embed/) { return 1; }
	return 0;
}

#
sub MakeSubject1
{
        my ($ap,@sp);

        #
        $ap = $_[0];
	#
	if($ap=~/<body/i)
	{
	}
        #
        $ap =~ s/\n/ /g;
        $ap =~ s/<script .*>.*<\/script>//gi;
        $ap =~ s/<.*?>//g;
        #
        $ap =~ s/^(.{240}).*$/$1/;
        $ap =~ s/\<//g;
        $ap =~ s/\>//g;
        $ap =~ s/\=//g;
        $ap =~ s/(.{80})/$1\-<br>/g;
        $ap =~ tr/[A-Z���]/[a-z���]/;
        $ap =~ s/(^.*)<br>$/$1/i;


        #
        return $ap;
}

#################################################################################33
#
sub pre
{
	my ($ap);

	#
	
}

#################################################################################33
#
sub preview
{
	my ($ap);

        #------------------------------------------------------------
        # GENERATE ARTICLE PREVIEW
        #------------------------------------------------------------
        #
        #
        $ap = $_[0];
        $ap =~ s/\s*$//;
        $ap =~ s/^\s*//;
        $ap =~ s/\t//g;
        $ap =~ s/\_/ /g;
        $ap =~ s/\ \ / /g;
	$ap =~ s/\-\-//g;
	$ap =~ s/\[.*?\]//g;
        #
        $ap =~ s/^(.{240}).*$/$1/;
	$ap = "$ap";

        #
        if($ap =~ /^\s*$/ || $ap eq "")
        {
                $ap = "No preview available";
        }

	#
	return $ap;
}

#
sub IsRunning
{
	my (@lst,$i,$i2,$i3,$i4);

	#
	@lst = LoadList("ps aux|grep $_[0]|grep -v pico|grep -v lynx|grep -v links|");

	#
	return $#lst;
}

#
sub UrlFix
{
	my ($url,$str);

	#
	$url = $_[0];
	if(NoTracking()) {
#		print "<LI>$url</LI>\n";
	}
	$str = "$ARTBASE\/";
	$url =~ s/^\/article\///;
	$url =~ s/^$str//;
	$url =~ s/^\/kaikki\/\.\.\///;
	$url =~ s/^kaikki\/\.\.\///;
	if(	$url=~/pub_artikkeli/
		||
		$url=~/[0-9]*\.[0-9]*\.txt$/)
	{
		$url =~ s/\.txt$/\.html/;
		$url =~ s/\/pub_artikkeli([0-9]+\.html)$/\/story-$1/;
#	if(NoTracking()) { print $url; }
	}
	if( !($url =~ /^\/[^\/]/) )
	{ 
		$url = "/$url"
	}
	return $url;
}

############################################################################
#
sub ViewCachePage
{
        my ($i,$i2,$str,@lst,$reu);

        #
#        print "Content-type: text/html\n\n";
        # Send error messages to the user, not system log
#        open(STDERR,'<&STDOUT');  $| = 1;

	#
	if($_[0] eq "")
	{
#		$reu = "index-finnish.html";
	}
	else
	{
		$reu = $_[0];
	}

        #
        @lst = LoadList("cache/$reu");

	#
	if($#lst<2)
	{
		print ("Redirection. $reu<BR>");
		print ("Please wait.<BR>
<meta http-equiv=\"refresh\" content=\"0; url=http://www.VAI.News/uutiset/\">
");
	}

        #
        for($i=0; $i<($#lst+1); $i++)
        {
                print "$lst[$i]\n";
        }
}

##########################################################
#
sub ParseOptions
{
        my ($i,$f,@ql,$quoteit,$tep,$author,$cap,@s);

	#
	$so{'imageurl'} = "";
	$so{'imageurl2'} = "";
	$so{'imageurl3'} = "";
	$so{'imageurl4'} = "";
	$so{'icap'} = "";

	#
	if( !(-e $_[0]) ) { return; }

        # Got image url!
        @iminfo = LoadList("$_[0]");
        if( !($iminfo[0]=~/\=/) ) { $so{'imageurl'} = $iminfo[0]; }

        #
        for($i=0; $i<($#iminfo+1); $i++)
        {
                if($iminfo[$i]=~/\=/)
                {
                        VarSet($iminfo[$i]);
                }
        }

        #
}

################################################################################################################
#
sub VideoSearchLinks
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,$str5,$str6,$bg,$width,@sp,$pl,$url,$cnt);
	my @items = (
		"All",
		"",
		"find.gif",

		"Saddam",	# TITLE
		"Iraq Saddam",  # KEYWORD 
		"find.gif",

		"Iran",	# TITLE
		"iran",  # KEYWORD 
		"find.gif",

		"Soviet",
		"soviet",
		"find.gif",

		"Russian",
		"russia",
		"find.gif",

		"DPRK",
		"dprk",
		"find.gif",

		"Korean",
		"korea",
		"find.gif",

		"German/DDR",
		"german ddr",
		"find.gif",

		"Funny",
		"funny",
		"find.gif",

		"Sexy",
		"",
		"find.gif",

		"Chinese",
		"china chinese",
		"find.gif",

		"Military",
		"tank mig army",
		"find.gif",

		"Karaoke",
		"karaoke",
		"find.gif",

		"Images",
		"http://www.VAI.News/imgbank.pl?l=en",
		"find.gif",

	#	"Music/MP3",
	#	"http://www.VAI.News/mp3machine.pl?l=en",
	#	"find.gif",

		);

		#
		$pl = 5;

                #
		$str = "";

		#
		$str = ("$str
<!--- START OF VIDEO BAR: --->
		<DIV>
		<TABLE cellpadding=0 cellspacing=0 width=100%
			bgcolor=#C00000
			height=32>
		<TR>
		<TD width=8%>
		<DIV align=center>
		<IMG SRC=\"$IMAGES_BASE/small_red_flag.gif\">
		</DIV>
		</TD>
		<TD width=92% valign=center>
		<DIV align=center>

<TABLE width=100% cellpadding=0 cellspacing=0>
");

	#
	$i2 = sprintf "%d", 800/($#items/3);

	#
	$pro = sprintf "%d", 75/($#items+1);

	#
	$width = 100;

	#
	for($i=0,$cnt=0; $i<$#items; $i+=3)
	{
		#
		if( ($cnt%$pl)==0 )
		{
			$str = ("$str<TR>");
		}

		$str2 = "";
		if($str2 eq "") { $str2 = $ARTCAP; }
		if($str2 eq "") { $str2 = $so{'q'}; }
		if($str2 eq "") { $str2 = $so{'article'}; }

		@splitti1 = split( /\:/, $items[$i+1] );
		@sp  = split(/\ /, $splitti1[0]);
		@sp2 = split(/\ /, $splitti1[1]);
		$bg = "#C00000";
		if($str2 ne "")
		{
			loop: for($i2=0; $i2<($#sp+1); $i2++)
			{
				$str3 = $sp[$i2];
				if($str2 =~ /$str3/i)
				{
					$bg = "#00C0C0";
					$str6 = "keyword_$items[$i+0]";
					$so{$str6}++;
					$hao++;
				}
				$str3 = $sp[$i2];
				if($str2 =~ /$str3/i)
				{
					$bg = "#00C0C0";
					$str6 = "keyword_$items[$i+0]";
					$so{$str6} = 0;
					$buhao++;
					last loop;
				}
			}
		}

		if($items[$i+1]=~/^http:\/\//)
		{
			$url = "$splitti1[0]";
		}
		else
		{
			$url = "/?q=$splitti1[0]&section=videos&FP_SECTION=finnish&maxts=80";
		}

		$str = ("$str
<TD width=$width bgcolor=$bg
	onMouseOver=\"this.className='td_over_black';\"
	onMouseOut=\"this.className='';\"
	onClick=\"window.location='$url';\"
	height=20>
<DIV ALIGN=CENTER>
<IMG src=\"$IMAGES_BASE/$items[$i+2]\" class=bulletin border=0>
<FONT size=2 face=Times Roman color=#F0F000>$items[$i+0]</FONT>
</DIV>
</TD>


			");

		#
		if( ($cnt%$pl)==($cnt-1) )
		{
			$str = ("$str</TR>");
		}

		#
		$cnt++;
	}

	#
	if( ($cnt%$pl)!=0 )
	{
		$str = ("$str</TR>");
	}

	#
	$str = ("$str
</TABLE>

		</DIV>
		</TD>


		</TR>
		</TABLE>
		</DIV>


<!--- END OF VIDEO BAR --->
");

	#
	return $str;
}

#########################################################################################
#
sub Googler
{
	my ($str);

	#
	$str = $_[0];
        $str =~ s/[��]/a/g;
        $str =~ s/[��]/o/g;
        $str =~ s/[^a-zA-Z0-9\ ]//g;
        $str =~ s/\ /\_/g;
        $str =~ s/^(.{20}).*$/$1/;
	return $str;
}

#########################################################################################
#
sub AutoDetermineImage
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$str2,@sp,@sp2,$cap);
	# Regard following words as important and redirect to correct target.
	my @important=(
		"putin:putin",
		"FUX:busheyes",
		"fox:busheyes",
		"army:usa",
		"bush:busheyes.jpg",
		"medicare:crbaby",
		"pentagon:usoutsm",
		"republican:bushads",
		"republicans:bushads",
		"gop:bushheil",
		"attack:explosion",
		"activist:demonstrators",
		"judge:justice",
		"judges:justice",
		"middle-class:money",
		"dvd:disc",
		"cd:disc",
		"celeron:computer",
		"cuba:cuba.jpg",
		"ecuador:ecuador",
		"ashcroft:ashcroft",
		"chavez:chavez.jpg",
		"oaxaca:oaxaca",
		"greek:greece",
		"denial:denial",
		"white house:white house",
		"elektroniikka:electronics",
		"tietoliikenne:computer",
		"t�it�:proletariat",
		"t�ihin:proletariat",
		"halpa:money2",
		"ammattilaisia:computer",
		"ohjelmistosuunnittelija:computer",
		"ohjelmistosuunnittelijoita:computer",
		"ohjelmoija:computer",
		"ohjelmoijia:computer",
		"myyntiassistentti:business",
		"rightard:bushheil",
		"rightards:bushheil",
		"dictatorship:bushheil",
		"nk:dprk2",
		"jobless:homeless",
		"iraq:iraqi",
		"clinton:billclinton",
		"marines:explosion",
		"911:wtc",
		"class:bushads",
		"Great Leader:bush",
		"McCain:bush",
		"mccain:bush",
		);
	# Ignore following words.
	my @igw=(
		"girl","girls","sex", "Great_wall", "george_michael",
		"jari", "communist", "communism",
		"being", "be", "are",
		"news",
		"himself", "flag",
		"on", "for", "ja", "it", "up",
		"and", "make", "tai",
		"or", "do", "vai", "to",
		"is", "not", "the", "an", "a", "the", "today", "east", "top",
		"with", "in", "again", "of", "kk","uk",
		"0", "00", "12", "td", "david", "pro", "family",
		"photo"
		);

	#
	if( keys %ikes <= 0 )
	{
		# Collect keywords from file names.
		@lst = LoadList("$ENV{'DOCUMENT_ROOT'}/images/cache/IMGcache.txt");

		#
		for($i=0; $i<($#lst+1); $i++)
		{
			$lst[$i] =~ s/^.*\/([^\/]*)$/$1/;
			$str = $lst[$i];
			$str =~ s/\.jpg$//;
			$str =~ tr/[A-Z���]/[a-z���]/;
			@sp = split(/[^0-9a-zA-Z������]/, $str);
			for($i2=0; $i2<($#sp+1); $i2++)
			{
				$str = $sp[$i2];
				# Search for words to ignore.
				loopz: for($i3=0,$i4=0; $i3<($#igw+1); $i3++)
				{
					if($str=~/^$igw[$i3]$/i) { $i4=1; last loopz; }
				}
				if(length($str)>1 && !$i4)
				{
					$ikes{$str} = $lst[$i];
				}
			}
		}
	}

	#
	$cap = $_[0];
	$cap =~ tr/[A-Z���]/[a-z���]/;
	@sp2 = split(/[^a-zA-Z0-9������]/, $cap);

	#
	for($i=0; $i<($#important+1); $i++)
	{
		@sp = split(/\:/, $important[$i]);
		for($i2=0; $i2<($#sp2+1); $i2++)
		{
			if($sp2[$i2] =~ /^$sp[0]$/i && $sp[1] ne "")
			{
				if($sp[1]=~/\.jp.g$/i) { return "$IMAGES_BASE/$sp[1]"; }
				@sp = ($sp[1]);
				goto past;
			}
		}
	}
 	# Split caption to string array.
	@sp = split(/[^a-z0-9���]/, $cap);
past:
	$i=0;

	#
	loop: for($i=0; $i<($#sp+1); $i++)
	{
		$str = $sp[$i];
		if($str ne "" && $sp[$i]=~/^[a-zA-Z������]+.*$/)
		{
			if( $ikes{$str}=~/\.jpg$/ )
			{
				if($ikes{$str}=~/kim/i)
				{
					if( !($cap=~/dprk/i) ) { goto past2; }
				}
				#print "$ikes{$str}\n";
				return "$IMAGES_BASE/$ikes{$str}";
past2:
			}
			else
			{
			}
		}
	}

	#
	return "";
}

#
# Google (Googlebot.com) / Yahoo (Inktomisearch.com)...
#
sub isRobot
{
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /yandex/i )
	{
		return 1;
	}
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /centiverse/i )
	{
		return 1;
	}
	#
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /amppari/i )
	{
		return 1;
	}
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /robot\.html/i )
	{
		return 1;
	}
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /Teoma/i )
	{
		return 1;
	}
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /ZyBorg/i )
	{
		return 1;
	}
	#
	if( $ENV{'HTTP_USER_AGENT'} =~ /HTTrack/i )
	{
		return 1;
	}
	if( $ENV{'HTTP_USER_AGENT'} =~ /crawler/i )
	{
		return 1;
	}
	if( $ENV{'HTTP_USER_AGENT'} =~ /spider/i )
	{
		return 1;
	}
	if( $ENV{'HTTP_USER_AGENT'} =~ /ia_archiver/i )
	{
		return 1;
	}
	if( $ENV{'HTTP_USER_AGENT'} =~ /msnbot\.htm/i )
	{
		return 1;
	}
	if( $ENV{'HTTP_USER_AGENT'} =~ /^msnbot\/[0-9]*\.[0-9]\s\(.*\)$/i )
	{
		return 1;
	}
	#if( $ENV{'REMOTE_HOST'}=~/^cache\-out.*\.inet\.fi$/ )	{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/^crawl/ )			{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/vunet\.org$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/vunet\.org.cn$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/coolpages.tk$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/searchme\.com$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/googlebot\.com$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/search\.live\.com$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/inktomisearch\.com$/ )	{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/\.yahoo\.net$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/\.scoutjet\.com$/ )		{ return 1; }
	if( $ENV{'REMOTE_HOST'}=~/\.search\.msnbot\.com$/ )		{ return 1; }

	#
	if( $ENV{'REMOTE_ADDR'} eq "168.144.28.208")		{ return 1; }

	#
	return 0;
}

#
sub Rot13URL
{
	my ($code1,$code2,$URL);

	#
	$URL = $_[0];
	$URL =~ s/pub_artikkeli/story-/;
	$URL =~ s/\.txt$/.html/;
	$URL =~ s/^[a-z]\///;
	$OURL  = $URL;
	$code1 = $URL;
	$code1 =~ s/^([a-z]*).*$/$1/;
	$code2 = $URL;
	$code2 =~ s/^.*\-([0-9\.]*)\..*$/$1/;

	#
	$code1 =~ y/A-J/0-9/;
	$code1 =~ y/a-z/n-za-m/;
	$code1 =~ y/0-45-9/5-90-4/;
	$code2 =~ y/0-45-9/5-90-4/;
	$code2 =~ y/0-9/A-J/;

	#
	$s = $_[0];
	$s =~ s/^([a-z]*)\/.*$/$1/;
	if($URL=~/[0-9]*\.[0-9]*\.html$/ || isAutoSection($s)==1)
	{
		$URL = "http://www.VAI.News/$URL";
	}
	else
	{
		$URL = "http://www.VAI.News/x$code1$code2";
	}

	#
	return $URL;
}

##################################################
#
# GetArticleTitleAndImageHTML
#
# Returns an array:
#
# 0: Title
# 1: Image HTML
#
sub GetArtTitleAndImageHTML
{
	my (@lst,$ii,$ii2,$IMG);

	#
	if(!-e $_[0])
	{
		#print "File not found: $_[0]<BR>\n";
		return;
	}

	#
	@lst = LoadList($_[0]);
	$optfn = ("$_[0]\_options.txt");
	$so{'imageurl'} = "";
	if(-e $optfn)
	{
		LoadVars($optfn)
	}

	#
	for($ii=0; $ii<($#lst+1); $ii++)
	{
		$lst[$ii] =~ s/<br>//gi;
	}

	#
	$IMG = "";
	if($so{'imageurl'} ne "")
	{
		$IMG = $so{'imageurl'};
		$IMG =~ s/^.*\/([^\/]+)$/$1/;
		$IMG = "$IMAGES_BASE/thumb2/th_$IMG";
		$IMG =~ s/\.[a-z]+$/.png/;
		$IMG = ("
<img src=\"$IMG\" border=0 align=middle>
		");
	}

	#
	return ("$IMG", "$lst[0]");
}


######################################################################
#
sub FixArFN
{
	my $arfn = $_[0];
	if( $ARTBASE ne "" && !($arfn =~ /^[\/]*$ARTBASE/) )
	{
		$arfn =~ s/^\/+//g;
		$arfn = "$ARTBASE/$arfn";
	}
	return $arfn;
}

######################################################################
#
# Returns a string containing the reconstructed URL built
# from the article path/file name.
#
sub NiceArticleURL
{
	my $nicearturl = $_[0];
#	$niceurl=~s/ä/a/gi;
#	$niceurl=~s/ö�a/gi;
#	$niceurl=~s/�å/a/gi;
	my $arfn = FixArFN($nicearturl);
	my @comb = GetArtTitleAndImageHTML($arfn);
	my $niceurl = CapUrl($nicearturl,$comb[1]);
	if($niceurl=~/^[^\/]/) {
		$niceurl = "/$niceurl"
	}
	## Not do not remove the remark in case of automated news sections like bush.
	$niceurl =~ s/\.txt$/\.html/;
	return $niceurl;
}

######################################################################
#
# Returns the specified (path/file name -specified) article title.
#
sub NiceArticleTitle
{
	my $arfn = FixArFN($_[0]);
	my @comb = GetArtTitleAndImageHTML($arfn);
	return $comb[1];
}

######################################################################
#
# Returns a string containing the reconstructed URL built
# from the article path/file name.
#
sub NiceArticleImageHTML
{
	my $arfn = FixArFN($_[0]);
	my @comb = GetArtTitleAndImageHTML($arfn);
	return $comb[0];
}

sub GetTop20FNs
{
	my $top20cachefn;
	if($ENV{'HTTP_HOST'} =~ /kultakaivos.info/) {
	        $top20cachefn = "cache/chart-gold-cache-86400-0.asc";
	} else {
	        $top20cachefn = "cache/chart-cache-86400-0.asc";
	}
	 if(-e $top20cachefn) {
                my @t20 = LoadList($top20cachefn);
		if($#t20 < 0 && NoTracking()) {
			print "<LI>Note for admin.: Error. Malfunction in GetTop20FNs.</LI>";
		}
                #die "test";
                for(my $i=0; $i<($#t20+1); $i++) {
                        $t20[$i] =~ s/$ARTBASE\/*//;
                        $t20[$i] =~ s/^([a-z]+)\/story\-([0-9]+)\.([a-z]+)$/$1\/pub_artikkeli$2.$3/;
                        $t20[$i] =~ s/\.html$/.txt/;
                        $t20[$i] =~ s/story\-([0-9]+)/pub_artikkeli$1/;
                        my @splitteri = split(/\s/, $t20[$i]);
                        if(NoTracking() && !$i) {
                                #print "<p>$splitteri[1]</p>\n";
                        }
                        $so{$splitteri[1]} = $splitteri[0];
                }
                #LoadVars($cachefn);
        }
}

###############################################################################
#
sub FixImageUrl
{
	$so{'imageurl'} =~ s/images\.vunet\.org/www.VAI.News\/images\//;
	$so{'imageurl'} =~ s/www\.vunet\.org\/images\//www.VAI.News\/images\//;
	$so{'imageurl2'} =~ s/images\.vunet\.org/www.VAI.News\/images\//;
	$so{'imageurl2'} =~ s/www\.vunet\.org\/images\//www.VAI.News\/images\//;
	$so2{'imageurl'} =~ s/images\.vunet\.org/www.VAI.News\/images\//;
	$so2{'imageurl'} =~ s/www\.vunet\.org\/images\//www.VAI.News\/images\//;
	$so2{'imageurl2'} =~ s/images\.vunet\.org/www.VAI.News\/images\//;
	$so2{'imageurl2'} =~ s/www\.vunet\.org\/images\//www.VAI.News\/images\//;
}

#
TRUE;

