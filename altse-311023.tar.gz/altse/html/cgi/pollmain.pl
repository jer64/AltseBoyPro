#!/usr/bin/perl
############################################################3
# pollmain.pl - VOTING CENTER
############################################################3

#
require "tools.pl";
require "modules/poll-cfg.pl";

#
$ENV{'CURSEC'} = "vote";
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
WebWalkTo("CHOOSE-TITLE1");
print("
<TITLE>Vaihtoehtouutiset - ��NESTYS</TITLE>
<meta name=\"keywords\" content=\"��nestys, ��ni, demokratia, kansanvalta, kansandemokratia, ��nest�, nyt, chat, online chat, online, chat, chatti, ch�tti\">
");
SkipTo("CHOOSE-TITLE2");

                        # Add main menu.
                        WebWalkTo("main-menu");
			print inc_menu($ENV{'CURSEC'}, "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

##################################################
sub CountPolls
{
	my $i,$i2,$i3,$i4;

	#
	loop: for($i=1; $i<10000; $i++)
	{
		if( open($f, "$VDB/poll$i\.form") )
		{
			close($f);
		}
		else
		{
			last loop;
		}
	}

	#
	return $i-1;
}

##################################################
#
sub RedMessage
{
		#
		print("
			<font color=\"#FF4020\">
			$_[0]<br>
			</font>
			<br>
			");
}

##################################################
#
sub SavePollForm
{
	my $i,$i2,$i3,$i4,$str,$str2,$f;

	#
	open($f, ">$_[0]") || die "CAN'T SAVE POLL FILE";
	loop: for($i=0; $i<1000; $i++)
	{
		$str2 = "form$i";
		$str = $so{$str2};
		if($str eq "") { last loop; }
		print $f "$str\n";
	}
	close($f);
}

##################################################
#
sub PerformCommand
{
	#
	if($so{'CMD'} eq "SAVE")
	{
		# Discard illegal polls.
		if($so{'form0'} eq "" || $so{'form1'} eq "" || $so{'form2'} eq "")
		{
			#
			RedMessage("Please verify your poll data.");
			RedMessage("The poll must have AT LEAST two possible answers and a question.");
		}
		else
		{
			#
			SavePollForm("$VDB/poll$so{'POLL'}\.form");

			#
			RedMessage("Poll Saved.");

			#
		        print("
		        <meta http-equiv=\"REFRESH\"
		        content=\"0;url=$SCRIPT_ADM\">
	                ");

		}
	}
}

##################################################
sub PollAdmMain
{
	my ($i,$i2,$i3,$i4);
	my @ads = (
		"Yhdyn Matti Nyk�sen kanssa seuraavassa lausahduksessa...",
		29,
		"Tarkkaileeko hallitus/isoveli sinua?",
		14,
		"Onko ulkoavaruudessa el�m��?",
		21,
		"Hyv�ksytk� musiikin, elokuvien tai tv-sarjojen ilmaisen lataamisen internetist�?",
		45,
		"Lukeeko isoveli s�hk�postisi?",
		17,
		);

	#
	if($ENV{'REMOTE_HOST'}=~/\.fi$/)
	{
		$PN = "Vunetin ��nestykset";
	}
	else
	{
		$PN = "VOTING CENTER";
	}

	#
	$cnt = CountPolls();

	#
	if($so{'CMD'} eq "")
	{
		#
		print("
			<div align=center>
			<font size=5>
			<b>
			$PN
			</b>
			</font>
			</div>
	
			<br>
			<B>Kuumat jutut...</B>
			");

		#
		for($i=0; $i<($#ads); $i+=2)
		{
			print("
<LI>
<A HREF=\"/poll.pl?POLL=$ads[$i+1]\">
<B>$ads[$i+0]</B>
</A>
</LI>
");
		}

		#
		if( NoTracking() )
		{
			print("
			<div align=right>
			<a href=\"$SCRIPT_ADM\">
			<font size=3>
			> edit polls
			</font>
			</a>
			</div>
			");
		}

		#
		print("
			<br>
			");

		#
		print("
			<div align=center>
			");

		#
		for($i=1; $i<($cnt+1); $i++)
		{
			#
			@poll = LoadList("$VDB/poll$i\.form");
	
			#
			print("
				<table width=300 cellpadding=0 cellspacing=0>
				<tr>

				<td width=90%>
				<li><a href=\"$SCRIPT?POLL=$i\" class=dark>$poll[0]</a></li>
				</td>
	
				<td width=10%>
				<font size=2>
				<a href=\"$SCRIPT?POLL=$i\">vote!</a>
				</font>
				</td>

				</tr>
				</table>

				<table width=300 cellpadding=0 cellspacing=0
					bgcolor=\"#000000\">
				<tr>
				<td>
				</td>
				</tr>
				</table>
	
				");
		}

		#
		print("
			</div>
			");
	}
}

##################################################
sub main
{
        #
        $DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	print ("
<TABLE cellspacing=0 cellpadding=4 width=800>
<TR valign=top>
<TD width=640>
	");

	#
	print ("
		<table cellpadding=32 cellspacing=0 width=550>
		<tr>
		<td>
		");

	#
	PollAdmMain();

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
	print ("
</TD>

<TD width=160>
<TABLE ALIGN=RIGHT>
<TR>
<TD>
<A HREF=\"/onlinechat.pl\">
<IMG SRC=\"/images/596952_yellow_dog_cute_with_tongue_out.jpg\" border=0>
HUOMAA ONLINE CHAT!
</A>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
	");

	#
}


