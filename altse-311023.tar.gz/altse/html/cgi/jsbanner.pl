#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

############################################################################################
#
sub Banner
{
	my @banners=(
	"avk-468x80-banneri.gif",
	"http://www.car-rent.fi",
	"tiedonantaja-468x80-banneri.gif",
	"http://www.tiedonantaja.fi",
	"kominform-468x80-banneri.gif",
	"http://www.kominf.pp.fi",
	"kulttuurivihkot-468x80-banneri.gif",
	"http://www.kulttuurivihkot.fi/",
	"mp3cd-468x80-banneri.gif",
	"http://www.huuto.net/fi/showitem.php3?itemid=30293323",
	"resistance.jpg",
	"http://www.albasrah.net/index.php"
		);
	my ($i,$i2,$i3,$i4);

	#
	srand(time);
	$i = sprintf "%d", rand()*(($#banners+1)/2);
	$i *= 2;

	#
	print("
document.write(\"<A HREF=\\\"http://www.vunet.world/?to=$banners[$i+1]\\\" target=\\\"_blank\\\"> \");
document.write(\"<IMG src=\\\"$IMAGES_BASE/$banners[$i+0]\\\"> \");
document.write(\"</A> \");
	");
}

############################################################################################
#
sub main
{
	#
	Banner();
}


