#!/usr/bin/perl
################################################################################################################
# quickbar.pl
#
# Link bar on top of all Vunet.org -pages.
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2);

	#
	$str = ("
		<table cellpadding=0 cellspacing=4 width=100% border=0>
		<tr align=top>

		<td>
		<div align=right>
		<form action=\"http://www.vunet.world/saa.pl\" class=formx target=_blank>
		<font size=2 color=#000000>
		S��tiedot:
		<select name=q onChange='Javascript:this.form.submit()' class=saa>
		<option name= selected>Kaupunki ...</option>
		<option name=Jyv�skyl�>Jyv�skyl�</option>
		<option name=Turku>Turku</option>
		<option name=Tampere>Tampere</option>
		<option name=Lappeenranta>Lappeenranta</option>
		<option name=Kuopio>Kuopio</option>
		<option name=Oulu>Oulu</option>
		<option name=Pori>Pori</option>
		<option name=Helsinki >Helsinki</option>
		<option name=Vantaa >Vantaa</option>
		</select>
		</font>
		</form>
		</div>
		</td>

		</tr>
		</table>
	");

        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

        #
        print(" document.write(\"$str\"); \n");

	#
}


