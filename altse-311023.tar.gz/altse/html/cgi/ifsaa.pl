#!/usr/bin/perl
###############################################################################
# Weather Forecast Viewer.
###############################################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "saa";

# Interval for fetching a new weather data.
$MAX_DATA_AGE = (60*5);

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

##################################################
#
sub HaeSaa
{
	my (@lst,$i,$i2,$str,$fn,$f);

	#
	$fn = "cfg/weather_$_[0].txt";

	#
	if( !(-e $fn) || FileAge($fn)>$MAX_DATA_AGE )
	{
		# FETCH NEW DATA.
		@lst = LoadList("lynx -dump \"http://www.fmi.fi/saa/paikalli.html?kunta=$so{'q'}\"|");
		# SAVE CACHE.
		open($f, ">$fn") || die "can't write $fn!";
		for($i=0; $i<($#lst+1); $i++)
		{
			print $f "$lst[$i]\n";
		}
		close($f);
	}
	else
	{
##		print "Cached result $fn.<br>\n";
		@lst = LoadList($fn);
	}

	#
	return @lst;
}

##################################################
#
sub SaaTiedot
{
	my (@lst,$i,$i2,$str,$str2,$c,$c1,$c2,$c3,$c4,$celcius,
		$x,$y,$z,$p);
	my @paikat = (
		"Jyv�skyl�",
		"Turku",
		"Tampere",
		"Lappeenranta",
		"Kuopio",
		"Oulu",
		"Pori",
		"Helsinki",
		"Joensuu",
		"Rovaniemi",
		"Kajaani",
		"Kotka",
		"Tornio",
		"Mikkeli",
		"Lahti",
		"Ivalo",
		"Vantaa",
		"Kokkola",	
		"Vaasa"
		);

	#
	@paikat = sort @paikat;

	#
	if($so{'q'} eq "")
	{
		$so{'q'} = "Jyv�skyl�";
	}

	#
	$so{'q'} =~ s/[^a-z���A-Z���]//g;

	#
	@lst = HaeSaa($so{'q'});

	# Fix the ASCII text.
	for($x=0; $x<($#lst+1); $x++)
	{
		$lst[$x] =~ s/^\[.*$//g;
	}

	#
	loop1: for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i]=~/5 vuorokauden ennuste/) { last loop1; }
	}
	
	######################################################################
	#
	# View weather information.
	#

	#
	# 0 Jyv�skyl� 5 vuorokauden ennuste
	# 1 Jyv�skyl� 5 vrk:n ennuste s��merkein
	# 2 Havaintoasema: Jyv�skyl� lentoasema / Tikkakoski
	# 3 Tuorein havainto: 08.07.2005 16:00
	# 4 l�mp�tila 23,4 �C paine 1019,3 hPa kosteus 29 % tyynt� 0,0 m/s
	# 5 pilvisyys 0/8

	#
	$str = $lst[$i+4];
	$str =~ s/^(.*) paine.*$/$1/i;
	$celcius = $str;
	$celcius =~ s/^(\S*)\s(\S*)\s(\S*)$/$2/;
	$celcius =~ s/\,/\./g;
	$str =~ s/^(\S*)\s(\S*)\s(\S*)$/$1 <b>$2<\/b> $3/;

	#
	if($celcius<0) { $c="#0000FF"; }
	if($celcius>0) { $c="#00FF00"; }
	if($celcius>16) { $c="#FFC000"; }
	if($celcius>20) { $c="#C00000"; }
	if($celcius>24) { $c="#FF0000"; }

	#
	$lst[$i+0] =~ s/\s*5 vuorokauden ennuste//;

	#
	$p = "";

	#
	$CAP = "$so{'q'} - $lst[$i+4]";

	#
	$p = ("$p
		<center><font size=6>
		<b><a href=\"http://www.vunet.world/search.pl?q=$so{'q'}&cmd=go\" class=dark>$lst[$i+0]</a></b>
		</font><br>
		<font size=5 color=$c>$str</font>
		</center><br>
		");

	#
	$p = ("
		<div align=center>
		<form action=/ifsaa.pl name=FORMSAA>
		Valitse kaupunki:
		<select name=q onChange='this.form.submit()'>$p");
	for($x=0; $x<($#paikat+1); $x++)
	{
		if($paikat[$x] eq $so{'q'}) { $z="selected"; }
		else { $z=""; }
		$p = ("$p
		<option name=$paikat[$x] $z>$paikat[$x]</option>
			");
	}
	$p = ("$p
		</select>
		</form>
		</div>
		");

	#
	$lst[$i+2] =~ s/^(\S*:)(.*)$/<b>$1<\/b>$2/;
	$lst[$i+3] =~ s/^(\S* \S*:)(.*)$/<b>$1<\/b>$2/;

	#
	$p = ("$p
		$lst[$i+2]<br>
		$lst[$i+3]<br>
		$lst[$i+4]<br>
		$lst[$i+5]<br>
		<br>
		� Ilmatieteen laitos

		<br><br>
		<br><br>
		<br><br>
		");

	#
	return $p;
}


########################################################################
#
sub main
{
	my ($saa);

	#
	ArgLineParse();

	#
	$saa = SaaTiedot();

	#
	print("
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">

		<table width=100% cellpadding=32 cellspacing=0>
		<tr valign=top>
		<td width=80%>
$saa
		");

	#
	print("
		</td>

		<td>
<br><br><br><br>
		</td>
		</tr>
		</table>");

	#
}


