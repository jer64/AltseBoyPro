#!/usr/bin/perl
####################################################
#
# Article Publishing Form
#
# See publish.pl for the actual practical
# publishing script.
#
####################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "julkaise";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
if(!NoTracking())
{
#	print "Access denied.";
#	return;
}

#
OpenWebIndex("./webindex2.html");
#
WebWalkTo("CHOOSE-TITLE1");
print("
<TITLE>Artikkelin Julkaisu</TITLE>
");
WebWalkTo("CHOOSE-TITLE2");
# Add main menu.
WebWalkTo("main-menu");
print inc_menu("julkaise", $so{'FP_SECTION'});
WebWalkTo("enterhere_section");
if( NoTracking() )
{
	@osastot = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/seclst.txt");

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=32>
<TR>
<TD>

<IMG SRC=\"$IMAGES_BASE/julkaisu.jpg\">

<FORM action=/cgi/publish.pl method=post>
<textarea name=\"article_content\" cols=\"80\" rows=\"20\" id=ta></textarea>
<br>
osasto:
<select name=\"osasto\">
		");

	#
	for($i2=0; $i2<($#osastot+1); $i2++)
	{
		#
		print "<option>$osastot[$i2]</option>\r\n";
	}
	#
	print("
</select>
<BR>

<input name=\"info\" value=\"archivei43538453\"
type=\"checkbox\">sijoita artikkeli
uutisjonon loppuun
(k�ytet��n <b>vain</b> vanhojen artikkeleiden
tallentamisessa)<br>

<input name=\"IS_HTML\" type=\"checkbox\">raksaa jos artikkeli on t�ysin HTML -muodossa
(ei suositella)

<br>
<a href=\"/cgi/admin/importnews.pl\">> Tuo uutisia KOMINFORMista</a><br>

<br>
<input value=\"Julkaise\" type=\"submit\">
		");

	#
	print("
</FORM>

</TD>
</TR>
</TABLE>

<SCRIPT LANGUAGE=\"Javascript\">
document.getElementById('ta').focus();
</SCRIPT>
		");
}
else
{
	@txt = LoadList("julkaisu_noadmin.txt");
	for($i=0; $i<($#txt+1); $i++) { print "$txt[$i]\r\n"; }
}
HandleRest();
print EndBar();
