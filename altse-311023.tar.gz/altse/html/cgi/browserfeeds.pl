#!/usr/bin/perl
#
# 404 ERROR HANDLER
#

#
require "./tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$so{'FP_SECTION'} = "finnish";
$so{'cursec'} = "browserfeeds";
OpenWebIndex("./webindex2.html");
#
WebWalkTo("CHOOSE-TITLE1");
#
print("
<TITLE>Vaihtoehtouutiset.info - browser feeds - selaimen sy�tteet - tilaa uutiset selaimeesi</TITLE>
");
SkipTo("CHOOSE-TITLE2");

# Add main menu.
WebWalkTo("main-menu");
print inc_menu("browserfeeds", "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
#
sub main
{
	#
	print("
	<TABLE cellspacing=0 cellpadding=16 border=0 width=100%>
	<TR>
	<TD>
		");

	#
	print("
	<TABLE cellspacing=0 cellpadding=16 border=0 width=550 valign=\"top\">
	<TR valign=\"top\">
		");

	#
	print("
	<TD width=50%>

	<P><U><B>Tilaa uutiset selaimeesi (perusosastot)
	</B></U></P>
	");
	ShowStandardBrowserFeeds();

	#
	print("
	</TD>
		");
	#
	print("
	<TD width=50%>

	<P><U><B>Tilaa uutiset selaimeesi (r��t�l�idyt osastot)
	</B></U></P>
	");
	ShowCustomizedBrowserFeeds();

	#
	print("
	</TD>
		");

	#
	print("
	</TR>
	</TABLE>
	");


	#
	print("
	</TD>
	</TR>
	</TABLE>
	");
}

##################################################
#
sub ShowCustomizedBrowserFeeds
{
	my ($i,$i2,$i3,$i4,@lst,$str);

	#
	my $fn = ("filelist_*.txt");
	$pathi = ("$ENV{'DOCUMENT_ROOT'}/cache/rss");
	@lst = LoadList("find \"$pathi\" -maxdepth 1 -name \"$fn\" -type f|");
	@lst = sort @lst;

	#
	my $html_content;
	for($i=0; $i<($#lst+1); $i++) {
		my $friendly_name = $lst[$i];
		$friendly_name =~ s/^$pathi\///;
		$friendly_name =~ s/filelist\_//;
		$friendly_name =~ s/\.txt$//;
		$friendly_name_2 = $friendly_name;
		$friendly_name =~ tr/[a-z���]/[A-Z���]/;
                my $FEED_ICON_HTML = ("
<IMG SRC=\"/images/icons2/rss_feed_icon_16x16.gif\" border=0 align=\"middle\">
");
		my $html_item = ("
                <a href=\"/rss/?sec=\_$friendly_name_2\" class=news5>
                <font size=\"2\">$FEED_ICON_HTML $friendly_name </font> </a><BR>
			");

		$html_content .= $html_item;
	}

	#
	print $html_content;

	#
}


##################################################
#
sub ShowStandardBrowserFeeds
{
	my ($i,$i2,$i3,$i4,@lst,$str);

	#
        @lst = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/seclst.txt");
	@lst = sort @lst;
	#$pathi = ("$ENV{'DOCUMENT_ROOT'}/cache/rss");

	#
	my $html_content;
	for($i=0; $i<($#lst+1); $i++) {
		my $friendly_name = $lst[$i];
		$friendly_name = $lst[$i];
		$friendly_name_2 = $friendly_name;
		$friendly_name =~ tr/[a-z���]/[A-Z���]/;
                my $FEED_ICON_HTML = ("
<IMG SRC=\"/images/icons2/rss_feed_icon_16x16.gif\" border=0 align=\"middle\">
");
		my $html_item = ("
                <a href=\"/rss.pl?sec=$friendly_name_2\" class=news5>
                <font size=\"2\">$FEED_ICON_HTML $friendly_name </font> </a><BR>
			");

		$html_content .= $html_item;
	}

	#
	print $html_content;

	#
}

