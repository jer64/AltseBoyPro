#!/usr/bin/perl
#
main();

sub main()
{
 # ** <html> BEGINNING & HEADER
 print ("Content-type: text/html\n\n

      <html>
       <head>
        <title></title>
       </head>
       ");


 # open body
 print ("
        <body bgcolor=\"FF0000\"
               text=\"#FFFFFF\"
               link=\"#FFFFFF\"
              alink=\"#FFFFFF\"
              vlink=\"#FFFFFF\"
             topmargin=\"0\"
            leftmargin=\"0\">\n
        ");




 #
 print "<table width=\"600\" bgcolor=\"FF2020\" cellpadding=\"8\">";
 print " <tr>";
 print "  <td width=\"112\" background=\"../icons/bar2.gif\">\n";
 print "  </td>\n";
 print "  <td width=\"550\">";

 #
 $aika = localtime;
 printf "<center><br><img src=\"../icons/servericon.gif\"><br>\n";
 printf "<h2><strong>Server Status</strong></h2>\n";
 printf "<strong><a href=\"http://$ENV{'SERVER_NAME'}:$ENV{'SERVER_PORT'}\">http://$ENV{'SERVER_NAME'}:$ENV{'SERVER_PORT'}</a> - %s</strong></center>\n",$aika;
 #
 printf ("
           <br>

           You are using <i>$ENV{'HTTP_USER_AGENT'}</i><br>\n
           Your IP address is <i>$ENV{'REMOTE_ADDR'}</i>
           <a href=\"http://$ENV{'REMOTE_ADDR'}\">HTTP</a> 
           <a href=\"ftp://$ENV{'REMOTE_ADDR'}\">FTP</a>
           <br>\n

           <br>

           This script is <i>$ENV{'SCRIPT_NAME'}</i><br>\n
           This server is using port <i>$ENV{'SERVER_PORT'}</i> to provide a HTTP access<br>
           Server Protocol: <i>$ENV{'SERVER_PROTOCOL'}</i><br>\n
           Gateway Interface: <i>$ENV{'GATEWAY_INTERFACE'}</i><br>\n
           I am running under <i>$ENV{'SERVER_SOFTWARE'}</i><br>\n

           <br>
        ");

 print "<pre>\n";
 system "ls -la";
 print "</pre>\n";

 print ("
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br>\n
 ");

 #
 print "  </td>";
 print " </tr>";
 print "</table>";



 # close body
 print "</body>\n";



 # ** end of html
 print ("
      </html>\n
       ");
}
