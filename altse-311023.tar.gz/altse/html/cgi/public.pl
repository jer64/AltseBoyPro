#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();

#####################################################################################
#
sub main
{
	#
	print("
		<meta http-equiv=\"refresh\" content=\"0; url=http://kim-jong-il.vunet.world$ENV{'REQUEST_URI'}\">
		");

	#
}
