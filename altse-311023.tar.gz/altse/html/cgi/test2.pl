#!/usr/bin/perl
$num = rand(100000000000000);
$num =~ s/\.//;
$tm = time;
return "$tm$num$num2.tmp";
