#!/bin/bash
#
rm -rf  /home/vai/db/frontpages
rm -rf  /home/vai/db/frontpages2
rm -rf  /home/vai/db/frontpages3
rm -rf  /home/vai/db/frontpages4
rm -rf  /home/vai/db/frontpages5
rm -rf  /home/vai/db/frontpages6
rm -rf  /home/vai/db/frontpages7
rm -rf  /home/vai/db/frontpages8
rm -rf  /home/vai/db/frontpages9
rm -rf  /home/vai/db/frontpages10
rm -rf  /home/vai/db/frontpages_ftp
rm -rf  /home/vai/db/frontpages_adult
rm -rf  /home/vai/db/frontpages_dprk
rm -rf  /home/vai/db/frontpages_music
rm -rf  /home/vai/db/frontpages_china
rm -rf  /home/vai/db/frontpages_uk
rm -rf  /home/vai/db/frontpages_itjobs

