#!/bin/bash
echo "Deleting all core dumps (core.*) ..."
cd ~; find . -name 'core.*' -type f|xargs rm -f
