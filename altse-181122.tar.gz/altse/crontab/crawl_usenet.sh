#!/bin/bash
echo "Crawling news from usenet for Vunet ..."
sleep 4
cd /home/vai/public_html/articles/global
gather.pl
cd /home/vai/public_html/articles/progressive
gather.pl
cd /home/vai/public_html/articles/democrats
gather.pl
echo "Finished crawling news for Vunet from usenet ..."

