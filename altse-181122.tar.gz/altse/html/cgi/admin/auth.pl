#!/usr/bin/perl
##############################################################
#
# News Center Administration Center
#
##############################################################
#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "modules/auth.pm";
require "modules/ArgLineParse.pm";
require "modules/Language.pm";
require "modules/CookieTools.pm";
require "modules/LoadList.pm";

#
if($ENV{'SCRIPT_URI'}=~/http:\/\//)
{
#	Redirection("https://www.vunet.org/admin/center.pl");
#	exit;
}

#
$ENV{'CURSEC'} = "hallinto";

#
print("
<META NAME=\"robots\" CONTENT=\"nofollow\">
");

#
main();

##############################################################
sub ViewActionsScript
{
	my ($i,$i2,$str,$str2,@lst,@sp);

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst); $i+=2)
	{
		#
		if($lst[$i]=~/^\-\ /) { $i++; goto pasto; } 
		@sp = split(":", $lst[$i]);
		$lst[$i+1] =~ s/^\@//;
		print("
<a href=\"$lst[$i+1]\" class=news3>
> $sp[0]<br>
</a>
");
pasto:
	}
}

##############################################################
sub ViewMailingListSettings
{
	my $i,$i2,$i3,$i4;

	#
	open(f, "../mail.lst") || die "mail.lst not found";
	@lst = <f>;
	close(f);
	for($i=0; $i<($#lst+1); $i++)
	{
		chomp $lst[$i];
	}

	#
	print "<br>\n";

	#
	print "(VANHA LISTA) Vaihtoehtouutiset-postituslista sis�lt�� seuraavat osoitteet:<br>";

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		print "<li>$lst[$i]</li>\n";
	}
}

#		<a href=\"http://vunet.org:10000\">
#		> server administration
#		</a><br>

#		<a href=\"/al.pl\">
#		> add new agency site
#		</a>
#		<br>
#		<a href=\"/links.pl\">
#		> view agency links
#		</a>

#
sub Tools
{
	print("
		<br>
		<b>Tools</b><br>

		<a href=\"/publish\" class=news3>
		> publish a new article
		</a><br>
		<a href=\"http://lista.vunet.org/\" class=news3>
		> mailing lists
		</a><br>
		<br>


		<a href=\"/admin/logview.pl&MAGIC=32785782378523758\" class=news3>
		> what are readers reading right now?
		</a><br>
		<a href=\"/awstats/awstats.pl?config=www.vunet.org\" class=news3>
		> visitor statistics
		</a><br>

		<br>

		");
}

##############################################################
sub Redirection
{
	#
	print("
<meta http-equiv=\"REFRESH\"
	content=\"0;url=$_[0]\">
	");
}

#
sub TABLE
{
	#
	if($_[0]==0)
	{
	print("
		<table cellpadding=4 cellspacing=0 bgcolor=\"#E0E0FF\" width=100%>
		<tr valign=top>
		<td>
		");
	}
	if($_[0]==1)
	{
	print("
		</td>
		</tr>
		</table>
		");
	}
}

##############################################################
#
sub UserEditor
{
	########################################################
	#
	TABLE(0);
	#
	print("
		User: $ENV{'REMOTE_USER'}
		");
	#
	TABLE(1);

	########################################################
	#
	print("
		<form action=\"center.pl\">

		First name: <input type=\"text\" name=\"USR_FNAME\" value=\"$so{'USR_FNAME'}\"><br>
		Last name: <input type=\"text\" name=\"USR_LNAME\" value=\"$so{'USR_LNAME'}\"><br>
		E-mail: <input type=\"text\" name=\"USR_EMAIL\" value=\"$so{'USR_EMAIL'}\"><br>

		<input type=\"submit\" value=\"Save\"><br>
		");
	#
	
	########################################################
	#
	print("
		</form>
		");
}

##############################################################
#
sub main
{
	# Load configuration & parse args.
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	CookieTools();
	#
	AddAdmin();
	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
//
AdminRegistration(1);
//
function AdminRegistration(days)
{
	var date = new Date();
	date.setTime(date.getTime()+(days*24*60*60*1000));
	setCookie(\"vunetadmin\", 'true', date.toGMTString(), '/', '');
}
</SCRIPT>
		");

	#
	if($so{'redirect'})
	{
		print("
		");
		Redirection("../_tmpjulkaisu.pl");
		exit();
	}

        #
        $cmd = $ENV{'QUERY_STRING'};
        $cmd =~ s/\+/ /ig;
        $cmd =~ s/%(..)/pack("C", hex($1))/eg;
        @vars = split("\&", $cmd);
	$userid = GetUserID();
        for($i=0; $i<($#vars+1); $i++)
        {
                @tmp = split("\=", $vars[$i]);
                if($tmp[0] eq "VIEW_USER_COUNT")
                {
			$VIEW_USER_COUNT = 1;
                }
	}

	#
	if($userid ne "")
	{
		#
		gotUserFile($userid);
	}

	###############################################################################
	#
	print("
		<table cellpadding=1 cellspacing=0 width=100% bgcolor=\"#FFFFFF\">
		<tr valign=top>
		<td>

		<table cellpadding=0 cellspacing=0 width=98>
		<tr valign=top>
		<td>

		<br>
		<div align=center>
		Disclaimer: Staff only.
		</div>
		<br>
		");

	#
	

	###############################################################################
	#
	print("
		<table cellpadding=16 cellspacing=0 width=100% valign=center>
		<tr valign=top>

		<td bgcolor=\"#FFF0F0\">
		$LOGIN_FORM_HTML
		</td>

		</tr>
		</table>
		");

	#
#	ViewMailingListSettings();

	###############################################################################
	#
	print("
		</td>
		</tr>
		</table>

		</td>
		</tr>
		</table>
		");

}


