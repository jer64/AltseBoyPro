#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();

#####################################################################################
#
sub EnvList
{
	foreach $key (sort(keys %ENV))
	{	
		print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
	}
}

#####################################################################################
#
sub main
{
	#
	EnvList();
}
