######################################################################
# Load a list into array.
#
sub LoadList
{
        my ($_f,@_ulst,$ich,$ich2,$str);

        #
        if( !open($_f, $_[0]) )
	{
		#$str = "Can't open $_[0]";
	       # $str =~ s/(.{8})/$1 /g;
		#print("<fontsize=2 color=\"#000000\">$str</font>\n");
		return;
	}
	flock $_f, LOCK_EX;
        @_ulst = <$_f>;
	flock $_f, LOCK_UN;
        close($_f);

        #
        for($ich=0; $ich<($#_ulst+1); $ich++)
        {
                chomp $_ulst[$ich];
		$_ulst[$ich] =~ s/\s*$//g;
		$_ulst[$ich] =~ s/^\s*//g;
        }

        #
        return @_ulst;
}

1;