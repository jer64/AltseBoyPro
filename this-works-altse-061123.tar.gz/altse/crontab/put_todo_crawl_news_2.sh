#!/bin/bash

# FTP Search (FTP sites)
echo "[Crawling] Crawling FTP sites ..."
cd /home/vai/db/www
screen -d -m crawl  http://ftp.sunet.se/pub/  -f 
screen -d -m crawl  http://ftp.funet.fi/pub/  -f 
screen -d -m crawl  http://ftp.urc.ac.ru/pub/  -f 
screen -d -m crawl  http://vvstepa.wheelnt.ru/FTP_root/  -f 
screen -d -m crawl  http://ftp.mozilla.org/pub/  -f 
screen -d -m crawl  http://download.videolan.org/pub/  -f 
screen -d -m crawl  http://pirxnet.pl/ftp/  -f 

# ADULT Search (Adult sites)
echo "[Crawling] Crawling Adult sites ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.adultwork.com/Default.asp?TargetURL=%2FHome%2Easp%3F  -f 
screen -d -m crawl  http://www.redtube.com/Default.asp?TargetURL=%2FHome%2Easp%3F  -f 
screen -d -m crawl  http://www.redtube.com/redtube/asian  -f 
screen -d -m crawl  http://www.pichunter.com/Default.asp?TargetURL=%2FHome%2Easp%3F  -f 
screen -d -m crawl  http://japandesire.com/  -f 
screen -d -m crawl  http://www.jjgirls.com/avgirls/63  -f 
screen -d -m crawl  http://www.gojapango.com/japanese_friends/japanese_girls/index.php -f 
screen -d -m crawl  http://beautyjpgirls.com/  -f 
screen -d -m crawl  http://jpdesire.com/  -f 
screen -d -m crawl  http://jpgravure.com/  -f 
screen -d -m crawl  http://www.ebaumsworld.com/pictures/view/80797832/  -f 
screen -d -m crawl  http://www.nudejapanesebeauties.com/  -f 
screen -d -m crawl  http://www.bravoteens.com/pics/japanese.shtml  -f 
screen -d -m crawl  http://www.samporn.com/category/Japanese Girls/  -f 
screen -d -m crawl  http://coed.com/2009/10/26/the-15-most-beautifully-busty-japanese-babes/  -f 
screen -d -m crawl  http://www.allgravuremodels.com/  -f 
screen -d -m crawl  http://www.myjapanesegirls.com/  -f 
screen -d -m crawl  http://www.hq69.com/?cat=19  -f 
screen -d -m crawl  http://cuteasianbabes.com/  -f 
screen -d -m crawl  http://www.redtube.com/466405  -f 
screen -d -m crawl  http://www.topsexygirl.tk/category/japanese-girl  -f 
screen -d -m crawl  http://www.pinterest.com/pin/297870962824941986/  -f 
screen -d -m crawl  http://jpidols69.com/  -f 
screen -d -m crawl  http://www.eastbabes.com/  -f 
screen -d -m crawl  http://onsenude.tumblr.com/  -f 
screen -d -m crawl  http://asianbestpics.com/  -f 
screen -d -m crawl  http://japanese-desire.com/  -f 
screen -d -m crawl  http://girls.gunaxin.com/14-incredibly-hot-japanese-women-youve-never-heard-of/28188  -f 
screen -d -m crawl  http://allnudeasians.com/  -f 
screen -d -m crawl  http://www.sexyasianbeauties.com/  -f 
screen -d -m crawl  http://izismile.com/2012/10/23/japanese_women_do_cosplay_best_53_pics.html  -f 



# ADULT Search (Adult sites)
echo "[Crawling] DPRK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.korea-dpr.com/  -f 
screen -d -m crawl http://www.kcna.co.jp/  -f 
screen -d -m crawl http://www.kp.undp.org/content/dprk/en/home/  -f 
screen -d -m crawl http://www.kp.undp.org/dprk/en/home.html  -f 
screen -d -m crawl http://www.koryogroup.com/  -f 
screen -d -m crawl http://www.youtube.com/user/stimmekoreas  -f 
screen -d -m crawl http://www.youtube.com/user/soffkj4y  -f 



# MUSIC Search (Music sites)
echo "[Crawling] Music ..."
cd /home/vai/db/www
screen -d -m crawl http://www.youtube.com/watch?v=GLv7eC_HZ0M&list=PL4B7518B6434C9639  -f 
screen -d -m crawl http://www.youtube.com/watch?v=nJ7wei17HI0&list=RD1bXtgIokvhI  -f 



# CHINA Search (China sites)
echo "[Crawling] News from China ..."
cd /home/vai/db/www
screen -d -m crawl http://www.shenzhen-standard.com/  -f 
screen -d -m crawl http://www.chinadaily.com.cn/china/  -f 
screen -d -m crawl http://www.china.org.cn/  -f 
screen -d -m crawl http://www.xinhuanet.com/english/china/  -f 
screen -d -m crawl http://www.sznews.com/english/  -f 
screen -d -m crawl http://europe.chinadaily.com.cn/  -f 



# News from UK
echo "[Crawling] News from UK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.bbc.co.uk/news/  -f 
screen -d -m crawl http://www.dailymail.co.uk/news/index.htm  -f 
screen -d -m crawl http://www.theguardian.com/uk-news  -f 
screen -d -m crawl http://www.telegraph.co.uk/news/uknews/  -f 
screen -d -m crawl http://www.express.co.uk/news/uk  -f 
screen -d -m crawl http://www.independent.co.uk/  -f 
screen -d -m crawl http://www.thesundaytimes.co.uk/sto/?CMP=INTstp2  -f 
screen -d -m crawl http://metro.co.uk/news/  -f 
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/  -f 
screen -d -m crawl http://www.mirror.co.uk/news/uk-news/  -f 
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/  -f 
screen -d -m crawl http://www.huffingtonpost.co.uk/  -f 
screen -d -m crawl http://news.sky.com/uk  -f 
screen -d -m crawl http://www.britishnewspaperarchive.co.uk/  -f 
screen -d -m crawl http://topics.nytimes.com/top/news/international/countriesandterritories/unitedkingdom/  -f 
screen -d -m crawl http://www.youtube.com/user/BritishForcesNews  -f 



# IT jobs Search (IT jobs sites)
echo "[Crawling] News from IT jobs ..."
cd /home/vai/db/www
screen -d -m crawl "http://jobsearch.monster.com/search/?q=Information-Technology-__26-Information-Systems"  -f 
screen -d -m crawl "http://www.careerbuilder.com/"  -f 
screen -d -m crawl "http://www.linkedin.com/job/q-information-technology-jobs"  -f 
screen -d -m crawl "http://www.eurojobs.com/en/candidate/job.html?search%5Bkeyword%5D=information+technology&search%5Bsector%5D=&search%5Bcountry%5D="  -f 
screen -d -m crawl "http://www.workinfinland.com/"  -f 
screen -d -m crawl "http://jobs.telegraph.co.uk/searchjobs/?Keywords=information+technology&location="  -f 
screen -d -m crawl "http://www.prospects.ac.uk/graduate_job_search_results.htm"  -f 
screen -d -m crawl "http://www.ic-software.com/c-jobs"  -f 



#
echo "[Crawling] Crawling some other websites ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.svu.fi/kilpailut/  -f 



#
#WaitUntilCrawlsStop.pl
#

#
#cd /home/vai/db/www
#find . -name 'links.txt'|xargs rm -f

#

