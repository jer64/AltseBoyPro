#!/bin/bash
cd /home/vai/altse/crontab
#
export HTTP_PROXY=
#
PATH=$PATH:/home/vai/altse/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# No more termination of crawl processes, may interrupt downloads elsewhere.
# First let's take care of the processes we should not be running ...
#echo "First let's take care of the processes we should not be running ..."
##killall crawl
##sleep 30
#killall -9 crawl

#
mkdir -p /home/vai/db/www

# * LOCAL VAIHTOEHTOUUTISET & KULTAKAIVOS FRONT PAGE UPDATE
cd /home/vai/db/www

#echo "[Removing unnecessary files] Locating links.txt files and removing ..."
#find . -name 'links.txt'|xargs rm -f

# XVII. Waiting until Finnish news are crawled. Memory usage up to 1 Gb using ReiserFS (takes lots of cache here apparently.)
#WaitUntilCrawlsStop.pl
##killall crawl

echo "[Crawling] Crawling Finnish websites ..."
# FINNISH NEWS
cd /home/vai/db/www
screen -d -m crawl http://finnish.ruvr.ru/    
screen -d -m crawl http://www.rusgate.fi/    
screen -d -m crawl http://yle.fi/uutiset/venajan_verkossa/    
screen -d -m crawl http://maailma.net/uutiset/eurooppa/itaeurooppa/venaja    
screen -d -m crawl http://www.finrusresearch.fi/    
screen -d -m crawl http://www.tvnewsradio.com/tv/tv-kanavat-venaja.htm    
screen -d -m crawl http://www.suomenmaa.fi/    
screen -d -m crawl http://www.forssanlehti.fi/    
screen -d -m crawl http://www.pietarsaarensanomat.fi/    
screen -d -m crawl http://www.iijokiseutu.fi/    
screen -d -m crawl http://www.kansanuutiset.fi/    
screen -d -m crawl http://www.kansanaani.fi/    
screen -d -m crawl http://www.kansantahto.fi/    
screen -d -m crawl http://www.demari.fi/    
screen -d -m crawl http://www.koillissanomat.fi/    
screen -d -m crawl http://www.rantalakeus.fi/    
screen -d -m crawl http://www.uusiaika-lehti.fi/    
screen -d -m crawl http://www.kotiseudunsanomat.fi/    
screen -d -m crawl http://www.sisis.fi/    
screen -d -m crawl http://www.joutsanseutu.fi/    
screen -d -m crawl http://www.loimaanlehti.fi/    
screen -d -m crawl http://www.kainuunsanomat.fi/    
screen -d -m crawl http://www.parikkalan-rautjarvensanomat.fi/‎    
screen -d -m crawl http://www.kaleva.fi/    
screen -d -m crawl http://www.kauppalehti.fi/    
screen -d -m crawl http://www.lansi-savo.fi/    
screen -d -m crawl http://www.uusimaa.fi/    
screen -d -m crawl http://www.iltalehti.fi/    
screen -d -m crawl http://www.iltasanomat.fi/    
screen -d -m crawl http://www.ts.fi/    
screen -d -m crawl http://www.tervareitti.fi/    
screen -d -m crawl http://www.kotiseutu-uutiset.com/    
screen -d -m crawl http://www.vaikka.fi/    
screen -d -m crawl http://www.kymensanomat.fi/    
screen -d -m crawl http://www.ita-savo.fi/    
screen -d -m crawl http://www.shl.fi/    
screen -d -m crawl http://www.viiskunta.fi/    
screen -d -m crawl http://www.ilkka.fi/    
screen -d -m crawl http://www.hameensanomat.fi/    
screen -d -m crawl http://www.orivedensanomat.fi/    
screen -d -m crawl http://www.satakunnanviikko.fi/    
screen -d -m crawl http://www.maaseuduntulevaisuus.fi/    
screen -d -m crawl http://www.taloussanomat.fi/    
screen -d -m crawl http://www.warkaudenlehti.fi/    
screen -d -m crawl http://www.satakunnankansa.fi/    
screen -d -m crawl http://www.kuntsari.fi/    
screen -d -m crawl http://www.keski-uusimaa.fi/    
screen -d -m crawl http://www.loviisansanomat.fi/    
screen -d -m crawl http://www.ksml.fi/    
screen -d -m crawl http://www.sss.fi/    
screen -d -m crawl http://www.kangasalansanomat.fi/    
screen -d -m crawl http://www.pohjalainen.fi/    
screen -d -m crawl "http://www.hs.fi/haku/?haku=Niinist%C3%B6"    
#WaitUntilCrawlsStop.pl
#sleep 30
#killall crawl

# FINANCE NEWS
echo "[Crawling] Crawling finance ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.marketwatch.com/    
screen -d -m crawl  http://www.foxbusiness.com/    
screen -d -m crawl  http://www.singaporetimes.com/    
screen -d -m crawl  http://www.europac.net/    
screen -d -m crawl  http://www.cnbc.com/    
screen -d -m crawl  http://www.themoscowtimes.com/    
screen -d -m crawl  http://www.valuewalk.com/    
screen -d -m crawl  http://www.seekingalpha.com/    
screen -d -m crawl  http://finance.yahoo.com/    
screen -d -m crawl  http://www.moneynews.com/    
screen -d -m crawl  http://www.bloomberg.com/    
screen -d -m crawl  http://www.telegraph.co.uk/finance/    
screen -d -m crawl  http://money.cnn.com/    
screen -d -m crawl  http://www.istockanalyst.com/    
screen -d -m crawl  http://www.upi.com/Business_News/    
screen -d -m crawl  http://www.businessinsider.com/    
screen -d -m crawl  http://www.businessweek.com/    
screen -d -m crawl  http://www.reuters.com/    
screen -d -m crawl  http://www.etftrends.com/    
screen -d -m crawl  http://www.bbc.co.uk/news/business/    
#sleep 30
#killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling entertainment ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.eonline.com/    
screen -d -m crawl  http://variety.com/    
screen -d -m crawl  http://www.tmz.com/    
screen -d -m crawl  http://www.imdb.com/    
screen -d -m crawl  http://perezhilton.com/    
screen -d -m crawl  http://www.rottentomatoes.com/    
screen -d -m crawl  http://games.allmyfaves.com/    
screen -d -m crawl  http://www.pogo.com/    
screen -d -m crawl  http://www.rollingstone.com/music    
screen -d -m crawl  http://www.lyricsnmusic.com/    
screen -d -m crawl  http://serendip.me    
screen -d -m crawl  http://www.time.com/time/    
screen -d -m crawl  http://www.nationalgeographic.com/    
screen -d -m crawl  http://9gag.com/    
screen -d -m crawl  http://www.funnyordie.com/    
screen -d -m crawl  http://www.youtube.com/    
screen -d -m crawl  http://espn.go.com/    
screen -d -m crawl  http://www.infinitylist.com/    
screen -d -m crawl  "http://www.fandango.com/?CJAFFILIATE&CMPID=cj_2477067"    
screen -d -m crawl  http://www.stubhub.com/    
screen -d -m crawl  http://entertainment.allmyfaves.com/    
#sleep 30
#killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling weather ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.weather.com/    
screen -d -m crawl  http://www.wunderground.com/    
screen -d -m crawl  http://www.accuweather.com/    
screen -d -m crawl  http://www.intellicast.com/    
screen -d -m crawl  http://www.wxusa.com/    
screen -d -m crawl  http://weather.cnn.com/    
screen -d -m crawl  http://www.weatherimages.org/    
screen -d -m crawl  http://www.harmweather.com/    
screen -d -m crawl  http://weather.unisys.com/    
screen -d -m crawl  http://www.weatherforyou.com/    
screen -d -m crawl  http://www.myforecast.com/    
screen -d -m crawl  http://www.hwn.org/    
screen -d -m crawl  http://www.noaa.gov/    
screen -d -m crawl  http://www.usatoday.com/weather/    
screen -d -m crawl  http://www.sailflow.com/    
screen -d -m crawl  http://www.theweathernetwork.com/    
screen -d -m crawl  http://wwghcc.msfc.nasa.gov/GOES/goeseastconus.html    
screen -d -m crawl  http://www.marineweather.com/    
#sleep 30
#killall crawl

# SPACE NEWS
echo "[Crawling] Crawling space news ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.space.com/    
screen -d -m crawl  http://www.ufoseek.com/    
#sleep 30
#killall crawl

# News from Russia
echo "[Crawling] Crawling 'news from Russia' ..."
cd /home/vai/db/www
screen -d -m crawl  http://sputniknews.com/russia/    
screen -d -m crawl  http://www.themoscowtimes.com/    
screen -d -m crawl  http://tass.ru/en    
screen -d -m crawl  http://english.pravda.ru/    
screen -d -m crawl  http://www.interfax.com/pressind.asp    
screen -d -m crawl  http://www.youtube.com/user/sputniknews    
#sleep 30
#killall crawl

# Science
echo "[Crawling] Crawling science ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.sciencenews.org/    
screen -d -m crawl  http://www.sciencedaily.com/    
screen -d -m crawl  http://www.bbc.co.uk/news/science_and_environment/    
screen -d -m crawl  http://www.nytimes.com/pages/science/    
screen -d -m crawl  http://esciencenews.com/    
screen -d -m crawl  http://news.sciencemag.org/    
screen -d -m crawl  http://student.societyforscience.org/sciencenews-students    
screen -d -m crawl  http://www.huffingtonpost.com/science/    
screen -d -m crawl  http://www.eurekalert.org/    
screen -d -m crawl  http://www.abc.net.au/science/news/    
screen -d -m crawl  "http://www.richarddawkins.net/news_articles?category=Science&gclid=CJjd3OfWjrsCFYNxOgodQHYAAQ"    
screen -d -m crawl  http://science.nasa.gov/science-news/    
screen -d -m crawl  http://www.sci-news.com/    
screen -d -m crawl  http://phys.org/science-news/    
screen -d -m crawl  http://news.yahoo.com/science/    
screen -d -m crawl  http://www.independent.co.uk/news/science/sun-will-flip-upside-down-within-weeks-says-nasa-8942769.html    
screen -d -m crawl  http://www.scientificamerican.com/    
screen -d -m crawl  http://www.reuters.com/news/science    
screen -d -m crawl  http://www.telegraph.co.uk/science/science-news/    
screen -d -m crawl  http://twitter.com/ScienceNewsOrg    
screen -d -m crawl  http://www.newscientist.com/section/science-news    
screen -d -m crawl  http://www.npr.org/sections/science/    
screen -d -m crawl  http://www.upi.com/Science_News/    
screen -d -m crawl  http://www.scienceagogo.com/    
screen -d -m crawl  http://www.science.org.au/nova/    
screen -d -m crawl  http://www.nsf.gov/news/    
screen -d -m crawl  http://www.theguardian.com/science    
screen -d -m crawl  http://www.nbcnews.com/science    
screen -d -m crawl  http://www.world-science.net/    
screen -d -m crawl  http://www.insidescience.org/    
screen -d -m crawl  http://www.latimes.com/science/    
screen -d -m crawl  http://onlinelibrary.wiley.com/journal/10.1002/%28ISSN%291943-0930    
#sleep 30
#killall crawl

# FTP Search (FTP sites)
echo "[Crawling] Crawling FTP sites ..."
cd /home/vai/db/www
screen -d -m crawl  http://ftp.sunet.se/pub/    
screen -d -m crawl  http://ftp.funet.fi/pub/    
screen -d -m crawl  http://ftp.urc.ac.ru/pub/    
screen -d -m crawl  http://vvstepa.wheelnt.ru/FTP_root/    
screen -d -m crawl  http://ftp.mozilla.org/pub/    
screen -d -m crawl  http://download.videolan.org/pub/    
screen -d -m crawl  http://pirxnet.pl/ftp/    
sleep 120

#
echo "[Crawling] DPRK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.korea-dpr.com/    
screen -d -m crawl http://www.kcna.co.jp/    
screen -d -m crawl http://www.kp.undp.org/content/dprk/en/home/    
screen -d -m crawl http://www.kp.undp.org/dprk/en/home.html    
screen -d -m crawl http://www.koryogroup.com/    
screen -d -m crawl http://www.youtube.com/user/stimmekoreas    
screen -d -m crawl http://www.youtube.com/user/soffkj4y    
#sleep 30
#killall crawl

# MUSIC Search (Music sites)
echo "[Crawling] Music ..."
cd /home/vai/db/www
screen -d -m crawl http://www.youtube.com/watch?v=GLv7eC_HZ0M&list=PL4B7518B6434C9639    
screen -d -m crawl http://www.youtube.com/watch?v=nJ7wei17HI0&list=RD1bXtgIokvhI    
#sleep 30
#killall crawl

# CHINA Search (China sites)
echo "[Crawling] News from China ..."
cd /home/vai/db/www
screen -d -m crawl http://www.shenzhen-standard.com/    
screen -d -m crawl http://www.chinadaily.com.cn/china/    
screen -d -m crawl http://www.china.org.cn/    
screen -d -m crawl http://www.xinhuanet.com/english/china/    
screen -d -m crawl http://www.sznews.com/english/    
screen -d -m crawl http://europe.chinadaily.com.cn/    
#sleep 30
#killall crawl

# News from UK
echo "[Crawling] News from UK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.bbc.co.uk/news/    
screen -d -m crawl http://www.dailymail.co.uk/news/index.htm    
screen -d -m crawl http://www.theguardian.com/uk-news    
screen -d -m crawl http://www.telegraph.co.uk/news/uknews/    
screen -d -m crawl http://www.express.co.uk/news/uk    
screen -d -m crawl http://www.independent.co.uk/    
screen -d -m crawl http://www.thesundaytimes.co.uk/sto/?CMP=INTstp2    
screen -d -m crawl http://metro.co.uk/news/    
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/    
screen -d -m crawl http://www.mirror.co.uk/news/uk-news/    
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/    
screen -d -m crawl http://www.huffingtonpost.co.uk/    
screen -d -m crawl http://news.sky.com/uk    
screen -d -m crawl http://www.britishnewspaperarchive.co.uk/    
screen -d -m crawl http://topics.nytimes.com/top/news/international/countriesandterritories/unitedkingdom/    
screen -d -m crawl http://www.youtube.com/user/BritishForcesNews    
#sleep 30
#killall crawl

# IT jobs Search (IT jobs sites)
echo "[Crawling] News from IT jobs ..."
cd /home/vai/db/www
screen -d -m crawl "http://jobsearch.monster.com/search/?q=Information-Technology-__26-Information-Systems"    
screen -d -m crawl "http://www.careerbuilder.com/"    
screen -d -m crawl "http://www.linkedin.com/job/q-information-technology-jobs"    
screen -d -m crawl "http://www.eurojobs.com/en/candidate/job.html?search%5Bkeyword%5D=information+technology&search%5Bsector%5D=&search%5Bcountry%5D="    
screen -d -m crawl "http://www.workinfinland.com/"    
screen -d -m crawl "http://jobs.telegraph.co.uk/searchjobs/?Keywords=information+technology&location="    
screen -d -m crawl "http://www.prospects.ac.uk/graduate_job_search_results.htm"    
screen -d -m crawl "http://www.ic-software.com/c-jobs"    
#sleep 30
#killall crawl

#
echo "[Crawling] Crawling some other websites ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.svu.fi/kilpailut/    
#sleep 30
#killall crawl

#
#WaitUntilCrawlsStop.pl
##killall crawl

#
#cd /home/vai/db/www
#find . -name 'links.txt'|xargs rm -f

#
#sleep 30
