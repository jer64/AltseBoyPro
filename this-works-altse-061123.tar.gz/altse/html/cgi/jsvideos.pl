#!/usr/bin/perl
################################################################################
#
# jsvideos.pl - Embedded MP4 Videos (JAVASCRIPT).
# (C) 2011 by Jari Tuominen.
#
################################################################################
require "tools.pl";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

################################################################################
#
sub videobar
{
	my ($i,$i2,$str,@lst,$loc,$url);

	#
	$loc = "$ENV{'DOCUMENT_ROOT'}/images/mp4/mpg";
	@lst = LoadList("find $loc -name \"*.mpg\" -type f -maxdepth 1|");

	#
	for($i=0; $i<($#lst+1) && $i<2; $i++) {
		$url = $lst[$i];
		$url =~ s/^$loc//;
		$url = "http://www2.vunet.world/images/mp4/mpg" . $url;
		$str .= ("
<P>
<OBJECT>
$url<BR>
<EMBED TARGET=\"$url\"
	SRC=\"$url\"
	 id=\"$video$i\"
         name=\"video$i\"
         autoplay=\"no\" loop=\"no\" width=\"400\" height=\"300\">
 <a href=\"javascript:;\" onclick='document.video$i.play()'>Play video1</a>
  <a href=\"javascript:;\" onclick='document.video$i.pause()'>Pause video1</a>
  <a href=\"javascript:;\" onclick='document.video$i.stop()'>Stop video1</a>
  <a href=\"javascript:;\" onclick='document.video$i.fullscreen()'>Fullscreen</a>
</EMBED>
</OBJECT>
</P>
			");
	}

	#
	return $str;
}

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if( !NoTracking() )
	{
		$IS_ADMIN = 1;
	}
	else
	{
		$IS_ADMIN = 0;
	}

	#
	if($so{'s'} ne "")
	{
		$SECTION = $so{'s'};
	}
	else
	{
		$SECTION = $ENV{'CURSEC'};
	}

	#
	if($SECTION eq "")
	{
		$SECTION = "progressive";
	}

	#
	$str = videobar();
        #
	$str =~ s/[\t\n\r\s]/ /g;
	$str =~ s/  / /g;
	$str =~ s/\"/\\\"/g;

	#
	@sp = split(/(.{48}[^\\]{8})/, $str);
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] ne "")
		{
		        print(" document.write(\"$sp[$i]\");\n ");
		}
	}

	#
}
