#!/usr/bin/perl
#
# jsadbar.pl
#
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

################################################################################################################
#
sub ShowAd
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$cap);

	#
	$i = $_[0]*4;

	#
	$str = $ads[$i+3];
	$str =~ s/^http:\/\///i;
	$str =~ s/^([^\/]*).*$/$1/i;
	$str =~ s/[^a-zA-Z0-9]*$//;
	$str =~ s/(\S{20})/$1 /g;

	#
	$cap = $ads[$i+0];
	$cap =~ s/(\S{20})/$1 /g;

	#
	$str3 = ("$str3
<TABLE width=100% cellpadding=1 cellspacing=0
	bgcolor=#C0C0FF>
<TR>
<TD>

<TABLE width=100% height=100% cellpadding=4 cellspacing=0
	onClick=\"window.open('/?to=$ads[$i+3]');\"
	class=withLink
	bgcolor=#F0FFFF
	background=\"$IMAGES_BASE/banners/blue_fade_2.png\">
<TR>
<TD>

<font size=2>
$cap</font><BR>

<font color=#0000FF size=1>
$ads[$i+1]
</font><BR>
<font color=#0000FF size=1>
$ads[$i+2]
</font><BR>

<font color=#FFFFFF>
<!--<font size=1>$str</font><BR>-->
</font>

</TD>
</TR>
</TABLE>

</TD>
</TR>
</TABLE>
");

	#
	return $str3;
}

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst);

	#
	if( $ENV{'REMOTE_HOST'} =~ /.fi$/ )
	{
		$DES = "Vaihtoehtouutiset.info-mainos";
		$LANG = "fi";
	}
	else
	{
		$DES = "Vaihtoehtouutiset.info ads";
		$LANG = "en";
	}

	#
	if($so{'w'} eq "")
	{
		$so{'w'}=500;
		$so{'h'}=32;
	}

	#
	$WIDTH = $so{'w'};
	$HEIGHT = $so{'h'};

	#
	$str3 = ("$str3
		<!--- START OF AD BAR: --->
");

	#
	@ads = LoadList("cfg/ads_$LANG.txt");

	#
        srand(time);
	loop: for($i=0; $i<10000; $i++)
	{
	        $a1 = sprintf("%d", rand($#ads/4));
	        $a2 = sprintf("%d", rand($#ads/4));
		if($a1 != $a2) { last loop; }
	}

	#
	$str = ShowAd($a1);
	$str3 = "$str3 $str ";

	#
	$str3 = ("$str3

<!--- END OF AD BAR --->
");

	#
        $str3 =~ s/[\t\n\r\s]/ /g;
        $str3 =~ s/  / /g;
        $str3 =~ s/\"/\\\"/g;

        #
        print(" document.write(\"$str3\"); \n");	

	#
}


