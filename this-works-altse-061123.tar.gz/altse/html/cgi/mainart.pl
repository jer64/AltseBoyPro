#!/usr/bin/perl
#######################################################
# Newswire Publishing System 1.0
# (C) 2004 by Jari Tuominen
#######################################################

#
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#
main();

#
sub main
{
	#
	print "test";

	#
	true;
}
