#!/usr/bin/perl
#
##############################################################################################################

#
require "./tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@lst2,$i,$i2,$i3,$i4,$str,$str2);

	#
	@lst = LoadList("webindex2.html");
	@lst2 = LoadList("/home/vai/public_html/cgi-bin/incqbar.pl|");

	#
	loop: for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]\n";
		if($lst[$i]=~/----before-uusilogo2----/) { last loop; }
	}

	#
	for($i2=0; $i2<($#lst2+1); $i2++)
	{
		print "$lst2[$i2]\n";
	}

	#
	loop: for(; $i<($#lst+1); $i++)
	{
		print "$lst[$i]\n";
	}
	#

	#
}


