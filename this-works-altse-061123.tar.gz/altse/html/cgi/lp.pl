#!/usr/bin/perl
##################################################################
require "tools.pl";
#
main();

##################################################################
sub main
{
	my $i,$i2;

	#
	@log = LoadList("old_avlog.txt");

	#
	open($f, ">parsed.txt");
	for($i=0; $i<$#log; $i++)
	{
		#
		$log[$i] =~ s/(')(.*)(')//;
		print "$log[$i]\n";
	}
	close($f);
}
