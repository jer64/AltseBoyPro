#!/usr/bin/perl
############################################################################################################
#
# Vunet Multimedia Search Engine.
# (C) 2006 by Jari Tuominen (jari@vunet.world).
#
############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

##########################################################################################
#
sub ViewResult
{
	my (@lst,$i,$i2,$i3,$i4,$str,$str2,$fn);

	#
	$fn = $_[0];
	$fn =~ s/^.*\/([^\/]*)$/$1/;
	$fn =~ s/^(.{60}).*$/$1/;

	#
	$fn =~ s/\-/ /g;
	$fn =~ s/_/ /g;
	$fn =~ s/\%20/ /g;
	$fn =~ tr/[A-Z���]/[a-z���]/;
	$fn =~ s/[^a-z0-9\.\ ]//g;
	$fn =~ s/^\s*//;
	$fn =~ s/\s*$//;

	#
	print("
o <A HREF=\"http://www.vunet.world/?to=$_[0]\" class=news2 target=_blank>
$fn
</A><BR>
");
}

##########################################################################################
#
sub SearchGo
{
	my (@lst,$i,$i2,$i3,$i4,$str,$str2);

	#
	$so{'q'} =~ tr/[A-Z���]/[a-z���]/;
	$so{'q'} =~ s/[^a-z0-9\ ]//g;
	$so{'q'} =~ s/^\s*//;
	$so{'q'} =~ s/\s*$//;

	#
	@lst = LoadList("multimedia.txt");

	#
	$str = $so{'q'};
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		if($lst[$i] =~ /$str/i)
		{
			$i2++;
			if( !$got{$lst[$i]} )
			{
				$got{$lst[$i]}++;
				ViewResult($lst[$i]);
			}
		}
	}

	#
	if(!$i2)
	{
		print("
No hits.
			");
	}
}

##########################################################################################
#
sub main
{
	#
	print("
<BR>

<TABLE WIDTH=450 cellspacing=32 cellpadding=0>
<TR>
<TD>

<TABLE WIDTH=100% cellspacing=4 cellpadding=0>
<TR>
<TD>
<DIV align=center>
<IMG SRC=\"$IMAGES_BASE/multimedia_search.gif\">
");

	#
	print("
<FORM action=\"/media.pl\">
<input type=text name=q value=\"$so{'q'}\" size=40>
<input type=submit value=Search>
</FORM>
		");

	#
	print("
</DIV>
		");

	#
	if($so{'q'} ne "")
	{
		SearchGo();
	}


	#
	print("

</TD>
</TR>
</TABLE>


</TD>
</TR>
</TABLE>
		");
}


