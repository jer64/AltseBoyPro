#!/usr/bin/perl
#
# SHOW A BRIEF VIEW OF NEWS FROM SELECTED SECTION
# ifbriefly.pl
# Called by jsheadlines at nw.pl.
#
################################################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
use POSIX;
require "tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#print $ENV{'QUERY_STRING'};

#
main();

#

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	if($ARGV[0] ne "" && $ARGV[1] ne "")
	{
		$so{'s'} = $ARGV[0];
		$so{'page'} = $ARGV[1];
	}

	#
	$so{'page'} =~ s/[^0-9]//g;
	$so{'page'} = sprintf "%d", $so{'page'};
	$so{'s'} =~ s/[^a-z]//g;

	#
	print("
<HTML>

<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\"
	href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
</HEAD>

<BODY>

<DIV id=ldr align=center>
<IMG SRC=\"http://images.vunet.world/icons1/altse_ajax_loader.gif\" valign=middle>
</DIV>


<DIV ID=\"maincontent\"
        style=\"display: none;\">

		");

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0 background=\"http://www.vunet.world/images/fade2b.gif\"
	valign=top
	style=\"vertical-align: top; background-repeat: repeat-y;\">
<TR>
<TD>
<script language=\"Javascript\" src=\"/cgi/jsbar2.pl?s=$so{'s'}&a=$so{'a'}\">
</script>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</TD>
</TR>
</TABLE>
		");

	#
	print("
</DIV>

<SCRIPT LANGUAGE=\"JavaScript\">
document.getElementById('ldr').innerHTML = '';
document.getElementById('maincontent').style.display = 'block';
</SCRIPT>
</BODY>

</HTML>
		");

	#
}


