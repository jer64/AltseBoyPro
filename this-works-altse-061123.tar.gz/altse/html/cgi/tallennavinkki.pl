#!/usr/bin/perl
####################################################################

#
require "tools.pl";

#
$HDIR = "hints";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("webindex.html");
WireLogo();
HandleExternal("main-menu", "./mainmenu.pl");

###############################################################################
#
WebWalkTo("ENTERHERE_SECTION");

#
main();

#
HandleRest();

#######################################################
#
sub GetName
{
	my $i,$i2;

	#
	loop: for($i=0; $i<1000000; $i++)
	{
		if( !open($f, "$HDIR/$i.txt") )
		{
			last loop;
		}
		close($f);
	}

	#
	return "$HDIR/$i.txt";
}

#######################################################
#
#
sub StoreArticle
{
	#
	$name = GetName();

	#
	if( open($f, ">$name") )
	{
		print $f "$ENV{'REMOTE_ADDR'} $ENV{'REMOTE_HOST'}\n";
		print $f "$so{'NAME'}\n";
		print $f "$so{'HINT'}";
		close($f);

		#
		if(!IsBanned($ENV{'REMOTE_ADDR'}))
		{
			system "mail lst\@vunet.world -s \"UUTISVIHJE.\" < $name";
		}

		#
		print ("
			<font size=1>
			<br>$name stored.<br>
			</font>
			");
		system "echo \"$name\" >> $HDIR/fileindex.txt";
	}
	else
	{
		print "ERROR WHILE WRITING FILE $name !<br>";
	}
}

#######################################################
#
# Search arguments line for options.
#
sub main
{
	my $str;

	#
	print("
		<table width=600 cellpadding=32 cellspacing=0>
		<tr>
		<td>
		");

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	$str = $so{'HINT'};
	$str =~ s/\n/<br>\n/g;

	#
	print("
		Kiitos uutisvihjeest�!!!<br>
		<br>

		<table cellpadding=4 cellspacing=0 width=100% bgcolor=\"#000000\">
		<tr>
		<td>

		<table cellpadding=4 cellspacing=0 width=100% bgcolor=\"#FFFF00\">
		<tr>
		<td>
		<b>FROM:</b> $so{'NAME'}<br>
		</td>
		</tr>
		</table>

		<table cellpadding=4 cellspacing=0 width=100% bgcolor=\"#FF0000\">
		<tr>
		<td>
		<font color=\"#FFFF00\">
		<b>CONTENT</b><br>
		</font>
		</td>
		</tr>
		</table>

		<table cellpadding=4 cellspacing=0 width=100% bgcolor=\"#00FFFF\">
		<tr>
		<td>
		$str<br>
		</td>
		</tr>
		</table>


		</td>
		</tr>
		</table>
		");

	#
	StoreArticle();

	#
	print("
		</td>
		</tr>
		</table>
		");
}

#

