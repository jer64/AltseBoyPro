#!/usr/bin/perl
require "tools.pl";

#
$OLDBASE = "http:\/\/www\.saunalahti\.fi\/ehc50\/uutiset";
$OLDBASE2 = "http:\/\/www\.saunalahti\.fi\/\~ehc50\/uutiset";
$NEWBASE = "\.\./uutiset";

#
@u = LoadList("imageurls.txt");

#
for($i=0; $i<($#u+1); $i++)
{
	@dat = LoadList($u[$i]);
	$res = process($dat[0]);
	open($f, ">$u[$i]") || goto past;
	print $f $res;
	close($f);
past:
}

sub process
{
	$str = $_[0];
	$str =~ s/$OLDBASE/$NEWBASE/;
	$str =~ s/$OLDBASE2/$NEWBASE/;
	print "[$str]\n";
	return $str;
}

