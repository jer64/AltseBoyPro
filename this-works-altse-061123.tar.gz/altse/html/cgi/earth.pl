#!/usr/bin/perl
###############################################################################
# News On Earth.
###############################################################################

#
require "tools.pl";

#
$ENV{'CURSEC'} = "earth";

# Interval for fetching a new weather data.
$MAX_DATA_AGE = (60*5);

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, "finnish");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

##################################################
#
sub Plot
{
	#
	print("
<div STYLE=\"position:relative; left:$_[0]; top:$_[1];\">
<a href=\"$_[2]\">
<img src=\"$IMAGES_BASE/plot.png\" border=0>
</a>
</div>
	");
}

##################################################
#
sub EarthNews
{
#	my @locs=

	#
	Plot(136,76+10, "http://www.yle.fi");

	#
	print("
<img src=$IMAGES_BASE/political_map_earth_640.png>



<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
		");
}

##################################################
#
sub main
{
	#
	ArgLineParse();

	#
	print("
		<table width=100% cellpadding=32 cellspacing=0>
		<tr valign=top>
		<td width=80%>
		");

	#
	EarthNews();

	#
	print("
		</td>

		<td background=$IMAGES_BASE/saapalkki.jpg>
		</td>
		</tr>
		</table>");

	#
}

