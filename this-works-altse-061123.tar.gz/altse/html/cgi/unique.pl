#!/usr/bin/perl
#
# Determines amount of unique visitors so far.
#
##############################################################################################################

#
require "tools.pl";

#
main();


###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str,$str2,$fn,$lt,$hits);

	#
#	system("./gentopten.pl");

	#
	@lst = LoadList("topten.txt");

	#
	loop: for($i=0,$rp=0; $i<($#lst+1); $i++)
	{
		#
#                printf "%6d / %6d    \r", $i,$#lst;

		#
		$fn = $lst[$i];
		$fn =~ s/^[0-9]* //;
		$fn = "$fn.counter";

		#
		if(-e $fn)
		{
			@art = LoadList($fn);
			for($i2=0; $i2<($#art+1); $i2++)
			{
				$ips{$art[$i2]}++;
			}
		}
	}

        #
	$cnt = 0;
        foreach $key (keys %ips)
        {
	    $cnt++;
            #print "$key\n";
        }

	#
	print "$cnt\n";

	#
	open($f, ">Unique.txt");
	print $f "$cnt\n";
	close($f);

	#
}


