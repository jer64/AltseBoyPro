#!/usr/bin/perl
#############################################################
#
# Change to text version.
#
#############################################################

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

#################################################
sub main
{
	$so{'low_graphics'} = "true";
	SaveProfile(GetUserID());
        #
        print "<meta http-equiv=\"refresh\" content=\"0; url=newswire.pl\">\n";
}

#


