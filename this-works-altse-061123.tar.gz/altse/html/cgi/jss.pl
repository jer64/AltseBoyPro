#!/usr/bin/perl
######################################################################################
#
# Javascript News Outlet from VUnet.org.
#
######################################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();


##################################################
sub main
{
		#
		print("
<table width=100%>
<tr>
<td>

<div align=center>
<font size=6>
<a href=\"http://text.vunet.world\">Vaihtoehtouutiset</a>
</font>
<br>
<font size=4>
Alternative News
</font>
</div>
<br>

			");

                ############################################################################################
                #
                # ADD NEWS HERE
                #
                open(CAL, "./js1.pl|");
                @cal = <CAL>;
                close(CAL);
                print @cal;

		#
		print("

</td>
</tr>
</table>
			");
}


