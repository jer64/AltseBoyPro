#!/usr/bin/perl
################################################################################
#
# jsbar.pl - Embedded News Bar (JAVASCRIPT).
# Featured in articles on the left.
# (C) 2006-2008 by Jari Tuominen.
#
################################################################################
require "tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ArticleViewerMonitor.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/JsHeadLines.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NaytaUutisotsikot.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewHL.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewXML.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/AnyComments.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewMainArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticleLib.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/EmbeddedViewArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/VerboseViewHL.pm";
#
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =		15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

#
sub viewArticles
{
  my ($str);

 
  $str = EmbeddedViewArticles($ARGV[0], $ARGV[1], $ARGV[2]);

  #
  return $str;
}

#
sub main
{
	#
	$str = viewArticles();
        #
	print STDOUT $str;
}
