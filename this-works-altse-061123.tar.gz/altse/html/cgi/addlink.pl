#!/usr/bin/perl

#
require "admin.pl";

#
$ENV{'CURSEC'} = "lis�� uutislinkki";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
WireLogo();
HandleExternal("main-menu", "./mainmenu.pl");
WebWalkTo("enterhere_section");
@txt = LoadList("addlink.txt");
for($i=0; $i<($#txt+1); $i++) { print "$txt[$i]\r\n"; }
HandleRest();
