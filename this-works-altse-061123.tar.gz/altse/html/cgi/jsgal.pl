#!/usr/bin/perl
################################################################################
#
# Embedded gallery.
#
################################################################################
# $ENV{'DOCUMENT_ROOT'}/cgi/
require "/home/vai/cgi/tools.pl";
require "/home/vai/cgi/modules/view_gal.pm";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$GAL = "asian";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
main();

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if($so{'q'} ne "")
	{
		$GAL = $so{'q'};
		$GAL =~ s/[^a-z0-9_]//g;
	}

	#
	$IMGBASE = "$IMAGES_BASE/$GAL";

	#
	$str = custom_gallery();

        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/\"/\\\"/g;
        print(" document.write(\"$str\"); \n");
}

################################################################################
#
sub gallery
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$fn);

	#
	@lst = LoadList("find /home/vai/public_html/uutiset/$GAL -maxdepth 1 -type f -name '*.jpg'|");
	@download = LoadList("find /home/vai/public_html/uutiset/$GAL -maxdepth 1 -type f -name 'download.txt'|");
	if($download[0] ne "")
	{
		$fn = "/home/vai/public_html/uutiset/$GAL/$download[0]";
		$DOWNLOAD_HTML = ("
<H2>
<DIV ALIGN=CENTER>
<A HREF=\"$dl[1]\">$dl[0]</A><BR>
</DIV>
</H2>

");
	}

	#
	$str = ("
$DOWNLOAD_HTML
			<table width=100% cellpadding=2 cellspacing=0>
		");

	#
	$str = ("$str
		<table width=140 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	$str = ("$str
<TABLE width=100% cellpadding=25 cellspacing=0>
<TR valign=top>
		");
	my @descriptions;
	if(-e "/home/vai/public_html/uutiset/$GAL/description.txt") {
		@descriptions = LoadList("/home/vai/public_html/uutiset/$GAL/description.txt");
	} else {
	}
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$fn = $lst[$i];
		$fn =~ s/^.*\/([a-zA-Z0-9_\-\.\ ]*\.jpg)$/$1/;

		#
		if( -e "/home/vai/public_html/uutiset/$GAL/thumbs/th_$fn" )
		{
			#
			if($i>0 && ($i&1)==0)
			{
				$str = ("$str
				</TR>
				</TABLE>
				<TABLE width=100% cellpadding=25 cellspacing=0>
				<TR valign=top>
					");
			}

			#
			my $des = $descriptions[$i];
	
			#
			$str = ("$str
			<TD width=50%>
			<A HREF=\"$IMGBASE/$fn\">
			<IMG SRC=\"$IMGBASE/thumbs/th_$fn\">
			$des
			</A>
			</TD>
				");
		}
		else
		{
			$str = "$str not found $fn<br>\n";
		}
	}

	#
	$str = ("$str
		</TR>
		</TABLE>

		</td>
		</tr>
		</table>
		");

	#
	return $str;
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$con,$re);

	#
	$re = 0;

	#
	@art = LoadList("$_[0]");

	#
	$con = "";
	$cap = substr($art[0], 0, 200);

	#
	if($cap eq "") { return ""; }

	#
	$u1 =~ s/poimitut\/\.\.//;
	$u2 =~ s/poimitut\/\.\.//;
	$u1 = UrlFix(BuildQuickUrl($_[0]));
	$u2 = UrlFix(BuildQuickUrl($so{'a'}));
	$URL = "http://vunet.world$u1";
	$u3 = $_[0];
	$u3 =~ s/[a-z]*\/\.\.\///;
	$u3 =~ s/pub_artikkeli(.*)\.txt/story$1.html/;
	$u3 = "/$u3";
	$URL = CapUrl($u3, $cap);

	#
	if($u1 ne $u2)
	{
		$con = ("$con
			<font size=1>
			");
	}
	else
	{
		$re = 1;
		$con = ("$con
			<font color=\"#FFFF00\" size=1>
			");
	}

	#
	$cap =~ s/<br>//ig;
	$cap =~ s/(\S{15})/$1 /g;

	#
	$con = ("$con
		<div>
		<li>
		<b>$cap</b>
		</li>
		</div>
		");
	if($u1 ne $u2)
	{
		$con = ("$con
			");
	}
	else
	{
		$con = ("$con
			</font>
			");
	}

	#
	return $con;
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,$i,$i2,$col,$con,$st,$str);

	#
#	if( !NoTracking() ) { return(); }

	#
	$str = ("
		<center>
		<table cellpadding=1 cellspacing=0 width=100%
			bgcolor=\"\">
		");

	#
	@lst = "";
	@lst = LoadList("$_[0]/fileindex.txt");
	$col = "";

	#
	loop: for($ii=$#lst,$i2=0,$st=time; $i2<$AMOUNT_OF_ARTICLES_TO_SHOW; $ii--)
	{
		#
		$t = time;
		if( ($t-$st)>2 ) { last loop; }

		#
		$fn = "$_[0]/$lst[$ii]";

		#
		if($fn=~/\/videos\// && $_[0] eq "poimitut")
		{
			goto skip;
		}

		#
		if( -e $fn )
		{
			$con = ViewHL($fn);
		}
		else
		{
			$con = "";
		}

		#
		if( ($i2&1)==0 )
		{
			$col = "#D0D0FF";
		}
		else
		{
			$col = "#C0C0FF";
		}
		if($u1 eq $u2) { $col = "#800000"; }

		#
		if($con eq "") { goto skip; }

		#
		$str = ("$str
			<tr bgcolor=\"$col\">
			<td width=50% style=\"vertical-align: top;\">
			<font size=1>


			<table cellpadding=4 cellspacing=0>
			<tr>
			<td onMouseover=\"this.className='td_over_white';\"
			    onMouseout= \"this.className='';\"
			    onClick=\"window.location.href='$URL';\">

			$con
			</td>
			</tr>
			</table>

			</font>
			</td>
			");
		$i2++;

		#
		if($ii==0) { last loop; }
skip:
	}

	#
	$str = ("$str
		</table>
		</center>
		");

	#
	return $str;
}
