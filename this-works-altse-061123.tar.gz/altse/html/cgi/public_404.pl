#!/usr/bin/perl
#
# 404 ERROR HANDLER
#

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
print("
<TITLE>TV.VUNET.ORG</TITLE>

<META http-equiv=\"refresh\" content=\"0; url=http://www.youtube.com/user/vunet\">
");
