package DADA::App::DBIHandle;   

use lib qw(../ ../DADA ../perllib); 
use DADA::Config; 
use DBI; 

my $database         = $SQL_PARAMS{database};
my $dbserver         = $SQL_PARAMS{dbserver};    	  
my $port             = $SQL_PARAMS{port};     	  
my $user             = $SQL_PARAMS{user};         
my $pass             = $SQL_PARAMS{pass};
my $email_id         = $SQL_PARAMS{id_column} || 'email_id';

if(!$dbtype){ 
	
	$dbtype = 'mysql' if $DB_TYPE eq 'MySQL';
	$dbtype = 'Pg'    if $DB_TYPE eq 'PostgreSQL';
	
	$dbtype = 'mysql' if $ARCHIVE_DB_TYPE eq 'MySQL';
	$dbtype = 'Pg'    if $ARCHIVE_DB_TYPE eq 'PostgreSQL';
	
	
 }
 
 
 sub new {

	my $class = shift;
	my %args = (@_); 
	   my $self = {};			
       bless $self, $class;
	   $self->_init(%args); 
	   return $self;

}




sub _init  { 

    my $self = shift; 
    my %args = @_; 
    $self->{sql_params} = {%SQL_PARAMS}; 
    
    if($DB_TYPE =~ m/SQL/i || $ARCHIVE_DB_TYPE =~ m/SQL/i){ 
    	$self->{enabled} = 1; 
    } 
    
    $self->{is_connected} = 0; 
   

}


sub dbh_obj { 

	my $self = shift; 
	# it's all yours, champ.
	
	return undef unless $self->{enabled}; 
	
	if($self->{is_connected} != 1){ 
		$self->connectdb; 
	}
	
	return $self->{dbh}; 
}




sub connectdb {
  
  my $self = shift; 
  
  return undef unless $self->{enabled}; 

  my $data_source = "dbi:$dbtype:dbname=$database;host=$dbserver;port=$port";
  $self->{dbh} = DBI->connect("$data_source", $user, $pass) || die("can't connect to db: $!");
  $self->{is_connected} = 1; 
}




sub disconnectdb {
  my $self = shift; 
  	return undef unless $self->{enabled}; 


  
  $self->{dbh}->disconnect;
  $self->{is_connected} = 0; 

}




sub DESTROY { 

	my $self = shift;
		return undef unless $self->{enabled}; 

	if($self->{dbh}){ 
		$self->disconnectdb ; 
	}else{ 
	}
}


1;
