package DADA::App::Messages; 

use lib qw(./ ../  ../DADA ../DADA/perllib); 

use DADA::Config;
use DADA::App::Guts; 

require Exporter; 
@ISA = qw(Exporter); 

@EXPORT = qw(

send_confirmation_message
send_unsub_confirm_email

send_unsubscription_email
send_subscribed_message

send_owner_happenings

); 

use strict; 
use vars qw(@EXPORT); 


sub send_confirmation_message { 

	my %args = (
			-List         => undef, 
			-Email        => undef, 
			-Settings_obj => undef, 
			@_		
	);
	
	my $li    = $args{-Settings_obj}->get;
	my $email = $args{-Email}; 
	my $list  = $args{-List}; 

	my $Body =  $li->{confirmation_message}; 
		
		# I need to eat, I'm as thin as a rail!
		$Body .= $FOOTER if $FOOTER ne '';
		
		my $headers = {To              => '"'. escape_for_sending($li->{list_name}) .'" <'. $email .'>', , 
					   Subject         => $li->{list_name} . ' Mailing List Confirmation', 
					  };
		
		my $msg = undef; 
	
		   $msg .= $_ . ': ' . $headers->{$_} . "\n"
			foreach(keys %$headers); 
		   $msg .= "\n" . $Body; 
			
		require DADA::App::FormatMessages; 
		my $fm = DADA::App::FormatMessages->new(-List => $list); 
		   $fm->use_header_info(1);
		   $fm->use_email_templates(0); 
		   
		my ($header_str, $body_str) = $fm->format_headers_and_body(-msg => $msg );
		
		require DADA::Mail::Send;  
		my $mh = DADA::Mail::Send->new($li); 
	
		$mh->send($mh->return_headers($header_str), 
				  Body => $body_str,
				 ); 
				 
}




sub send_unsub_confirm_email { 

	my %args = (
			-List         => undef, 
			-Email        => undef, 
			-Settings_obj => undef, 
			@_	
		); 
		
	my $email = $args{-Email}; 
	my $list  = $args{-List}; 
	
	if (! $args{-Settings_obj}){
		require DADA::MailingList::Settings; 
		$args{-Settings_obj} = DADA::MailingList::Settings->new(-LIst => $args{-List}); 
	}
	my $li = $args{-Settings_obj}->get; # yeah, I have no idea why this is being passed...

	my $headers = { 
					To              =>    $email, 
					Subject         =>    $li->{list_name} . ' Mailing List Confirmation', 
				  }; 
	my $msg = undef; 
	
	$msg .= $_ . ': ' . $headers->{$_} . "\n"
	   	foreach(keys %$headers); 
	$msg .= "\n" . $li->{unsub_confirmation_message};
	
	require DADA::App::FormatMessages; 
	my $fm = DADA::App::FormatMessages->new(-List => $list); 
	   $fm->use_header_info(1);
	   $fm->use_email_templates(0); 
	   
	my ($header_str, $body_str) = $fm->format_headers_and_body(-msg => $msg );
	
	require DADA::Mail::Send;  
	my $mh = DADA::Mail::Send->new($li); 

	$mh->send($mh->return_headers($header_str), 
		      Body => $body_str,
		     ); 
}




sub send_unsubscription_email{ 

	my %args = (-List      => undef,
				-Email     => undef,
				-List_Info => undef,
				@_);

	my $li    = $args{-List_Info};
	my $email = $args{-Email}; 
	my $list  = $args{-List}; 
	
	my $headers = { To              =>   $email, 
					Subject         =>   $li->{list_name} . ' Unsubscription', 
				  }; 
	
	my $msg = undef; 
	
	$msg .= $_ . ': ' . $headers->{$_} . "\n"
	   	foreach(keys %$headers); 
	$msg .= "\n" . $li->{unsubscribed_message};
	
	require DADA::App::FormatMessages;
	
	my $fm = DADA::App::FormatMessages->new(-List => $li->{list}); 
	   $fm->use_header_info(1);
	   $fm->use_email_templates(0); 
	   
	my ($header_str, $body_str) = $fm->format_headers_and_body( -msg => $msg );
	
	require DADA::Mail::Send;  
	my $mh = DADA::Mail::Send->new($li); 

	$mh->send($mh->return_headers($header_str), 
		      Body => $body_str,
		     ); 
		     
}



sub send_subscribed_message { 

	my %args = (
	-List         => undef, 
	-Email        => undef, 
	-Settings_obj => undef, 
	@_	
	); 

	my $email = $args{-Email}; 
	my $list  = $args{-List}; 
	
	if (! $args{-Settings_obj}){
		require DADA::MailingList::Settings; 
		$args{-Settings_obj} = DADA::MailingList::Settings->new(-LIst => $args{-List}); 
	}
	my $li = $args{-Settings_obj}->get; # yeah, I have no idea why this is being passed...
	

	my $headers = {
					To            => "\"New Subscriber\" <$email>", 
					Subject       => "Welcome to " . $li->{list_name}, 
				   };
				   
	my $msg  = undef; 
	   $msg .= $_ . ': ' . $headers->{$_} . "\n"
		foreach(keys %$headers); 
	   
	   $msg .= "\n" . $li->{subscribed_message};
		
	require DADA::App::FormatMessages; 
	
	my $fm = DADA::App::FormatMessages->new(-List => $list); 
	   $fm->use_header_info(1);
	   $fm->use_email_templates(0); 
	   
	my ($header_str, $body_str) = $fm->format_headers_and_body(-msg => $msg );
	
	require DADA::Mail::Send;  
	my $mh = DADA::Mail::Send->new($li); 

	$mh->send($mh->return_headers($header_str), 
			  Body => $body_str,
			 ); 
				 
}




sub send_owner_happenings { 

	my $list    = shift; 
	my $email   = shift; 
	my $status  = shift; 
	my $lh_obj  = shift || undef; # bad form..
	my $ls_obj  = shift || undef; # bad form..

	my $send_it = 1; 
	
	my $ls; 
	if($ls_obj){ 
		$ls = $ls_obj; 	
	}else{ 
		require  DADA::MailingList::Settings; 
		   $ls = DADA::MailingList::Settings->new(-List => $list); 
	}
	
	my $li = $ls->get; 
	
	if($status eq "subscribed"){  
	   if(exists($li->{get_sub_notice})){ 
		 if($li->{get_sub_notice} == 0){         
			$send_it = 0; 
			}
		 }   
	   }elsif($status eq "unsubscribed"){  
		if(exists($li->{get_unsub_notice})){ 
		  if($li->{get_unsub_notice} == 0){ 
			$send_it = 0; 
		   }
		}   
	  } 
		
	if($send_it == 1){ 
	
		my $lh;
		
		if($lh_obj){ 
			$lh = $lh_obj; 
		}else{ 
			$lh = DADA::MailingList::Subscribers->new(-List => $list); 
		}
		
							   
		my $num_subscribers = $lh->num_subscribers;   
		
		my $localtime = scalar(localtime());

my $Body = qq{

Hello,
This is a quick note to say that 
$email has $status on list: $li->{list_name} 

Server Time: $localtime
IP Logged:   $ENV{'REMOTE_ADDR'}

There is now a total of: $num_subscribers subscribers.

-$PROGRAM_NAME

};
		require DADA::Mail::Send;  
		my $mh = DADA::Mail::Send->new($li);
		my %mailing = ( 
		'Reply-To'     => $email, 
		To             =>  '"List Owner for: '. escape_for_sending($li->{list_name}) .'" <'. $li->{list_owner_email} .'>', 
		Subject        => "$status $email",
		Body           => $Body,
		);  
		
		$mh->send(%mailing); 	
	}
}






