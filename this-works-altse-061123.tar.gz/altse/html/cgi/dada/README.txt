          Dada Mail. An Easy and Powerful List Management System

    By Justin Simoni - http://justinsimoni.com Copyright 1999 - 2005

    And the Dada Mailers

Introduction

    Hello! Let me start by thanking you personally for downloading Dada
    Mail. I strongly believe that this version is our richest version yet,
    both in terms of what it does now and what it will do in the near
    future!

    A support site is available to you for this program:

    http://mojo.skazat.com

    There you will find the latest information on the program, as well as
    support and detailed instructions. This document should help and point
    you in the right direction.

    If you don't already know all the great features available to you with
    this program, please read:

    http://mojo.skazat.com/features/

Quick Instructions

    This release of Dada Mail needs 4 variables changed in the Config.pm
    file that's located in the DADA folder. Installation instructions are
    available at:

    http://mojo.skazat.com/installation/

    Detailed instructions are found inside that script (Config.pm). Two of
    the four variables probably don't need to be changed to start you up!
    For even more detailed instructions, a complete walk-through of that
    script is available at:

    http://mojo.skazat.com/support/documentation/Config.pm.html

    If you're having problems, be sure to check out the support section:

    http://mojo.skazat.com/support/

    Professional Installation is available for this script! Details are
    found here:

    http://mojo.skazat.com/support/regular.html

    This program is Open Source Software and is covered under the GNU
    General Public License. You should have gotten a copy of the license
    with this script. If not, you can view a copy at:

    http://www.gnu.org/copyleft/gpl.html

What's New in Dada Mail?

    A running log of changes can be found at:

    http://mojo.skazat.com/support/documentation/changes.pod.html

Documentation

    This distribution comes with documentation for the entire program,
    located in the:

    dada/extras/documentation/html_version

    folder. Just open up 'index.html' in a web browser.

