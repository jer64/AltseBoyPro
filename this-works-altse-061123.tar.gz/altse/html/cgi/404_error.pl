#!/usr/bin/perl
#
# 404 ERROR HANDLER
#

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
#
WebWalkTo("CHOOSE-TITLE1");
#
print("
<TITLE>Vunet.org</TITLE>
");
SkipTo("CHOOSE-TITLE2");

# Add main menu.
WebWalkTo("main-menu");
print inc_menu("", "english");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#####################################################################################
#
sub EnvList
{
	foreach $key (sort(keys %ENV))
	{
		print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
	}
}

#######################################################################################################
#
sub GuessImage
{
	my ($i,$i2,$i3,$i4,@lst,@found,$content);

	#
	$content = ("
<table cellpadding=16 cellspacing=0 width=100% bgcolor=#FFFFFF>
<tr>
<td>

	<font size=6 color=#A00000>
	IMAGE SEARCH
	</font>


<table cellpadding=0 cellspacing=0
	bgcolor=\"#000000\"
	width=100% height=8>
<tr valign=top>
<td>

</td>
</tr>
</table>

<BR>
	");

	#
#	EnvList();

	#
	@lst = LoadList("/home/vai/public_html/uutiset/index.txt");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\.\///;
		$olst[$i] = $lst[$i];
		$olst[$i] =~ s/^.*\/([^\/]*)$/$1/;
	}
	for($i=0; $i<($#olst+1); $i++)
	{
		$olst[$i] =~ s/\.jpeg//ig;
		$olst[$i] =~ s/\.jpg//ig;
		$olst[$i] =~ s/\.png//ig;
		$olst[$i] =~ s/\.gif//ig;
		$olst[$i] =~ s/[^a-zA-Z0-9]/ /g;
	}

	#
	$str = $ENV{'REQUEST_URI'};
	$str =~ s/\.jpeg//ig;
	$str =~ s/\.jpg//ig;
	$str =~ s/\.png//ig;
	$str =~ s/\.gif//ig;
	$str =~ s/[^a-zA-Z0-9]/ /g;
	@lst2 = split(/\ /, $str);


	#
	loop: for($i=0,$hits=0,@found=(),$st=time; $i<($#lst+1); $i++)
	{
		if( (time-$st)>5 ) { last loop; }
		@sp = split(/ /, $olst[$i]);
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			loop2: for($i3=0; $i3<($#sp+1); $i3++)
			{
				$avain = $sp[$i3];
				if( $avain ne "" && $lst2[$i2] =~ /$avain/i )
				{
					print "\"$olst[$i]\" $avain => $lst2[$i2]<BR>\n";
					push(@found, $lst[$i]);
					if( ($hits++)>5 ) { last loop; }
					last loop2;
				}
			}

			#
		}
	}

	#
	if($hits<=0) { return ""; }

	#
	for($i=0; $i<($#found+1) && $i<10; $i++)
	{
		$content = ("$content
		<IMG SRC=\"$IMAGES_BASE/$found[$i]\"><BR>
			");
	}

	#
	$content = ("$content
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>

</td>
</tr>
</table>
		");

	#
	return $content;
}

##################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str);

	#
#	@lst = LoadList("/home/vai/public_html/uutiset/index.txt");
	if( $ENV{'SERVER_NAME'} eq "$IMAGES_BASE" && 1!=1 )
	{
		$str = GuessImage();
		if($str eq "")
		{
			error440();
		}
		else
		{
			print $str;
		}
	}
	else
	{
		error440();
	}
}

##################################################
#
sub error440
{
	#
	print ("

<table cellpadding=16 cellspacing=0 width=100% bgcolor=#FFFFFF>
<tr>
<td>

	<font size=6 color=#A00000>
	HTTP ERROR 404 - PAGE NOT FOUND
	</font>


<table cellpadding=0 cellspacing=0
	bgcolor=\"#000000\"
	width=100% height=8>
<tr valign=top>
<td>

</td>
</tr>
</table>

<BR>
<TABLE WIDTH=650>
<TR>
<TD>
<i>Server side error.</i><BR>
<BR>
By <A HREF=\"http://www.vunet.world/?to=http://www.vunet.world/contact.pl\">reporting this problem</a> to
the administration you will help us notice it and fix it as 
soon as it is humanely possible (Link => Contact Us).
<BR>
<A HREF=\"http://www.vunet.world/?to=http://www.vunet.world/contact.pl\">Ilmoittamalla t�st� virheest� yll�pidolle</a> autat meit� huomaamaan ja korjaamaan 
ongelman 
mahdollisimman pian (Linkki => Contact Us).
</TR>
</TD>
</TABLE>
<BR>

<BR>
<TABLE WIDTH=500 cellspacing=0 cellpadding=0>
<TR>
<TD>
<i>Perhaps you are interested in ...</i>
<script src=\"http://www.vunet.world/jsticker.pl?s=progressive\">
</script>
<BR>
<script language=\"Javascript\" src=\"http://www.vunet.world/~vai/cache/top_videos.js\">
</script>
</TD>
</TR>
</TABLE>

<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
<br><br>

</td>
</tr>
</table>
		");
#	$ENV{'REDIRECT_STATUS'} -

	#
	goto past;
	#
        open($f, "|mail jari\@vunet.world -s \"[404] $ENV{'REDIRECT_REDIRECT_ERROR_NOTES'}.\"");
	print $f "HTTP ERROR 440\n";
	print $f "Client: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
	print $f "\n";
        foreach $key (sort(keys %ENV))
        {
                print $f "$key</b>=\"$ENV{$key}\"\n";
        }
	close($f);
past:

	#
}


