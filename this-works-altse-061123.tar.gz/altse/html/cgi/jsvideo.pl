#!/usr/bin/perl
#
# jsvideo.pl
#
################################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	$uni = sprintf "%d", rand(1000000);

	#
	$sz = "1";

	#
	if($so{'v'}=~/^[a-z]*\/pub_artikkeli[0-9]*\.txt$/)
	{
		#$str = "p��";
		@lst = LoadList("/home/vai/cgi-bin/$so{'v'}");
		if($so{'v'}=~/^videos\//)
		{
			for($i=0; $i<($#lst+1); $i++)
			{
				if($lst[$i]=~/xembed/)
				{
					$URL = $lst[$i];
					$URL =~ s/<xembed\s*src=\"([^\"]*)\".*$/$1/;
					$lst[$i] =~ s/xembed/embed/;
					$player = ("
						<FONT SIZE=3>$lst[0]</FONT><BR>
						$lst[$i]");
					$player =~ s/\n/ /g;
					$player =~ s/\"/\\\"/g;
				        #
				        $opt = "$so{'v'}_options.txt";
				        if(-e $opt)
				        {
				                @lst = LoadVars($opt);
				                if($so{'imageurl'} ne "")
				                {
				                        #
				                        $so{'imageurl'} =~ s/\/([^\.]*)\.[a-z]*$/\/thumb3\/th_$1.jpg/i;
	
				                        #
	                			        $IMGHTML = ("
								<A HREF=\"Javascript:ActivateVideo('video');\"
									class=dark>
<IMG src=\"$IMAGES_BASE/video_clip.gif\" border=0 align=middle> play video
								<BR>
				                                <IMG SRC=\"$so{'imageurl'}\" border=0 vspace=4 hspace=4>
								</A>
								<BR>
				                                        ");
				                }
				        }

					#
					$player =~ s/\</\\\</g;
					$player =~ s/\>/\\\>/g;
					$player =~ s/\"/\\\"/g;
					$player =~ s/\'/\\\'/g;
					$str = ("
                <script language=\"Javascript\">
                        function ActivateVideo(video_id)
                        {
                                vid = document.getElementById(video_id);
                                if(vid)
                                {
                                      vid.innerHTML = '$player';
                                }
                        }
                </script>

						");
				}
			}
		}
		else
		{
			$sz = "3";
			$str = "";
			for($i=0; $i<($#lst+1); $i++)
			{
				$str = ("$str\n$lst[$i]\n");
			}
		}
	}

	#
	$str3 = ("
<TABLE width=100% cellspacing=0 cellpadding=0
	bgcolor=#FFFFFF>
<TR valign=top>

<TD>

<FONT size=$sz color=#000000>
<A HREF=\"$URL\" class=dark>
<IMG src=\"$IMAGES_BASE/download.gif\" border=0 align=middle>
download video</A>
<!--- $so{'v'} --->
<TABLE cellspacing=0 cellpadding=0>
<TR>
<TD ID=video>
</TD>
</TR>
</TABLE>
$IMGHTML
$str
</FONT>

</TD>
</TR>
</TABLE>
");

	#
        $str3 =~ s/[\t\n\r\s]/ /g;
        $str3 =~ s/  / /g;
        $str3 =~ s/\"/\\\"/g;

	#
        print("  document.write(\"$str3\");  \n");

	#
}


