#!/usr/bin/perl
################################################################################
#
# TextOnly.pl - Text News Box. Called by textonly.pl.
# (C) 2006-2011 by Jari Tuominen (jari@vunet.world).
#
################################################################################
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ArticleViewerMonitor.pm";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
$DONT_AFFECT_DB = 1;
ArgLineParse();
if($ENV{'HTTP_HOST'} =~ /text\.vunet\.org/) {
	print("
<meta http-equiv=\"refresh\" content=\"0;url=http://www.vunet.world/textonly.pl?$ENV{'QUERY_STRING'}\"> 
		");
	exit;
}
if($ENV{'printable'} ne "") {
	$so{'printable'} = $ENV{'printable'};
	$so{'c'} = $ENV{'maara'};
	$so{'sec'} = $ENV{'osasto'};
}
if($so{'v'} ne "") {
	## Score this article view.
	ArticleViewerMonitor($so{'v'});
	PerArticleCounter( "$ENV{'DOCUMENT_ROOT'}/articles/$so{'v'}" );
}

#
main();

#
sub UrlParse
{
	my $reparsed1 = $_[0];
	$reparsed1 =~ s/^$ENV{'DOCUMENT_ROOT'}//; 
	$reparsed1 =~ s/^\/articles\///; 
	$reparsed1 =~ s/^kaikki\/\.\.\///; 
	$reparsed1 =~ s/^kaivos\/\.\.\///;
	return $reparsed1; 
}

################################################################################
#
sub main
{
		#
		if($so{'sec'} eq "")
		{
			if($ENV{'NW_LANGUAGE'} eq "fi")
			{
				$so{'sec'} = "kaikki";
			}
			else
			{
				$so{'sec'} = "progressive";
			}
		}
		if($so{'c'} eq "")
		{
			$so{'c'} = 10;
		}

		#
		if($so{'l'} eq "fi")
		{
			$urlopt = "&printable=2";
			$so{'c'} = 20;
		}
		#
		if($so{'c'} ne "" || $so{'sec'})
		{
		#	$urlopt = "&printable=2";
		}

		#
		@opt = (
			"democrats", "Democrats",
			"progressive", "Progressive",
			"global", "Global Warming",
			"kaikki", "Kaikki",
			"kummalliset", "Kummalliset"
			);

	#
	if($so{'printable'}==2)
	{
#		$PR2 = ("
#(Yhteystiedot alapuolella. Contact information follows after the content.)<BR>
#<BR>
#		");
	}

	
	#
	if($so{'printable'} eq "")
	{
		#
		print("
		<div align=center>

		<form action=\"$ENV{'REQUEST_URI'}\">
		<select name=\"sec\">
	");
			#
			for($i=0; $i<($#opt); $i+=2)
			{
				if($opt[$i+0] eq $so{'sec'}) { $sel="selected"; } else { $sel=""; }
				print("	
		<option value=$opt[$i+0] $sel>$opt[$i+1]</option>
				");
			}
			#
			print("
		</select>
		<select name=c>
		<option value=10>10</option>
		<option value=20>20</option>
		<option value=50>50</option>
		<option value=100>100</option>
		</select>
		
		<input type=submit value=ok>
		</form>
		</div>
		");
	}

		#
		$WID = "100%";


		#
		if($so{'printable'} eq "")
		{
			Caption("News / Uutisia / Nyheter / Nachrichten", $WID, "", "#004000", "Book Antiqua", 5,
					0, "$IMGBASE/fp/spectrogram1.png", "");
		}
		#
		if($so{'printable'} eq "")
		{
		print("
<A HREF=\"http://text.vunet.world/?v=&sec=$so{'sec'}&c=$so{'c'}&printable=1\" target=_blank>
> Printable version.
</A><BR>
			");
		}

		#
		if($so{'printable'} eq "")
		{
			if($so{'expand'} ne "all")
			{
			print("
	<A HREF=\"http://text.vunet.world/?v=&sec=$so{'sec'}&c=$so{'c'}&expand=all\">
	> Expand all articles.
	</A><BR>
				");
			}
			else
			{
			print("
	<A HREF=\"http://text.vunet.world/?v=&sec=kaikki&c=$so{'c'}&expand=\">
	< Minimize all articles.
	</A>
				");
			}
		}
		$FP = "finnish";
		ViewNewStuff($so{'sec'});
		print("
			<br>
			<DIV ALIGN=CENTER>
			$ENV{'PUBLISHER'}
			</div>
			");

		#
#		print("
#Jos haluat poistua postituslistalta.
#Ota yhteytt� meihin.
#<a href=\"http://www.vunet.world/contact.pl\">http://www.vunet.world/contact.pl</A><BR>
#
#If you wish to depart the mailing list.
#Please contact us.
#<A HREF=\"http://www.vunet.world/contact.pl\">http://www.vunet.world/contact.pl</A><BR>
#
#			");
}

################################################################################
#
sub ViewHL
{
	my (@art,$cap,$url,$c,$c2,$c3,$c4,$ast,$ast2,$TPR,$MAX,$CHRS,$lv,$str);

	#
	$CHRS = 60;

	#
	@art = LoadList("$_[0]");

	#
	$cap = substr($art[0], 0, 200);
	$cap =~ tr/[a-z���]/[A-Z���]/;
	if($so{'printable'} eq "1") { $cap =~ tr/[���]/[AOA]/; }
	$cap =~ s/<br>//gi;

	#
	#$url = UrlFix(BuildQuickUrl($_[0]));
	$str = "$ENV{'DOCUMENT_ROOT'}/articles/";
	$url = $_[0];
	$url =~ s/$str//;
	$url = "/".CapUrl($url, $cap);
	$url =~ s/kaikki\/\.\.\///;

	#
	if($so{'printable'} eq "")
	{
		$plussa = "+";
	}

	#
	#	<div>
	#	</div>
	my $reparsed1 = UrlParse($_[0]);
	##############<a href=\"http://www.vunet.world$url$urlopt\" class=\"blue\">
	if($so{'v'} ne $reparsed1 && $so{'expand'} ne "all")
	{
		if($plussa ne "")
		{
			print("
			<A HREF=\"http://text.vunet.world/?v=$reparsed1\&sec=$so{'sec'}&c=$so{'c'}#here\" class=\"blue\">
			$plussa
			</A>
				");
		}
		$lv = 0;
		$link_to = "http://text.vunet.world/?v=$reparsed1&sec=$so{'sec'}&c=$so{'c'}#here";
		if($so{'printable'} ne "")
		{
			$link_to = "$url";
		}

		print("
			<A HREF=\"$link_to\" class=\"blue\">
			<b> 
			$cap</b>
			</a><BR>
			");
	}
	else
	{
		$CHRS = 1000;
		$lv = 1;
		print("
		<a name=\"here\"></a>
		");

		print("
			<A HREF=\"http://text.vunet.world/?v=&sec=$so{'sec'}&c=$so{'c'}#here\" class=\"blue\">
			- <b> 
			$cap</b>
			</a><BR>
			");
	}

	#
	$MAX = $CHRS*3;

	#
	print("<font size=2>");
	$TPR = "";
	loop: for($c=1,$c2=0; $c<($#art+1); $c++)
	{
		#
		$ast = $art[$c];
		$ast =~ s/<br>/ - /gi;
		$ast =~ s/^\s- //g;
		$ast =~ s/(<.*>)//gi;
		$ast2 = $ast;
		$ast2 =~ s/\s//g;
		if($ast2 ne "")
		{
			if($c2==0) { $ast =~ s/^\s//; }
			$ast = substr($ast, 0, $MAX-$c2);
			$TPR = "$TPR$ast";
		#	print $ast;
			$c2 += length($ast);
			if($c2>=$MAX) { last loop; }
		}
	}
	if($so{'printable'} eq "1") { $TPR =~ tr/[������]/[AOAaoa]/; }

	#
	if(!$lv) { $TPR =~ s/(.{$CHRS}[\S]*)/$1<BR>/g; }
	if(!$lv) { $TPR =~ s/(.*)<br>$/$1/; }
	$TPR =~ s/\n//g;
	$TPR =~ s/\r//g;
#	$TPR =~ tr/[A-Z���]/[a-z���]/;
	if(!$lv) { print "$TPR..."; } else { print "$TPR"; }

	#
	print("
		</font><br>
		<font color=#808080>http://$ENV{'HTTP_HOST'}$url</font>
		");

	#
	print("
		<font size=-1>
		<P>	
		</font>
		");
}

################################################################################
#
sub ViewNewStuff
{
	my (@lst,$i,$i2,$col,$ii,$ii2,$ii3,$ii4,$fn,$ifn);

	#
	print("
$PR2

		<center>
		<table cellpadding=4 cellspacing=4 width=$WID
			bgcolor=\"\">
		");

	#
	@lst = "";
	$ifn = ("$ENV{'DOCUMENT_ROOT'}/articles/$_[0]/fileindex.txt");
	@lst = LoadList($ifn);
	$col = "";

	#
	#http://text.vunet.world/?v=&sec=kaikki&c=10&printable=1\&only_newest=1
	if($so{'only_newest'}==1)
	{
		$so{'c'} = 100;
		#print "Alla 24H sis�ll� julkaistut viimeisimm�t jutut!";
	}

	#
	tehty: for($ii=$#lst,$ii2=0,$cnt=0; $ii2<1000 && $cnt<$so{'c'}; $ii2++,$ii-=1)
	{
		#
		$fn = "$ENV{'DOCUMENT_ROOT'}/articles/$_[0]/$lst[$ii]";
		if( $so{'printable'}==1 && FileAge($fn)>=(60*60*24) ) { last tehty; }
		if( -e $fn && !($_[0] eq "kaikki" && ($fn=~/videos\//)) )
		{
			#
			print("
				<tr bgcolor=\"$col\">
				<td width=50% style=\"vertical-align: top;\">
				<font color=\"#000000\" size=3>
				");
			ViewHL($fn);
			print("
				</font>
				</td>
				");
			$cnt++;
		}
	}

	#
	print("	
		</table>
		</center>
		");
}

################################################################################
#
sub Caption
{
	#
	print("
		<table cellpadding=4 cellspacing=0 align=center width=$_[1] border=$_[6] bgcolor=$_[2]>
		<tr>
		<td>
		<center>
		<font color=\"$_[3]\" face=\"$_[4]\" size=\"$_[5]\">
		");
	if($_[8] ne "")
	{
		print("
			<img src=\"$_[8]\" alt=\"\" border=1>
			");
	}
	print("
		$_[0]
		</font>
		</center>
		</td>
		</tr>
		</table>

		");
}

