#!/usr/bin/perl
# Traffic monitor.
#
print "Content-type: text/html\n\n";
require "$ENV{'DOCUMENT_ROOT'}/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/ClicketyClick.pl";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
ClicketyClick();
