#!/usr/bin/perl
#############################################################################
# Version Rewrite 2022.
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use Encode;
use DateTime;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
require "./modules/settings.pm";
require "./modules/Logging.pm";
require "./modules/FixScands.pm";
require "./modules/EvalScore.pm";
require "./modules/AltseMenu.pm";
require "./modules/GetDBFileFromURL.pm";
require "./modules/BuildKeywordSuggestionsHTML.pm";
#
AltseOpenConfig();
#
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
if($ENV{'SERVER_NAME'}=~/vunet\.world/)
{
	print("
<meta http-equiv=\"refresh\" content=\"0; url=/nw/?FP_SECTION=finnish\">
		");
	exit;
}

#
$MAX_SAFE_PRECOUNT = 5000;
$MAX_SAFE_RESULTS = 500;
#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$so{'q'} =~ s/^\s+//g;

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\">
#        </iframe>
#</DIV>
#");

# Phases of Search.
if($so{'q'} ne "")
{
	InitSearch();
	DoSearch();
}

#
if($so{'iframe'} eq "") { PrintSearchForm(); 
}

if($so{'iframe'} eq "" && $so{'q'} ne "") { 
        #
        print "<DIV ALIGN=\"CENTER\"><H2>" . sprintf("%d",$#search_results+1) . " search result(s).</H2></DIV>";
        
        #
        $current_year_month_day = POSIX::strftime("%Y/%m/%d", localtime(time));
        $current_year_month = POSIX::strftime("%Y/%m", localtime(time));
        $current_year = POSIX::strftime("%Y", localtime(time));
        
        #
        print("
        <DIV ALIGN=\"center\">
        <H2>Rajaus, limit news:
        <A HREF=\"/?q=$so{'q'}&d=$current_year_month_day\">24H</A> - <A HREF=\"/?q=$so{'q'}&d=$current_year_month\">Monthly, kk</A> - <A HREF=\"/?q=$so{'q'}&d=$current_year\">Year, vuosi</A> - <A HREF=\"/?q=$so{'q'}\">All, kaikki</A>
        </H2></DIV>
        ");

        #
        $first_word = $so{'q'};
        $first_word =~ s/^(\S*)\s.*/$1/;
        #print $first_word;
        my $htmlcon1 = ("
        <H2>
<STRONG>Suggested Searches - Ehdotuksia</STRONG>
</H2>
	");
        $htmlcon1 .= BuildKeywordSuggestionsHTML($first_word);
        print $htmlcon1;
        print "<BR><BR>\n";

}

# VIEW ONLY THE SUGGESTIONS ON iframe=2 && q!="".
if($so{'iframe'} eq "2" && $so{'q'} ne "")
{
        #
        $first_word = $so{'q'};
        $first_word =~ s/^(\S*)\s.*/$1/;
        #print $first_word;
        my $htmlcon1 = BuildKeywordSuggestionsHTML($first_word);
        print $htmlcon1;
}

if($so{'q'} ne "" && ($so{'iframe'} eq "1" || $so{'iframe'} eq "")) {
	DisplaySearchResults();
} else
{
        if($so{'q'} ne "" && ($so{'iframe'} eq "1" || $so{'iframe'} eq ""))
	{
	##########################
	# Front Page.
	#
	my (@lst) = LoadList("$DB/download.log");
	@lst = reverse @lst;
	
	#      0          1                2                                                                      3   4
	# 1697178396 downloaded https://www.washingtonpost.com/politics/2023/10/01/supreme-court-new-term-ethics/ as was/www.washingtonpost.com//home/vai/db/www/was/www.washingtonpost.com/1.dump.gz
	my ($i);
	
	print("
	<DIV ALIGN=\"CENTER\">
	<TABLE width=\"1000\" bgcolor=\"#F0F0F0\">
	<TR>
	<TD>
	");
	
	$ENV{'HOME'} = "/home/vai";
	my @hostlist = LoadList("$DB/altse/bin/hostlist -p www|sort -g|");

	print("
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#E04040\">
	List of Websites - Sivustolista
	</FONT>
	</H1>
	</DIV>
	
	
	<TABLE>
	<TR>
	<TD>
	<P>
	<DIV ALIGN=\CENTER\">
	");
	
	for($i=0; $i<($#hostlist+1); $i++)
	{
		@sp = split(/\|/, $hostlist[$i]);
		
		$niceservername = $sp[1];
		$niceservername =~ s/^www[0-9]*\.//;
		
		print("
		<DIV style=\"display: inline-block; float: left; padding: 16px 4px 4px; width: 64; height: 32; font-size: 24px;\">
		<A HREF=\"/?q=$niceservername\">$sp[1]</A> 
		</DIV>
		");
	}
	
	#
	print("
	</DIV>
	</P>
	</TD>
	</TR>
	</TABLE>
	<BR>
	<BR>
	");
	
	
	print("
	
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#40E040\">
	New Content - Uutta Sisältöä
	</FONT>
	</H1>
	</DIV>
	");
	
	my (@sp,$timeint,$doctime);
	
	for($i=0; $i<10; $i++)
	{
		@splitted = split(/ /, $lst[$i]);
		
		#my $time = Time::Piece->strptime($sp[0], '%Y%m%d%H%M%S');
		          eval {
				$timeint = int($splitted[0]);
                                $doctime = DateTime->from_epoch( epoch => $timeint ); 
                     #           #strftime("%a %b %e %H:%M:%S %Y", $doctime);
                };
		#$timestr = POSIX::strftime("%Y/%m/%d", $doctime);
		#print $time->strftime('%Y-%m-%d-%H:%M:%S'), "\n";
		#my $ticks = time-$sp[0];
		#xmy $ticks_minutes = int($ticks/60)+1;
		$timestr = $doctime->strftime("%H:%M:%S %Y-%m-%d", $timeint);
		
		print("
		[$timestr] Downloaded <A HREF=\"/viewart/?url=$splitted[2]\">$splitted[2]</A>
			<BR>
		");
	  }
	}
	
	#
	print("
	</TD>
	</TR>
	</TABLE>
	</DIV>
	");
}

#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();

#
sub InitSearch
{
	@gl_reward_urls = LoadList("ranks/reward_urls.txt");
	@gl_reward_caps = LoadList("ranks/reward_caps.txt");
}

# Parameter: a single word of text.
sub SingleSearch
{
	my ($i,@lst,$con);

	#/db/fastdb/index/title/p/e/t/e
	
	my $chars = $_[0];
	$chars =~ s/^(.{1})(.{1})(.{1})(.{1}).*$/$1\/$2\/$3\/$4/;
	for(; length($chars)<4; ) { $chars = "$chars\_"; }

                my $keyword = $_[0];
                for(; length($keyword)<64; ) { $keyword="$keyword\_"; }
                $keyword =~ s/^(.{64}).*$/$1/;
                my $nextword = $_[1];
                for(; length($nextword)<64; ) { $nextword="$nextword\_"; }
                $nextword =~ s/^(.{64}).*$/$1/;
                if($nextword=~/^[_]*$/) {
                	$nextword = "*";
                }
	
	#$con = $con . $keyword . "," . $nextword;

	my $dir1 = "$DB/fastdb/index/$_[2]/$chars";
	if(-e $dir1)
	{
		my $find1 = "find $dir1 -name '$keyword,$nextword\.txt' -type f -printf \"%1.8s %p\n\" 2>/dev/null|";
		$con .= "<H1>" . $#find1+1 . "</H1>\n";
	
		my @lst = LoadList($find1);
		
		if($#lst == -1)
		{
			# No results, Retrying...
			# Fail back and optimization for single keyword search.
			$nextword = "*";

			my $find1 = "find $dir1 -name '$keyword,$nextword\.txt' -type f -printf \"%1.8s %p\n\" 2>/dev/null|";
			my @lst = LoadList($find1);
			if($#lst==-1)
			{
				#die "oh my";
				# Okay, giving up, it is empty result.
				goto past;
			}
		}
		
		@lst = sort @lst;
		@lst = reverse @lst;
		#print @lst;
	
		for($i=0; $i<($#lst+1); $i++)
		{
	 		#$con .= "<H1>$lst[$i]</H1>";
			my @spp = split(/\s/, $lst[$i]);
			if($spp[0] > 0 && $spp[1] ne "" && -e $spp[1])
			{
				my @res = LoadList("tail -n 1000 $spp[1]|");
				if($#res >= 2)
				{
					my $strcon = join("\n", @res);
					$strcon = FixScands($strcon);
					$con = "$con$strcon";
					$con =~ s/\r\n/\n/g; 
				}
			}
		}
	}
	
past:
	#
	return $con;
}

#
sub SearchFor
{
	my (@sp,$con,$i);
	
	@sp = split(/\s/, $_[0]);
	#print $_[0];
	
	#print $#sp+1 . " arguments\n";
	
	$con = "";

	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i+0] ne "")
		{
			$con .= SingleSearch($sp[$i], $sp[$i+1], "description");
			$con .= SingleSearch($sp[$i], $sp[$i+1], "title");
			$con .= SingleSearch($sp[$i], $sp[$i+1], "keywords");
		}
	}
	return $con;
}

#####################################################################################################
# VAI.News CGI CODE.
# (C) 2022 Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub PrintSearchForm
{
	#
	my $HTML_MENU = AltseMenu();


	#
	print("
$HTML_MENU

<TABLE width=\"100%\" align=\"center\" bgcolor=\"black\"
	cellpadding=\"24\" cellspacing=\"0\">
<TR><TD>
	");
	
	################
	#
	# LOAD UP THE ALTSE's Search log slog.txt.
	#	
	
	#
	if($so{'q'} ne "")
	{
		$BOYLOGOWIDTH = int(450/2);
		$BOYLOGOHEIGHT = int(300/2);
		$REDCAP = "";
	}
	else
	{
		$BOYLOGOWIDTH = int(350/1.25);
		$BOYLOGOHEIGHT = int(350/1.25);
		$REDCAP = ("
<A HREF=\"/\"><H1>		
<H1>VAI.News talousuutishaku - VAI.News economic news search:</H1>
<H2>Hae vaihtoehtoisia talousuutisia täältsuomeksi ja englanniksi 
- Search In Both Finnish And English </H2></A>

");
	}
	$SEARCH_FORM_HTML = ("
<CENTER>
<FONT style=\"color: WHITE; font-size: 24px;\">

<!---<FORM method=\"get\" action=\"/?\">--->

<!-------
<TABLE style=\"position: absolute; display: block;\" width=\"250\" height=\"32\" bgcolor=\"#D0D0F0\">
<TR>
<TD>
	<A HREF=\"/Vaihtoehtouutiset Artificial Intelligence/\">Mit&auml; kuuluu?</A>
</TD>
</TR>
</TABLE>
---------->
<TABLE WIDTH=\"100%\" bgcolor=\"#FFFFFF\">
<TR>
<TD>

<DIV ALIGN=\"CENTER\">
<A HREF=\"/top20/\">
<DIV STYLE=\"display: block; align: left;\">
<IMG SRC=\"/images/vainews.jpg\" title=\"Altse-haku\" alt=\"Vaihtoehtouutiset Artificial Intelligence\"
	width=\"$BOYLOGOWIDTH\" height=\"$BOYLOGOHEIGHT\">
</DIV>
<P><FONT STYLE=\"color: BLACK;\">
	&#128513; Pohjautuu tekoälyn pioneerin Vaihtoehtouutiset Artificial Intelligencehyn- Based On The A.I. Pioneer Vaihtoehtouutiset Artificial Intelligence.

</FONT></P>
</A>
</DIV>

</TD>
</TR>
</TABLE>

$REDCAP

<!-----
<INPUT TYPE=\"Text\" Id=\"q\" Name=\"q\" Value=\"$so{'q'}\"
	style=\"font-size: 24px;\">
<INPUT TYPE=\"Submit\" name=\"\" value=\"Hae\" target=\"_blank\">
</FORM>
------------->

</FONT>
</CENTER>
	");
	
	#
#	@trends = LoadList("/usr/bin/perl ./trends|");
#	for($i=0; $i<($#trends+1) && $i<100; $i++)
#	{
#		$key = $trends[$i];
#		$key =~ s/^([0-9]+\s)(.*)$/$2/;
#		print("<DIV ALIGN=\"LEFT\"><A HREF=\"/?q=$key\">$key</A></DIV>");
#	}
	
	#
	
	if($so{'q'} eq "")
	{
        $SEARCH_FORM_HTML .= ("
        <script language=\"javascript\">
        document.getElementById('q').focus();
	</script>
	");
	}


	
	#
	if($so{'q'} eq "")
	{
		# SEARCH FORM
		print("
$SEARCH_FORM_HTML

$HTML_TOP500

	");
	}
	else
	{
		#
		LogThisSearch();
		#
		print("

$SEARCH_FORM_HTML
<BR>
<FONT STYLE=\"color: WHITE;\">
<DIV ALIGN=\"CENTER\"><H2>Tulokset haulle - Search Results: \"$so{'q'}\".</H2></DIV>
<DIV ALIGN=\"center\">
<IMG SRC=\"/images/400px-P_newspaper.svg.png\"
	alt=\"Hakutulokset: $so{'q'}\"
	title=\"Hakutulokset: $so{'q'}\"
	width=\"100\" height=\"82\">
</DIV>
</FONT>
	");


	}
	




	
	#
	print("
</TD>
</TR>
</TABLE>
	");
}

#
sub DoSearch
{
		$so{'q'} =~ s/[\s\.](com|net|org|xyz|online)$//;
		$so{'q'} =~ s/^www[\s]+//;
		$so{'q'} =~ s/http[s]*//g;
		## Nice the query.
		$so{'q'} =~ s|<.+?>||g;;
		$so{'q'} =~ s/[\|]/ /g;
		$so{'q'} =~ s/^\s//;
		$so{'q'} =~ s/\s$//;
		$so{'q'} = lc $so{'q'};
		$so{'q'} =~ s/[^a-zA-ZäöåÄÖÅ0-9]/ /g;
		#print "\"" . $so{'q'}  ." \"\n";
		## SEARCH - RESULTS
		my $res = SearchFor($so{'q'});
		$res =~ s/\n\n/\n/g;
		my @results = split(/\n/, $res);
		my @spam_caps = LoadList("cfg/spam_caps.txt");
		my @spam_urls = LoadList("cfg/spam_urls.txt");
		#print @spam;
		
		#
		loop: for($i=0; $i<($#results) && $i<$MAX_SAFE_PRECOUNT; )
		{
			#$results[$i+0] =~ s|<.+?>||g;
			# Last loop on empty URL.
			if($results[$i+0] eq "")
			{
				goto past;
			}
			$results[$i+1] =~ s|<.+?>||g;
			$results[$i+2] =~ s|<.+?>||g;
			$results[$i+1] = encode 'iso-8859-1', $results[$i+1];
			$results[$i+2] = encode 'iso-8859-1', $results[$i+2];
			$results[$i+1] = FixScands($results[$i+1]);
			$results[$i+2] = FixScands($results[$i+2]);
			$results[$i+1] =~ s/[^a-zA-ZäöåÄÖÅ0-9\-\+,\/:;\&\.\'\"\#\%\&ǁ\$\€\£]/ /g;
			$results[$i+2] =~ s/[^a-zA-ZäöåÄÖÅ0-9\-\+,\/:;\&\.\'\"\#\%\&ǁ\$\€\£]/ /g;
			my $host = $results[$i+0];
			$host =~ s/^http[s]:\/\/([^\/]+).*$/$1/;

			my $doctime = $results[$i+2];
			$doctime =~ s/^.*ǁ([0-9]*).*$/$1/;
			$results[$i+2] =~ s/^(.*)ǁ.*$/$1/;
			$results[$i+2] =~ s/^([^\'\"]+)[\"\'].*$/$1/;

			if( int($doctime) > 0 )
			{
				eval {
				$doctime = DateTime->from_epoch( epoch => $doctime ); 
				#strftime("%a %b %e %H:%M:%S %Y", $doctime);
				};
			}
			else
			{
				$doctime = "";
			}
			$results[$i+2] =~ s/^(.*)ǁ[0-9]+.*$/$1/;
			
			if($results[$i+2] =~ /^http[s]*:\/\//)
			{
				$results[$i+2] = "";
			}
			
			my $cap = $results[$i+1];	
			$cap =~ s/^\s*//g;
			$cap =~ s/\s*$//g;
			
			
			for($ii=0; $ii<($#spam_caps+1); $ii++)
			{
				if($spam_caps[$ii] ne "" && $cap =~ /$spam_caps[$ii]/) {
					goto past;
				}
			}

			for($ii=0; $ii<($#spam_urls+1); $ii++)
			{
				if($spam_urls[$ii] ne "" && $results[$i+2] =~ /$spam_urls[$ii]/) {
					goto past;
				}
			}

			if( !($cap =~ /^http[s]*:\/\//) && !$alcap{$cap} && !$alurl{$results[$i+0]}
				&& ($so{'d'} eq "" || $results[$i+0]=~/$so{'d'}/i) )
			{
				#print "<H1>$so{'d'} - $results[$i+0]</H1>\n";
				my $trimcap = $cap;
				$trimcap =~ s/^(.{200}).*$/$1 .../;
				
my $score = EvaluateScoreForSearchResultEntry("$results[$i+0]|$trimcap|$results[$i+2]|$host|$doctime");
				
				push(@search_results, (sprintf "%1.8d", $score) . "|$results[$i+0]|$trimcap|$results[$i+2]|$host|$doctime");

				$alcap{$cap}++;
				$alurl{$results[$i+0]}++;
			}

past:
			$i++;
			for(; $i<($#results+1) && !($results[$i+0] =~ /^http[s]*:\/\//); $i++)
			{
			}
		}
		
		#
		print("
</FONT>
		");
}

#
sub DisplaySearchResults
{
	@search_results = sort @search_results;
	@search_results = reverse @search_results;
	#
	if($so{'max'} eq "") {
		$so{'max'} = 999999;
	}
	for($i=0; $i<($#search_results+1) && $i<$so{'max'} && $i<$MAX_SAFE_RESULTS; $i++)
	{
		PrintSearchResult($search_results[$i]);
	}
}

#
sub PrintSearchResult
{
	my @sp = split(/\|/, $_[0]);
	
	my $i;
	my @keys = split(/\s/, $so{'q'});
	my $nicecap = $sp[2];
	$nicecap = FixScands($nicecap);
	for($i=0; $i<($#keys+1); $i++)
	{
		#$keys =~ s/ä/\.\*/g;
		#$keys =~ s/ö/\.\*/g;
		if($nicecap ne "")
		{
			$nicecap =~ s/($keys[$i])/<b><font style=\"color: blue;\">$1<\/font><\/b>/gi;
		}
	}
	
	#
	my ($dbfilefn);
	if( ($dbfilefn = GetDBFileFromURL($sp[1])) )
	{
		#
	}

	#
	print("
				<H1><A HREF=\"/viewart/?url=$sp[1]\" target=\"_blank\">$nicecap</A> </H1>
				<H3 style=\"color: #C00000;\">$sp[3]  rank ".sprintf("%d",$sp[0]),"</H3>
				");
				# Host
				if($sp[4] ne "")
				{
					print("
<H3 style=\"color: #808040;\"><A HREF=\"/?q=$sp[4]\" target=\"blank\">Hae / Search: $sp[4]</A></H3>
					");
				}
				if($sp[5] ne "")
				{
					print("
				<H3 style=\"color: #00C000;\">$sp[5]</H3>
					");
				}
				print("
				<BR>
				");
}

1;
