#!/usr/bin/perl
################################################################################################################
# quickbar.pl
#
# Pink link bar on top of all Vaihtoehtouutiset.info -pages.
# Javascript version.
################################################################################################################

#
require "./tools.pl";

#
#print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'>/home/vai/public_html/cgi-bin/qbar.log');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$valipalkin_vari = "404040";

#
require "./QBAR_sections.pl";

#
main();

#
sub VunetNewsLogo
{
	my ($i,$i2,@lst,$str,$MSG);

	#
	$bg = "/images/vunetlogo.jpg";

	#
        if(-e "iplist.txt")
        {
                @lst = LoadList("iplist.txt");
        }

        #
        $i = $#lst+1;

	# English
	$MSG = "different visitors since";
        #
        if($ENV{'NW_LANGUAGE'} eq "en" || $ENV{'NW_LANGUAGE'} eq "")
        {
                # English
                $MSG = "different visitors since";
        }
        if($ENV{'NW_LANGUAGE'} eq "fi")
        {
                # Finnish
                $MSG = "eri k�vij��, laskenta aloitettu";
        }
        if($ENV{'NW_LANGUAGE'} eq "nl")
        {
                # Dutch
                $MSG = "verschillende bezoekers sinds";
        }
        if($ENV{'NW_LANGUAGE'} eq "se")
        {
                # English
                $MSG = "unika bes�kare sedan";
        }

	#
	$g = GoogleAd();

	#
	return ("
<!---- VUNET NEWS LOGO ---->
<DIV class=\"opac50\">
<table cellpadding=0 cellspacing=0 border=0 height=192 width=$w bgcolor=\"#FF8080\">
<tr valign=top>
<td>
</td>
</tr>
</table>
</DIV>

<table cellpadding=0 cellspacing=0 border=0 width=$w bgcolor=\"#FFFFFF\">
<tr valign=top>
<td>


<FONT FACE=\"Times Roman\">
<!--- FIRST TABLE ---->

<script language=\"Javascript\" type=\"text/javascript\">
function clickHandle1(e,url)
{
	window.location.href = url;
}
</script>

<table width=$w height=8
style=\"vertical-align: top;\" cellpadding=\"0\" cellspacing=\"0\"
        background=\"$IMAGES_BASE/bg2.gif\">
        <tr valign=top>
        <td>
        </td>
        </tr>
</table>

<table width=$w height=96
	onClick=\"Javascript:clickHandle1(this, 'http://vunet.world/');\"
	class=portal_logo_area
	cellspacing=0 cellpadding=0
	background=\"$bg\">
<tr valign=top>

<TD width=25%>
</TD>


<TD width=75%>

<DIV ALIGN=LEFT>
<FONT COLOR=YELLOW size=1>
<BR>
<BR>
<BR>
$i $MSG 1.6.2006
</FONT>
</DIV>

</TD>

</tr>
</table>

<table width=$w height=8
style=\"vertical-align: top;\" cellpadding=\"0\" cellspacing=\"0\"
        background=\"$IMAGES_BASE/bg2.gif\">
        <tr valign=top>
        <td>
        </td>
        </tr>
</table>

	");
}

################################################################################################################
#
sub ShowJsSS
{
	my ($i,$i2,$i3,$i4,$str,$str2,$big,$menu,@sp,$splitted_menu,@sp_menu);

	# @subs :
	#	"puolueet",
	#	"SHP:tausta5",
	#	"http://shp.vunet.world/",
	#	"icon_socialist.gif",
	#	...
	#	"*","*","*",

	#
	@sp_menu = split(/.{20}/, $menu);

	#
	$splitted_menu = "\"\"";
	for($i=0; $i<($#sp_menu+1); $i++)
	{
		$splitted_menu = "$splitted_menu, \"$sp_menu[$i]\"";
	}

	#
	loop: for($i=0; $i<($#subs+1); $i++)
	{
		if($subs[$i] eq $_[0]) { last loop; }
	}

	#
	$menu = (" <FONT COLOR=YELLOW><H2>$subs[$i+0]</H2></FONT> ");
	$i++;
	loop2: for(; $i<$#subs; $i+=3)
	{
		$IMG = "";
		if($subs[$i+2] ne "")
		{
			$IMG = "<IMG SRC=$IMAGES_BASE/$subs[$i+2] border=0 align=middle>";
		}
		@sp = split(/\:/, $subs[$i]);
		if($subs[$i+0] eq "*") { last loop2; }
		$menu = ("$menu
<A HREF='http://www.vunet.world/?to=$subs[$i+1]' class=yellow>
$IMG
$sp[0]</A>
<BR>
");
	}

	$menu =~ s/\n/ /g;
	$menu =~ s/\'/\\\'/g;
	$menu =~ s/\"/\\\"/g;

	#
	$str = ("$str

<DIV id=\"div_$_[0]\" style=\"position: absolute;\">
<TABLE WIDTH=150 HEIGHT=0 cellspacing=0 cellpadding=1
	class=plain_hidden_window
	id=\"table_$_[0]\"
	onClick=\"Javascript:WindowPop_$_[0]();\">
<TR>
<TD>
<TABLE WIDTH=150 HEIGHT=0 cellspacing=0 cellpadding=2
	bgcolor=#C00000>
<TR valign=top>
<TD id=\"td_$_[0]\">
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</DIV>

<SCRIPT LANGUAGE=\"Javascript\">
var closed_$_[0]=1;
var ok_$_[0]=1;
function WindowPop_$_[0]()
{
	if(ok_$_[0]!=0)
	{
		$ok_$_[0]=0;
		if(closed_$_[0])
		{
			ShowSubSection_$_[0]();
		}
		else
		{
			HideSubSection_$_[0]();
		}
		setTimeout('$ok_$_[0]=1;', 500);
		closed_$_[0]=1-closed_$_[0];
	}
}

function ShowSubSection_$_[0]()
{
	t = document.getElementById('table_$_[0]');
	t.style.visibility = 'visible';
	t.style.background = \"#000000\";
	td = document.getElementById('td_$_[0]');
	td.innerHTML = $splitted_menu;
	td.style.background = \"#A00000\";
}
function HideSubSection_$_[0]()
{
	t = document.getElementById('table_$_[0]');
	t.style.visibility = 'hidden';
}
</SCRIPT>

");

	#
	return $str;
}

################################################################################################################
#
sub RenderLinkBar
{
	my ($i,$i2,$i3,$i4,$str,$str2,$big);
	#
	$i2 = sprintf "%d", (1000/($#bar+1));
	$tw = $i2*($#bar+1);
	$sepw = $tw;

	#
$big = ("$big

<TABLE width=100% height=16
	cellspacing=0 cellpadding=0>
<TR valign=top>
<TD>


<DIV ALIGN=CENTER>

<!---- QBAR MENU TABLE ---->

<TABLE width=100% cellspacing=0 cellpadding=4>
<TR>

");

	#
	for($i=0,$x=0; $i<$#bar; $i+=3,$xx++,$x+=100)
	{
		@sp = split(/\:/, $bar[$i+0]);
		if($sp[1] eq "") { $sp[1]="#C0C0C0"; }

		#
		if($bar[$i+1]=~/^http:\/\//)
		{
			$turl = "$bar[$i+1]";
			$js = "";
			$pull = "";
		}
		else
		{
			$turl = "Javascript:WindowPop_$bar[$i+1]();";
			$js = ShowJsSS("$bar[$i+1]");
			$pull = "<IMG SRC=\"$IMAGES_BASE/pull_down.gif\" class=bulletin border=0>";
		}

		$IMG = "";
		if($bar[$i+2] ne "" && $bar[$i+2]=~/\.gif$/)
		{
			$IMG = ("
			<img src=\"$IMAGES_BASE/$bar[$i+2]\" align=\"middle\" vspace=0 hspace=0 border=1
				alt=\"icon\" title=\"$sp[0]\" class=bulletin1>
				");
		}

		$y = 0;
		$c = "qbar";
		if(!($bar[$i+2]=~/\.gif$/) )
		{
			$c = $bar[$i+2];
		}

		# HTTP://....
		$big = ("$big

<TD background=\"$IMAGES_BASE/$sp[1]\">

$js

<DIV ALIGN=CENTER>
<font><a href=\"$turl\" class=$c>$pull $IMG $sp[0]</a></font>
</DIV>


</TD>
	<!--- $IMG $pull --->


		");

		#
	}

	#
	$g = Google();

	#
	$big = ("$big
<TD background=\"$IMAGES_BASE/black.gif\" width=46>
<DIV ALIGN=RIGHT>
<IMG SRC=\"$IMAGES_BASE/tinygoogle.gif\">
</DIV>
</TD>
<TD background=\"$IMAGES_BASE/black.gif\" width=145>
$g
</TD>

</TR>
</TABLE>

</DIV>


		</TD>	
		</TR>
		</TABLE>

		</TD>	
		</TR>
		</TABLE>


<!--- 1 PX BLACK LINE --->
<TABLE width=$w height=1 cellspacing=0 cellpadding=0 bgcolor=$valipalkin_vari>
<TR>
<TD>
</TD>
</TR>
</TABLE>
<!--- END OF QUICK BAR --->
");

	#
	return $big;
}

################################################################################################################
#
sub RenderNavBar
{
	my ($i,$i2,$i3,$i4,$str,$str2,$big,@lst,$fn);
	@langs = (
		"uutiset:black",
		"http://www.vunet.world/uutiset/",
		"finnish_flag.gif",

		"nyheter:black",
		"http://www.vunet.world/nyheter/",
		"swedish_flag.gif",

		"nieuws:black",
		"http://www.vunet.world/nieuws/",
		"dutch_flag.gif",

		"news:black",
		"http://www.vunet.world/news/",
		"english_flag.gif",
	);

	#
	$fn = "cfg/locals/qbar_$ENV{'NW_LANGUAGE'}.txt";
	if(-e $fn)
	{
		@lst = LoadList($fn);
	}

	#
	$str = ("
<TABLE width=100% cellspacing=0 cellpadding=0
	bgcolor=#000000>
<TR>
<TD>

<DIV ALIGN=CENTER>
<TABLE width=622 celspacing=0 cellpadding=0>
<TR>
<TD width=120>
<IMG SRC=\"$IMAGES_BASE/tiny_logo.gif\" border=0>
		");

	#
	$dis = " disabled";
	$bg = "#808080";
	$CGI = "/nw.pl";
	$script = "";
	if($ENV{'HTTP_REFERER'}=~/\/uutiset\// || $ENV{'HTTP_REFERER'}=~/\/nw\.pl/)
	{
		$CGI = "/nw.pl";
		$dis = "";
		$bg = "#000000";
	}
	if($ENV{'HTTP_REFERER'}=~/\/imgbank\.pl/)
	{
		$CGI = "/imgbank.pl";
		$dis = "";
		$bg = "#000000";
		$script = ("
<SCRIPT LANGUAGE=\"Javascript\">
document.getElementById('tamax').focus();
</SCRIPT>
");
	}

	#
	$str = ("
$str
</TD>
<TD width=422>
<FORM CLASS=FORMX action=\"http://www.vunet.world$CGI?\"
	id=form123 name=form123>
<INPUT TYPE=HIDDEN NAME=FP_SECTION value=\"finnish\">
<INPUT TYPE=HIDDEN NAME=section value=\"kaikki\">
<INPUT TYPE=HIDDEN NAME=l value=\"$so{'NW_LANGUAGE'}\">
<INPUT TYPE=TEXT NAME=q id=tamax size=56 STYLE=\"background: $bg; color: #FFFFFF;\"$dis>
<INPUT TYPE=SUBMIT value=\"$so{'w_find'}\"$dis>
$script
<BR>
		");

	#
	$sel=0;
	
	#
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\:/, $lst[$i]);

		if($ENV{'HTTP_REFERER'}=~/$sp[2]/)
		{
			$sel = $i;
		}

		$s = "";
		if($i==$sel)
		{
			$s = " checked";
		}

		$str = ("$str
<FONT COLOR=#FFFFFF>
<INPUT TYPE=RADIO NAME=where_to$s onClick=\"Javascript:document.location='$sp[1]';\"> $sp[0]
</FONT>
			");
	}

	#
	$str = ("$str
</FORM>
</TD>

<TD width=80>
");

	#
	$str = ("
	$str
<DIV align=center>
		");
	#
	for($i=0; $i<($#langs); $i+=3)
	{
		$str = ("$str
<A HREF=\"$langs[$i+1]\">
<IMG SRC=\"$IMAGES_BASE/$langs[$i+2]\" border=0>
</A>
				");
		if($i==3) { $str = "$str <BR> "; }
	}

	#
	$str = ("$str
</DIV>
		");

	$str = ("$str

</TD>
</TR>
</TABLE>
</DIV>

</TD>
</TR>
</TABLE>
		");

	#
	return $str;
}

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$big);

	#
	LoadVars("cfg/locals/$ENV{'NW_LANGUAGE'}.txt");

	#
	if( $ENV{'NW_LOGO_LANGUAGE'} eq "fi" ) { @items = @items_fi; $find = "haku"; }
	if( $ENV{'NW_LOGO_LANGUAGE'} eq "nl" ) { @items = @items_en; $find = "find"; }
	if( $ENV{'NW_LOGO_LANGUAGE'} eq "en" ) { @items = @items_en; $find = "find"; }
	if( $ENV{'NW_LOGO_LANGUAGE'} eq "se" ) { @items = @items_en; $find = "find"; }
	if( $ENV{'NW_LOGO_LANGUAGE'} eq "cn" ) { @items = @items_en; $find = "find"; }
#	if( $ENV{'HTTP_REFERER'} =~ /hanhi\.vunet\.org/ ||
#		$ENV{'HTTP_REFERER'} =~ /marx\.vunet\.org/ ||
#		$ENV{'HTTP_REFERER'} =~ /vene\.vunet\.org/ ||
#		$ENV{'HTTP_REFERER'} =~ /www\.vunet\.org\/galleria\.pl/ ||
#		$ENV{'HTTP_REFERER'} =~ /hannu\.vunet\.org/)
#	{
#		@items2 = @items2_hannu;
#	}

	#
	$big = "";

	#
	$w = $GLOBALW2;

	#
	$big = ("$big
<!--- START OF QUICK BAR: --->
		<DIV>

<!--- 1 PX BLACK LINE --->
<TABLE width=$w height=1 cellspacing=0 cellpadding=0 bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>
	");


		#
		$big = ("$big
<!--- START OF QUICK BAR PART 2: --->
		<DIV>

<!--- 1 PX BLACK LINE --->
<TABLE width=$w height=1 cellspacing=0 cellpadding=0 bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>
		");

	#
#	$big = ($big . RenderNavBar());

	#
	@bar = @items;
	$big = ($big . RenderLinkBar());

	#
	if( $ENV{'HTTP_REFERER'}=~/^http:\/\/www\.vaihtoehtouutiset\.info/)
	{
	}
		$big = ($big . VunetNewsLogo());

	#
	$big =~ s/[\t\r]/ /g;
	$big =~ s/  / /g;
	$big =~ s/\"/\\\"/g;
	@sp = split(/\n/, $big);

	#
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] ne "")
		{
			print("document.write(\"$sp[$i]\");\r\n");
		}
	}

	#
}

sub nothing
{
	print("
<!----		<TD width=20%>

		<table cellpadding=0 cellspacing=4 width=$w border=0>
		<tr align=top>

		<td>
		<div align=right>
		<form action=/saa.pl class=formx>
		<font size=2 color=#000000>
		S��tiedot:
		<select name=q onChange='this.form.submit()' class=saa>
		<option name= selected>Kaupunki ...</option>
		<option name=Jyv�skyl�>Jyv�skyl�</option>
		<option name=Turku>Turku</option>
		<option name=Tampere>Tampere</option>
		<option name=Lappeenranta>Lappeenranta</option>
		<option name=Kuopio>Kuopio</option>
		<option name=Oulu>Oulu</option>
		<option name=Pori>Pori</option>
		<option name=Helsinki >Helsinki</option>
		<option name=Vantaa >Vantaa</option>
		</select>
		</font>
		</form>
		</div>
		</td>
---->


	");

}

#
sub Google
{
	my ($str);
	
	#
	$str = ("
<DIV ALIGN=RIGHT>
<FORM method=\"get\" action=\"http://www.google.com/custom\" name=\"FORM1\" class=formx>
<input type=\"hidden\" name=\"sa\" value=\"Google+Search\">
<input type=\"hidden\" name=\"client\" value=\"pub-4178289363390566\">
<input type=\"hidden\" name=\"forid\" value=\"1\">
<input type=\"hidden\" name=\"ie\" value=\"ISO-8859-1&oe=ISO-8859-1\">
<input type=\"hidden\" name=\"domains\" value=\"www.vunet.world\">
<input type=\"hidden\" name=\"cof\" value=\"GALT%3A%23008000%3BGL%3A1%3BDIV%3A%23336699%3BVLC%3A663399%3BAH%3Acenter%3BBGC%3AFFFFFF%3BLBGC%3AE00000%3BALC%3A0000FF%3BLC%3A0000FF%3BT%3A000000%3BGFNT%3A0000FF%3BGIMP%3A0000FF%3BLH%3A50%3BLW%3A269%3BL%3Ahttp%3A%2F%2F$IMAGES_BASE%2Fvunet-a1_search1.gif%3BS%3Ahttp%3A%2F%2Fwww.vunet.world%3BFORID%3A1%3B\">
<input type=\"hidden\" name=\"hl\" value=\"en\">
<input type=\"hidden\" name=\"sitesearch\" value=\"www.vunet.world\">
<input type=\"hidden\" name=\"cmd\" value=\"go\">
<input type=\"text\" name=\"q\" size=\"15\" value=\"\" class=edit5>
<input type=\"submit\" value=\"$find\">
</FORM>
</DIV>
	");
}

#
sub GoogleAd
{
	my ($str);

	#
	$str = ("
	");

	#
	return $str;
}
