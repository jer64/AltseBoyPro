#!/usr/bin/perl

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();

#####################################################################################
#
sub EnvList
{
	foreach $key (sort(keys %ENV))
	{	
		print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
	}
}

#####################################################################################
#
sub main
{
	#
	print("
		<table width=600 cellpadding=0 cellspacing=0>
		<tr>
		<td>
		");

	#
	OPENTABLE("#FF0000");
	print("
		<center>
			<img src=\"$IMAGES_BASE/lenin.jpg\" border=1>

		<br>
		Vunet Information System
		</center>
		");

	#
	print("
		<h1>Error <b>$ENV{'REDIRECT_STATUS'}:</b>
		$ENV{'REDIRECT_ERROR_NOTES'}</h1>
		<br>

<TABLE cellpadding=8 cellspacing=0 width=100%>
<TR valign=top>
<TD>
<IMG SRC=\"$IMAGES_BASE/error_sign.gif\">
</TD>
<TD>
T�m� virhe on mahdollisesti vain pelkk� v�liaikainen juttu, kokeileppa esim. 30 sek p��st� uudestaan.<br>
<BR>
This error is possibly just temporary thing, please try again in approximately 30 seconds.<BR>
<BR>
</TD>
</TR>
</TABLE>
		");

	#
	if( NoTracking() )
	{
		EnvList();
	}

	#
        open($f, "|mail jari\@vunet.world -s \"[500] $ENV{'REDIRECT_REDIRECT_ERROR_NOTES'}.\"");
        print $f "HTTP ERROR 500\n";
        print $f "Client: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
        print $f "\n";
        foreach $key (sort(keys %ENV))
        {
                print $f "$key=\"$ENV{$key}\"\n";
        }
        close($f);

	#
	CLOSETABLE("#FF0000");

	#
	print("
		</td>
		</tr>
		</table>
		");
}
