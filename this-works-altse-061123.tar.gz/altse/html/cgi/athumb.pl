#!/usr/bin/perl
# article thumb - athumb.pl
##########################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
if( 
!($ENV{'HTTP_REFERER'} =~ /www\.vaihtoehtouutiset\.info/) 
&&
!($ENV{'HTTP_REFERER'} =~ /www\.vunet\.org/) 
&&
!($ENV{'HTTP_REFERER'} =~ /www\.kultakaivos\.info/) 
)
{
	exit;
}

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

##########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$opt);
	my @des=("down", "up");
	my @desimg=(
		"thumb_down.gif",
		"thumb_up.gif"
	);
	$so{'section'} =~ s/[^a-z]//g;
	$so{'id'} =~ s/[^0-9,]//g;
	my @s = split(",", $so{'id'});

	#
	if($ENV{'REMOTE_HOST'} =~ /googlebot\.com/)
	{
		die "No access suitable for googlebot.com.\n";
	}

	#
	print("
<TABLE WIDTH=100% CELLPADDING=32 CELLSPACING=0>
<TR>
<TD>
		");

	#
	if($s[0] eq "") { return(); }

	#
	$article_id = $s[0];
	$comment_id = $s[1];

	#
	print("
<H1>Your thumb has been added!</H2>

<IMG SRC=\"$IMAGES_BASE/$desimg[$so{'t'}]\" class=bulletin>
thumb $des[$so{'t'}]<BR>
<BR>
article ID: $article_id<BR>
		");

	#
	print("
</TD>
</TR>
</TABLE>
		");

	#
	$fn = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'section'}/pub_artikkeli$article_id.txt_thumbs.txt";

	#
	if(-e $fn)
	{
		@lst = LoadList($fn);
	}

	#
	$opt = $lst[0];
	$opt =~ s/intlfox//;
	$opt =~ s/^\s*//;
	$opt =~ s/\s*$//;
	$opt =~ s/\<[^\>]*\>$//g;

	#
	$str = $ENV{'REMOTE_ADDR'};
	$str =~ s/\./\\\./g;
	if($opt =~ /userid=$str/)
	{
		print "<H2>Et voi antaa peukkua omalle kommentillesi!</H2><BR>";
		goto back;
	}
	if($opt =~ /t?\,$str/)
	{
		print "<H2>Olet jo antanut peukun!</H2><BR>";
		goto back;
	}

	#
	$opt = "t$so{'t'},$ENV{'REMOTE_ADDR'} $opt";

	#
	open($f, ">$fn") || die "can't write options file!";
	print $f "$opt\n";
	for($i=1; $i<($#lst+1); $i++)
	{
		print $f "$lst[$i]\n";
	}
	close($f);

	#
        open($f, "|mail $PRIM_ADMIN_EMAIL -s \"Thumb up for article received.\"");
        print $f "New thumb $des[$so{'t'}] received.\n";
        if(!NoTracking())
        {
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
        }
        print $f "Article: http://www.vunet.world/article/$so{'section'}/story$article_id.html\n";
        print $f "Article number: $article_id\n";
        print $f "==========================================\n";
        print $f "Vaihtoehtouutiset Information System\n";
        print $f "http://vunet.world\n";
        close($f);


back:
	#
#	print("
#<META HTTP-EQUIV=\"Refresh\"
#      CONTENT=\"0; URL=/article/$so{'section'}/story$article_id.html\">
#");

	#
}


