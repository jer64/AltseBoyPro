#!/usr/bin/perl

#
if($ENV{'DOCUMENT_ROOT'} eq "")
{
        $ENV{'DOCUMENT_ROOT'} = "/home/vai/altse/html";
}

# See nw.pl search for the search functionality.
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$NW_MAX_CACHE_ITEM_AGE = (5);   # 60*2

#
main();

sub Cached
{
	my ($i,$i2,$i3,$i4,@lst,$fn,$str,$str2,$f,$age);

	#
	print "Content-type: text/html\n\n";
	# Send error messages to the user, not system log
	open(STDERR,'<&STDOUT');  $| = 1;

	#
	$ENV{'newswire_conset'} = "TRUE";

	#
	$str = $ENV{'QUERY_STRING'};
	$str =~ s/\?/\_/g;
	$str =~ s/[^a-z0-9\_]/\_/gi;
	$fn = "cache/newswire-$so{'section'}-$so{'FP_SECTION'}-$str-$ENV{'NO_TRACKING'}.asc";

	#
	$age = FileAge($fn);

	#
	if( -e $fn && $age<$NW_MAX_CACHE_ITEM_AGE )
	{
		#
	#	if( NoTracking() ) { print "Cached: $fn ($age/$NW_MAX_CACHE_ITEM_AGE)<br>\n"; }
	#	@lst = LoadList($fn);
	}
	else
	{
		#
	#	if( NoTracking() ) { print "REFRESHING.<br>\n"; }

		#
		@lst = LoadList("./nw.pl|");
		#
		if( open($f, ">$fn") )
		{
			for($i=0; $i<($#lst+1); $i++)
			{
				$lst[$i] =~ s/^\s*//;
				$lst[$i] =~ s/\s*$//;
				print $f "$lst[$i]\n";
			}
			close($f);
		}
	}

	#
#	for($i=0; $i<($#lst+1); $i++) { print STDOUT "$lst[$i]\n"; }
	system("cat $fn");
}

##################################################
sub main
{
	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	if($so{'FP_SECTION'} ne "" && $so{'section'} eq "")
	{
		Cached();
	}
	else
	{
		system "./nw.pl";
	}

	#
}

TRUE;

