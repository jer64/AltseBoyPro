#
#if(NoTracking())
#{
#$dbh = DBI->connect("DBI:Pg:database=vunet;host=127.0.0.1;", "root", "mango", {RaiseError => 0});
#$dbh = DBI->connect("dbi:SQLite:dbname=dbfile","","");

#$dbh = DBI->connect('DBI:mysql:vunet;host=localhost', 'root', 'VAI.News',
#	            { RaiseError => 0 }
#	           );

#}

true;
