#!/usr/bin/perl

#
require "admin.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "tietoa";

#
OpenWebIndex("$NWPUB_CGIBASE/webindex.html");
WebWalkTo("past-uusilogo2");
main();
HandleRest();

#################################################################################################
#
sub BuildDirHTML
{
	my $i,$i2,$i3,$i4,$isdir;

	#
	print("
		<font size=\"4\" face=\"fixedsys\">
		");

	#
	for($i=0; $i<($#dir+1); $i++)
	{
		#
		if( -d "./$dir[$i]" ) { $isdir=1; } else { $isdir=0; }

		#
		if($isdir)
		{
			print("
				<a href=\"$dir[$i]\">[$dir[$i]]</a><br>
				");
		}
		else
		{
			print("
				<a href=\"$dir[$i]\">$dir[$i]</a><br>
				");
		}
	}

	#
}

#################################################################################################
#
sub Invalid
{
	#
	print("
		<h1>INVALID REQUEST \"$where\"</h1>
		");
}	

#################################################################################################
#
sub main
{
	#
	$where = $ENV{'REQUEST_URI'};

	#
	if(!($where =~ /^\/dir/))
	{
		Invalid();
		return;
	}

	#
	opendir(IMD, $ENV{'REQUEST_URI'}) || die("Cannot open directory");
	@dir = readdir(IMD);
	closedir(IMD);

	#
	BuildDirHTML();
}

