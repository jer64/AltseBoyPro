#!/usr/bin/perl
###########################################################################################################################
# mp3machine.pl
###########################################################################################################################

#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

#######################################################################################################
#
sub LoadDesc
{
	my ($i,$i2,$i3,$i4,$str,$str2,@des,@sp,@sp2,@sp3,@lst,@lst2);
	# Important folders to import.
	my @imp=(
	"arab:arab",
	"Iraq:arab",
	"dprk2:dprk",
	"dprk2/Patriotic:dprk",
	"dprk2/Paek-du_san:dprk",
	"soviet:soviet",
	"soviet/mp3:soviet",
	"komt:misc",
	"antiwar:misc",
	"jari:misc",
	"psychology:misc",
	"hauskat:misc",
		);

	#
#	@des = LoadList("cfg/imgdesc.txt");

	#
	for($i=0; $i<($#imp+1); $i++)
	{
		#
		@sp = split(/\:/, $imp[$i]);

		#
		@lst2 = LoadList("find /home/public/public_html -maxdepth 3 -name '*.mp3' -type f|");

		#
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			$lst2[$i2] =~ s/^.*\/(.*)$/$1/;
			$des[$#des+1] = "$sp[0]/$lst2[$i2]=,$sp[1],";
			#print "$des[$#des]<BR>\n";
		}
	}

	#
	return @des;
}

######################################################################################################3
#
sub ConductSearch
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@des,@sp,@sp2,@sp3,@lst,@lst2,$p);

	#
	@sp3 = split(/\:/, $so{'q'});
	$str = $sp3[1];
	$str =~ tr/[A-Z���]/[a-z���]/;
	@keys = split(/\ /, $sp3[0]);

	#
	@des = LoadDesc();

	#
	@lst = LoadList("find /home/public/public_html/ -name '*.mp3' -type f -maxdepth 1|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] =~ s/^\/home\/public\/public_html\///;
	}

	#
	$str4 = "$str\_info";
	$info = $so{$str4};
	if($info ne "")
	{
		$full = $info;
		$full =~ s/\"/\\\"/;
		$full =~ s/\'/\\\'/;
		$prv = $info;
		$prv =~ s/^(.{75}\S*).*$/$1 . . . /;
		$prv =~ s/^(\S*)\s/<font color=#C00000>$1<\/font> /;
		$info = ("
<SCRIPT LANGUAGE=\"Javascript\">
function n1()
{
	document.getElementById('tahan').innerHTML='$full';
}
</SCRIPT>
<div align=justify>
<font face=arial size=3>
<b id=tahan>
	<A HREF=\"javascript:n1();\" class=dark>
	$prv (click here for more)
	</A>
</b>
</font>
</div>
");
	}

	#
	if($so{'r'} eq "") { $so{'r'} = "http://public.vunet.world/"; }
	else
	{
		if($so{'r'} ne "")
		{
			$so{'r'} =~ s/\^/\=/g;
			$so{'r'} =~ s/\~/\&/g;
			$so{'r'} = "http://www.vunet.world$so{'r'}";
		}
	}

	print("
		<TABLE width=100%>
		");

	#
	for($i=0,$cnt=0; $i<($#des+1) && $cnt<300; $i++)
	{
		#
		@sp = split(/\=/, $des[$i]);
		@sp2 = split(/\,/, $sp[1]);

		#
		$lst[$i] =~ s/^\///;
		$fn = $sp[0];
		if(!($fn=~/\.mp3$/)) { goto past; }
		if($fn=~/^[a-zA-Z0-9_\-\.������ ]*\.jpg$/)
		{
			#print "$fn<BR>";
			$tfn = "thumb/th_$fn";
		}
		else
		{
			$tfn = $fn;
			$tfn =~ s/^.*\/(.*)$/$1/;
			$p = $fn;
			$p =~ s/^([0-9a-zA-Z\-_]*)\/.*$/$1/;
			$tfn = "$p/thumbs/th_$tfn";
			#print "$tfn<BR>";
		}
		$afn = "/home/public/public_html/$fn";
		#
		$str2 = $fn;
		$str2 =~ s/\.jpg$//;
		$str2 =~ tr/[A-Z���]/[a-z���]/;
		for($i2=0; $i2<($#keys+1); $i2++)
		{
			if($keys[$i2] ne "" && $str2 =~ /$keys[$i2]/i)
			{
				goto match;
			}
		}
		if($sp2[1] eq $str)
		{
match:
			#
			if( !(-e $afn) ) { goto past; }

			#
			$txt = $fn;
			$txt =~ s/^.*\/(.*)$/$1/;
			$txt =~ s/^(.{30})(.*)$/$1.../;
			$sz = sprintf "%d", ((stat($afn))[7]/1024)+1;


			#
			if( ($cnt&3)==0 )
			{
				print("
				<TR valign=top>
					");
			}
			print("
<TD>
	<FONT SIZE=1>
	<A HREF=\"$so{'r'}$fn\">
	$txt
	</A>
<BR>
	$sz K
	</FONT>
</TD>
			");

			#
			if( ($cnt&3)==3 )
			{
				print("
				</TR>
					");

			}

			#
			$cnt++;
		}
past:
	}


	#
	if( ($cnt&3)!=3 )
	{
		print("
		</TR>
			");
	}

	#
	print("
		</TABLE>

		");

	#
}

######################################################################################################3
#
sub LinkBar
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,$bg,$width,@sp,$cnt,$per_line);
	my @items = (
		"Arab/Iraqi music",
		":arab",
		"find.gif",

		"DPRK music",
		":dprk",
		"find.gif",

		"Soviet",
		":soviet",
		"find.gif",

		"Other",
		":misc",
		"find.gif",

		"Images",
		"http://www.vunet.world/imgbank.pl",
		"find.gif",

		"Videos",
		"http://www.vunet.world/videos/",
		"find.gif",
	);

	#
	$per_line = 6;

	#
	$str = "";

	#
	$str = ("$str
<!--- START OF NAVIGATION BAR: --->
		<DIV>
		<TABLE cellpadding=0 cellspacing=0 width=100%
			bgcolor=#C00000
			height=32>
		<TR>
		<TD width=8%>
		<DIV align=center>
		<IMG SRC=\"$IMAGES_BASE/small_red_flag.gif\">
		</DIV>
		</TD>
		<TD width=92% valign=center>
		<DIV align=center>

<TABLE width=100% cellpadding=0 cellspacing=0>
");

	#
	$i2 = sprintf "%d", 800/($#items/3);

	#
	$pro = sprintf "%d", 75/($#items+1);

	#
	$width = 100;

	#
	for($i=0,$cnt=0; $i<$#items; $i+=3)
	{
		#
		if( ($cnt%$per_line)==0 )
		{
			$str = ("$str
			<TR valign=top>
			");
		}

		$str2 = "";
		if($str2 eq "") { $str2 = $ARTCAP; }
		if($str2 eq "") { $str2 = $so{'q'}; }
		if($str2 eq "") { $str2 = $so{'article'}; }

		@sp = split(/\ /, $items[$i+1]);
		$bg = "#C00000";
		if($str2 ne "")
		{
			loop: for($i2=0; $i2<($#sp+1); $i2++)
			{
				$str3 = $sp[$i2];
				if($str2 eq $str3)
				{
					$bg = "#00C0C0";
					last loop;
				}
			}
		}

		#
		if($items[$i+1]=~/^http:\/\//)
		{
			$url = "$items[$i+1]";
		}
		else
		{
			$url = "/mp3machine.pl?q=$items[$i+1]&r=$so{'r'}&l=$so{'l'}";
		}

		#
		$str = ("$str
<TD width=$width bgcolor=$bg
	onMouseOver=\"this.className='td_over_black';\"
	onMouseOut=\"this.className='';\"
	onClick=\"window.location='$url';\"
	height=20>
<DIV ALIGN=CENTER>
<IMG src=\"$IMAGES_BASE/$items[$i+2]\" class=bulletin border=0>
<FONT size=2 face=Times Roman color=#F0F000>$items[$i+0]</FONT>
</DIV>
</TD>
			");

		#
		if( ($cnt%$per_line)==($per_line-1) )
		{
			$str = ("$str
			</TR>
			");
		}

		#
		$cnt++;
	}

	#
	if( ($cnt%$per_line)==0 )
	{
		$str = ("$str
		</TR>
		");
	}

	#
	$str = ("$str
</TABLE>

		</DIV>
		</TD>


		</TR>
		</TABLE>
		</DIV>


<!--- END OF NAVIGATION BAR --->
");

	#
	return $str;
}

######################################################################################################3
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$l);

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	$so{'q'} =~ s/[^\.\:a-zA-Z������ \_\-]//g;

	#
	$l = $ENV{'NW_LANGUAGE'};
	if($so{'l'} ne "") { $l = $so{'l'}; }

	#
	$so{'imperialismi_info'} = "NATO - an aggressive military block of Capitalist countries. Its poisonous arrow is aimed against socialist countries and national-liberation movements in the world.";
	$so{'sosialismi_info'} = "Socialism - a social formation that appears following the collapse of capitalism as a result of the dictatorship of the proletariat. It is based on public property on the means of production. The public property stipulates the absence of antagonistic relations, exploiting classes. It abolishes national inequality, discrepancies between the city and the village, between mental and physical labor. In the Socialist society there are two friendly classes: workers and peasants. The relationship between the classes are characterized by mental and spiritual unity, friendship and cooperation. On the basis of the public property the development of national economy becomes planned which is absolutely impossible under capitalism. The material wealth is shared according to the socialist principles.";
	$so{'kapitalismi_info'} = "Fascism - is a political movement that appeared in capitalist countries under general crisis. It reflects the interests of the most reactionary and aggressive forces of imperialist bourgeoisie. When fascism comes to power it becomes a terrorist dictatorship of the most reactionary forces of monopolistic capital which is executed for the sake of capitalist regime preservation. The main characteristics of fascism are as follows: - extreme violence to suppress proletariat and other working people, - extreme anti-communism, - chauvinism, - racism, - wide application of state monopoly methods to control economy, - strict monitoring over private life of people.  Domestic policy under fascism is aimed at exploiting working people. Its foreign policy means imperialistic wars. In the center of fascist ideology there is an idea of military expansion, racial inequality, class harmony, leadership. One of the most striking features of fascist ideology is its yielding demagogy aimed at hiding its reactionary essence. At present we witness neo-fascist tendencies which become more and more active in decaying capitalist countries. Under deep crisis of capitalism neo-fascist forces are involved into all sorts of subversive activities trying to frighten the population.";
	$so{'taide_info'} = "Art is a special form of philosophy; the highest aesthetic ideal is expressed in the philosophy of the working class that struggles for Communist renovation of the world.";
	if($l eq "fi")
	{
		$etsi_kuvia = "etsi MP3sia";
		$kuvapankki = "MP3-KONE";
		$hae = "hae";
		$vain_taidetta = "100% taidetta ja agitaatiota";
		$fp = "finnish";
		$so{'dprk_info'} = "Pjongjangin v�est�luvun on arvioitu olevan noin 2.5 miljoonaa, kertoo japanilainen kuukausittain julkaistava lehti 'Is�nmaa'.";
	}
	#
	if($l eq "en")
	{
		$etsi_kuvia = "find MP3s";
		$kuvapankki = "MP3 MACHINE";
		$hae = "find";
		$vain_taidetta = "100% art and agitation only";
		$fp = "english";
		$so{'dprk_info'} = "Pyongyang's population is estimated at around 2.5 million, the Japan-based monthly \"Fatherland\" said in a recent issue.";
	}
	#
	if($l eq "se")
	{
		$etsi_kuvia = "find MP3s";
		$kuvapankki = "MP3 MACHINE";
		$hae = "find";
		$vain_taidetta = "100% art and agitation only";
		$fp = "swedish";
		$so{'dprk_info'} = "Pyongyang's population is estimated at around 2.5 million, the Japan-based monthly \"Fatherland\" said in a recent issue.";
	}

	#
	$s = "mp3machine$l";

	#
	OpenWebIndex("./webindex2.html");
	WebWalkTo("main-menu");
	print inc_menu($s, $fp);
	
	#
	WebWalkTo("ENTERHERE_SECTION");

	#
	if($so{'q'} eq "")
	{
		$so{'q'} = ":arab";
	}

	#
	print("

	<TABLE width=750 cellpadding=16 cellspacing=0>
	<TR>
	<TD>

	<TABLE width=100% cellspacing=0 cellpadding=0>
	<TR>
	<TD width=40%>
	<H2><b>$kuvapankki</b></H2>
	</TD>
	<TD width=60%>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as\";
google_ad_type = \"text_image\";
//2006-10-19: MP3MACHINE
google_ad_channel = \"9463574954\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
	</TD>
	</TR>
	</TABLE>
		");

	#
	$str = $so{'q'};
	if($str eq ".") { $str = ""; }

	#
	print LinkBar();

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR>
<TD WIDTH=50%>
<FORM action=/mp3machine.pl id=f>
$etsi_kuvia > <input type=text id=q name=q value=\"$str\">
<input type=submit value=$hae>
<input type=hidden name=r value=\"$so{'r'}\">
<input type=hidden name=l value=\"$so{'l'}\">
</FORM>
</TD>
<TD WIDTH=50%>
<DIV ALIGN=RIGHT>
$vain_taidetta
</DIV>
</TD>
</TR>
</TABLE>

<script language=\"Javascript\">
function sf()
{
	f = document.getElementById('q');
	f.focus();
}
sf();
</script>

		");

	#
	if($so{'q'} ne "")
	{
		ConductSearch();
	}

	#
	print("
	</TD>
	</TR>
	</TABLE>
		");

	#
        if( !NoTracking() && !isRobot($ENV{'REMOTE_HOST'}) )
        {
                #
                open($f, "|mail seuranta\@vunet.world $PRIM_ADMIN_EMAIL -s \"$ENV{'SERVER_NAME'}: MP3MACHINE-k�ynti $ENV{'REDIRECT_QUERY_STRING'} ($ENV{'REMOTE_HOST'})\"");
                print $f "Uusi k�vij� kuvapankissa osoitteesta:\n";
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
                foreach $key (sort(keys %ENV))
                {
                        print $f "$key=\"$ENV{$key}\"\n";
                }
                print $f "==========================================\n";
                print $f "Vaihtoehtouutiset Information System\n";
                print $f "http://vunet.world\n";
                close($f);
        }

	#
}


