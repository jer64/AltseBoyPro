#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
sub main
{
	#
	print ("

<br>
<br>

<center>
<h1>VAI-TV (record)</h1>

<!-- BEGIN GENERIC ALL BROWSER FRIENDLY HTML FOR NETSHOW V3 --> 
<OBJECT ID=\"MediaPlayer\"
classid=\"CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" 
codebase=\"http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=,1,52,701\" 
standby=\"Loading Microsoft Windows Media Player components...\"  
type=\"application/x-oleobject\"> 
<PARAM name=\"FileName\" value=\"http://82.103.200.47:8080\"> 
<EMBED type=\"application/x-mplayer2\"  
pluginspage=\"http://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/\" 
SRC=\"http://www.saunalahti.fi/~ehc50/temp/hologrammed.wmv\" 
name=\"MediaPlayer\" 
width=320 
height=240> 
</EMBED> 
</OBJECT> 

<br>
<br>

		");

	#
	system "echo \"visitor television\" >> television.txt";
}


