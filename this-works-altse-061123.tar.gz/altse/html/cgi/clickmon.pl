#!/usr/bin/perl

#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

##################################################
#
sub ClickMon
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,@lst2,@sp,
		$url,$url1,$host,$ip,$t,$shost,$w1,$w2,$w3);

	#
	@lst = LoadList("tail -n 2500 logs/redir.log|");

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		if(!($lst[$i]=~/msnbot\.msn\.com/) && !($lst[$i]=~/crawl/)
		&& !($lst[$i]=~/207\.46\.98\./) && !($lst[$i]=~/216\.143\.191\./)
		&& !($lst[$i]=~/65\.55\.246\./) )
		{
			$lst2[$i2++] = $lst[$i];
		}
	}

	#
	$w1 = "20%";
	$w2 = "40%";
	$w3 = "40%";

	#
	print("
			<DIV align=center>
				<FORM action=clickmon.pl name=f>
				<INPUT type=text name=q value=\"$so{'q'}\">
				<INPUT type=submit>
				</FORM>
			</DIV>
	");

	if($so{'q'} eq "")
	{
		print("
<SCRIPT language=\"Javascript\">
document.f.q.focus();
</SCRIPT>
			");
	}

	print("
			<table width=100% cellpadding=2 cellspacing=0>
			<tr valign=top>

			<td width=$w1 bgcolor=\"#F00000\">
			<div align=center><font size=3 color=\"#FFFFE0\">Time.</font></div>
			</td>

			<td width=$w2 bgcolor=\"#E00000\">
			<div align=center><font size=3 color=\"#FFFFA0\">Clicked URL.</font></div>
			</td>

			<td width=$w3 bgcolor=\"#D00000\">
			<div align=center><font size=3 color=\"#FFFF60\">Host.</font></div>
			</td>

			</tr>
			</table>
		");

	#
	$count = 500;
	if($so{'q'} ne "")
	{
		$count = 5000;
	}


	#
	for($i=$#lst2,$i2=0; $i>=0 && $i2<$count; $i--)
	{
		#
		@sp = split(" \& ", $lst2[$i]);

		#
		$url = $sp[3];
		$url1 = $url;
		$url =~ s/^(.{20}).*(.{20})$/$1...$2/;
		$t = POSIX::strftime("%H:%M:%S, %d.%m.%Y", localtime($sp[0]));

		#
		$host = $sp[2];
		if($host eq "") { $host = $sp[1]; }
		# Make short host.
		if($host=~/^[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*$/)
		{
			$shost = $host;
		}
		else
		{
			$shost = $host;
			$shost =~ s/^.*\.(.*\..*)$/$1/;
		}
		$host =~ s/^(.{20}).*(.{20})$/$1...$2/;
		if($so{'q'} ne "" && !($url =~ /$so{'q'}/))
		{
			goto skip;
		}
		if($host eq "vunet.world") { goto skip; }

		#
		if(($i2%10)==9)
		{
			print("
			<table width=100% cellpadding=0 cellspacing=0 height=2
				bgcolor=\"#AACCCC\">
			<tr valign=top>
			<td>
			</td>
			</tr>
			</table>
				");
		}

		#
		print("
			<table width=100% cellpadding=2 cellspacing=0>
			<tr valign=top>

			<td width=$w1 bgcolor=\"#F0F0FF\">
			<div align=center>
			<font size=1>$t</font>
			</div>
			</td>

			<td width=$w2 bgcolor=\"#F0FFF0\">
			<font size=1><a href=\"$url1\" class=news2 target=\"_blank\">$url</a></font>
			</td>

			<td width=$w3 bgcolor=\"#FFF0F0\">
			<font size=1>$host
			<a href=\"/whois.pl?t=$shost\" target=\"_blank\">[?]</a>
			</font>
			</td>

			</tr>
			</table>
			");

		#
		$i2++;
skip:
	}

	#
	print("
		<BR>
		$i2 items found.<BR>
		");
}

##################################################
#
sub main
{
	#
	print("
			<table width=640 cellpadding=32 cellspacing=0>
			<tr>
			<td>
		");

	#
	ClickMon();

	#
	print ("
			</td>
			</tr>
			</table>
		");

	#
}


