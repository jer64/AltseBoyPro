#!/usr/bin/perl
#############################################################################
# PUBLISHING/COMMENTING SCRIPT.
# (C) 2004 by Jari Tuominen.
# Updated 6:17 24.2.2004.
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "admin.pl";

#######################################################
# Go to main loop.
#
main();


