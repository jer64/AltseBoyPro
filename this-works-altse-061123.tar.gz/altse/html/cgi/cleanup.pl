#!/usr/bin/perl
#
require "tools.pl";

#
$IP_REM = "217.122.6.149";

#
main();

#
sub ProcessFile
{
	my ($i,$i2,$str,$str2,@lst,$f,$f2);

	#
	if(-e $_[0])
	{
		@lst = LoadList($_[0]);
	}
	else
	{
		return;
	}

	#
	$str = $IP_REM;
	$str =~ s/\./\\\./g;
	#
	if($lst[0] =~ /$str/)
	{
		print "IP $IP_REM detected at $_[0]\n";
	}
	#
	$lst[0] =~ s/t[0-1]\,$str//g;
	$lst[0] =~ s/^\s*//g;
	$lst[0] =~ s/\s*$//g;
	
	#
	open($f, ">$_[0]") || die "can't write $_[0]\n";
	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print $f "$lst[$i]\n";
	}
	#	
	close($f);

	#
}

#
sub main
{
	my ($i,$i2,$str,$str2,@lst);

	#
	@lst = LoadList("find -name 'pub_artikkeli*.txt_comment*.txt'|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		ProcessFile($lst[$i]);
	}

	#
}
