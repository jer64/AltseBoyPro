#!/bin/bash
cp -i new_fileindex.txt fileindex.txt
