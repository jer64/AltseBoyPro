#!/usr/bin/perl

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
sub main
{
	#
	print("Paivitys menossa (kaikki) ... <br>");
	system "bash ./cacheupd2.sh";
	system "bash ./up2b.sh"; 
	print("<br>Tehty.<br>");
}

