#!/usr/bin/perl
#
# Generate Top Ten List.
#
##############################################################################################################

#
require "tools.pl";

#
chdir("/home/vai/cgi");

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@ipl,$i,$i2,$i3,$i4,$str,$str2);

	#
	chdir("/home/vai/public_html/cgi");

	#
	print "Browsing articles ... ";
	@lst = LoadList("find /home/vai/public_html/articles -name '*.counter' -type f|");
	print "\n";

	#
	print "Checking counter files ... \n";
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		printf "%6d / %6d    \r", $i,$#lst;

		#
		$str = $lst[$i];
		$str =~ s/^articles\///;
		$str =~ s/.counter$//;
		#
		@ipl = LoadList($lst[$i]);
		$ch[$i2++] = sprintf("%1.8d $str", $#ipl+1);
		for($i3=0; $i3<($#ipl+1); $i3++)
		{
			$key = $ipl[$i3];
		#	print STDERR "$key\n";
			$gipl{$key}++;
		}
	}
	print "\n";

	#
	@ch = sort @ch;
	@ch = reverse @ch;

        #
	print STDERR "Generating 'topten.txt' ... \n";
	open($f, ">/home/vai/public_html/cgi-bin/topten.txt") || die "can't write file (1)";
	for($i=0; $i<($#ch+1); $i++)
	{
		print $f "$ch[$i]\n";
	}
	close($f);

	#
	print STDERR "Generating 'iplist.txt' ... \n";
	open($f, ">/home/vai/public_html/cgi-bin/iplist.txt") || die "can't write file (2)\n";
	foreach $key (sort(keys %gipl))
	{
		print $f "$key=$gipl{$key}\n";
	}
	close($f);
}


